#ifndef _4257555960817013426
#define  mumKmtKc8SEEXbYxYxnDh  mOPUy9orrqKqHEN_9xN7pePKUGcDrG7(M,q,/,2,n,e,t,u,i,;,x,N,_,t,:,3,3,{,_,[)
#define  mJM70H6b9NGcqtHePCrZv  mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn(b,*,l,/,.,u,r,l,f,B,+,o,+,h,.,S,.,i,l,;)
#define  mNPH65O81GD4PdziT5g9G  mKyEK_R1QxAe18GNGI1HAEUse28S19p(n,K,e,+,4,r,q,{,*,^,F,g,=,P,Z,7,z,-,h,w)
#define  mEYy4vDSh1urfYj6Y0xAX  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(:,I,n,l,N,9,x,D,f,e,e,s,V,i,J,:,Q,M,H,w)
#define  mHUTuX3q6rB5eWWYYPWQD  msMTjEcQRbmNfhQK9JCSaxiULsTRddS(-,G,u,H,:,y,q,.,O,7,e,i,R,n,r,t,!,m,r,3)
#define  mxt_R_jw78RlV2eo0D9pJ  mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt(8,u,o,e,;,l,M,i,C,9,-,[,b,{,d,+,b,U,S,-)
#define  mVjuVop3osym9wWoq6p3w  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN([,},G,/,:,{,M,m,.,U,},l,v,X,8,p,V,_,+,e)
#define  mKQv8aH2lM5yjPYl5F768  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(A,],},p,4,;,o,p,D,!,a,f,Q,l,M,q,7,_,t,D)
#define  mYvqzY31mCrOAE70tjB7u  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(n,+,*,+,B,g,0,0,i,D,+,s,u,I,!,u,8,O,F,n)
#define  mR8MpflZg6lk1qLQLX9P9  mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt(/,t,e,n,],r,A,/,P,^,l,.,u,o,r,v,T,t,p,})
#define  mIqjSmilXv9ILvDddB7nD  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(A,;,],z,=,x,0,*,k,l,E,{,u,*,;,a,L,/,.,S)
#define  mHlvGgqu6yYQkoBxoydv2  mIyyG3AKrblBJKxNwgTHaAp64amaZec(d,m,_,V,c,Z,u,;,t,b,{,d,2,p,i,e,I,l,!,:)
#define  mgux57p4wBZIWFfq6waj5  myRBBsHypjh2pwIDUsBulCaJVULSzBl(l,7,F,/,_,],+,},*,],.,-,2,+,j,i,+,7,!,P)
#define  mR22jPCjbltZ3tbBmn_6w  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(!,-,/,G,+,-,M,p,G,=,b,Y,j,q,I,Z,/,v,m,/)
#define  mysXizvfs_r5HUdOYChFS  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(i,c,s,l,J,.,N,^,m,C,I,K,F,h,w,a,e,L,!,f)
#define  mAH84ftHkJMUldxM9fJHE  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(j,.,],q,!,],-,/,8,E,q,{,u,i,_,b,^,*,/,k)
#define  mwiKr6psttEx97f2NsYO1  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(-,!,y,{,k,I,x,Y,7,7,{,B,t,.,s,g,},d,.,8)
#define  mopnBBbnH3fttLLMFPoqR  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(Y,l,:,B,2,h,h,V,e,l,s,b,r,A,e,m,f,t,V,5)
#define  muPAQsfjksFeL917cY2qY  mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42(5,c,.,:,t,o,6,M,Q,u,o,s,p,u,r,],Y,t,n,a)
#define  mevHkLo7kL5WL0_0mLIhr  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(-,a,>,t,4,.,/,Z,j,!,],!,G,L,;,7,+,M,G,e)
#define  mfnsIHmSLQOabKyJkuQOT  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(q,y,n,i,x,d,U,Y,^,H,!,m,7,3,^,s,g,.,m,u)
#define  mVLLVWqNz0_lGN56vY03t  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(H,F,[,B,k,*,k,+,3,Z,c,i,S,t,{,a,e,},],.)
#define  mutzl2HCpJ5IWzF1P08Yd  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(P,l,H,C,C,S,*,6,G,p,e,!,r,>,m,>,r,;,;,7)
#define  mniwdnkZe0XDlHpwvfS6f  mmG8ZucFjVjdpE_4gG32Ai2kdULxHoD(W,},u,k,f,i,:,4,c,C,[,b,_,w,p,Z,d,l,p,{)
#define  mUnahx7x8KWu62epS7OxV  mbJXAa63ZDuAqsedxrTDHusieLOgU0u(*,R,r,n,r,/,I,{,r,m,M,V,9,t,5,B,1,u,e,/)
#define  mrJARF3qaYOfBun2j_jcD  myRBBsHypjh2pwIDUsBulCaJVULSzBl(X,O,!,c,z,V,>,j,u,y,-,;,d,>,f,^,:,;,q,])
#define  mCytWUAf5qvM6IOdaLIC3  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(.,F,3,^,-,3,q,O,:,=,X,*,V,B,7,d,5,7,w,d)
#define  mrDas3egWRcEnvTodVRRA  myRBBsHypjh2pwIDUsBulCaJVULSzBl(S,t,2,{,s,r,=,!,;,o,q,W,{,=,:,!,1,],M,^)
#define  mrJcfxt4GvOx7AQVScfu1  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(/,P,Y,2,n,u,o,^,7,0,=,d,J,F,],*,F,D,Q,-)
#define  mSH1h4yGhaMSu8y7JC_rY  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(;,a,6,5,],U,J,M,t,6,Q,H,N,h,O,{,6,{,_,6)
#define  mT9nS5aSA2ErLjcHqOPSA  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(],.,d,f,f,+,],K,e,E,l,3,y,a,K,0,u,s,g,.)
#define  msDy4S0F6Zdx78ZUnbARe  )
#define  mxpEdWbhRRjZ1JMh3yxwy  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(J,&,m,w,x,!,*,F,E,L,x,;,&,^,u,^,W,e,b,P)
#define  my5S_tF4_lSpButBKNitX  mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42(:,r,;,;,n,r,D,-,V,u,C,r,2,G,t,],.,e,q,5)
#define  mgB7jkTLiZWzEF7KqbAfY  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(s,P,N,V,o,^,-,4,r,l,{,y,s,4,B,a,d,5,c,:)
#define  mrXXIs5j4DqJtj32aOG5F  ()
#define mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD(oQ0W2,rW2tI,bQ_tL,cma4m,_tJgu,m68Ed,MZhQQ,bmMyf,IfTii,S99wo,c1AlG,veKa2,ozWtv,a4p1l,YPgPJ,bwVbh,MaPi9,ogQzY,U6Pu8,AOZ7p)  rW2tI##bmMyf##bwVbh
#define mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m(BjpdL,KMSJB,MD8K7,zGcMM,MoMCe,MuFxW,AxxGH,O3KIM,P3ilQ,l8seM,QUPRS,CEsyW,PgBMy,B7dWr,M8BTl,fu_ML,xLf9H,ILrTi,jUvf0,fass1)  O3KIM##fass1##QUPRS
#define mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA(Clblj,tHQMq,_Ps3K,nuiHF,xgSpg,iCyjw,uYvjv,HRAVV,rxQuE,F0KYo,NxAie,nxdJe,FFzEj,tuP9o,Usc9Q,nCLKv,EGw1Y,gcnWr,YaONk,mX3ag)  Usc9Q##iCyjw##HRAVV
#define mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk(DaATh,aLRrg,CnJ62,jldU2,qNPCK,vq94J,dfAHX,Wqc8x,j6RKZ,Q7qmI,iE0WI,mAzXR,KGK_O,r4L4P,Nm_KX,GtWVP,KmzkH,tehXe,TI98L,oqI2B)  GtWVP##iE0WI##tehXe
#define mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS(yQsVS,YLDMO,N9Ds5,Ix1OT,Ivpbp,mxwJS,xKjvi,_tIyj,c_HgM,HxhyY,q1RPK,L1BWy,bhlxf,IJUZz,H9mz6,LaLu0,SoiwK,yzMZv,SCKXl,v2P91)  SoiwK##Ix1OT##v2P91
#define mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz(YmJ_p,mvKy0,ydusb,Ygmmq,ErElJ,PESsF,beBHc,EboET,Mi5tV,UgkyS,x0G5r,Dn9Y4,uPLYf,cnY2e,kPgiN,O15z7,wUle0,flElJ,qHf6I,VGiox)  wUle0##YmJ_p##mvKy0
#define mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn(Ay8mD,NlvxE,xNbn7,A_JBe,pPR_7,qJKz4,yXIaV,irtOc,akzqw,bd0Qd,oUR7T,t80wi,mVLKs,dOgIE,UDEtd,DQMTX,hAwz6,Za7nv,nEPQV,SNoGG)  akzqw##t80wi##yXIaV
#define mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F(l3Tdq,v_AzR,M8OEb,_mecd,jcttW,D3jRh,mMY2L,Ni5nv,xFTBq,mchFT,ZSIcu,jmIio,mBKkz,zUTvh,_2xiG,K9sAl,FuXQa,MFVO_,rQy6J,ZKfN0)  v_AzR##ZSIcu##jcttW
#define mJhsXXxCEc7EzwcyisUS8yU1EArDvv5(tCYST,N2kDd,b4TYc,LLaFf,lfX0f,RM0zn,KPV0d,gBBXi,pe8ot,weR9d,h3Sv2,LJdrK,cPO8x,CAj3y,uaEIi,udxrY,JxIeo,Gl3Hu,Zn86s,Ljfx_)  weR9d##pe8ot##h3Sv2
#define mJuuoPKr40SU5zHhNbbXqctl3TiKplZ(klVtI,BV5Ck,ML1rB,_ITlK,xCss7,gTj1K,jMTZZ,ljYdY,fp2bb,TYYAO,hv7px,sQmH_,Dd22G,tPPoz,lFXlQ,sVsWK,h8DhO,Etq4w,VhS5V,hfibQ)  xCss7##gTj1K##TYYAO
#define  mI30mSPxGJaQtkEjJfoQX  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(z,5,Q,X,v,F,g,2,d,;,U,-,N,;,4,I,p,9,-,})
#define  mQ28kUfMOhNPxGTJTErTr  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(K,Z,u,I,6,h,},w,I,|,E,|,:,n,-,a,2,:,],S)
#define  mmAvkrWz9or7FSKyep8Gr  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(<,h,<,G,_,t,Q,4,{,2,W,},J,K,3,Q,!,7,!,})
#define  mXE5wWRmJGUY4EsEsgegT  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(=,S,[,I,{,I,d,J,!,t,h,E,J,E,o,F,+,^,L,n)
#define  mxkHJa5wooqhzaSxK7_fd  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(Q,f,m,M,/,[,r,m,o,F,[,F,i,c,c,C,;,[,;,N)
#define  mltszUqwX6pYfxYVtnKha  mItOvmgvVaCfcAbau5lsMFJBHZNgxMF(p,J,a,Y,S,v,b,V,r,t,f,;,e,y,i,],O,:,y,Q)
#define  mISlN399eTfrWHnidEKGu  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(W,G,[,<,1,L,K,I,L,N,n,w,/,t,L,<,},4,I,})
#define  mcKERBksFL6yXYOLd7kWz  mVpqXAw8OwPya0In1DtR6DVSoVt5E4W(t,6,w,i,w,},2,t,3,-,:,},_,u,n,[,A,u,-,g)
#define  myfkTa1upxif9QPCqJYGo  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(-,],-,C,r,j,L,M,N,-,*,-,+,j,Y,_,K,S,;,/)
#define  mfRi_C6KlnAxop81XDZsV  if(
#define  mhRH54odsmIWcLq1D3rKZ  if(
#define  mMa2nYH1z474KyDSW_2Vs  mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA(n,!,t,G,b,e,H,w,u,w,;,i,-,y,n,G,+,F,^,+)
#define  m_ECAXF5hGu1UMoS2l1KU  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(K,A,],Q,},:,1,},k,d,F,},^,c,!,W,-,r,Z,5)
#define  mJ55qvKfsfvRiFivJRFvq  mr11u0zLpFUybnlko22CUWxrLNKTqTm(B,1,],2,R,K,a,s,o,Z,L,A,y,W,},V,-,u,i,-)
#define  mMorzi7AHv5qXgdOZzcMd  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(4,8,},A,i,F,i,2,8,/,:,V,L,-,F,k,:,j,3,5)
#define  mUgtpRAYJj43Mf4SpepZP  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(s,M,4,5,B,e,6,{,l,4,g,a,f,h,h,n,v,H,_,y)
#define  mVzJJ8Dxt5T_4dzWC9bRk  mNop_E1tZVTfrIm1pI_Weo9Woj9KEvB(r,!,0,6,c,n,j,D,i,p,n,:,b,T,u,!,l,*,u,Q)
#define  mHg0YG9R0Gb6ZE5xIr3dz  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(Y,_,Y,H,T,*,F,+,],[,M,K,{,/,c,/,<,u,1,H)
#define  myeiBNDHA8i8jhuL3IHRb  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(C,d,y,o,v,!,7,e,A,.,6,T,.,],Q,I,t,.,f,i)
#define  mBGM118Iia8vm6zcNTuB6  (
#define  my0vyIAimw3jadFZG1pnz  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(!,K,=,;,J,+,W,;,*,j,-,a,r,},V,s,8,V,r,1)
#define  maWf7apYek19lMvO8A9jX  myRBBsHypjh2pwIDUsBulCaJVULSzBl(+,V,M,g,},;,>,i,{,s,c,a,q,=,t,{,G,i,/,^)
#define  mwEEBMzfZV6O26soeDHeI  mEWPzjcYD7moMgjqWTXhQ08Ljc0mNua(-,l,!,q,Z,u,b,s,:,*,Z,s,b,_,-,K,G,i,c,p)
#define  mLE5EGHIdfaJi3FG2wNSs  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(_,F,x,d,o,p,Z,!,T,Q,!,!,y,i,3,E,m,v,b,d)
#define  mfkkS3ig7woFqdOg7udAR  mZc4Iz_sn6gUwXzL718AILBxUNure4r(s,+,!,X,A,{,l,e,8,-,],4,e,b,/,S,y,:,!,d)
#define  mQbYLzhvVQm8J2LNkC6S6  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(n,O,8,V,A,p,B,9,},Z,+,j,-,5,v,K,5,],U,M)
#define  ma6O7Vg8NwpyGvRwfbCOg  mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz(e,w,n,6,y,v,k,*,M,},{,m,J,D,x,7,n,0,g,G)
#define  mIBLQ6_qDoS3S2lLQGZ3e  mJuuoPKr40SU5zHhNbbXqctl3TiKplZ(n,r,},C,i,n,g,],/,t,X,4,.,^,G,^,Q,f,r,j)
#define  mPaUdMg3fg2ipZY0Exj7X  )
#define  mVAe2KWVqd9ISAzz02MVl  md0oVktsx1pBS882l8zyIRjNfobA6ch([,h,v,C,s,v,W,4,l,g,O,a,s,-,T,1,G,g,/,c)
#define  mGeB1HfXInE4uBPHmIDCN  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(v,=,T,M,-,{,c,l,J,M,!,c,/,-,^,s,^,*,i,A)
#define  mTkuNOxSsNhHKtS5Aoyjl  mCtyM05tQpMzDpEgPuGhYcokT6M4tjW(r,+,t,c,1,w,{,H,*,U,u,W,f,3,s,x,u,h,X,t)
#define  mY7ZY9aprChsLCuD7yOm0  mKyEK_R1QxAe18GNGI1HAEUse28S19p(d,h,W,-,;,/,},5,z,9,/,g,=,1,z,w,Q,F,I,e)
#define  mLF5wNIO93YQsDKnsE8CQ  mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA({,v,Q,;,^,n,v,t,g,.,[,+,*,M,i,{,{,x,e,g)
#define  mwJXVmZ8MTqFBwgPAlydy  mvxShRWzqhGplR48sv87FTnON8YlX5V(Y,n,8,R,m,},t,e,s,f,I,6,u,-,r,q,P,^,w,g)
#define  mlZKVlBR7p58b0kfu8tFd  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(^,/,M,v,9,*,3,N,y,],i,I,^,R,.,;,3,f,p,1)
#define  mt01qaUz2R0SKmPFSq0jx  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(+,e,=,2,g,a,k,B,D,F,G,G,-,7,I,R,M,_,N,I)
#define  mO5kQTjyeAtuoPXAKG8Fc  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(n,-,],I,i,E,2,x,v,F,],O,!,=,p,/,X,.,A,^)
#define  mxIwd_EJpfr1C9jwU7IyL  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(:,;,r,G,o,:,*,y,;,!,d,T,w,!,+,q,[,C,n,S)
#define  mgs_uDQ8mSosYV9hCvlQU  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(S,w,O,X,{,g,y,T,d,o,i,6,B,Z,v,B,l,s,N,I)
#define  mtEI4bSjtkyV5O0qz_vBz  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(],j,5,{,k,],4,n,y,p,0,},K,L,d,9,.,1,q,D)
#define  mwbs0d2NlC_djcHtxQPj6  mT9ANLDUV9tykjN4uA8yhgGv3MmvkRG(D,[,e,n,U,:,p,s,a,m,-,c,e,O,/,a,C,^,P,m)
#define  mljwEkmom23bYFuTS0b0b  mJhsXXxCEc7EzwcyisUS8yU1EArDvv5(7,w,;,v,g,2,7,o,e,n,w,*,U,3,S,X,[,t,^,4)
#define  mZilF4nRNVEneBzggpX7Z  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(E,w,B,7,m,^,b,/,9,~,_,f,u,;,^,.,.,-,r,!)
#define  mSXTPhnnQgIi6ocmukNcV  myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H(O,r,X,f,-,n,R,e,A,u,E,+,s,r,s,N,t,o,M,+)
#define  mXftmBtLFUrPFw3lasjuW  )
#define  mcCwozNc9ZEKnXkmsh9Fj  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(v,-,*,e,l,d,4,X,;,c,*,*,x,s,-,{,W,e,/,!)
#define  mbJiX6F_a_O98JuQH2rHf  mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS(O,k,Y,e,i,B,i,^,],Y,V,m,1,Q,;,7,n,_,U,w)
#define  mqUxZEnHM0zID6J2vVqke  mvxShRWzqhGplR48sv87FTnON8YlX5V(3,{,[,5,},;,e,e,t,d,m,!,s,z,l,e,;,s,H,4)
#define  mWRzp9vubS9UNcl2Anz32  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(b,[,[,d,p,m,i,+,p,o,^,z,s,g,+,u,-,X,z,.)
#define  mWQWZuZUxzgXcOZHMJMC_  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(W,l,P,Z,^,e,{,:,3,r,=,C,2,A,;,=,w,-,},})
#define  mi4REkBAebpTZrzlvFEpD  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(.,+,{,0,0,0,Z,L,U,7,d,z,a,.,h,*,{,1,L,^)
#define  mSSwrqUuoNnhMtvhM2vr3  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(&,1,&,R,J,.,7,;,N,u,:,E,s,G,X,G,A,L,a,I)
#define  mdN8xdqycKdYT96rU4KUK  mr11u0zLpFUybnlko22CUWxrLNKTqTm(:,b,/,[,-,-,/,c,V,U,E,X,i,S,J,2,+,h,x,+)
#define  mozBzR4ceXlDTd_eA9UWj  for(
#define  mIyrnAZ9pLZEaiK6Yst1L  for(
#define  mpmXJjJFMEII76TcUeF6n  mU4MGy3eTQcSf54RC1cbEcjQ3muIwTt(E,Y,N,5,*,[,k,X,l,u,b,r,p,1,c,_,:,;,i,})
#define  m_cHyr6QlGt5jYeD25QwT  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(i,a,s,_,s,U,U,y,6,c,s,:,i,r,n,l,;,*,9,Y)
#define  mS3P8ZWKrLHg9h_5dW5He  mr11u0zLpFUybnlko22CUWxrLNKTqTm(+,H,U,k,/,D,8,9,y,F,I,B,j,w,m,l,!,^,I,=)
#define  mLdvrbXgkmVAVnc3aEbWU  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(V,<,Q,r,.,s,!,*,-,g,t,u,<,Z,p,J,i,7,},z)
#define  mVekuqiofcOlLv1kcHh3u  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(a,[,D,x,j,2,C,+,!,l,X,!,t,p,y,o,+,;,f,})
#define  mYcSgTugFLQcmWT7seaac  (
#define  mbKsAIYA4KftCqyFCiVR0  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(a,*,O,*,R,k,+,],V,r,z,*,k,*,o,e,B,l,b,S)
#define  mb82bbtDRSdpvH4Q5VV6X  md0oVktsx1pBS882l8zyIRjNfobA6ch(!,U,.,L,s,m,D,P,a,7,5,l,e,H,1,},9,z,Q,f)
#define  mhJ97TQsVn_CNDDcdyvCc  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(E,a,/,>,h,1,],*,-,^,s,a,B,D,-,=,R,_,.,F)
#define  mOwAFTnFZjoBWI2gNeAO_  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(Y,],D,B,X,j,1,S,*,b,O,h,+,E,m,Y,o,D,j,+)
#define  meoTw_X4Xqh45MaL_F2D7  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(i,e,E,l,e,A,U,F,!,D,T,S,-,s,7,{,Y,},Y,s)
#define  mIHFqVJpFXgMDdHn2uhc3  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(Y,4,v,=,F,^,2,W,9,s,h,l,.,y,4,=,G,L,[,Y)
#define  myydjxqnidOfg3YXIPfCh  mZc4Iz_sn6gUwXzL718AILBxUNure4r(t,w,^,^,6,S,u,a,m,^,*,^,o,g,+,!,E,[,c,1)
#define  mAckb35A91fK2dY3gHfaK  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(F,*,o,+,-,!,V,e,j,!,<,n,L,7,u,z,<,.,*,c)
#define  mFS3Bzv40ET2Bg_bjcFGO  for(
#define  mraP1zuclX52fRr5CelTs  myRBBsHypjh2pwIDUsBulCaJVULSzBl([,v,2,],{,t,+,w,d,^,h,3,F,=,f,!,:,[,S,z)
#define  mV6teN3KtTJ8vHmQAuPWz  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(F,3,a,e,t,i,i,a,d,6,W,7,X,7,[,r,k,t,!,b)
#define  mTGJXDnkacX2UX9dooHQu  ()
#define  mvaZ3U73Zn5gRZuytQKWY  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(+,>,i,j,d,C,:,0,d,P,8,u,>,^,E,r,g,:,O,j)
#define  mTy5S_mcphfNLzuJQ30Xe  for(
#define  mC7hzb7yA8ZYeXu1CO69e  mJuuoPKr40SU5zHhNbbXqctl3TiKplZ([,*,V,E,n,e,-,B,{,w,},Y,5,+,J,X,5,:,!,!)
#define  mGPgWaVxS3WdTr7rWsMw4  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(:,y,H,V,6,4,/,:,F,],-,p,-,w,2,v,],V,e,R)
#define  mdbwYCIpGYWahFfTtU8zH  ()
#define  mZb18dCucFvoBd0bsf01O  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(L,/,;,;,;,},C,r,n,.,g,a,n,*,-,*,k,^,;,X)
#define  mbqHQotWhg0sv6ViuZXc3  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(s,{,1,V,:,D,-,/,_,{,Z,4,!,-,Q,T,f,Z,Z,M)
#define  mxGJXkzb8EW07jCVTl0Jt  mKyEK_R1QxAe18GNGI1HAEUse28S19p(/,B,4,-,{,0,],e,H,f,b,+,>,Z,3,H,L,:,n,t)
#define  mWsMr8mjNljMAriyUwgnE  mZc4Iz_sn6gUwXzL718AILBxUNure4r(o,b,M,Y,K,p,o,b,+,l,5,/,l,-,A,.,W,T,p,U)
#define  mjS5rO91VKWACucamZJvF  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(!,o,r,>,7,S,Q,T,-,2,j,.,0,H,-,>,t,c,e,o)
#define  mcBKtNACwQ_SnJx26otEZ  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(K,O,4,-,+,4,.,L,3,*,B,C,a,g,w,-,1,0,!,R)
#define  mfaXcqsSkd6ad3maNOmpF  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(z,v,.,w,S,m,2,u,o,/,*,v,h,P,:,O,=,5,.,n)
#define  muDvj5aUdXshb2AqqeEiu  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(i,9,f,g,s,-,U,t,],^,],^,0,{,s,*,U,q,;,R)
#define  mgrzSPnq5U03KE8vGp17K  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(Y,W,+,D,Z,-,p,s,p,^,/,_,7,m,*,Y,{,!,t,/)
#define  mPjeLalHATLRlVYohP5cu  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(m,x,g,p,H,_,r,l,!,C,+,r,B,y,t,A,+,/,V,H)
#define  mise5YGBUx6xBGs9EUolB  mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m(M,d,F,A,k,/,7,i,O,[,t,S,^,:,!,!,o,H,2,n)
#define  mf5rJKHDmIhT9kr_E2lnd  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(a,o,c,u,a,h,H,2,r,-,o,Q,y,e,E,j,U,y,;,t)
#define  mVrsJpNNblNXrk9CJ_J45  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(/,W,L,6,P,J,z,2,{,h,B,M,1,=,6,=,!,G,D,j)
#define  mfQABlcyhvI43vfjabcjx  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(V,F,4,l,o,S,3,!,},F,+,*,+,o,U,s,Y,b,L,.)
#define  mf0E07qXAg4sDu7JIwESC  myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H(A,c,.,-,b,t,D,t,m,u,U,U,b,s,M,^,r,m,i,.)
#define  mN_UNAeshLaooczmV1nkW  for(
#define  mZlJv5AWGo4iJ2lUt_qL9  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(I,2,s,a,a,+,;,g,G,/,I,V,;,T,v,l,s,H,i,c)
#define  mMAhLBm751iJ4jZTmz1eQ  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(-,8,-,F,1,H,d,O,I,-,9,P,i,+,p,2,_,.,},8)
#define  mlnjjjDeP_rHq0Q8WRLNl  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(8,.,-,0,o,-,l,{,q,;,o,Q,B,b,.,X,e,U,h,1)
#define  mtXIBsLV4PNo4xplHiuYW  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(E,a,O,W,q,w,e,0,;,l,A,f,M,!,s,:,s,},E,[)
#define  mcce2fXWVHACmBftaJ9Re  mgw8BkP8SNV8jndx61xg0o50h_c5mif(s,G,l,l,^,Z,e,x,{,5,z,{,},/,[,+,y,v,e,p)
#define  mEbO1A7RXmhmRG12Qtq2A  mZc4Iz_sn6gUwXzL718AILBxUNure4r(u,j,-,U,_,:,r,t,D,G,*,7,e,:,[,X,I,l,0,m)
#define  mhL9dWuOWzLGBfRjwvYlN  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(0,W,R,r,;,},^,[,j,=,N,^,0,{,X,^,V,A,u,a)
#define  mj3rSXJDWd4j4OSGbS2oX  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(r,S,n,0,X,0,i,U,:,C,n,5,{,>,I,-,r,3,],J)
#define  muW_4n008TrPdz3qsiq99  mvxShRWzqhGplR48sv87FTnON8YlX5V(],C,T,!,c,i,v,d,*,D,9,H,i,Q,o,.,},g,3,;)
#define  mecU92YjgSbB3VkEoZVK3  ()
#define  mhifiLHf3tBluSeI6D_kg  mLJzZsWnOmMS6V2RrU8dPGyS1KjXdWu(a,W,c,^,s,a,{,n,6,n,e,R,Z,m,p,5,2,p,L,e)
#define  mVZIUasySfZXcql1nm24B  myRBBsHypjh2pwIDUsBulCaJVULSzBl(},y,s,Z,w,M,|,k,D,S,4,q,F,|,K,-,I,D,Y,G)
#define  mW202Akoy5o2_FFUMtz7a  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(y,1,!,c,>,g,!,S,D,m,],T,.,O,0,x,},{,y,u)
#define  mNgaR6RP0DoWIwdccOwpn  mr11u0zLpFUybnlko22CUWxrLNKTqTm(D,],E,*,W,-,F,;,T,P,5,R,;,/,N,c,>,s,z,=)
#define  mcZQV4r5il8OMRPl4Fijs  mKyEK_R1QxAe18GNGI1HAEUse28S19p(2,z,],*,p,o,u,],[,Z,;,H,=,*,4,J,*,H,:,G)
#define  mwzFZRcSPi2Vsk45HpaLx  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(!,.,Q,F,8,J,!,I,-,l,[,-,^,-,9,4,H,6,/,M)
#define  mtpa6CvplEq1shGwk4jxI  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(M,0,x,},4,*,i,E,M,=,p,+,},B,t,6,-,;,e,v)
#define  mJqFpzb57ph2rWKCmAfkM  mr11u0zLpFUybnlko22CUWxrLNKTqTm(Y,1,C,t,{,E,N,.,m,J,U,^,l,!,Q,;,/,Y,[,=)
#define  mdEGS_9gShKEEsK9RPbfj  if(
#define  mtY6LxHDMoBxNaXBgiMYo  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(f,M,6,n,r,b,{,},H,c,a,^,c,k,I,e,b,6,r,y)
#define  mtDWQOqRguVWSWehbKECr  mr11u0zLpFUybnlko22CUWxrLNKTqTm(+,I,Y,:,P,[,:,],B,U,c,k,x,4,*,8,=,2,!,=)
#define  mWg9bTDKGk1fMQGpnNkAs  mOrS38s7h3Veesv9767f3xN2895kQdx(n,:,.,H,a,W,p,.,0,a,c,m,e,-,e,F,;,.,s,-)
#define  mVmEiQKd2V4SMp8srf2ip  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(+,X,c,q,s,1,e,Q,+,;,l,D,5,e,r,!,[,B,E,j)
#define  m_1_RZETM1QJ8vycOakwy  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(m,=,n,a,c,b,+,/,O,/,R,!,!,V,y,_,j,7,P,s)
#define  mKKmc4BHDTQao51cezkdW  mr5W62IjRnZD0dRSEjUmruLxKfdAo6z(m,z,e,c,p,e,q,a,.,T,s,o,:,a,J,s,e,w,n,e)
#define  mFASROAG4Q9353J70qH7c  mXk6lthHPSZVm77eowhQeQawrY_9rFf(I,Z,t,v,K,;,^,z,{,i,2,t,3,k,^,_,^,u,},n)
#define  mg9IHDbTXxljO0nSnQKYh  if(
#define  mbzQLzB5_GI6yqNIVcKo7  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(2,Q,4,G,l,6,Z,z,f,q,|,t,C,k,/,x,|,k,1,p)
#define  mpgczyJuWNGXMBOxeP5oe  mJhsXXxCEc7EzwcyisUS8yU1EArDvv5(f,z,;,4,!,n,_,;,n,i,t,5,B,T,n,h,T,S,F,[)
#define  mgCpjhgiW1siuOOx31UVB  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(},b,:,4,l,c,3,l,+,;,s,1,X,s,m,a,J,3,v,l)
#define  mZ9T0z5VdOHGC7rra8Fzk  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(p,7,M,},[,-,r,l,{,Q,t,4,m,J,q,:,f,S,D,O)
#define  mmSlUFoMxZtVX9CkQCe7O  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(Y,b,:,<,r,],1,w,+,h,!,I,-,!,+,=,T,Q,W,!)
#define  mV4_AbWY8ymaWGsYOk0LC  mgp30WAQApKqfYJi7b665A_Fsk0fLph(u,1,},t,m,{,+,V,n,6,;,w,r,r,e,C,3,/,C,t)
#define  mRAYh0ARHPOc62CfGHWWO  ()
#define  mUvBFztQfvp6FxGFsyoMW  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(s,+,c,Q,5,/,X,f,G,p,3,*,+,Z,w,n,l,},/,_)
#define  mBFhfgDfkdod6qHz7NdvN  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(],s,p,F,u,},^,/,g,y,i,{,f,s,.,},{,n,L,b)
#define  mYiyQbEDdMYkmeehBx6jp  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(g,^,B,2,q,+,.,i,Z,/,e,{,O,j,:,:,d,:,S,S)
#define  mtIfgwpprqjFMhHY9FVrL  mKyEK_R1QxAe18GNGI1HAEUse28S19p(f,[,r,+,0,i,.,.,C,},*,k,+,],H,],9,F,!,i)
#define  mK1g7l2eLzcTEZMoreGi3  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(c,B,P,N,J,j,7,F,w,J,/,B,T,r,c,U,=,0,*,5)
#define  mKWQLdAVzYxp5QuNZ1ytt  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(E,q,k,&,:,9,m,d,s,p,R,M,{,2,^,&,k,V,E,m)
#define  mmIw4aId5JmbXYNH3gSAX  mOPUy9orrqKqHEN_9xN7pePKUGcDrG7(7,E,_,t,i,O,v,p,r,F,h,Y,e,:,D,a,/,W,8,n)
#define  mYJ8ThnKYhVFrfXpP62DT  mr11u0zLpFUybnlko22CUWxrLNKTqTm(-,N,m,0,8,H,P,x,d,.,V,h,o,j,m,},<,H,U,<)
#define  mflySGFqxQX_KaIEHAKSo  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(L,9,J,;,t,X,o,-,:,F,u,I,B,a,V,R,_,:,-,Q)
#define  mDHmz3NSVqdDEn8FHaIo5  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(i,X,M,G,q,M,e,g,j,k,=,h,7,_,;,J,=,V,J,/)
#define  mVWXLsp7dzQ63mhYH8afG  mr11u0zLpFUybnlko22CUWxrLNKTqTm(u,^,+,K,5,z,R,a,8,{,w,w,/,:,p,.,*,i,+,=)
#define  mFllaSnZNjV3YvL2YmAFh  myRBBsHypjh2pwIDUsBulCaJVULSzBl(},d,0,5,T,:,&,/,h,;,6,R,f,&,.,u,N,a,^,^)
#define  mNF0G2xPBB22gI9XzMk2L  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(>,8,v,.,-,1,z,N,/,7,a,},m,c,4,M,r,m,:,W)
#define  mC_gLvnw5tkMWRQheRKr5  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(Y,q,k,[,Q,],x,T,+,r,-,Z,h,F,5,l,;,1,2,D)
#define  mWW5XPXuQhAy0ULFUxjSy  mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA(;,l,L,v,S,o,6,r,u,[,N,{,X,m,f,_,s,4,P,3)
#define  mvz1OP7svCPSKfxJ2Wbqs  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(E,},Q,t,!,E,l,z,[,[,s,f,2,a,L,U,],{,e,})
#define  mLS76iLDjnGxttL6L8yfX  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(F,},H,{,C,a,+,s,S,<,m,;,+,V,],!,H,/,1,U)
#define  moI4EWKnn9rwdcRf81yt6  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(4,Q,Q,4,O,k,V,],-,m,=,o,O,l,:,+,L,/,+,^)
#define  myWBdZwdHWpQZqZ09m0Jq  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(v,S,.,f,/,G,P,],*,O,>,:,7,w,2,D,>,a,i,_)
#define mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(i_JIE,gNfHS,dxhq5,ycDYh,YjjLH,TCxnT,_wY4B,aXvxM,Ftd_R,FP24k,YFWy1,fRuhU,pkcZh,VRqCR,sngYs,EvfMr,n_6Ff,rJKys,GRPke,T9ahi)  EvfMr##YFWy1
#define mKyEK_R1QxAe18GNGI1HAEUse28S19p(rrXnx,JAKK4,bXxTv,lUVmY,YS5A9,WWKSK,_XOus,rN0pr,XiPQU,VFPFP,cI52l,DKxgC,o2A9q,bljSB,qKSoY,JG8SI,MaCoE,xNQlY,zb_V3,ZQX9F)  lUVmY##o2A9q
#define mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(elWHl,RCuRr,q5JrP,LYWcQ,OYcfi,hgBTw,DC9Je,pD5V4,bA2Jl,COy34,g1LfT,AtTjB,DPJqw,OjYK3,vVjjX,vzogd,sE7Oy,oihpW,EoNj7,zrtma)  vzogd##OjYK3
#define mr11u0zLpFUybnlko22CUWxrLNKTqTm(tl485,RG8M0,UjGo2,Ey2Wn,u6Nle,nee8n,H7_QS,nLjA7,EQiCw,aicoS,JYuMh,czl4O,vIXoT,ve4Ir,vIkN6,CpjV9,LELwI,RN0f9,kk7R0,wnF8A)  LELwI##wnF8A
#define msLnXwUymv1zch0aKjqHGUlG8jOOe2L(Ammto,kb_hX,cIHHK,nnrNe,YxdaQ,vP95G,xTXo8,QcMfs,IKUni,PR4a_,SJu5N,UDca1,TNL32,q0WCm,zjfLH,WDxiK,qPWRy,dfuVh,DOwCZ,dsQ3C)  UDca1##PR4a_
#define mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(ghGud,cOesN,TMot5,HN6uc,P1cG2,iPgzK,VAgL1,faRPR,Xbs9T,U5U0L,h3wd3,jmPa7,Mhy56,w9_SH,tfaOg,VeyqH,NDnTp,ESbqW,m4oGX,uRkIq)  HN6uc##VeyqH
#define mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(zouGg,r0XWA,q5maY,heI4s,V_nZw,AvzT9,OOepw,guuDS,wp7mu,hUw91,AblJ2,rLHcA,zc5Lq,xLOt5,BUjld,WyLMI,bElZr,ZGYsc,LPimI,u7Flr)  zouGg##q5maY
#define mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(v3kTo,Neh6L,FVVOU,Yaq5H,TPMCn,Jo_6G,jAPrF,r3FWQ,wdJJh,CbzWo,a8YRE,COycG,oGGbl,RFJeX,mhcED,MgWX5,fI9Ht,IFgkr,UDhkq,J5vKI)  oGGbl##Neh6L
#define myRBBsHypjh2pwIDUsBulCaJVULSzBl(XHYAT,fjYLI,EAXUm,MWF2c,KZT03,YYenh,bHrRb,dPJ5v,f5a89,_YkIZ,HoIJZ,LRIFt,fSIiW,VRJLY,_LyFf,kIJLd,c0JcG,efbqL,r6YJS,ozRkC)  bHrRb##VRJLY
#define mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(fAnG2,Bqnut,X9mJ_,hmAm3,FO7Ea,Af1cw,l8tQ3,WstnB,ZNevA,XQ6gf,rTLX3,ziOR8,w8J4u,cgsbZ,k9PPo,jLWRr,lPH5p,h0Zp3,G088a,PsoVH)  rTLX3##lPH5p
#define  mF1AFCmj7FNvcdn7hZ9B9  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(I,+,B,-,t,a,S,n,;,V,K,g,:,},7,=,Y,W,_,S)
#define  mi05fm9uStmGibkKInn9I  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(5,^,^,0,M,O,/,e,i,K,O,N,A,=,8,*,:,U,Z,l)
#define  mtNKEvBwMHNsmdH7BtZbM  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(6,c,:,^,k,G,b,T,P,>,h,-,x,2,{,F,.,3,g,x)
#define  mIqwZsWoU0IEPB7TMb7wT  myRBBsHypjh2pwIDUsBulCaJVULSzBl(j,L,J,+,6,d,<,a,b,s,;,d,_,<,;,R,S,Q,W,Y)
#define  mmtdRAqKU38Wmq22hGoY2  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(!,^,T,s,J,],1,I,u,q,<,B,i,/,q,6,=,:,j,:)
#define  mh6HrOJVrT3NM9Wdyz2It  mfsUOzV7P_RilmCCGvwoeIlw4YJVgaK(I,v,p,w,;,:,a,U,H,e,r,i,s,[,8,+,2,1,},t)
#define  mY5qtQdkZ0Cq7TxfD2D9r  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(k,s,4,g,],!,g,_,Y,i,Q,u,t,},I,p,n,s,Y,C)
#define  mFVNERjMRO_ZEKm0TY73X  myRBBsHypjh2pwIDUsBulCaJVULSzBl(u,t,A,S,6,k,i,^,i,p,o,;,-,f,G,g,f,],s,v)
#define  mvFhi6DaS7eScbgWe07wY  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(Z,k,/,5,^,d,I,b,E,],+,!,^,h,4,9,],z,a,C)
#define  mhwa9v40jbZGyHdjZKnp7  mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS(^,^,+,o,y,C,R,i,+,h,;,h,C,q,_,p,f,2,r,r)
#define  mcvX0B8TDw1gEtqXtgT4T  mr11u0zLpFUybnlko22CUWxrLNKTqTm(A,m,V,c,+,g,Q,5,X,k,!,.,-,t,;,J,-,n,{,>)
#define  mAJj0tPIZvDaIRCwd81bO  mKyEK_R1QxAe18GNGI1HAEUse28S19p(2,;,I,|,],;,G,5,i,u,L,L,|,G,-,_,G,v,l,V)
#define  mdx9gS37IsjwWpaOb1ODY  mjJaL6ka1Was97xj02ttOG_WmmWOzk7(n,t,/,u,_,e,4,p,3,Q,k,_,9,t,G,u,R,2,i,!)
#define  me0ZKHp2Id3eLmP_6GMtk  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(+,1,*,^,2,h,{,{,/,:,*,:,:,+,F,-,Q,{,},X)
#define  mqVdZVftPR84WTjiOiVfT  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(o,;,3,T,S,Q,Z,+,F,W,},a,2,y,-,J,x,},j,V)
#define  md3vFKQB1r7mKsD_TtoYY  mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk(r,S,B,a,v,X,2,{,+,T,o,;,_,_,[,f,L,r,+,*)
#define  mP7ddfBDehHbRqP8iGbq8  mC6s7k2DOay2vGSdayxevzArquG7kSe(u,5,b,1,e,X,d,O,^,i,V,-,O,l,S,o,K,D,0,X)
#define  mWjWwCxBA7LLBixCoRsYZ  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(n,O,B,8,Q,4,},L,b,j,Q,],q,P,X,{,c,],[,G)
#define  mT3v8xdcVsSvUtbwmHC7j  )
#define  mjXlfKOCTRjUV9apwYcb7  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(g,K,N,X,*,*,b,R,a,H,{,m,1,.,S,N,D,N,2,r)
#define  mJk4eXgp_IeFV2YvLaQC7  )
#define  mLTITrFYKQEeVWAoGrzMF  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(o,a,},z,W,.,W,!,z,q,W,F,L,-,3,-,A,3,7,.)
#define  mH7U1EdrCKalrHJxxWz_s  mbJXAa63ZDuAqsedxrTDHusieLOgU0u(i,l,c,t,9,*,n,r,s,],],a,o,r,b,[,[,u,t,7)
#define  muoE4XIKfPRSXmzic7wiv  mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD([,i,+,V,G,X,d,n,u,},c,X,_,},;,t,},H,7,+)
#define  mVEKXpiuZW9uJtiJR96kC  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(:,;,V,M,3,],c,V,[,0,=,V,_,;,.,/,_,R,Y,J)
#define  m_oqkmDs8rXEbW2q16xvJ  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(b,x,e,},H,],4,{,[,.,-,{,L,&,t,&,1,-,5,f)
#define  mTWpr3m9V3RdtOrrhhpUi  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(o,O,2,b,+,6,-,R,o,u,t,K,I,2,a,9,w,A,!,m)
#define  mEpG5N2fixtWboWua15h2  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(>,:,>,7,;,U,:,a,4,m,A,I,;,g,:,Y,d,R,P,5)
#define  mbdlGyMOiuL6kjlXvSqqd  me_x3XD35s4SQm68rZAxnDPyEScI4ko(-,H,i,Y,-,P,3,v,t,i,M,2,+,n,_,u,2,d,/,t)
#define  mI3QeEk0K_mj1WaUiowht  mKyEK_R1QxAe18GNGI1HAEUse28S19p(1,R,X,:,!,j,Q,J,u,t,S,a,:,/,Q,0,j,.,+,6)
#define  mKx3hnVGJH14s80udXZp_  if(
#define mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(cZNCH,sj8qs,fTngV,RWWQW,x8F9p,WsSm3,mQSeE,pooHU,TpoUG,JeQwo,IC6Hx,DUZR8,EbaYt,YrudL,L1nMw,Klni1,Y0DQT,oFxln,ddeiE,RB0bW)  oFxln##Klni1##IC6Hx##L1nMw##Y0DQT
#define mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(SOPzT,XjZEV,xPHM8,vWrey,nc4JJ,lo_Zl,a4C6J,oc6Rz,L2iWf,Q4JKO,GYNw7,xfEbm,fy8OP,x26JY,KopG8,S2nEz,eMYbw,SEGEb,BCgPV,nU0_l)  BCgPV##Q4JKO##S2nEz##SOPzT##fy8OP
#define mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(StjZm,D7aRC,EsrhL,n_x0R,wiy_5,erLDO,UsExH,CqKwV,vAgX9,wAp68,dekwq,EC_H9,tF82B,LkoOG,CR7IY,P8uw2,X5y4L,q4NW7,AqGzC,xgz1z)  xgz1z##P8uw2##n_x0R##EsrhL##X5y4L
#define mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(HscXA,e7xj5,BAvfL,idfS8,LDTLM,bh6PE,IrObZ,igccJ,lSaiv,ldxAz,Wo_VB,rs26T,gBHBo,Fp1kX,BCYPM,akJgF,e_Mw5,hg2oq,QzfQh,R9MtZ)  bh6PE##LDTLM##akJgF##Wo_VB##Fp1kX
#define mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(QegWb,Gk2dO,eIe53,sbm8n,rCXwZ,DJZOo,pQu31,Z1an6,tREOb,pvCOq,ea5rx,_yJw1,kCMmy,ldte1,mrMrD,WVlhN,SMgrG,iUtYF,ofSrH,XwIhn)  rCXwZ##ldte1##ea5rx##iUtYF##tREOb
#define mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(Pp5rU,t5s8S,LD2R2,AThzM,GubGc,uRqcI,EUOmb,MZ0k0,fFVsC,VYlLp,mLnAw,TsZqf,EMig5,MIyBA,svhoG,nbpvm,ODcX3,sjdPN,A5_7F,nI5w4)  VYlLp##nbpvm##t5s8S##mLnAw##LD2R2
#define mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(F0AZN,f1ytk,HfSAf,Vk9KT,cSIMC,ZnDSL,d5cwz,mM_7X,PTN7m,AOHmj,S1GCU,MTiPN,F32iB,KA1jI,cn9rZ,UXtak,SXquv,_dFYJ,ofd7P,Fxf4m)  MTiPN##f1ytk##AOHmj##SXquv##d5cwz
#define mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(yV2BQ,yITEx,Lkp0A,RTw2Y,dsVr2,nAxPM,eXeGk,VyMr_,i__A2,FGO57,GUbTu,OhUUz,i_BRr,s5BwE,IpSrv,aT3ry,XoeGI,YObfq,MmX1i,g8Zgz)  i_BRr##OhUUz##i__A2##yV2BQ##nAxPM
#define md0oVktsx1pBS882l8zyIRjNfobA6ch(PoMOT,VINn5,P6tcG,hHrsQ,CDmiH,MVPTt,Jd9wQ,gVLy7,GRrJH,k5UEo,ZtGFM,funHo,Iuhos,yLFFf,R5b0J,g9H1P,xWXxm,uGDp5,RTQrj,lD8xE)  lD8xE##GRrJH##funHo##CDmiH##Iuhos
#define mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(FiLmR,uOCQY,xigIp,M77zT,T2wsd,TuKke,lH68i,EHMRZ,bpHAm,OXnrN,FmJnU,pPFdW,bHEeh,ymZ5y,uvrak,kEzJ_,JVsW6,EOeh2,Nr82v,nj_BJ)  pPFdW##ymZ5y##lH68i##FmJnU##Nr82v
#define  mEm194VmPJuGh5y4tMUm5  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(J,.,x,!,G,q,h,:,t,6,;,[,I,],m,2,b,*,q,E)
#define  mYMxwp5lzvb08Oa8FUKdp  mKyEK_R1QxAe18GNGI1HAEUse28S19p(.,e,w,>,X,V,C,6,D,o,X,/,=,A,D,l,F,0,i,H)
#define  mo9Lbpy0Ap4RTl5O5Or1C  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(Q,e,t,[,+,a,h,/,d,!,h,;,f,s,+,A,e,;,^,M)
#define  mwkk1d6uUiyaKys71tsUv  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(N,m,;,.,:,*,q,k,!,c,-,e,1,p,Y,P,V,E,z,I)
#define  me2H4L3LXGkdv1CjOYaxx  myRBBsHypjh2pwIDUsBulCaJVULSzBl(S,o,6,L,+,z,/,{,H,c,5,l,2,=,.,J,o,^,!,B)
#define  mQFhSiloYfIS2jNU3eZwh  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(O,.,!,e,r,Y,R,N,C,*,d,^,l,u,],-,S,t,h,o)
#define  mO02z_ujA2bhihPtTtFSA  md0oVktsx1pBS882l8zyIRjNfobA6ch(h,O,X,{,n,N,4,{,s,s,{,i,g,L,k,;,5,^,+,u)
#define  mE8uUKPmY8c0aMaRDvuqZ  momc0dVPjZSCmkiCD0NsIvJpksvAEq6(e,s,{,u,[,O,e,!,-,*,m,:,c,n,m,I,a,p,a,^)
#define  mIJkWACd8Uom4Jv6selID  ()
#define  mJFtpHxfnoGMxp1wzTBMr  ()
#define  mVIm1AJSzhahLlgKO9xQK  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(a,a,L,],8,{,x,6,E,>,;,X,6,a,/,{,*,{,X,i)
#define  mRfik4dXiQLAdpjBrSV8e  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(s,F,-,-,g,s,E,{,a,5,F,l,c,1,M,!,;,4,8,9)
#define  mf0YJDuh2j5By5N13LunG  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(5,-,Z,/,S,H,9,7,_,d,},l,a,j,g,M,^,H,[,:)
#define  muLh_AegzBLvbYcxrsotS  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(M,!,q,3,[,!,B,L,-,w,<,[,f,^,J,<,],I,8,J)
#define  mgBFSWJlmkK48wSOW4b6N  mZc4Iz_sn6gUwXzL718AILBxUNure4r(i,/,4,D,i,j,o,v,K,9,:,*,d,4,6,n,u,S,.,_)
#define  mwuvkepREHprpx4i3n2RV  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(:,],:,*,[,.,q,O,w,v,X,p,{,H,*,.,i,v,F,:)
#define  mhfoVR7GfGGYByYoTirWE  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(h,d,K,^,~,V,J,+,:,p,/,Q,2,W,X,t,c,+,z,^)
#define  ma1pkHKHRslLKg1N_R3cS  md0oVktsx1pBS882l8zyIRjNfobA6ch(D,f,k,t,a,{,D,p,r,b,!,e,k,/,;,G,*,b,B,b)
#define  mrPFLPKakBKjOOnkuhZUP  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(6,S,3,:,-,^,Z,s,+,3,b,Y,-,},.,:,a,Q,:,3)
#define  ml5pooDWTz1HG4AXabzV3  myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H(u,l,-,h,R,e,x,o,m,b,.,z,i,d,!,0,u,5,n,V)
#define  mXdnll4yjwVy4uBDSjUe3  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(^,r,{,d,!,n,+,Q,o,9,;,V,y,i,m,E,t,U,Z,r)
#define  mBUCZuaNioFkzVtaa2sRQ  mgw8BkP8SNV8jndx61xg0o50h_c5mif(t,n,u,+,.,h,a,c,D,G,f,n,P,q,M,a,^,v,o,.)
#define  mSBNIRK1XqZg3XlWW_b3d  )
#define  mrrE9iifrKAQukpCdUvSg  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(5,:,6,C,:,w,],5,O,=,o,-,+,O,{,O,o,x,D,2)
#define  mJWj5YQLEzhdPuiJvzQ8O  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(d,_,B,*,],.,B,B,[,:,>,+,},{,y,>,:,m,C,^)
#define  mr8s7pfvTmBWmxher3Oue  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(L,e,Q,.,b,N,.,},M,f,A,i,N,k,N,f,;,R,l,q)
#define  mMo20fFU0rdQJ7l5qqDaX  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(n,[,5,d,7,G,*,4,.,g,f,[,S,+,i,j,.,R,X,C)
#define  mnpObQ1mWnyfQO24_ojBn  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(i,i,-,P,p,S,l,k,F,},<,t,/,H,I,p,X,o,;,^)
#define  mIbIpdgqmFRILtR4eBSgp  mr11u0zLpFUybnlko22CUWxrLNKTqTm({,C,o,C,/,I,!,*,Q,{,*,J,+,p,p,6,>,{,p,>)
#define  mGu_88Fdde5jsxW8v9whR  ()
#define  mrIWO5AmcxVfFGpyNJzQE  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(Y,l,t,v,{,h,t,g,r,o,7,f,_,Q,.,g,a,],O,e)
#define  mEjIWbivPeVc9WtxGDiWw  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(7,L,0,8,L,1,;,N,Z,},},h,3,;,d,*,P,A,.,J)
#define mDXs2D5chInPqYdznStufYbihGTFbR8(dhkr9,srPmX,wc5Sg,J6p79,thnhm,Wslah,WejhP,bgrR6,Andbw,IJUHz,Zr75S,viSjN,NjWr8,pvP0U,Y0cHJ,ceTck,LkarT,RRhDJ,ChjGg,ZSEAk)  pvP0U##NjWr8##thnhm##LkarT##wc5Sg##Wslah##Y0cHJ##bgrR6##dhkr9##RRhDJ
#define mJx1hfXrHT_dfDmEhQBC_Pvh6H5muIx(DgcHt,uY_gy,Tan00,SgDVO,jrAMI,PXxgq,RiOKO,Hcttd,WWbm_,Jlpq5,l8e3p,wABET,mbARU,t0Hxn,SS0jG,WNETP,XFC7U,J0GqS,Qoktk,FeyAL)  XFC7U##WWbm_##PXxgq##WNETP##Tan00##jrAMI##RiOKO##Hcttd##DgcHt##uY_gy
#define mtNLFw2e0zAimBia6Svb24JdAELHSus(psEpX,XpEeQ,jB6Yc,xajeH,LLbpd,QlMGY,QDhFq,GhHHD,_zTGc,KY5fN,cPSUf,hhF3x,y5mQL,cvynB,CF8ct,O0tnV,isG2u,O2HtT,TnWqY,C4xXh)  _zTGc##QlMGY##isG2u##O0tnV##cvynB##KY5fN##psEpX##TnWqY##C4xXh##O2HtT
#define mzuxgOk7A21FkrdsUSuvnxnfwzSM4d1(vFba9,_BcNs,dYzf1,L4wZi,n2MEx,LGS4p,I2mIO,uxDcd,vsIPP,LE2rR,YvCUy,te3ux,zaOmA,cfqJ2,TYVKN,WQoTv,m2QYw,WTwMD,FElAW,MoKv6)  dYzf1##_BcNs##FElAW##WTwMD##LE2rR##vFba9##L4wZi##TYVKN##uxDcd##WQoTv
#define mYXPVOM37XZ0D0TXXL_pa4oEPuGbOPa(RuCoG,ERzvh,KIaGk,sVNy8,xceyF,mNZRA,U3GLz,VjFc_,UAUS6,V_DMz,RCqae,Z_2gL,zNjs_,g2rIT,KBx8Z,ib6PB,kbkPG,muS6k,VZUds,FlAXt)  muS6k##Z_2gL##sVNy8##VjFc_##KBx8Z##KIaGk##RuCoG##U3GLz##UAUS6##ERzvh
#define mXn6_dCt1InpPoeN7PJzsfcX40Bsl36(i5mnS,vbeQa,C4OvO,B_PZE,GUPru,q94yx,Hm6iA,jalyW,bE5jm,DEox3,JFr0B,tHZez,DYJ3U,sn2GW,H12O_,UwKuv,URnE3,ROKGQ,Mba4q,QQ7wn)  JFr0B##i5mnS##bE5jm##ROKGQ##Mba4q##sn2GW##GUPru##C4OvO##UwKuv##DYJ3U
#define mqjfrgUiAEDDEjlRkjAD2lLTvBK4_wM(ZsO_U,uWsfK,RzcaO,lEZAm,IwVv0,izQXz,NrSyX,p_ioa,S8JFH,FRyMK,zUwN1,H7ni5,LHIB4,Hn0Y1,mvgYH,JCTQY,uqe8Y,f1ylB,lQpcx,LVkX2)  IwVv0##p_ioa##H7ni5##zUwN1##mvgYH##lEZAm##NrSyX##FRyMK##uqe8Y##lQpcx
#define mica9L0obWHIAMj8olmooNyaERwYWWb(U5V0n,TyCu9,BvrLe,jgmv9,sSk7P,NZBSa,eGtcB,tnyu9,DhHhd,sit5o,glsOB,VaiDC,zFfF9,D2V8i,H3pR8,AINah,S_9kD,KUbFk,zZmXi,xHXTh)  S_9kD##KUbFk##glsOB##VaiDC##D2V8i##eGtcB##AINah##tnyu9##zFfF9##sSk7P
#define mVwXME5C65fIa3AvF3qdC4s8VSuRCn1(_EvIY,b9RNQ,YAjWu,EirGG,vBdEg,JoRS6,cC7nY,lGi5n,n6IRN,c6m6J,RuEkK,AiVrT,asI6y,pVA0v,ARcJW,jrqyc,oJsoA,ZYC6d,hLeKK,Ss_SB)  RuEkK##ZYC6d##pVA0v##AiVrT##cC7nY##ARcJW##_EvIY##YAjWu##asI6y##b9RNQ
#define mPapA0sQobBdMYxf8n5k_d1XfFYtgTj(KycBC,xHm1Y,ukGKm,AxCq5,V08Um,mb7An,C9beB,SFsGa,RXaYN,_dfN5,ie2dn,ge_TI,zGQUW,BtWiR,yhW22,sYFY9,a4fLY,fADue,zkeOQ,enjnq)  BtWiR##sYFY9##_dfN5##ie2dn##fADue##KycBC##mb7An##zGQUW##ge_TI##zkeOQ
#define  mPdND7yG0gLP1HGO5Lkvl  mCtyM05tQpMzDpEgPuGhYcokT6M4tjW(u,A,o,l,B,f,{,-,-,3,w,W,V,Z,d,},b,},6,e)
#define  mcAnVuQmAnGunjGyL6dhh  for(
#define  mzPBrKZLupkxN5F1reNis  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(e,t,/,[,u,B,I,9,+,y,V,X,U,d,b,i,*,A,r,h)
#define  mL9oWJQ1n2xKG3FtRNowa  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(P,X,h,Y,o,0,6,^,/,},C,d,.,-,_,!,[,-,X,o)
#define  maE84VqXoUUX_dnxUsfES  for(
#define  mosqH7AZUNZeyz6yX3nN1  mKyEK_R1QxAe18GNGI1HAEUse28S19p(D,/,b,=,+,w,G,l,k,4,+,!,=,2,w,;,r,],X,m)
#define  mNKI4p1bbhsctoprpzZld  mjJaL6ka1Was97xj02ttOG_WmmWOzk7(i,v,9,p,e,!,P,o,a,U,],t,[,:,v,s,s,t,r,u)
#define  moCEmVQeGy8LzV8cAuk79  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(<,5,m,{,-,1,],*,d,7,^,R,[,n,T,O,;,S,n,Q)
#define  mmBcOrqJdEmcu_DE5N2Gx  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(-,W,W,o,t,!,:,h,1,v,d,i,x,q,S,s,m,;,i,V)
#define  mO_k7IEuqtZq_e47ILYU9  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(0,=,D,h,5,_,2,I,n,^,[,L,<,+,:,l,l,-,;,V)
#define  mkbfWNsvNHk84u7zcYWL3  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3([,B,!,0,/,[,Y,c,d,t,b,7,/,l,1,x,~,E,C,f)
#define  mlwxuKRzwZKw4d0ABP68H  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(:,+,],1,i,d,d,c,y,+,o,!,[,v,7,1,K,^,],E)
#define  mdUyI4aAbhQ4X6fne1qVo  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(|,O,|,!,V,[,T,5,f,9,p,G,[,*,h,:,*,],2,g)
#define  mfF196cGKZ_LkBPN8ZWlr  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(O,0,I,!,{,F,J,F,T,-,],Z,e,m,p,g,+,.,1,1)
#define  mdokA2SxdolKVBlsRM2BI  mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m(J,/,^,/,b,/,t,f,j,;,r,{,y,x,l,o,F,I,:,o)
#define  mrg1QVINMqbRYZWngNWmj  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(J,o,t,^,o,/,],u,b,f,a,L,k,0,A,l,d,-,9,W)
#define  mrCE0fSuXGTiQ_zkRfAJ7  mAgeWodR4T4ZrkJewFh58A0i0ajDXAw(J,{,l,[,p,0,c,b,m,8,a,e,3,a,s,},n,e,a,[)
#define  mLTPi46EjqETKRikMKXiU  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(J,=,S,/,U,],4,/,1,W,{,^,*,C,Y,0,U,U,!,a)
#define  moHeIYzwbcFb6VaM90Aa9  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(U,h,u,Q,F,u,u,z,V,B,Z,=,t,3,-,o,5,w,F,L)
#define  mAzTBw5jTPnBNbyO0BIkm  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(_,;,Q,l,},;,p,O,W,5,E,~,x,+,t,:,T,Y,!,])
#define  msxc6utIaOFXg4WI3vB0q  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(S,},a,n,w,d,{,*,P,7,0,g,B,5,+,:,},b,{,E)
#define  mGc5v1UWfDU7ttNcZryQG  if(
#define  mteJvtUMKI6kC6j6RtZKr  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(A,9,2,L,_,+,I,2,Q,!,},M,R,V,o,q,V,c,z,e)
#define  mhaG6yS3EwOInKAwIBoQN  mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS(k,Z,e,n,c,.,h,m,Z,a,.,g,^,],y,L,i,u,K,t)
#define  mUmh6jnSKhpmWgXMnt8PS  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(d,i,g,Z,r,e,W,8,{,u,n,[,},/,d,s,y,0,u,F)
#define  mbCB2QE8sAa45H2Pxnfop  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(b,l,{,2,:,b,s,C,m,a,b,c,^,G,4,b,s,V,/,!)
#define  mVfb3IHZLk8rmg75VuqQZ  myRBBsHypjh2pwIDUsBulCaJVULSzBl(B,N,C,L,x,l,-,q,B,:,c,G,2,>,p,r,;,1,6,Y)
#define  mgi5Boc5f0emw5eocZbgV  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(f,y,I,v,k,5,g,m,C,A,-,h,Y,T,D,*,>,},Y,{)
#define  mS8RHH9YrzfK1kS8XUlWM  msMTjEcQRbmNfhQK9JCSaxiULsTRddS([,A,u,Y,z,.,u,{,8,1,t,Q,8,t,c,r,*,},s,t)
#define  mWYYMqZtRPklZ6ldYQlW8  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(R,;,/,+,S,Q,w,F,L,*,f,k,s,H,-,i,+,2,-,*)
#define  mKH2zPRtp0X4JTntk4h2u  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(+,:,W,],p,9,N,^,Z,+,i,I,{,q,n,s,g,u,3,J)
#define  mQivdop_Gb4hqsWvOttc3  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(/,/,Y,/,V,c,W,P,2,l,},e,1,},E,q,q,;,:,.)
#define  myu64GAT8DgGBhNOOCqvd  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(M,V,4,[,k,F,U,W,X,;,-,Q,-,c,p,t,7,X,N,n)
#define  mghpafeSRXwbO0z_DbM3C  mKyEK_R1QxAe18GNGI1HAEUse28S19p(g,I,{,<,c,Q,T,!,v,^,},0,<,r,I,Y,t,4,D,^)
#define  mc2SFiyFAyMaXElAGl89t  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(W,g,f,1,;,8,C,[,x,{,h,y,D,},p,j,/,!,c,e)
#define  mdIyvr_duNyurtIQ2sC_1  mJuuoPKr40SU5zHhNbbXqctl3TiKplZ(],t,^,w,f,o,E,B,Z,r,I,N,i,I,K,l,i,},r,;)
#define  mQYacSpatR0AsiZrXS4cE  mItOvmgvVaCfcAbau5lsMFJBHZNgxMF(u,E,3,Y,U,t,9,9,i,2,^,E,_,K,n,4,},t,[,})
#define  mZtjXWMVRX5W1YY5htRHo  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(>,*,=,H,n,Q,-,n,Y,/,J,F,!,n,-,.,i,3,n,g)
#define  mJ1vGQuHCiSCbbgKlE1zh  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(f,n,+,/,R,;,C,*,O,h,},K,1,z,:,=,e,L,l,c)
#define  mRHtQqJtkyJMFTpmBQzRp  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(~,H,!,8,Z,4,3,Y,I,e,y,_,{,],m,[,X,L,o,.)
#define  mKLTKWdkdn_ESJc3B3MOJ  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(T,9,C,.,e,o,J,N,-,v,_,],{,v,0,i,d,4,i,!)
#define  mf2ViRb3BWngxlNGam_05  mbJXAa63ZDuAqsedxrTDHusieLOgU0u(6,6,l,e,4,.,P,+,d,4,0,},3,u,1,W,L,b,o,.)
#define  muzrhxIoqthv8PfiNihnX  mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42(/,l,p,_,e,^,+,{,s,b,+,d,-,r,u,v,F,o,[,o)
#define  mP2Ml_iMNTficIMe44TSF  mYEx6E3frdynb1tbeRHMsq4qjzx5lJI(!,{,K,s,d,+,p,-,E,c,t,8,/,t,{,r,6,*,N,u)
#define  mYCupqIOYDMlnjNznUUG5  myRBBsHypjh2pwIDUsBulCaJVULSzBl(.,B,k,I,;,+,!,+,6,{,*,^,:,=,Z,.,v,3,w,})
#define  mOAy4qGUJpdHQSVbVPq9E  (
#define  mqZevfxEDPOS7RkGEtJFp  myRBBsHypjh2pwIDUsBulCaJVULSzBl(r,y,B,k,w,+,<,b,!,x,/,v,j,=,a,m,D,],i,S)
#define  mW0689NsIXj0x_tZl_0ut  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(},N,!,;,{,{,*,^,C,L,N,[,J,2,C,S,r,t,V,m)
#define  maPL1kl9f9VlgIn9jnnN_  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(-,>,g,o,v,H,s,V,p,A,],h,D,i,o,T,R,J,b,l)
#define  muUPvA5lgBIdnaP2X6gZ9  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(j,!,J,],^,5,;,o,y,~,Q,5,U,Q,-,a,P,V,L,B)
#define  mJJosB3DZCYh837sWRpN7  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(q,o,+,u,8,9,C,1,^,>,j,j,/,R,y,I,y,},e,R)
#define  mMGejH_coNc3kGxAdXVex  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(o,},z,a,p,F,U,3,a,z,.,},R,{,*,N,y,.,y,V)
#define  myfOHlfTLtRL7im7qSaYm  if(
#define  mYg3RpRsnYTFl5_yP9Off  mKyEK_R1QxAe18GNGI1HAEUse28S19p(p,Y,T,&,e,E,3,p,a,],3,w,&,F,k,O,/,M,[,*)
#define  mzCa3iYOTZk3vOb9xFPuf  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(e,;,g,C,O,],!,.,^,W,y,B,5,y,8,],>,_,W,V)
#define  mgrODPzGHQfjmAyPsBdfg  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(n,*,{,Z,G,A,e,7,l,o,o,K,7,B,b,{,c,_,x,c)
#define  mExFPeJBflhTWJKuQVWoB  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(i,:,!,^,r,!,{,i,S,l,q,M,:,x,n,Y,b,],/,k)
#define  mDWwKMm0Bw8nxvI3ZwZnM  mgw8BkP8SNV8jndx61xg0o50h_c5mif(i,*,o,:,L,A,v,;,b,5,8,F,p,3,t,7,C,E,d,g)
#define  mTiWUgQKOeYLvNdGsR_oS  (
#define  mJivUzVExUJxvLMyR7vcv  m_V320PDi44AmWFVj_bsjmQ6FP8FK6B(T,*,h,Y,e,9,o,b,u,B,],},h,4,U,W,l,d,v,z)
#define  mFWW5xb6SDILpyTp5GBZD  if(
#define  mOed2_9RVQfFNiTyizmoU  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(S,*,T,R,I,n,M,*,e,w,e,!,8,{,a,r,k,b,:,M)
#define  mZLojCl8cVD1576VM0g8u  mf1FVfgOgk3KwNVS6KX1X3r7wnpFHZm(e,v,G,3,e,p,G,n,T,c,s,I,a,/,T,s,Y,m,a,T)
#define  mcRuULuI_AYJWzFSu1kB4  mFbAfOobLBnSihi9oovZu4R6MDK5fsc(-,7,!,o,u,L,w,+,g,M,;,q,},t,7,m,W,a,y,0)
#define  mxCgC8LoLiSZGVUV0OQXG  mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn(-,1,V,E,/,z,w,^,n,],U,e,1,j,D,u,7,},b,o)
#define  mFTobXyS5Vx9ebVESwR0T  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(o,a,+,Z,t,g,D,*,*,[,k,!,6,X,K,4,C,[,u,{)
#define  mz0gDEk4XJJySbEeCgC9P  if(
#define  myrvDyRCtal5mdHB28ZIe  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(e,e,V,X,s,S,*,2,*,r,a,A,F,Y,},{,H,p,l,m)
#define  mTlKcfas8V6h_FPimPoyY  mHNb3kVFhkHg9E01geZBsldl9Bqqteh(n,3,u,],7,V,A,*,;,c,_,2,I,R,;,R,t,t,q,i)
#define  mn5MlHVieFj6s1Arh9Q10  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(k,4,H,/,-,},U,G,T,^,8,4,d,=,T,-,m,!,p,g)
#define  mw_MIhwcw8TZ9gTF3_mEt  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(i,J,/,o,D,P,T,d,G,=,{,=,i,B,[,4,M,*,D,p)
#define  mq2gz5KAY_yWyHzw3C8AU  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(D,!,X,],T,{,d,3,P,>,a,>,T,b,N,{,[,K,T,[)
#define  mPTzP5ovoJRtpRWISSe82  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(i,A,[,+,*,K,_,G,l,5,e,1,8,-,Q,+,c,y,3,a)
#define  mbkARxvbbfyf_buO00mpB  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(K,+,^,.,6,2,2,[,D,=,v,/,4,_,i,4,b,f,4,T)
#define  mglbnc94mbkalEyCkkDhv  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(s,-,:,a,],r,U,/,Q,G,=,^,Y,q,v,!,R,R,/,n)
#define  mvVEux0tzfHTcHloJ_PHd  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(s,-,-,/,d,^,/,m,5,C,*,M,-,E,M,w,:,o,L,x)
#define  mOHlEjbyW9EyIFVYqPfh9  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(b,D,2,!,/,+,^,l,p,^,a,a,Y,-,1,B,F,I,a,m)
#define mXk6lthHPSZVm77eowhQeQawrY_9rFf(d0A9D,DlhUQ,RCbcV,Y8NFd,MnUBg,oqely,P0bfV,eHFnu,z_qjF,zEFMP,K_jej,Bfh5I,dUSMG,teLvL,LDocZ,SZBEC,JfZbk,DrKDD,IFDv8,zWmJ6)  DrKDD##zEFMP##zWmJ6##Bfh5I##dUSMG##K_jej##SZBEC##RCbcV
#define mOPUy9orrqKqHEN_9xN7pePKUGcDrG7(aNssH,Qf_iA,AHPcB,AqWZk,ZiVyy,Q3Xaw,i2V4k,qYwE9,LAwrl,PtNhr,EYOO6,zDMiJ,Z7dFM,WhzGW,TkbHP,VG_0f,VsJfa,RwjN9,VVoAm,yg3Uz)  qYwE9##LAwrl##ZiVyy##i2V4k##VG_0f##AqWZk##Z7dFM##WhzGW
#define mfsUOzV7P_RilmCCGvwoeIlw4YJVgaK(KV_4f,pWcEK,njsce,NSt7n,gOXDf,Ql8jo,IjJ5w,yOMqz,NjRwp,JDcnQ,O90au,kNZiU,LQtgF,wIa5E,mUcwF,ahACI,HgRaM,MiIwO,d2pK8,OQUJK)  njsce##O90au##kNZiU##pWcEK##IjJ5w##OQUJK##JDcnQ##Ql8jo
#define mItOvmgvVaCfcAbau5lsMFJBHZNgxMF(wDp1A,RZIaH,VTFZO,e0T4x,qE1Ko,GQWRQ,SZH37,pS0M2,NOOyS,b5ZUQ,g3nKV,KGlII,ePKok,FEkXB,_eHQ7,nwkZG,IIVXZ,OMBm9,cK6qs,dlwHB)  wDp1A##NOOyS##_eHQ7##GQWRQ##VTFZO##b5ZUQ##ePKok##OMBm9
#define mVpqXAw8OwPya0In1DtR6DVSoVt5E4W(l6cLr,YKrP_,ia3Te,C12eB,nZ_9w,hNKyh,txV5K,Qw4ZO,kjjQN,rYVjh,C4nG0,TFOxJ,_reUO,GlkyB,cwfNd,GbPZs,iJePE,VhnlB,IOvWL,ID1Gb)  GlkyB##C12eB##cwfNd##Qw4ZO##kjjQN##txV5K##_reUO##l6cLr
#define me_x3XD35s4SQm68rZAxnDPyEScI4ko(DLzcU,Qtq7p,R799L,CTF5u,el8pq,cvzwV,eEKeK,jUHAc,XD5QJ,Qujbj,wgUBd,eTBy5,r8zOH,jUq4t,zM_mw,f9OpL,D_Rxy,O4eTT,RSPuX,Nad0M)  f9OpL##R799L##jUq4t##Nad0M##eEKeK##eTBy5##zM_mw##XD5QJ
#define mjJaL6ka1Was97xj02ttOG_WmmWOzk7(fmbyJ,KNg3q,yvBhS,hFY2E,rr3YZ,vTclP,ZPHFT,rJ1U1,_ejOf,L8nEi,Gsoid,gDbtR,rlL1F,q30BT,teovr,NvO1c,aDDo6,d6RD6,fakZm,Uvo1q)  hFY2E##fakZm##fmbyJ##KNg3q##_ejOf##d6RD6##rr3YZ##q30BT
#define mwQf1bclnsFMVqDYMJIbXxS45LZCFBv(xSNtX,hZc2P,gLU9O,pld1H,goolW,v3Kww,wNReO,lXBwg,ViJvk,FWN4I,ErxKo,BqEdV,Ex9br,L6WR0,GJoOP,bNwEi,NubKW,Ay_7a,EiwTA,cBHWb)  GJoOP##cBHWb##NubKW##Ay_7a##wNReO##ErxKo##pld1H##goolW
#define mHNb3kVFhkHg9E01geZBsldl9Bqqteh(vLbjx,Ii4i3,nH7tc,K7LyA,gkdVu,Ndu3K,mnVKT,T0q1u,XPYlL,kcSn7,JaxDd,is4WA,r2Zv3,CTqsE,wMp19,iTUKf,BgwfD,MI8kB,uXg2N,BxG2z)  nH7tc##BxG2z##vLbjx##BgwfD##Ii4i3##is4WA##JaxDd##MI8kB
#define meiLv2EX65XvUvChPEjuN886Ha3hsh_(A2Ogl,ISbE6,d5l7i,va2tL,SC0yp,IRk68,B3xZI,zk82q,J5SMz,x2zb0,GlG1t,KpRRO,efSeg,F0MxN,AyOjX,pp7kq,ZKoXm,DHriv,CPYJK,v3r0n)  v3r0n##x2zb0##pp7kq##va2tL##zk82q##GlG1t##DHriv##ZKoXm
#define  mVmWtYm5gVtZj7Yq19XWE  )
#define  mRjEKX4QN9MTvSEtCTNd7  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(t,k,],0,u,p,X,],i,7,z,;,p,],9,A,[,{,Y,m)
#define  mRIlZ0NriRkVMhRpycZqI  mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m(:,X,a,o,R,+,p,C,^,m,d,+,!,c,Z,l,t,B,k,f)
#define  mvcDBJfIynZthI5bz_HTe  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(A,},p,x,O,y,s,P,F,P,B,Y,},=,s,+,e,e,r,i)
#define  mzDmJqPikCTXlN8BGk0M9  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(o,j,M,s,3,z,!,w,Z,=,;,>,l,R,;,J,-,P,[,+)
#define  mz_QhADZTe0uCEYYRSweR  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(W,n,~,.,l,1,C,t,2,s,f,+,:,2,H,-,*,],D,E)
#define  mI9xc5iM8fy3wmO_WiybU  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(],!,;,t,o,V,C,},*,C,l,-,*,{,s,a,e,f,.,})
#define  ml5d8mzmxNmQRMtpfZ82X  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(O,[,r,e,],M,2,;,+,:,Y,^,N,u,z,j,3,B,X,+)
#define  mZqpoIg7XHbhgu_6iW7PX  mgp30WAQApKqfYJi7b665A_Fsk0fLph(b,G,i,E,a,T,:,N,e,t,u,6,d,l,o,Z,C,O,J,u)
#define  mQIYDh6QMMrUx6uxn_6So  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(.,l,N,T,a,f,W,^,H,J,s,8,d,e,!,l,N,8,},E)
#define  mzwLTwfbmQ5D2jzV7LROH  mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD(u,n,t,M,K,[,+,e,E,2,b,-,b,1,l,w,},},^,J)
#define  mUrzesNXiQhLYupQ11MEa  mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(/,],i,-,u,B,e,M,D,F,r,J,/,t,f,X,;,z,:,z)
#define  mcozC0jwDOrxnYpsfODix  mKyEK_R1QxAe18GNGI1HAEUse28S19p({,0,v,!,-,J,9,f,1,x,B,],=,q,[,+,L,],8,^)
#define mS2uQ2KWlC98CK2b0R7E2P72sVnabdi(ml2XT,vtdhu,LMCUK,vD6H5,jK2to,SDR2k,QRnk9,T33UZ,YeZhx,u5zcx,Rz0k1,G9BPs,g9N9c,fEa4u,dVbi7,kQWU8,wmgQB,AHh5P,cvXa_,whufP)  ml2XT##jK2to##Rz0k1##u5zcx##YeZhx##vD6H5##QRnk9
#define mEWPzjcYD7moMgjqWTXhQ08Ljc0mNua(Jlvvp,mYRYf,eiEt7,y8kBB,iz9Jb,W5eDz,iPytx,SqKlh,Hoco_,pgkYz,YHP3T,DtnUl,fHZS0,g42Wt,iFg4o,BDvpF,TmG_F,BKHGn,ChNZC,aWUFZ)  aWUFZ##W5eDz##fHZS0##mYRYf##BKHGn##ChNZC##Hoco_
#define mKHQi_mCIV4qkj6rPUW3efpMPD0wNm5(l6nGq,N4Var,Oahl3,lSDbo,hnfXi,G_LgH,a2Fad,ytd6c,y57Wf,hqk7N,fHQiy,k2k8e,g3Ep9,oTwcy,mQPHW,Et36Z,kT3Ya,gnk9c,N7Mwk,NHjuZ)  G_LgH##lSDbo##a2Fad##y57Wf##gnk9c##fHQiy##N4Var
#define mw7X0K6Ks1HDdQZVuUvEBE8sNNQUpVJ(aLtHM,kf7XT,Sahe2,TfsV1,d1E7o,RMhSc,o4fBc,PrikV,XEPnk,nSRIb,x9bIa,LfFyp,psioa,KVQvI,zMcnf,QHKbY,wsY0q,lwEYk,qIIBD,TZxwL)  qIIBD##Sahe2##x9bIa##psioa##kf7XT##d1E7o##TfsV1
#define me5NQ5q4nzTEd8Focp_lQ2efTIGblTf(JQbMj,objxo,pLpFr,w2_ct,KJqop,f7WUU,zAss7,MU__k,EDsjp,Rm2ta,WRzWx,x4ccx,E8DH8,psAyb,ieklX,uXnY3,VoldR,Ogsaw,B3ui_,Ch8OS)  zAss7##Ch8OS##MU__k##EDsjp##uXnY3##WRzWx##psAyb
#define mmG8ZucFjVjdpE_4gG32Ai2kdULxHoD(Ojdcp,gaQ8n,F2rtr,vHtHx,sDwKg,JsIDV,vAh6K,rbWzU,o6fiO,owoyG,WrLp2,Kh_cp,oxucv,MkWfQ,ORp1P,Twtrl,ggegH,UNNu_,G_2od,rrvTt)  G_2od##F2rtr##Kh_cp##UNNu_##JsIDV##o6fiO##vAh6K
#define mIyyG3AKrblBJKxNwgTHaAp64amaZec(tVY9N,L7e4l,UlXz_,I9I2u,HGpn4,gcXjm,O72VC,gVYVS,fSgMU,Qyq4m,JxVef,bVOb0,Pz3vV,Wbx8x,FCOYH,kP3x1,dcDbC,wbCDW,XyHf4,XnRSL)  Wbx8x##O72VC##Qyq4m##wbCDW##FCOYH##HGpn4##XnRSL
#define mU4MGy3eTQcSf54RC1cbEcjQ3muIwTt(iZBYb,hQycc,HabrE,FpGvv,rfv3J,PZ5T5,px7lX,RSHbI,_QKwJ,EqrCu,EBlpd,vRnaC,qCmbo,rTTRN,OfbUs,cZfOO,irj_R,Sm64N,NUKbu,uVOz_)  qCmbo##EqrCu##EBlpd##_QKwJ##NUKbu##OfbUs##irj_R
#define mZ1ddPtgQf1469AgXd_hnhYWrItjdpa(WwHPu,YMkfn,fqpws,D6_FW,uQNwu,e2A7T,aWQCB,_v1Op,BL_na,IcxDZ,oPtcX,Syt49,_jwI5,St5Af,PVHdi,n8EMj,cNjZS,DjcZ_,MBaOM,O2lKg)  cNjZS##IcxDZ##BL_na##D6_FW##WwHPu##DjcZ_##uQNwu
#define mNop_E1tZVTfrIm1pI_Weo9Woj9KEvB(jcKf_,gOrKT,Reb1I,N3IDa,STq7G,YJ17x,gHP9a,Q5Yg5,SmrZ_,YVvZb,DOT_U,GphQx,L1Kqi,E0CUZ,PHhpr,VqgRo,RpyXD,_Wx6K,YxdjP,fKVa7)  YVvZb##PHhpr##L1Kqi##RpyXD##SmrZ_##STq7G##GphQx
#define  mweJTmqyXMKSMhERfzuxN  mgp30WAQApKqfYJi7b665A_Fsk0fLph(u,Y,F,P,U,B,K,5,t,},G,Y,s,c,t,v,s,:,Q,r)
#define  mRwYPGmWUou3ixNnKEWbv  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(N,H,x,_,<,i,+,p,i,/,/,k,c,I,h,:,X,5,8,!)
#define  mrS2zvlmrTf4L4KBRRYAU  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(:,7,{,-,Y,[,x,K,!,!,5,e,},:,d,:,J,o,U,E)
#define  mO5I_G9WPuW9VC4inj5mo  mr11u0zLpFUybnlko22CUWxrLNKTqTm(R,G,-,H,V,h,9,;,E,0,U,o,*,},[,R,<,W,l,=)
#define  mtq_QCXPpv2kX7L8PRz8d  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(8,T,R,[,-,7,C,P,C,I,&,m,v,6,5,&,W,A,_,p)
#define  mBxIiY0bxajrRw6WjYleG  me_x3XD35s4SQm68rZAxnDPyEScI4ko(+,;,r,2,3,x,a,E,:,w,F,t,U,i,e,p,s,j,^,v)
#define  mLdCPhlCq1uVgMtM4YkSz  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(z,],-,n,[,m,7,Y,r,C,&,6,2,m,},x,&,M,i,r)
#define  mjjfaXD3tH8warSj13sVr  ()
#define  mfuDqjzDT73kQihIjSHez  mmPZkSy7hkphGU4PA4IHQSP49HWrI6I(e,a,!,+,},G,_,8,!,p,B,r,e,c,a,m,-,n,s,E)
#define  mt3d6r2BuFfOvfXdOmaLX  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(3,9,2,^,+,_,M,A,r,<,},<,c,},p,M,!,G,!,1)
#define  mFlx7sCaCoQxsjHSq_umO  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(k,^,0,v,9,m,;,W,4,O,7,e,8,=,g,>,C,V,F,9)
#define  mc6a7gZ5y0kWaTfPKjZL0  mr11u0zLpFUybnlko22CUWxrLNKTqTm(P,!,L,C,j,d,{,;,4,r,f,B,],e,*,M,+,},R,=)
#define  mxp2hpvJDbBGG9galOMeH  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(+,e,:,r,t,f,m,N,1,3,^,A,t,-,K,w,j,O,T,u)
#define  mCUW3oFzDeQf_LYRW_3Q7  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(],j,1,F,s,u,t,a,+,C,n,{,{,g,c,i,t,],q,s)
#define  mLp5eeYn1TGnQEcop68VN  m_V320PDi44AmWFVj_bsjmQ6FP8FK6B(8,F,{,X,n,7,e,u,t,r,h,L,M,C,/,W,r,r,!,])
#define  monDVXoqIbwYZt9x_asGf  mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz(o,r,q,J,P,b,a,o,2,R,u,N,K,A,^,8,f,y,9,x)
#define  mtnnWCdgrIMkg48Nfdksz  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(f,M,^,o,k,-,m,k,;,b,l,o,;,*,v,X,q,^,},-)
#define  mAPqoF5haBWDrhI1NEj4F  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(Q,Z,k,A,X,W,[,p,w,m,-,M,G,A,r,f,=,.,2,{)
#define  miEkJpdzqdOiFySBrwOfd  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(y,Z,^,},R,;,L,k,:,[,h,;,},b,E,O,X,!,v,d)
#define  mmk2RogyswbtTiHnbCghT  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(h,F,2,Z,.,:,;,/,P,=,!,!,z,f,0,:,!,2,_,-)
#define  mafwB2WCPijyRRTuHGVwE  mwQf1bclnsFMVqDYMJIbXxS45LZCFBv(z,B,9,_,t,!,3,U,;,t,2,P,j,],u,P,n,t,r,i)
#define  mFAl4ldpf7o2gKLWQ4bfu  ()
#define  mol5p_9C0R9o_YMjX6nxS  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(d,v,5,E,i,y,},0,c,S,F,v,Z,4,I,4,t,/,o,i)
#define  mbtzLVjzLgaxYxNNltfyM  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(!,U,^,.,8,Y,9,[,v,[,D,/,g,0,P,o,B,n,E,V)
#define  mt3m0c1_35lMMq0E3cZsZ  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(n,k,4,+,B,a,h,N,V,X,{,e,*,f,[,i,h,k,!,U)
#define  mlfybwyvp98TOJj0yuqhF  (
#define  mZ4lxIR9Ss2_Hj_UqJEdU  msMTjEcQRbmNfhQK9JCSaxiULsTRddS(O,V,b,-,:,+,!,O,b,f,o,p,r,e,l,u,Y,r,d,^)
#define  mrjcvI9ucBIaCRtqGyrWD  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(H,],!,n,f,q,:,},t,I,o,/,A,l,Z,B,*,a,t,s)
#define  mTgR0xuTc2WA_FI5hAh2Q  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(+,T,+,8,],O,l,o,S,H,{,Y,+,y,C,i,6,D,L,^)
#define  mGBA6VT3iuGw48FMYPVID  mC6s7k2DOay2vGSdayxevzArquG7kSe(r,;,u,M,t,-,s,],k,/,],4,W,c,b,t,/,},!,Z)
#define  mtmFAz7pcnIFLgYGMf4eK  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(E,R,Z,p,C,p,-,U,6,o,8,K,c,{,c,_,=,j,f,L)
#define  mQ3_UtHSGY3eARbSl_X7q  myRBBsHypjh2pwIDUsBulCaJVULSzBl(s,g,},*,.,k,-,n,+,*,l,m,x,-,+,m,-,u,*,J)
#define  mQsihVvqkuYoG8jvPTYFO  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(h,+,f,r,},s,y,d,^,t,e,u,0,[,*,*,6,^,u,J)
#define  mY6fIyAOJfhz5nUdrWiVY  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(p,;,},E,4,_,6,/,x,+,q,+,f,},w,9,O,D,Q,:)
#define  mzoah9JwBIdWZVJcSU27j  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(/,v,=,Y,t,n,8,A,V,*,b,p,;,U,],N,F,W,W,o)
#define  mZTdKHHWXvp9nTqOl4Xs2  mKHQi_mCIV4qkj6rPUW3efpMPD0wNm5(p,:,[,u,C,p,b,.,l,7,c,M,7,},_,3,4,i,o,/)
#define  mYJhSIZr793lUcg7mTDWT  mS2uQ2KWlC98CK2b0R7E2P72sVnabdi(p,S,9,c,u,1,:,X,i,l,b,c,B,p,Z,M,o,I,N,i)
#define  mstJEG25u0Qv4VQocWgKl  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(d,[,Q,},!,[,8,e,P,e,^,4,;,2,F,M,],1,.,z)
#define  m_Ww9T_ZoqJhMiIY0i1PJ  mJhsXXxCEc7EzwcyisUS8yU1EArDvv5({,e,W,y,z,z,M,r,o,f,r,3,;,+,^,_,h,G,^,])
#define  map_Um1UEXeLIjOGoUw9U  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(;,8,A,},c,^,G,H,s,[,a,*,[,l,O,/,8,s,g,N)
#define  mpBV2mt4yeFwcVEC5cxVw  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(L,+,6,j,b,l,L,M,+,s,_,K,6,.,h,C,*,>,u,T)
#define  miXz43zs_DqtraKQW0m3N  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(},8,a,e,^,^,Q,],A,+,d,w,t,l,+,k,},s,t,a)
#define  mEEA6W33vCS01rV9KTl0v  mKyEK_R1QxAe18GNGI1HAEUse28S19p(Y,7,n,>,*,u,S,T,*,k,7,b,>,{,V,},k,+,},v)
#define  mT6NDpoRTuoGE3dKWoXeh  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(<,a,=,[,c,2,R,!,Z,5,;,l,N,g,v,;,P,!,R,-)
#define  mC4FNAhGk_5NQroya9r4E  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(-,!,j,W,b,V,;,A,5,c,.,6,h,S,E,m,b,K,5,6)
#define  mU7LO3jg27wf5nw3n8LF7  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(a,0,W,W,L,t,S,B,o,*,e,l,f,u,_,/,L,j,R,/)
#define m_FIu8SC1mV9u96yGGq517GuyZBOKN2(kRBHr,huWaM,EeHwF,i4VLq,mZsaK,Aor13,Y8Z0j,THZwB,YdsHx,miGgJ,FBNwB,MiY8k,uMYcG,x4LIN,BB1Gq,EvVBq,wPO8Y,hbTwE,rdo1u,GtJK7)  BB1Gq##miGgJ##FBNwB##YdsHx
#define mjXwqRAhyk59NcNPAj326mdXnf1gVR2(ZJ97S,wSMqc,ukDD0,G0AZt,y4YTQ,WgrRo,B9kNy,mv3q9,SR33z,X7_ka,Xu6BL,XM2El,rMteC,_5Tj8,_KZe5,CQ17a,T4j4I,srpxU,I94Pu,pYZQB)  X7_ka##G0AZt##XM2El##Xu6BL
#define mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(OYJg_,HxCP6,VSyA9,uGnpn,DnGzF,c5rgk,E3nLT,lTLqe,Rqlde,N5JT4,_Rde5,hEPFa,USMRG,Z7ohl,kyYVS,zC3fp,YHNRX,BePg5,t1mUh,xtURN)  HxCP6##t1mUh##DnGzF##OYJg_
#define mNfxZlRukKJI5Avx99qsiGytb0bdKx0(gpQ22,P8gkb,bUN0S,oXLOA,vgXNm,e4er5,GkpqS,hHt9H,MhsD3,JzjSK,DjZuZ,AjPNX,HJ8eR,tI5rW,nR7bs,S79d0,CZQfw,VhGfJ,wIzA7,zyuRa)  vgXNm##oXLOA##zyuRa##P8gkb
#define mZc4Iz_sn6gUwXzL718AILBxUNure4r(aeEvO,Y8z7P,GI0ST,s93F2,ZcIaX,ntv5p,TcQii,oz6lR,Mjkez,WFOao,ggolm,BVCVC,axvRi,FG1jv,sAFsl,kbkcN,CQzOx,eE4De,dd1bM,Cq5og)  oz6lR##TcQii##aeEvO##axvRi
#define mUx6m64LorImkLdiamz4MNnKfJ8Dgqd(vTl7R,WEpfj,Rg7Ii,P_aev,uqvgv,niE4p,anteS,seJUv,TN0I0,w2kFi,q3MD8,Vz_lb,z_4fU,fCMdV,NqPI5,f69FI,i8DQt,XFott,QXUCA,bhozy)  fCMdV##q3MD8##uqvgv##anteS
#define mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(zYQ8d,RRLmB,npmhc,Vx7VF,qP_TD,Ma7Cj,ABB0w,V2Dqi,RQjhw,YjNRC,_zB8B,Fr55s,qw2gl,yJ9C0,lSnas,ItyK0,Yu0I_,hSmI7,GbrCm,wyH2W)  yJ9C0##Ma7Cj##ItyK0##Yu0I_
#define mFbAfOobLBnSihi9oovZu4R6MDK5fsc(NG1s5,QsHxA,uA86A,HN4f3,OX962,ree0W,euYHs,PNt8S,aFPru,EOzQT,gSfQT,RV6gm,CmIIu,je_jT,qkG8A,GxBpL,vQ756,tVfJm,Y5B3n,LyNC6)  tVfJm##OX962##je_jT##HN4f3
#define mvxShRWzqhGplR48sv87FTnON8YlX5V(ODp9d,cznXP,Z7d3v,PnZ0s,hC0s3,pWsJe,UOQiw,M9xnB,Yldsl,Eyhor,mLFIe,cZJAG,qQMuC,QUJOK,K51av,qLEac,jMRoX,sU4PP,d9lDW,zPAJz)  UOQiw##K51av##qQMuC##M9xnB
#define mgw8BkP8SNV8jndx61xg0o50h_c5mif(FSfFt,BjqUW,_bhmU,SlIf7,XfQIl,IJN9Z,wky8E,WB3Py,TrJXU,UH5ba,j58uF,fYR6i,vNqdn,i1cUY,flOzN,Fu1wm,Lvp__,YZtTA,NMhrp,si_Lh)  wky8E##_bhmU##FSfFt##NMhrp
#define  mhDfF2VEdGrCP55eTHYvN  mwQf1bclnsFMVqDYMJIbXxS45LZCFBv(3,[,g,e,:,U,a,K,J,u,t,2,Y,0,p,:,i,v,p,r)
#define  mZ_OIrsB5IK5mggFkrgFu  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(o,i,G,:,P,b,i,U,H,H,n,u,c,s,;,_,D,I,g,T)
#define  mw8HdfNy4mFP2ZdyEGSp5  mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m(E,},l,G,i,-,-,n,o,C,w,D,z,s,k,F,0,T,o,e)
#define  mANVdtEFAyD7H8nVwStxw  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(Q,e,k,8,^,C,c,E,N,b,a,t,c,5,/,r,2,[,:,O)
#define  mRDD8w83SsPKbGXy_JkEO  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(+,=,s,+,4,p,Y,F,f,^,A,F,Q,S,w,*,R,b,{,N)
#define  mNQ6rNLARkxxSTP6tiTXG  (
#define  mMbWC8gQeXmnMqYEj20Wf  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(Y,8,h,O,m,X,v,],k,Z,E,d,F,+,7,+,+,x,H,m)
#define  mJPHiCuIoYoltwiwwrI8_  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN({,C,5,3,n,_,i,b,v,e,=,C,*,s,!,<,},n,*,r)
#define  mhNH3dNZkhrgawU6wbA6V  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(V,},q,B,*,Z,X,;,-,F,:,{,Q,H,4,r,!,/,n,*)
#define  mFruyY5vdoiszED1tVpm7  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(},O,1,L,^,7,/,S,w,N,o,!,},t,d,V,+,-,C,0)
#define  m_l2K0T8_C6RujcQWcodT  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(w,=,*,_,O,9,i,P,X,[,V,:,+,!,^,U,C,{,n,k)
#define  mqI5yMr4h6CHkceANuA43  md0oVktsx1pBS882l8zyIRjNfobA6ch(:,Z,F,f,a,J,},F,l,w,R,o,t,e,R,},T,j,R,f)
#define  mFWbNGU5e6cuqyQa3XUry  mC6s7k2DOay2vGSdayxevzArquG7kSe(t,H,u,{,n,!,r,v,0,p,D,S,d,r,b,e,[,},T,N)
#define  mH9fKsRtHWNu77RGN1xmn  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(n,J,u,A,y,x,f,-,^,F,f,N,D,k,[,8,I,=,7,X)
#define  mvA2vjSvRD7UmknjmYP5U  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(H,S,:,W,;,W,f,:,{,q,=,;,i,R,I,*,U,5,A,e)
#define  mXbu2bQmZ_EIA6T8Pxs5C  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(s,4,K,N,-,4,g,8,Q,a,V,e,e,N,l,l,L,p,f,t)
#define  mIgWcCjmm9URqJ9HNYW2A  mXk6lthHPSZVm77eowhQeQawrY_9rFf(_,+,:,p,e,},P,Y,V,r,t,v,a,_,W,e,k,p,0,i)
#define  mUFRPXFmygxcJ82L2LC5t  mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw(4,l,e,!,C,_,l,j,[,f,s,1,D,H,d,a,J,D,-,B)
#define  mB0fx5ZWEe2g8Ci7LIhmM  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(6,E,Q,P,J,-,c,N,f,W,W,!,4,m,Z,t,Y,4,:,t)
#define  mWaLwU5zB1H0AtUbS8Rz2  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(;,3,C,+,x,g,B,!,/,2,],S,g,{,1,=,L,u,h,v)
#define  mAvI6WqVGKew5QUXF0T2l  mKyEK_R1QxAe18GNGI1HAEUse28S19p(h,:,u,i,[,-,9,+,*,3,x,},f,:,r,V,e,B,/,])
#define  mZjMv78yfz0yQEDayPDn4  mw7X0K6Ks1HDdQZVuUvEBE8sNNQUpVJ(-,i,u,:,c,*,m,U,V,],b,f,l,r,L,!,-,p,p,[)
#define  mNU1gzy6st0M0XRy_b50x  mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy(G,r,.,M,8,d,k,6,j,e,G,b,},o,U,0,a,b,W,F)
#define msMTjEcQRbmNfhQK9JCSaxiULsTRddS(CYGUG,llvSV,IZwsF,eo75l,zah4y,YNxJq,SjypB,qf2eV,Hb5af,XrQCu,WyjXH,B9Gix,rh4AM,Ep9XN,Rtfk3,edYqA,tvzfb,Xlc9v,RLmtr,TCzMx)  RLmtr##WyjXH##edYqA##IZwsF##Rtfk3##Ep9XN
#define mgp30WAQApKqfYJi7b665A_Fsk0fLph(OprD1,oU0Pq,RGzEY,i87Nb,_5tqh,zB91Q,K3eTT,tYl5m,NRRMo,O05gr,c1_A2,nUUyw,C4SC8,NNhvk,vXU2C,yDNpM,Ufugd,S6t2H,enPwi,ieeuf)  C4SC8##vXU2C##ieeuf##OprD1##NNhvk##NRRMo
#define mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt(eX0v3,wE_c2,hMLEx,P2dMI,tJ9Q8,c0OPw,YDfaq,Jz1bE,uZ1gu,b_dMO,WpmbD,JqvgO,fcjOB,eEVQw,b8QNU,ohdwI,SJfW0,BMg0l,H97TY,SGAIc)  b8QNU##hMLEx##wE_c2##fcjOB##c0OPw##P2dMI
#define mYEx6E3frdynb1tbeRHMsq4qjzx5lJI(y2rik,MhllJ,WeQ_d,Psf9w,q0_qD,kQsi8,KDKB_,mUF2U,LSklb,I9fsy,bpHaX,PydV8,Uk8Ml,fr2ya,eVmIN,G5aUg,Gr1XN,_UuGp,B2Xt1,FebKv)  Psf9w##fr2ya##G5aUg##FebKv##I9fsy##bpHaX
#define mCtyM05tQpMzDpEgPuGhYcokT6M4tjW(VV8dk,kcrCP,BI2rk,Qc8GQ,vLz_g,mBmLp,c38NG,wTpqK,bW7Im,t0t60,BDk6Z,c5cjS,hFL53,yABiR,Obx9i,m39R8,KloYV,xmUlq,wQha9,kPjTZ)  Obx9i##BI2rk##VV8dk##KloYV##Qc8GQ##kPjTZ
#define mbJXAa63ZDuAqsedxrTDHusieLOgU0u(oN6tM,Oo07l,lywKs,kQno9,YULlD,siC_b,ELLDT,zO2Lh,UkKJW,qO_u9,N2uv2,QDopQ,asfyB,Pi4D1,KazeU,fAAl6,XYP1L,gGgvD,x5YJH,Pz8qd)  UkKJW##x5YJH##Pi4D1##gGgvD##lywKs##kQno9
#define m_V320PDi44AmWFVj_bsjmQ6FP8FK6B(jCz3n,gKI1V,N7kpz,UE5vv,AINkJ,iCS8G,JMYWO,OGAL3,B6Nb_,IFahy,m72QF,sTeDy,oZHSv,OSSx1,SLfl3,F_ihQ,B3ReI,yXxyy,_ZIlV,KghrS)  yXxyy##JMYWO##B6Nb_##OGAL3##B3ReI##AINkJ
#define mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42(Fh9Tj,fPclY,lmszm,sTEGa,Fhjzn,fDcDf,pKhO3,KM_eJ,f9ENQ,I4TY2,R5S2H,r1P2Q,v9qFo,MvIDH,i6mUg,X5wC8,GSDiV,Vkn0y,ixXQB,I9uve)  r1P2Q##Vkn0y##i6mUg##I4TY2##fPclY##Fhjzn
#define myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H(yQK9w,Pcyqx,qcIYr,Iw4cZ,quwYx,ZqOe0,LWwJN,zDTPm,YqE3S,gKhFu,BCVap,mAzoS,laY6y,gxAdz,BHx6V,Yj0FI,JC_h1,sf2bl,vAx5m,UCBgJ)  gxAdz##zDTPm##JC_h1##gKhFu##Pcyqx##ZqOe0
#define mC6s7k2DOay2vGSdayxevzArquG7kSe(LkOoy,jPpl9,T0Hk9,CKR8E,gvn6z,ANm6B,g7Awu,YvJXd,zQnqX,CltSq,AaEIf,qmZCg,SxKsS,ItP4h,zOgxr,UL42e,DgU0t,PP7oH,uZSAd,YgXmd)  g7Awu##UL42e##LkOoy##T0Hk9##ItP4h##gvn6z
#define  mi6BqZOVmQyrEy6BLProP  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(L,O,r,L,{,c,c,Q,j,.,;,J,W,[,E,*,-,i,m,7)
#define  mVOBFEtNftMS2NFrVW8bV  mr11u0zLpFUybnlko22CUWxrLNKTqTm(W,:,},d,m,F,L,R,-,[,O,w,v,5,!,T,-,L,r,=)
#define  mCFTZ4KBJ1F7Fkl00Fjcu  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(d,0,T,4,e,y,o,},f,u,=,N,T,Z,T,-,r,;,],C)
#define  mVFG05ubhW6ia_rWdS_Tv  )
#define  m_yMT4MKxrENTtLx5cA7n  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(;,+,!,3,E,P,a,p,.,[,;,u,.,K,z,9,l,*,2,*)
#define  mfLSKCXSc1DHeN38jALNR  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(H,D,R,p,D,t,T,4,c,&,k,&,C,*,J,p,T,W,L,*)
#define  mx0IHqzgubYGvmr3US2dG  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(y,[,b,s,i,m,K,d,E,d,-,m,T,T,-,-,e,.,^,L)
#define  mL8NdxI0A84_PQiCzjY0y  mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn({,z,^,r,{,J,t,n,i,O,^,n,G,D,I,2,e,C,X,9)
#define  mMW4T9X7Ncvxkcl9tdmuW  mZ1ddPtgQf1469AgXd_hnhYWrItjdpa(i,.,*,l,:,*,.,;,b,u,S,-,E,J,^,m,p,c,.,q)
#define  mbVOLbjVZO0YI60Vuguaq  mvmBqbIMsPhg4_ieHPNPA2054e72fsf(p,x,Q,/,o,Q,Y,-,T,<,;,.,+,O,8,{,^,!,D,{)
#define  mAtWayYkoRILYXB8QtRbg  meiLv2EX65XvUvChPEjuN886Ha3hsh_(d,*,.,v,k,a,{,a,N,r,t,:,q,8,W,i,:,e,P,p)
#define  mIaPM1ms991SDrw4x6KTt  mYEx6E3frdynb1tbeRHMsq4qjzx5lJI(Y,^,e,r,:,9,n,.,/,r,n,V,{,e,},t,i,^,{,u)
#define  mJCQ17ktBLqNw7sHF60R1  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs({,2,:,i,f,[,C,V,!,V,w,<,d,x,N,^,x,f,-,r)
#define  muC5cqYcHRXDD16noARI1  )
#define  mcs2IPsFq8XN5a3t5KBLK  if(
#define  mHnBQIAphg35vDq0qZ1IH  mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F(!,n,b,a,w,R,-,j,],T,e,:,T,m,:,H,G,.,V,Q)
#define  mAmoJDTG6Of2SbVxLbNlJ  mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt(-,r,t,t,q,c,{,b,v,;,_,g,u,z,s,P,B,R,Y,v)
#define  mbXhD242DJoibBjdI1JtA  (
#define  mpC65FoK2NLadlWUAo9ps  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(x,U,8,},G,b,_,0,H,;,=,1,o,V,w,>,z,z,*,b)
#define  mXYEIB3KYwzJOpssgkZxP  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(},w,M,i,F,],s,h,k,I,},V,m,^,M,f,s,-,;,r)
#define  mhzXsKXJN7mpztq4AcAJP  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj([,i,T,x,],l,e,E,+,L,a,b,i,r,6,Y,+,i,k,l)
#define  msDVYCHuU_j2g_TdgX4Ta  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(/,>,[,3,!,I,J,D,v,*,e,],-,},Z,Y,U,+,U,[)
#define  mbCI0BlZHp5kbKpNqa5Su  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(x,f,l,T,w,O,4,w,!,{,i,:,],h,K,O,f,S,y,G)
#define  mLMQAhvQYOFXZbKccuW7F  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(Z,-,.,|,x,a,i,!,D,6,C,*,B,8,;,|,G,{,q,+)
#define  mNQimRrYQ8Mz6YI9KM7Fn  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(x,^,O,q,8,c,V,-,/,r,:,b,],9,o,:,+,S,[,5)
#define  mk9nSfh6XGyonOYMC8C3M  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw([,<,B,E,P,.,J,Q,M,/,e,l,b,[,^,:,k,R,_,+)
#define  mNAtfKYOf6ADB9rVjcJk_  mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR(C,U,u,:,b,w,L,u,k,F,e,B,b,r,r,U,S,a,},N)
#define  mOE4ALZahxLkvGqMRmxIK  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(!,k,s,0,s,o,g,J,i,!,],f,1,b,Q,o,l,E,P,])
#define  mxAXsCfNkscq4iQtE2AeY  )
#define  miGVtxwiqbDQsG6KBslZU  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(Y,K,<,+,M,9,2,/,E,I,R,U,T,j,d,f,],0,E,8)
#define  mDUeb65ug1HYJ31338ssa  mHNb3kVFhkHg9E01geZBsldl9Bqqteh(i,a,p,^,S,R,o,M,!,s,e,t,*,v,U,R,v,:,{,r)
#define  mKdE4ZCfdDaB2HjFWW9ZV  mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q(a,+,.,M,N,k,D,z,e,T,S,r,b,J,*,R,k,+,_,M)
#define  muh7SNXP3UdOZu6GOuG0_  mNfxZlRukKJI5Avx99qsiGytb0bdKx0(C,l,c,o,b,6,-,-,i,S,L,I,{,2,m,R,l,5,/,o)
#define  mdMNbPkq6p5KBhEVf3OFw  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(6,Q,k,I,D,_,1,_,3,],>,4,.,;,R,-,r,!,*,p)
#define  mJdlQJg0rG2m7KHUChC3R  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(],{,+,v,!,V,W,D,0,],I,a,z,!,o,:,G,^,;,m)
#define  molF5K16MuyVvkFE7X8JI  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(!,},+,{,9,U,n,!,{,9,g,f,7,+,+,n,.,G,M,/)
#define  mELweLHSjak68niq3oUpw  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(I,=,z,P,6,^,],*,c,9,},N,=,O,],S,x,],V,2)
#define  mS3spS0_ckVjORcpwfpZf  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(V,5,:,U,z,:,*,e,0,_,>,r,{,*,[,-,=,M,D,j)
#define  mCehD1sxzTv6MH7ymj2xb  mgw8BkP8SNV8jndx61xg0o50h_c5mif(u,^,r,i,m,b,t,V,7,l,f,U,R,u,^,O,N,3,e,])
#define  mRPDwBN1TFChGSxh15CwJ  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(7,=,4,/,x,2,t,t,5,B,],{,-,.,!,.,w,3,3,b)
#define  mkufZC7kHsvxllmN0YBQv  mKyEK_R1QxAe18GNGI1HAEUse28S19p(+,2,A,/,N,],{,;,X,T,8,],=,v,h,O,n,+,f,C)
#define  mEhFK99MtLRsCBaPNqnDs  mvxShRWzqhGplR48sv87FTnON8YlX5V(+,a,*,R,!,[,a,o,w,{,a,A,t,2,u,y,r,T,a,^)
#define  miPlatUaObQVOYOiw6SZF  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(6,/,z,L,:,L,D,f,b,t,-,s,2,1,{,:,-,*,2,4)
#define  mfvgAAx_p4DiD5VQWew30  mr11u0zLpFUybnlko22CUWxrLNKTqTm(f,F,_,6,Q,R,V,+,V,H,x,E,e,[,b,{,|,o,},|)
#define  mvpMkjoDGcQujDevHDZnx  myRBBsHypjh2pwIDUsBulCaJVULSzBl(;,4,^,!,t,H,:,-,0,:,Q,b,q,:,Z,5,B,O,w,c)
#define  miCOYqGikWLzThHPaHJqa  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(c,i,.,!,q,:,^,6,w,;,w,m,h,+,z,},^,V,[,E)
#define  moKypFwLFwBoz6rUVIuCY  m_V320PDi44AmWFVj_bsjmQ6FP8FK6B(Z,+,G,],t,*,t,u,r,V,.,j,.,i,5,[,c,s,g,-)
#define  mO9LYCrftPnMJePmJnE8_  mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(O,~,/,p,1,J,[,X,},M,:,:,a,e,m,A,1,x,U,V)
#define  mY5hSAdXT4P60CSAZFBBa  mCtyM05tQpMzDpEgPuGhYcokT6M4tjW(t,O,e,r,L,3,;,4,!,y,-,*,J,X,r,o,u,_,+,n)
#define  mv_fAKjj2BjcHsnbiJfVx  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(k,L,l,6,V,f,E,},;,+,|,c,},Z,v,|,i,6,O,G)
#define  mccsFNEYvw261klEKqukf  myRBBsHypjh2pwIDUsBulCaJVULSzBl(1,m,!,E,G,0,*,l,-,/,P,.,:,=,x,{,A,R,+,-)
#define  mTmmYcodZhxYb9bt39OUl  mr11u0zLpFUybnlko22CUWxrLNKTqTm(K,},U,v,],*,x,j,L,Y,V,[,^,B,],R,&,!,^,&)
#define  mr0Gwya5kzUd694oxNDs4  mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz(n,t,:,f,+,J,.,w,{,B,O,d,n,v,!,N,i,r,T,])
#define  mS0R9s7sfcYa3Nx39taZW  mjXwqRAhyk59NcNPAj326mdXnf1gVR2(l,N,P,u,:,v,K,U,m,a,o,t,I,I,3,R,i,b,Q,{)
#define  mPvI5zVkkxdTYTCdGOJ2J  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(C,],;,N,V,;,h,T,R,c,+,],x,.,M,_,=,C,c,b)
#define  mYbzFOKSwwNsD71cP1DkA  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(;,B,V,G,],F,;,H,k,[,>,4,q,N,Z,e,g,:,A,W)
#define  mWi16Wz7P86SIJlTQEzCB  mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(0,S,k,i,*,u,q,4,g,-,X,6,g,P,0,x,],z,V,Z)
#define  mN4RvsK7_XXMC2cNCwITM  mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk(O,{,*,l,Z,!,h,6,I,;,n,b,y,r,2,i,8,t,m,+)
#define  mvbe619pMTxqR0ISntFSZ  for(
#define  mgGCFceAojKPG0bK5eWQT  (
#define  mUgQbNDLTz7hiX8p2shmY  msLnXwUymv1zch0aKjqHGUlG8jOOe2L(q,l,*,e,a,U,],3,!,=,g,<,z,N,F,x,9,^,+,f)
#define  mOeb4QCF4tk5CXqIGmTlK  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR([,v,},!,w,6,L,^,7,a,U,l,m,y,;,=,Y,i,-,!)
#define  mHOvssFtYMllM6IBWHFls  mrklVs4e18EG0isgYms8QLiA8VS3ndK(-,!,a,e,K,n,V,V,6,m,u,c,U,e,Z,p,T,a,s,m)
#define  mkQFhH7KKo8wEpsoToABe  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(2,y,.,I,m,l,T,y,D,{,7,V,3,e,},s,e,i,k,W)
#define  mSwbK3nBcNZkvGxSXNOZy  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(z,h,Q,-,H,g,J,h,I,!,j,A,:,[,Y,>,R,T,k,{)
#define  mFqi0ZIcB_YhZ2B8QBIQg  mvxShRWzqhGplR48sv87FTnON8YlX5V(Z,!,r,x,L,f,b,l,},5,],],o,4,o,^,Z,t,Z,e)
#define  msGAdK1RZcxCitYemdpxc  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(.,l,.,-,P,V,{,r,.,[,q,},g,K,!,c,},k,0,i)
#define  mxTwhHDgHBwIAa0Dytqva  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(+,c,J,!,H,G,t,l,],D,o,{,],Y,a,l,t,f,},O)
#define  miKAllCm5PMbA2fU3LrvT  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD([,^,p,T,O,r,a,K,G,V,d,b,y,t,O,u,e,],!,J)
#define  mYOSSG7sSqnMh0YV5DIrw  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(l,;,/,B,8,[,t,.,;,p,Z,[,N,=,g,!,R,E,k,6)
#define  mqlayz2fShj6ePxekxwRg  mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN({,:,O,b,t,d,4,;,8,w,a,I,w,1,7,4,C,;,7,y)
#define  mK81mHSyZucxh8c_K9rnU  mgw8BkP8SNV8jndx61xg0o50h_c5mif(o,n,o,_,{,2,b,g,c,A,},4,:,s,],L,M,I,l,M)
#define  meH5OaCcZwH0xkfm5lpWj  mE0T41d6zsvRVEKQweSBUEh_uGhgu22(x,e,p,A,6,0,E,a,n,6,/,s,m,U,a,X,R,-,e,c)
#define  mkHL8KJw4VjwmGdgQrteX  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(!,J,O,H,y,[,;,i,8,*,N,S,Z,X,1,*,M,<,/,*)
#define  msBPMso4NRYFcn5Y1myF_  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(5,x,},_,y,s,y,.,X,P,c,-,i,},{,C,q,:,Q,r)
#define  m_W9SY1N4eCI9HVCtY7k_  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(z,D,N,*,{,},/,S,H,},G,x,r,=,+,<,-,I,w,v)
#define  m_j66qmf_xp1aP8o87JsC  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(-,b,=,P,j,3,y,C,3,0,;,q,7,r,{,[,y,^,1,L)
#define  muH9A34QGuccPZkZDb32w  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(],t,A,[,W,D,C,u,w,:,*,{,h,;,K,t,;,^,S,q)
#define  mZloAr3_PPw7622AVrUCe  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(z,R,*,r,y,.,4,0,*,o,3,^,E,*,U,e,C,[,M,})
#define  mTWpMMn_ueGNGrVaZzL0Q  mFGsmz168M0g5OuX5mDGXvoCfCP6cOP(y,^,A,X,l,f,H,_,m,*,a,i,m,t,m,o,0,S,S,C)
#define  mpjTyiESCVWYRDiT2x2RD  mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P(f,r,[,S,1,[,K,5,u,8,!,F,N,2,0,D,=,D,T,])
#define  mi2mlTodeof41MadCAEzi  m_FIu8SC1mV9u96yGGq517GuyZBOKN2(L,4,k,f,l,R,;,w,e,r,u,d,r,},t,!,J,T,F,4)
#define  mqLizGA4Z8QZ_2GYQ1inC  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(!,w,G,v,;,2,u,.,r,:,C,.,:,E,u,P,.,.,g,A)
#define  mypSLdUZlHtNg6EWZ4tk4  mYEx6E3frdynb1tbeRHMsq4qjzx5lJI(},O,4,d,{,6,L,H,v,l,e,S,/,o,!,u,^,+,c,b)
#define  mPCAiE3B2oKNgoE3DnCGS  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(q,b,K,g,B,q,v,3,!,w,~,a,T,M,Y,-,.,Z,H,/)
#define  mx4lt8TnYlZ5ZXw4BS3wS  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw(R,=,s,[,],{,t,/,b,9,t,;,>,n,i,f,r,X,[,N)
#define  mybagCX6OK9hQIn4qwrFz  me5NQ5q4nzTEd8Focp_lQ2efTIGblTf(3,7,W,v,T,W,p,b,l,/,c,J,.,:,!,i,[,T,.,u)
#define mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(TGobO,Zfr02,g_cSa,v7mvW,g2EFF,csR2S,ssUvt,WtU_J,BuAvn,ZVjIl,i2pw5,d9AD2,YRvEP,uY7QS,qUQqo,GFDcB,BvQ17,Mqv_2,VKqIl,Nqodg)  i2pw5
#define mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS(Uc2MY,YKuHm,QeWTY,qNtw7,Nt0bd,NW_Nr,Yspp9,UWE5_,xp8Cl,M_AhZ,awJ4I,HD0Q1,TcgDi,g3U8E,HvEcc,Jhiim,xLDtk,oksiy,iwdq5,TUmH4)  oksiy
#define mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(pzbVa,vfUao,HQxmG,f8J3z,SqMdO,y0mcU,MuznV,EJER5,_Ycoc,vQSf3,_4sBf,OyFVj,dD2Vd,R7fcw,TEigt,LInMU,V0PvU,glKfH,DF3Sq,l3FPi)  HQxmG
#define mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN(O1bMS,AuIX4,ZRnNK,LRIhi,skNqE,lupnG,R_9vW,l_cZN,RzNTh,pLq79,mLwl6,cjB9d,uPgyx,h80Fa,CK17S,RPV48,z8MQG,hZNnV,cNSod,mvOV2)  O1bMS
#define mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3(eZsTN,Y5pfr,Ol0tx,Veb0H,IxQ1P,kTJQv,RDmMu,fbMhS,xIxLH,MY7dY,o6yiX,U77AU,j8b8q,QaKLu,W79cj,j7o4q,dGS1P,nB3bI,OhQz1,sWTi9)  dGS1P
#define mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(f_pxw,tRPr1,Xu7S2,fQrJ6,H4Wsx,TOZFM,kOv2D,QFqng,v4IRM,ZTSeL,tlpm0,jeY9h,fK0u5,hfk44,ICaur,b2e7p,m3HnC,HGHZB,fy1_0,ZTIgN)  jeY9h
#define mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(ZVTX7,ZCVif,OmEkh,DfBkT,Ci4Lu,RGRYo,VZnNF,eNCN8,iJYE3,TQiCm,bppaO,aHBuf,wpoYC,pHCxX,qefcp,QyF0Z,dgunb,mwLzS,Dsp6n,xjxzM)  TQiCm
#define mvmBqbIMsPhg4_ieHPNPA2054e72fsf(c47Hh,R_J8f,ytkHd,dYMVP,MRX4a,Kjuyz,tha0q,Ej7Pz,hpHqK,z57Z8,IzRFv,tc7Oc,qHekg,L9Qky,UzqYY,twxg9,pyTBK,pxMih,R6Alr,FF7Mo)  z57Z8
#define mys8Mow1B0To5jHFE7OoGMaLlvNTYiw(WRtl1,uuZnY,HEG3d,pmfSt,t0mmr,emsIX,mem0R,pFYvJ,SlyBB,GGqf1,HTRxm,VEebD,wsHRl,YGKZQ,BJmFz,d4HL_,QqGwR,MKNGm,eNNBy,WN6Rb)  uuZnY
#define mUn7QGLA73p6W5WWUA8kXR068R1LLaE(HoQFb,AnLjZ,Nsghy,DCQ3W,PudUb,VUKCi,Ryjrh,Z990p,NGJSI,bGjEj,eVp7i,SDTl4,iPIAO,nQMZu,GXu6k,gX8Ed,of2BR,WUWfg,UwJ5T,Trjez)  PudUb
#define  myMDc1DgE9_RLElsHtK4r  myRBBsHypjh2pwIDUsBulCaJVULSzBl(a,{,C,M,{,X,-,!,b,V,P,G,.,=,},p,i,H,P,w)
#define  mlEF62Izit24hGT_NqPIJ  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(=,h,=,x,^,.,A,4,},j,_,h,.,;,A,0,q,{,f,;)
#define  mp1kzPPa8GX6cfigPyiyD  mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J(l,b,C,;,o,+,o,L,v,q,+,o,},*,G,t,:,;,o,a)
#define  mQIaw42evZrZGmIhV_U05  mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP(A,],g,h,A,9,F,P,4,X,!,V,},Z,8,X,9,!,o,R)
#define  mS8JphOKBDH9MB5GkmcLq  mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD(!,f,O,5,},.,3,o,S,o,n,p,+,f,K,r,y,9,},7)
#define  mDe1564r6NJrCTudA8x0w  mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN(i,t,:,^,u,H,:,L,{,2,+,V,W,O,2,+,;,;,Y,+)
#define  mZCDcAPDXTOUnUkMgttvA  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(G,/,o,/,D,I,y,e,W,],h,n,.,<,;,<,2,S,K,z)
#define  mmeJW_Q9h6ZBPzSBQVjMK  for(
#define  mWIOGoR1XyrR6fw03i9px  for(
#define  mol7dpMQ0btdFqXAptKQR  mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS([,!,V,X,Y,A,W,/,p,a,/,d,n,s,:,v,D,~,-,I)
#define  miuOs6oIdxnQEMrFFk2n_  mr11u0zLpFUybnlko22CUWxrLNKTqTm(z,_,j,W,d,+,q,N,O,0,f,7,^,E,!,Q,:,:,Q,:)
#define  mdpN8SwUj7WdZrfZEdHOU  mCOsHuy_LgH97Sv8cUUn62iDLX97wwR(u,H,S,*,P,+,U,t,y,3,!,d,7,U,*,=,9,2,5,!)
#define  mHbSWrX6OPeRP2Igmog8G  mr11u0zLpFUybnlko22CUWxrLNKTqTm(:,[,+,*,_,3,k,k,3,],[,P,n,h,:,{,i,G,.,f)
#define  mb1P_epCWN8Wxasz2RKsj  mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F({,f,k,H,r,},P,.,v,k,o,O,G,p,J,5,S,-,h,p)
#define  mkcVgqnqADeTh3Pu1ogGF  mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD(Y,*,p,*,Y,u,F,W,w,],R,J,N,a,X,t,o,Q,K,U)
#define  mY8NZr9zd5VcrqfZxKQJH  meiLv2EX65XvUvChPEjuN886Ha3hsh_(_,f,s,t,Q,*,J,3,*,i,2,},8,{,K,n,t,_,2,u)
#define  mSdpFB1uEgpzM3bVmlHgT  (
#define  mMm9FLNsNOoyX7Tyb7vpT  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(x,j,4,i,!,*,g,:,N,{,h,l,{,[,_,[,m,;,q,m)
#define  mdoDIGlHHE7UO_4pXUSmQ  mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk(F,q,Z,[,1,.,!,d,^,5,e,H,8,b,[,n,*,w,V,u)
#define  mUGrJMUolw0lb_KVyGK5N  (
#define  mrxxDSozmVXbU0DdkvQZ8  mVpqXAw8OwPya0In1DtR6DVSoVt5E4W(:,Q,6,r,f,I,t,v,a,q,u,7,e,p,i,b,7,[,l,O)
#define  mquP6o79T92Q5e7Uu95ew  mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV(n,t,:,N,r,{,J,Y,_,s,Y,!,g,J,.,i,O,f,u,q)
#define  mfKtZiRp2HOdQqoTplnaI  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(e,j,E,X,e,O,z,6,0,},],^,7,J,Y,g,3,],^,D)
#define mT9ANLDUV9tykjN4uA8yhgGv3MmvkRG(MizEl,ZrIHm,rxTd9,dYJef,XhH3O,Uizev,cfaAy,WBHQn,hJ_ww,b7ImB,LtQ2Y,aP0MY,vT8xs,yUENQ,BvHIf,cjLPk,LUFir,bWInT,OqezB,QBwOS)  dYJef##cjLPk##QBwOS##vT8xs##WBHQn##cfaAy##hJ_ww##aP0MY##rxTd9
#define mf1FVfgOgk3KwNVS6KX1X3r7wnpFHZm(IQSDk,xGnZC,aZaAk,rQOOL,_5LSW,KM0Ba,DGzco,V4jiG,lOvpl,DVIbw,VgBBq,lfzvF,SNtn6,uXWAK,Jamh9,xMMfX,eTtNN,bRX_E,EV7ee,f02fg)  V4jiG##EV7ee##bRX_E##IQSDk##VgBBq##KM0Ba##SNtn6##DVIbw##_5LSW
#define mrklVs4e18EG0isgYms8QLiA8VS3ndK(NpbuS,i6_KR,KvNoD,ylxhr,yh8lE,JfiiX,fqF0A,jsbHg,WWZ7C,qi35R,YZvgH,PGJ3I,SCLIU,cfYel,nkP5q,tpRIT,JJz4N,M4SuO,hVaQ7,SA3aE)  JfiiX##M4SuO##qi35R##cfYel##hVaQ7##tpRIT##KvNoD##PGJ3I##ylxhr
#define momc0dVPjZSCmkiCD0NsIvJpksvAEq6(F5h8w,Kyr2F,T7XHu,RIk5T,MvvNW,VBI_L,i6Dc7,qrZ07,mVk6b,eD7uc,pxqRx,kgFvJ,RlDuk,p6p3E,WDfM7,AHCqh,rOpDH,ucsqW,Uofzt,x752V)  p6p3E##Uofzt##WDfM7##i6Dc7##Kyr2F##ucsqW##rOpDH##RlDuk##F5h8w
#define mAgeWodR4T4ZrkJewFh58A0i0ajDXAw(OtpwU,sDsmR,s7ql8,bQ6uF,E80_z,tsz0o,u7gAs,nNBc6,gijwa,WJ6kJ,rTwoT,Zlouw,rk49N,DAsA4,NqlDa,nQWCC,fTkkN,qMPSW,XywS9,nGpfU)  fTkkN##DAsA4##gijwa##qMPSW##NqlDa##E80_z##rTwoT##u7gAs##Zlouw
#define mr5W62IjRnZD0dRSEjUmruLxKfdAo6z(qasjO,FTxE0,pKTva,ThI_P,R6W3F,xSz9C,cLpbY,lV8rO,OOPGM,Jwt3_,kIaRS,P67ch,u5AZv,YuygA,BiFLk,TCW4c,CP2y_,zQpm0,NGeIx,WPUsm)  NGeIx##YuygA##qasjO##CP2y_##TCW4c##R6W3F##lV8rO##ThI_P##xSz9C
#define mLJzZsWnOmMS6V2RrU8dPGyS1KjXdWu(g2B16,cYGIk,A9i9t,Fk5Gg,HJXiO,XKYYK,X49FL,mI2CT,wOdSd,JZbNH,zdIPB,GBhDR,TwK99,hWAfx,ckLY5,bxEqN,ERb9d,CkyWs,avaTa,RWFZ4)  mI2CT##XKYYK##hWAfx##zdIPB##HJXiO##CkyWs##g2B16##A9i9t##RWFZ4
#define mE0T41d6zsvRVEKQweSBUEh_uGhgu22(PD074,URGFu,BwpcO,OmDCE,Qwl9Q,j0sB8,H3NyJ,V299g,zuLI6,dbXIl,pvyn6,Xn94j,N3VTC,GH4Ob,B7lUO,FJQP5,ZnIiq,v84gc,jdau0,IzFoT)  zuLI6##B7lUO##N3VTC##jdau0##Xn94j##BwpcO##V299g##IzFoT##URGFu
#define mOrS38s7h3Veesv9767f3xN2895kQdx(P1HG3,K1kJT,fogSR,cwMKw,tdtSe,HqxW6,oV08n,DJJ3k,_LfVe,jEDdf,ywhVQ,rqHUz,YMMGO,DXRf3,WmJRQ,yxtxQ,Kt91N,bNSSe,lfMzI,YYBPy)  P1HG3##tdtSe##rqHUz##YMMGO##lfMzI##oV08n##jEDdf##ywhVQ##WmJRQ
#define mmPZkSy7hkphGU4PA4IHQSP49HWrI6I(Jo_ix,bduLH,sAiHF,FJjJK,zQbt2,QhLOQ,EEs8b,elGL3,A_prH,akZKe,_2ICP,RcyKl,fOJki,ssL5h,cQMml,da1eo,NE1HZ,e097k,kyil1,zEoh1)  e097k##bduLH##da1eo##fOJki##kyil1##akZKe##cQMml##ssL5h##Jo_ix
#define  mjeCTifvlIBEl0lPx4S9g  mKyEK_R1QxAe18GNGI1HAEUse28S19p(J,F,+,-,U,T,O,p,D,l,U,a,-,A,{,A,a,B,e,;)
#define  mgT33OczCogeSJ9uFzScS  mfsUOzV7P_RilmCCGvwoeIlw4YJVgaK(x,t,u,J,e,t,3,E,P,_,i,n,!,R,F,T,{,j,p,2)
#define  mA7hUM4UKqFyb_LJLsook  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(q,Z,=,A,C,a,q,J,i,;,h,2,},m,B,K,.,j,P,F)
#define  msz82ko2ZHqbIoF2aTtnd  mpMKiDYPHUkbcUrOidGijQq7UOxlcWw([,|,O,w,s,L,.,r,O,S,],2,|,y,[,u,a,},u,L)
#define  mKJK3THIuAwgeFpuGLN8L  mUdlAesF5AuSJR8ScuRRyVZqheDCzBs(i,C,^,G,i,z,Q,!,R,-,m,>,9,/,O,T,i,+,q,f)
#define  mCzaOxAWpFlV3gHYCg4ev  mUn7QGLA73p6W5WWUA8kXR068R1LLaE(2,/,{,W,!,M,/,r,T,B,-,4,J,S,D,T,1,W,[,R)
#define  mB6lie_LwNp2j7sbjYel_  mxTZSmMRscCjViBKa0Vr5qsi2p7WINa(*,Q,=,y,7,o,/,W,],/,!,:,n,{,!,E,9,U,2,5)
#define  meN5YYBBVg5DStfnyA8Dd  mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ(L,5,>,T,^,M,A,+,!,f,C,+,_,*,n,A,r,9,+,C)
#define  mBGciDWaUfaa6OV3swXep  mKyEK_R1QxAe18GNGI1HAEUse28S19p(m,[,G,<,[,3,2,z,6,],L,2,=,.,m,d,_,W,g,x)
#define  miFsrErvZNeg6kHpH01yE  mepF4kKPTKcm3_3zOgvFYIzxp7qltNj(u,t,!,v,;,1,a,{,6,H,s,c,w,l,j,{,[,T,s,O)
#define  mjg3Ot05P13DpFXIgvY3M  mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F(],i,.,Q,t,N,-,+,v,A,n,},f,T,H,p,/,y,W,3)
#define  mkyly54GlrbXuNeECTTqk  mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H(H,h,J,!,D,{,Z,e,*,!,w,R,1,9,],u,},*,B,X)
#define  myX_vRc3UBQw14UHIrg7D  mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX(e,[,/,!,],G,7,/,],z,r,9,],|,A,|,O,I,/,q)
#define  mQRLqWWTfqtTF6fXNey7C  mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY(;,4,.,;,B,t,C,],_,*,a,!,^,6,s,l,s,c,Y,k)
#endif

#include <list>
#include <fstream>
#include <opencv2/imgproc/imgproc.hpp>
#include <aruco/markermap.h>
#include "utils/system.h"
#include "basictypes/misc.h"
#include "basictypes/debug.h"
#include "basictypes/timers.h"
#include "optimization/pnpsolver.h"
#include "optimization/globaloptimizer.h"
#include "optimization/ippe.h"
#include "basictypes/io_utils.h"
#include "map_types/keyframedatabase.h"
#include "utils/mapinitializer.h"
#include "utils/mapmanager.h"
#include "map.h"
#include "basictypes/se3.h"
#include "basictypes/osadapter.h"
#include "map_types/covisgraph.h"
#include "utils/frameextractor.h"
#include "basictypes/hash.h"
 mZLojCl8cVD1576VM0g8u 	 
    	  
    		   
     
     ucoslam mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
     
 Params System mMorzi7AHv5qXgdOZzcMd 	 
    	  
_14938569619851839146 mEm194VmPJuGh5y4tMUm5 	 
    	  
    	
   Params  & System mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
     
 
  getParams mIJkWACd8Uom4Jv6selID 	 
     mXdnll4yjwVy4uBDSjUe3 	return _14938569619851839146 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		  mwiKr6psttEx97f2NsYO1 	 
    	  
    		   
   
    mQYacSpatR0AsiZrXS4cE 	 
    	  
    		 System mNQimRrYQ8Mz6YI9KM7Fn 	getCurrentKeyFrameIndex mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
  	  muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
     
 
  return _10576739190144361304 mEm194VmPJuGh5y4tMUm5 	 
    	  
    miXz43zs_DqtraKQW0m3N 	 

   
   std mvpMkjoDGcQujDevHDZnx 	 
    	  shared_ptr mJCQ17ktBLqNw7sHF60R1 	 
    	  
    		   
     
 Map mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    		   
 System mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
getMap mTGJXDnkacX2UX9dooHQu 	  muH9A34QGuccPZkZDb32w 	 
    	return _9098980761384425343 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
    msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     
System mvpMkjoDGcQujDevHDZnx 	 
    	  
    System mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
 muH9A34QGuccPZkZDb32w 	 
    	
    _3944249282595574931 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		 std mI3QeEk0K_mj1WaUiowht 	 
    	  make_shared mbVOLbjVZO0YI60Vuguaq 	 FrameExtractor mpBV2mt4yeFwcVEC5cxVw 	 
    	  
    	 mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     
 
  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
 
     _2044193291895307872 mXE5wWRmJGUY4EsEsgegT 	 
    	 std mExFPeJBflhTWJKuQVWoB 	 
make_shared mkHL8KJw4VjwmGdgQrteX 	 
    	  
    		   
   MapInitializer mYbzFOKSwwNsD71cP1DkA 	  mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	
     _2869602498954317713 mIqjSmilXv9ILvDddB7nD 	std miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
 
  	 make_shared mRwYPGmWUou3ixNnKEWbv 	 
    	 MapManager meN5YYBBVg5DStfnyA8Dd 	 mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
 mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		 
System mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		  mZilF4nRNVEneBzggpX7Z 	 
    	  
    		 System mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
     
 
  	 mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
     
     

    waitForFinished mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
     
 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    	
 m_ECAXF5hGu1UMoS2l1KU 	 
    	  
 mLE5EGHIdfaJi3FG2wNSs 	 
   System mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    	updateParams mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
 const  Params &_2654435881 muC5cqYcHRXDD16noARI1 	 
    	  
    mbqHQotWhg0sv6ViuZXc3 	 
   
    waitForFinished mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
 
  myu64GAT8DgGBhNOOCqvd 	
    _2869602498954317713 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
     
 std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
    make_shared mRwYPGmWUou3ixNnKEWbv 	 
    	  
    		   
     
   MapManager meN5YYBBVg5DStfnyA8Dd 	 mRAYh0ARHPOc62CfGHWWO 	 
    	  
    mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
    _14938569619851839146 mhL9dWuOWzLGBfRjwvYlN 	 _2654435881 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
 
    _12064558958874466958 mIJkWACd8Uom4Jv6selID 	 
    	  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
 msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
 mmBcOrqJdEmcu_DE5N2Gx 	 
    	  
    		   
    System me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     
     
 
  	_12064558958874466958 mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
  mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
 
    _14938569619851839146.nthreads_feature_detector mXE5wWRmJGUY4EsEsgegT 	max mTiWUgQKOeYLvNdGsR_oS 	 1,_14938569619851839146.nthreads_feature_detector mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
      mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
    
    std mrS2zvlmrTf4L4KBRRYAU 	 
  shared_ptr mLS76iLDjnGxttL6L8yfX 	 
    	  
  Feature2DSerializable maPL1kl9f9VlgIn9jnnN_ 	 
    _15583457929083796945 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    	Feature2DSerializable mMorzi7AHv5qXgdOZzcMd 	 
    create mSdpFB1uEgpzM3bVmlHgT 	 
  _14938569619851839146.kpDescriptorType muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  	 myu64GAT8DgGBhNOOCqvd 	 
    _14938569619851839146.maxDescDistance mtmFAz7pcnIFLgYGMf4eK 	 
   _15583457929083796945 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		 getMinDescDistance mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
     
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    
    _3944249282595574931 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		   
setParams mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
  _15583457929083796945, _14938569619851839146 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    mqLizGA4Z8QZ_2GYQ1inC 	 
    
    _3944249282595574931 mevHkLo7kL5WL0_0mLIhr 	 
    removeFromMarkers mdbwYCIpGYWahFfTtU8zH 	 
    	   mvA2vjSvRD7UmknjmYP5U 	 
    	_14938569619851839146.removeKeyPointsIntoMarkers mwkk1d6uUiyaKys71tsUv 	 
    	  
    		  
    _3944249282595574931 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
     
     
 
 detectMarkers mjjfaXD3tH8warSj13sVr 	 
    	  
 mhL9dWuOWzLGBfRjwvYlN 	 
    	  _14938569619851839146.detectMarkers mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   

    _3944249282595574931 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
detectKeyPoints mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
   _14938569619851839146.detectKeyPoints mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		  
 mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
     
    
 myeiBNDHA8i8jhuL3IHRb 	 
    	  
    		   System mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
    setParams mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     
 
  std mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
 shared_ptr mJCQ17ktBLqNw7sHF60R1 	 
    	  
    		   
     
    Map mVIm1AJSzhahLlgKO9xQK 	 
    	  _11093822290287, const  Params &_2654435881,const string &_4953871428288621283 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
      mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
     
     
 
    _9098980761384425343 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
    _11093822290287 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 
  
    _14938569619851839146 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
    _2654435881 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  	    
    _12064558958874466958 mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
     
 
  	 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     

    
     mbCI0BlZHp5kbKpNqa5Su 	 
    	  
 mYcSgTugFLQcmWT7seaac 	 
    _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
 isEmpty mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
     
     
 
 mT3v8xdcVsSvUtbwmHC7j 	 
 mi6BqZOVmQyrEy6BLProP 	 
    	 
        _3857178690860967008 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
   STATE_LOST m_yMT4MKxrENTtLx5cA7n 	 
         mHbSWrX6OPeRP2Igmog8G 	 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
    mCzaOxAWpFlV3gHYCg4ev 	 
    	  
    		   
     
     
 
  	 _4953871428288621283.empty mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
       msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
  mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
  
            _9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		   
     
 TheKFDataBase.loadFromFile mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
    _4953871428288621283 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     myu64GAT8DgGBhNOOCqvd 	 
    	  
    	
         msBPMso4NRYFcn5Y1myF_ 	 
   
        MapInitializer mMorzi7AHv5qXgdOZzcMd 	Params _3005399798454910266 mo9Lbpy0Ap4RTl5O5Or1C 	
         mt3m0c1_35lMMq0E3cZsZ 	 
    	  mOAy4qGUJpdHQSVbVPq9E 	 
    	   _14938569619851839146.forceInitializationFromMarkers mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  
            _3005399798454910266.mode mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    	MapInitializer mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
 
  ARUCO mI30mSPxGJaQtkEjJfoQX 	 
    	  
   
        else
            _3005399798454910266.mode moHeIYzwbcFb6VaM90Aa9 	 
    MapInitializer mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
     
 
 BOTH mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     

        _3005399798454910266.minDistance mR22jPCjbltZ3tbBmn_6w 	 
    	  
   _14938569619851839146.minBaseLine mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
        _3005399798454910266.markerSize mvA2vjSvRD7UmknjmYP5U 	 
 _14938569619851839146.aruco_markerSize mxIwd_EJpfr1C9jwU7IyL 	 
 
        _3005399798454910266.aruco_minerrratio_valid mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
     
 
  	  _14938569619851839146.aruco_minerrratio_valid mo9Lbpy0Ap4RTl5O5Or1C 	 
    
        _3005399798454910266.allowArucoOneFrame mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
     
 
  	 _14938569619851839146.aruco_allowOneFrameInitialization mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		
        _3005399798454910266.max_makr_rep_err mIqjSmilXv9ILvDddB7nD 	 
    	  
 2.5 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		  
        _3005399798454910266.minDescDistance mH9fKsRtHWNu77RGN1xmn 	 
    	  
   _14938569619851839146.maxDescDistance mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		  
        _2044193291895307872 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
     
  setParams mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		  _3005399798454910266 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
  mQivdop_Gb4hqsWvOttc3 	 
    	  
    	
     msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     
    
    else
        _3857178690860967008 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    STATE_LOST mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
   
 m_ECAXF5hGu1UMoS2l1KU 	 
    	  
    		   
     
  
 mgBFSWJlmkK48wSOW4b6N 	 
    	  
    		System mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
  waitForFinished mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
    mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
     
     
 
  
 _2869602498954317713 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
     
     
 stop mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
  mxIwd_EJpfr1C9jwU7IyL 	 
  
 _2869602498954317713 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
mapUpdate mecU92YjgSbB3VkEoZVK3 	 
    	  
    	 mwkk1d6uUiyaKys71tsUv 	 
    	  
   
 mf0YJDuh2j5By5N13LunG 	 
    	  
    







 mmBcOrqJdEmcu_DE5N2Gx 	 
    	  
    		   
    System mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
resetTracker mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   mi4REkBAebpTZrzlvFEpD 	 
    	  
    		  
    waitForFinished mIJkWACd8Uom4Jv6selID 	 
    	  
    		    myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 

    _10576739190144361304 mR22jPCjbltZ3tbBmn_6w 	 
  -1 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
   
    _17976495724303689842 mA7hUM4UKqFyb_LJLsook 	 
    	  
se3 mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		 mQivdop_Gb4hqsWvOttc3 	
    _3857178690860967008 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
    STATE_LOST mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
    _14938569046430841631.clear mRAYh0ARHPOc62CfGHWWO 	 
    	  
 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
  	
    _4913157516830781457.clear mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
      m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
    
    _14463320619150402643 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    Mat mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
     mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
  
    _10558050725520398793 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
     -1 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
 
 mwiKr6psttEx97f2NsYO1 	 
    	  
    		   
  
cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   
     
Mat System mwuvkepREHprpx4i3n2RV 	 
    	  
    		process mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   const Frame &_46082543180066935 mXftmBtLFUrPFw3lasjuW 	 
  mbqHQotWhg0sv6ViuZXc3 	
     se3 _16937225862434286412 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
     
 
  	_17976495724303689842 mxIwd_EJpfr1C9jwU7IyL 	 

    
     mWYYMqZtRPklZ6ldYQlW8 	 
    	  
    mSdpFB1uEgpzM3bVmlHgT 	 
    	  
   mOAy4qGUJpdHQSVbVPq9E 	 
    	  
 void* mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
    &_46082543180066935 mglbnc94mbkalEyCkkDhv 	  mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
 
void* mXftmBtLFUrPFw3lasjuW 	 
    	  
    	&_14938569046430841631 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
 
   mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
 
  	 
        swap mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     _4913157516830781457,_14938569046430841631 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    mI30mSPxGJaQtkEjJfoQX 	 
    	  
        _14938569046430841631 mR22jPCjbltZ3tbBmn_6w 	 
   _46082543180066935 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
   
     mMGejH_coNc3kGxAdXVex 	
    
     mHbSWrX6OPeRP2Igmog8G 	 
    	  
    		   
     
 mgGCFceAojKPG0bK5eWQT 	 
    	 _17450466964482625197 mELweLHSjak68niq3oUpw 	 
    	  
    		   
     
    MODE_SLAM   mLdCPhlCq1uVgMtM4YkSz 	 
   mB0fx5ZWEe2g8Ci7LIhmM 	 
    	  
    		   
     
     
 
  	_2869602498954317713 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
     
     
 
  	hasMap mjjfaXD3tH8warSj13sVr 	 
    	  
    mJk4eXgp_IeFV2YvLaQC7 	 
    	  
  
        _2869602498954317713 mevHkLo7kL5WL0_0mLIhr 	 
    	  
  setMap mTiWUgQKOeYLvNdGsR_oS 	 
    	  
   _9098980761384425343 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 
 
     muDvj5aUdXshb2AqqeEiu 	 
 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
 mB0fx5ZWEe2g8Ci7LIhmM 	_14938569619851839146.runSequential  mfLSKCXSc1DHeN38jALNR 	 
    	  
    		   _17450466964482625197 mlEF62Izit24hGT_NqPIJ 	 
    	  
    		   
     
     
 
  	 MODE_SLAM  mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		  
        _2869602498954317713 mxGJXkzb8EW07jCVTl0Jt 	 
 start mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
   m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		  
    
    
     mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
 _2869602498954317713 mSwbK3nBcNZkvGxSXNOZy 	 
    	 mapUpdate mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
  
         mbCI0BlZHp5kbKpNqa5Su 	 
    	  mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     _2869602498954317713 mtNKEvBwMHNsmdH7BtZbM 	bigChange mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     
 
 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
   
        _14938569046430841631.pose_f2g mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
     
 
  _2869602498954317713 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		   
     
     
 
getLastAddedKFPose mrXXIs5j4DqJtj32aOG5F 	 
  mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
 
    
     mIyrnAZ9pLZEaiK6Yst1L 	 
    	  
    		   
   auto &_175247760135:_4913157516830781457.ids mSBNIRK1XqZg3XlWW_b3d 	 

         mAvI6WqVGKew5QUXF0T2l 	 
    	  
    		    mSdpFB1uEgpzM3bVmlHgT 	 
    	  
   _175247760135 mS3P8ZWKrLHg9h_5dW5He 	 
    	  
    		   
     
     
std mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
 numeric_limits moCEmVQeGy8LzV8cAuk79 	 
    uint32_t mKJK3THIuAwgeFpuGLN8L 	 
    	   mrS2zvlmrTf4L4KBRRYAU 	max mrXXIs5j4DqJtj32aOG5F 	 
    	  mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
      muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
     
 

             mr8s7pfvTmBWmxher3Oue 	 
    	  
    		   
     
 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
     mkyly54GlrbXuNeECTTqk 	_9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
   map_points.is mUGrJMUolw0lb_KVyGK5N 	 
  _175247760135 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
  mxAXsCfNkscq4iQtE2AeY 	  _175247760135 mXE5wWRmJGUY4EsEsgegT 	 
    	  
std me0ZKHp2Id3eLmP_6GMtk 	 
  numeric_limits moCEmVQeGy8LzV8cAuk79 	 
    	  
uint32_t mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
      mExFPeJBflhTWJKuQVWoB 	 
    	  
    		max mIJkWACd8Uom4Jv6selID 	 
    	  
    		   mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
   
             mEYy4vDSh1urfYj6Y0xAX 	 
    	  
 mg9IHDbTXxljO0nSnQKYh 	 
    	  
    		   
     
  _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
     
     
 
 map_points mVLLVWqNz0_lGN56vY03t 	 
    _175247760135 ml5d8mzmxNmQRMtpfZ82X 	 
    	  
    .isBad mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
   mxAXsCfNkscq4iQtE2AeY 	 
    _175247760135 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
     
 std mvpMkjoDGcQujDevHDZnx 	 
   numeric_limits mRwYPGmWUou3ixNnKEWbv 	 
uint32_t mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
     
     me0ZKHp2Id3eLmP_6GMtk 	 
    	 max mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    mC_gLvnw5tkMWRQheRKr5 	 
         mMGejH_coNc3kGxAdXVex 	 
 
    
     mKx3hnVGJH14s80udXZp_ 	 
    	  
    		  _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		isEmpty mRAYh0ARHPOc62CfGHWWO 	 
    	  
    mxpEdWbhRRjZ1JMh3yxwy 	 
    _17450466964482625197 mELweLHSjak68niq3oUpw 	 
   MODE_SLAM mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
    mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
   
         mHbSWrX6OPeRP2Igmog8G 	 
    	  
 mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     _2016327979059285019 mTiWUgQKOeYLvNdGsR_oS 	_14938569046430841631 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
      mJk4eXgp_IeFV2YvLaQC7 	 
   
            _3857178690860967008 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
     
     
 
  	STATE_TRACKING mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     

     mqVdZVftPR84WTjiOiVfT 	 
    	  
    		   
     
     

    else mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		
        
         myfOHlfTLtRL7im7qSaYm 	 
    _3857178690860967008 mosqH7AZUNZeyz6yX3nN1 	 
    	  
    		  STATE_TRACKING mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
  mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
    
            _10576739190144361304 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    	_1513765969352381626 mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
   _4913157516830781457,_17976495724303689842 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
   mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 
  
            _17976495724303689842 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
   _11166622111371682966 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     _14938569046430841631,_17976495724303689842 mT3v8xdcVsSvUtbwmHC7j 	 
    mo9Lbpy0Ap4RTl5O5Or1C 	 
    	
             myfOHlfTLtRL7im7qSaYm 	 
    	  
    molF5K16MuyVvkFE7X8JI 	 
    	  
    		 _17976495724303689842.isValid mdbwYCIpGYWahFfTtU8zH 	 
    	  
     msDy4S0F6Zdx78ZUnbARe 	
                _3857178690860967008 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
   STATE_LOST mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
         mwiKr6psttEx97f2NsYO1 	 
   
        
         mFVNERjMRO_ZEKm0TY73X 	 
    	  mNQ6rNLARkxxSTP6tiTXG 	 
    	  
  _3857178690860967008 mELweLHSjak68niq3oUpw 	 
    	  STATE_LOST msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
      mSH1h4yGhaMSu8y7JC_rY 	 
    	  

            se3 _5564636146947005941 mQivdop_Gb4hqsWvOttc3 	 
    	
             mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		   
     
     
 mUGrJMUolw0lb_KVyGK5N 	 
 _16487919888509808279 mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     _14938569046430841631,_5564636146947005941 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
 mVFG05ubhW6ia_rWdS_Tv 	 
     muH9A34QGuccPZkZDb32w 	 
    
                _3857178690860967008 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
     
STATE_TRACKING m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
  
                _17976495724303689842 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
_5564636146947005941 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
                _10576739190144361304 mA7hUM4UKqFyb_LJLsook 	 
  _1513765969352381626 mgGCFceAojKPG0bK5eWQT 	 
    _14938569046430841631,_17976495724303689842 mXftmBtLFUrPFw3lasjuW 	 
    	 mEm194VmPJuGh5y4tMUm5 	 
    	  
   
                _10558050725520398793 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
   _14938569046430841631.fseq_idx mwkk1d6uUiyaKys71tsUv 	 

             mEjIWbivPeVc9WtxGDiWw 	 
    
         mL9oWJQ1n2xKG3FtRNowa 	 
    	  
        
         mhRH54odsmIWcLq1D3rKZ 	  _3857178690860967008 mlEF62Izit24hGT_NqPIJ 	 
    	  
    		   STATE_TRACKING msDy4S0F6Zdx78ZUnbARe 	 mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   
     
 
            _14938569046430841631.pose_f2g mhL9dWuOWzLGBfRjwvYlN 	 
_17976495724303689842 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
  
             mHbSWrX6OPeRP2Igmog8G 	 
    	  
    		   
    mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
    _17450466964482625197 mosqH7AZUNZeyz6yX3nN1 	 
    	  
    		MODE_SLAM   mfLSKCXSc1DHeN38jALNR 	  mbXhD242DJoibBjdI1JtA 	 
       mNQ6rNLARkxxSTP6tiTXG 	 
 _14938569046430841631.fseq_idx mNgaR6RP0DoWIwdccOwpn 	 
   _10558050725520398793+5 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
 
    msz82ko2ZHqbIoF2aTtnd 	 
   mNQ6rNLARkxxSTP6tiTXG 	 
  _10558050725520398793 mrDas3egWRcEnvTodVRRA 	 
    	  
    		   
  -1 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    	   msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		  mSBNIRK1XqZg3XlWW_b3d 	 
               _2869602498954317713 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
  newFrame mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
_14938569046430841631,_10576739190144361304 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
   m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
         m_ECAXF5hGu1UMoS2l1KU 	 
 
     mqVdZVftPR84WTjiOiVfT 	 
    	  
    		  
    
     mFWW5xb6SDILpyTp5GBZD 	 
    	  
    	 _3857178690860967008 mtDWQOqRguVWSWehbKECr 	 
    	  
    		   
     
     
 
  	 STATE_LOST  mSSwrqUuoNnhMtvhM2vr3 	  _17450466964482625197 mlEF62Izit24hGT_NqPIJ 	 
    	  
    		   
     
  MODE_SLAM  mSSwrqUuoNnhMtvhM2vr3 	 
    	  
     _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
     
 
 keyframes.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
     
 mJPHiCuIoYoltwiwwrI8_ 	 
    	  
    		   5  mKWQLdAVzYxp5QuNZ1ytt 	 
    	  
    		   _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
     
   keyframes.size mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
  mpjTyiESCVWYRDiT2x2RD 	 
    	  
    		 0 mxAXsCfNkscq4iQtE2AeY 	 
  muH9A34QGuccPZkZDb32w 	 
  
        _2869602498954317713 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
reset mFAl4ldpf7o2gKLWQ4bfu 	 
    	 mo9Lbpy0Ap4RTl5O5Or1C 	 
        _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
     
 clear mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
  
        _2044193291895307872 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
     
     
 
reset mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
    mEm194VmPJuGh5y4tMUm5 	 
    	  
    		  
        _2869602498954317713 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
     
     
setMap mlfybwyvp98TOJj0yuqhF 	_9098980761384425343 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
  mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     miXz43zs_DqtraKQW0m3N 	 









    
      mt3m0c1_35lMMq0E3cZsZ 	 
    	  
    		   
     
     
 
  	 mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
   _3857178690860967008 mELweLHSjak68niq3oUpw 	 
    	  
    		   
  STATE_TRACKING  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
    mMm9FLNsNOoyX7Tyb7vpT 	 
    	  
    		   
     
  
        _14463320619150402643 mRDD8w83SsPKbGXy_JkEO 	cv mrPFLPKakBKjOOnkuhZUP 	 
    	 Mat mExFPeJBflhTWJKuQVWoB 	eye mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     
 
  	4,4,CV_32F mJk4eXgp_IeFV2YvLaQC7 	 
    	  
   mxIwd_EJpfr1C9jwU7IyL 	 
    	  
   
         mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		   
     
  mNQ6rNLARkxxSTP6tiTXG 	 
    	  
   _16937225862434286412.isValid mGu_88Fdde5jsxW8v9whR 	  mXftmBtLFUrPFw3lasjuW 	 
     mSH1h4yGhaMSu8y7JC_rY 	 
    	  
            _14463320619150402643  mR22jPCjbltZ3tbBmn_6w 	 
    	  
 _17976495724303689842.convert mecU92YjgSbB3VkEoZVK3 	*_16937225862434286412.convert mRAYh0ARHPOc62CfGHWWO 	 .inv mjjfaXD3tH8warSj13sVr 	 
    	  
    m_yMT4MKxrENTtLx5cA7n 	
          msBPMso4NRYFcn5Y1myF_ 	 
    	  
  
     msBPMso4NRYFcn5Y1myF_ 	 
    	  
    else mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   
     
     

        _14463320619150402643 mXE5wWRmJGUY4EsEsgegT 	 
    	  
  cv mwuvkepREHprpx4i3n2RV 	 
    	  
Mat mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
      mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   

     mMGejH_coNc3kGxAdXVex 	 
    	  
    		   

    _14938569046430841631.pose_f2g mvA2vjSvRD7UmknjmYP5U 	 
_17976495724303689842 mC_gLvnw5tkMWRQheRKr5 	 
    	  
   
#ifndef _UCOSLAM_123asd
     mhRH54odsmIWcLq1D3rKZ 	 
    	  
    		   
     
    mPTzP5ovoJRtpRWISSe82 	 
    	  
    		   
     
     _13033649816026327368 meN5YYBBVg5DStfnyA8Dd 	 
    	  
    	  mbXhD242DJoibBjdI1JtA 	 10*4*12*34*6 mVmWtYm5gVtZj7Yq19XWE 	/2 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		 
        _17976495724303689842 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		  cv mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
    Mat mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		
#endif
     mWYYMqZtRPklZ6ldYQlW8 	 
    	  
    		   
     
     
 
  mUGrJMUolw0lb_KVyGK5N 	_3857178690860967008 mtDWQOqRguVWSWehbKECr 	 
    	  
    		   
 STATE_LOST  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
  return cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
 
  	Mat mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
  mxIwd_EJpfr1C9jwU7IyL 	 

    else
         mY5hSAdXT4P60CSAZFBBa 	 
    	  _17976495724303689842 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
 
 m_ECAXF5hGu1UMoS2l1KU 	 
    	  
    		   
     
     
 
  	 
pair mbVOLbjVZO0YI60Vuguaq 	 
 cv mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
     
Mat,cv mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
  Mat mW202Akoy5o2_FFUMtz7a 	 
    	  
    		   
     
     
  System mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
    _8992046403730870353 mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
 
  	const cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
     
 
  	Mat &_16998117773731312345, ImageParams &_175247760147,const     cv mrPFLPKakBKjOOnkuhZUP 	 
 Mat &_6806993204424110071  mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     

 mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     
    
     mN4RvsK7_XXMC2cNCwITM 	 
  _12933028743841222941 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
     
 
 18053.0184 *3.141516 *  mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    2*5+3 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
  mI30mSPxGJaQtkEjJfoQX 	 

    cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
   Mat _706246329555533 mR22jPCjbltZ3tbBmn_6w 	 _16998117773731312345,_46082575733341031 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
     
 
_6806993204424110071 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
   
#ifndef _UCOSLAM_123asd
     mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		 mbXhD242DJoibBjdI1JtA 	 
    	  
    		     _16998117773731312345.size mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
     
.area mIJkWACd8Uom4Jv6selID 	 
    	  
    		 *_14938569619851839146.kptImageScaleFactor*_14938569619851839146.kptImageScaleFactor  mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
  _12933028743841222941 mVFG05ubhW6ia_rWdS_Tv 	 
   
     mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
     
 
 
         mKQv8aH2lM5yjPYl5F768 	 _706246308256699 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		  sqrt mbXhD242DJoibBjdI1JtA 	 
   _12933028743841222941/float mYcSgTugFLQcmWT7seaac 	 _16998117773731312345.size mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   .area mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
  mSBNIRK1XqZg3XlWW_b3d 	 
     mJk4eXgp_IeFV2YvLaQC7 	 
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		  
          cv mwuvkepREHprpx4i3n2RV 	 
    	  
    		 Size _175247759442 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 
 _16998117773731312345.cols*_706246308256699,_16998117773731312345.rows*_706246308256699 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
      mxIwd_EJpfr1C9jwU7IyL 	 
        
         mhRH54odsmIWcLq1D3rKZ 	_175247759442.width%4 my0vyIAimw3jadFZG1pnz 	 
    	  
    		   
     
 0 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     

            _175247759442.width mvcDBJfIynZthI5bz_HTe 	 
    	  
    		   
     
     
 
  4-_175247759442.width%4 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
         mfRi_C6KlnAxop81XDZsV 	 
    	 _175247759442.height%2 mS3P8ZWKrLHg9h_5dW5He 	 
 0 mxAXsCfNkscq4iQtE2AeY 	 
    	  
 _175247759442.height mtIfgwpprqjFMhHY9FVrL 	 
    	  
    		   
     
     
 
   mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  	
        cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
  resize mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
 _16998117773731312345,_706246329555533,_175247759442 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
 
        _175247760147.resize mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     _175247759442 mT3v8xdcVsSvUtbwmHC7j 	  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
         mhRH54odsmIWcLq1D3rKZ 	 
    	  
    		   
    mB0fx5ZWEe2g8Ci7LIhmM 	 
    	  
    		   
     
     
_6806993204424110071.empty mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
 muC5cqYcHRXDD16noARI1 	 
    	  
  mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
     
 
 
            cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     resize mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
   _16998117773731312345,_46082575733341031,_175247759442 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		  myu64GAT8DgGBhNOOCqvd 	 
    	  
   
         mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
     
     mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     
     
 
  	 
#endif
     mHUTuX3q6rB5eWWYYPWQD 	 
    	  
    		   
     
    mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
     
     
 
  	_706246329555533,_46082575733341031 mqVdZVftPR84WTjiOiVfT 	 
    	   mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
 msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     

cv mvpMkjoDGcQujDevHDZnx 	 
    	  Mat System mvpMkjoDGcQujDevHDZnx 	 
  process mlfybwyvp98TOJj0yuqhF 	 
   cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
Mat &_6441194614667703750, const ImageParams &_46082544221062900, mdx9gS37IsjwWpaOb1ODY 	 
    	  
    		   
     
     
 _9933887380370137445, const cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    		Mat & _46082575014988268, const cv mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
    Mat &_1705635550657133790 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
  mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   

    ImageParams _18212413899834346676 mvA2vjSvRD7UmknjmYP5U 	 
    	  
  _46082544221062900 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
 
    pair miGVtxwiqbDQsG6KBslZU 	cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
Mat,cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
 Mat mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
     
  _175247762377 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
    _8992046403730870353 mSdpFB1uEgpzM3bVmlHgT 	 
   _6441194614667703750,_18212413899834346676,_1705635550657133790 muC5cqYcHRXDD16noARI1 	 
    	  
   mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
    
    cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
     
 
  	Mat _16998117773731312345 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
     _175247762377.first m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
    
    cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
   Mat _6806993204424110071 mo9Lbpy0Ap4RTl5O5Or1C 	
    _6806993204424110071 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		 _175247762377.second myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
  
    swap mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
    _4913157516830781457,_14938569046430841631 mT3v8xdcVsSvUtbwmHC7j 	  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
    
    std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
   thread _1403653089436386197 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
   
     mt3m0c1_35lMMq0E3cZsZ 	 
    	  
    		   
   mbXhD242DJoibBjdI1JtA 	_17450466964482625197 mrDas3egWRcEnvTodVRRA 	 
    	MODE_SLAM mSBNIRK1XqZg3XlWW_b3d 	 
    	  
   _1403653089436386197 mIqjSmilXv9ILvDddB7nD 	 std me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		  thread mUGrJMUolw0lb_KVyGK5N 	 
    mVLLVWqNz0_lGN56vY03t 	 
   & ml5d8mzmxNmQRMtpfZ82X 	 
    	  
    		   
     
     
  mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
     
 mjXlfKOCTRjUV9apwYcb7 	 
    	  
    		   
     
     
         mWYYMqZtRPklZ6ldYQlW8 	 
    	  
    		  mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     
 
  	 _2869602498954317713 mxGJXkzb8EW07jCVTl0Jt 	 
    	 mapUpdate mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
  msDy4S0F6Zdx78ZUnbARe 	
             mr8s7pfvTmBWmxher3Oue 	 
    	  
   mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
   _2869602498954317713 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
     
 bigChange mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
    mVFG05ubhW6ia_rWdS_Tv 	
                _14938569046430841631.pose_f2g mRDD8w83SsPKbGXy_JkEO 	 
    	  
   _2869602498954317713 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
   getLastAddedKFPose mFAl4ldpf7o2gKLWQ4bfu 	 
  mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
   
         mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  mf0YJDuh2j5By5N13LunG 	 
    	  
    		   mxAXsCfNkscq4iQtE2AeY 	 
    	  
  mC_gLvnw5tkMWRQheRKr5 	
    
     mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		   
  mlfybwyvp98TOJj0yuqhF 	 
    	 _46082575014988268.empty mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
    mTmmYcodZhxYb9bt39OUl 	 
    	  
    		   _6806993204424110071.empty mdbwYCIpGYWahFfTtU8zH 	 
    	  
 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
   _3944249282595574931 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
     
  process mYcSgTugFLQcmWT7seaac 	 
    	  
 _16998117773731312345,_18212413899834346676,_14938569046430841631,_9933887380370137445 , std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
   max mOAy4qGUJpdHQSVbVPq9E 	 
    	 _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
   getTargetFocus mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
     
 
 ,_14938569619851839146.targetFocus mT3v8xdcVsSvUtbwmHC7j 	 
    mSBNIRK1XqZg3XlWW_b3d 	 mxIwd_EJpfr1C9jwU7IyL 	 
    
     myrvDyRCtal5mdHB28ZIe 	 
   mfRi_C6KlnAxop81XDZsV 	 
    	  
    		   
     
     
 
  _6806993204424110071.empty mRAYh0ARHPOc62CfGHWWO 	 mSBNIRK1XqZg3XlWW_b3d 	 _3944249282595574931 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
process_rgbd mNQ6rNLARkxxSTP6tiTXG 	 
    	  
 _16998117773731312345,_46082575014988268,_18212413899834346676,_14938569046430841631,_9933887380370137445  mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   mQivdop_Gb4hqsWvOttc3 	 
    	  
    		 
     mqUxZEnHM0zID6J2vVqke 	 
    	  
    		   
     _3944249282595574931 mxGJXkzb8EW07jCVTl0Jt 	 
    	processStereo mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		  _16998117773731312345,_6806993204424110071,_18212413899834346676,_14938569046430841631,_9933887380370137445,_14938569619851839146.targetFocus mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
    mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     mGc5v1UWfDU7ttNcZryQG 	 
    	  
    		    _14938569619851839146.autoAdjustKpSensitivity mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
   mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     
     
        
        
        
         mise5YGBUx6xBGs9EUolB 	 
    	_1699599737904718822 mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
 _14938569619851839146.maxFeatures-_14938569046430841631.und_kpts.size mFAl4ldpf7o2gKLWQ4bfu 	 
     mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
  	 
         myfOHlfTLtRL7im7qSaYm 	 
    	  
   _1699599737904718822  mpBV2mt4yeFwcVEC5cxVw 	 
0 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
      muH9A34QGuccPZkZDb32w 	 
    	  
    		   
             mqI5yMr4h6CHkceANuA43 	 
    	  
 _46082575832048655 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		  1.0f-  mTiWUgQKOeYLvNdGsR_oS 	 
    	  
   float mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     _1699599737904718822 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
 /float mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
 _14938569046430841631.und_kpts.size mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
    mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
 
  
             mxTwhHDgHBwIAa0Dytqva 	 _6148074839757474704 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
     
    _3944249282595574931 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    getSensitivity mRAYh0ARHPOc62CfGHWWO 	 
    	  
   +_46082575832048655 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		 
            _6148074839757474704 moHeIYzwbcFb6VaM90Aa9 	 
    	  std mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
     max mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		_6148074839757474704,1.0f mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
            _3944249282595574931 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
setSensitivity mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
      _6148074839757474704 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    	
         miXz43zs_DqtraKQW0m3N 	 
    	
        else mqlayz2fShj6ePxekxwRg 	 
    	  
    		   
     
     
 

            
            _3944249282595574931 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		setSensitivity mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		  _3944249282595574931 mSwbK3nBcNZkvGxSXNOZy 	 
    	getSensitivity mrXXIs5j4DqJtj32aOG5F 	 
    	  *0.95 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
   mqLizGA4Z8QZ_2GYQ1inC 	
         mf0YJDuh2j5By5N13LunG 	 
    	  
    		   
     
     
 
  	 
     mf0YJDuh2j5By5N13LunG 	 
   
    
     mWYYMqZtRPklZ6ldYQlW8 	 
    mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
   _17450466964482625197 mELweLHSjak68niq3oUpw 	 
    	  
 MODE_SLAM muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  	 _1403653089436386197.join mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
    mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
  	  
     mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
     
   mgGCFceAojKPG0bK5eWQT 	 
    	  _2869602498954317713 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		   
     
     
 
bigChange mIJkWACd8Uom4Jv6selID 	 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    	
        _14938569046430841631.pose_f2g moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
      _2869602498954317713 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
 getLastAddedKFPose mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
    cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
   Mat _3005399805025936106 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
     
 
  	 process mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
     
 _14938569046430841631 mxAXsCfNkscq4iQtE2AeY 	 
    	 m_yMT4MKxrENTtLx5cA7n 	 
    	
    
     mKQv8aH2lM5yjPYl5F768 	 
    	_6154865401824487276 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
  sqrt mYcSgTugFLQcmWT7seaac 	 
    	  
    float mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    _14938569046430841631.imageParams.CamSize.area mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
 /float mYcSgTugFLQcmWT7seaac 	 
_6441194614667703750.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
    .area mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     muC5cqYcHRXDD16noARI1 	 
    	  
    		  mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		
    _14031550457846423181 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     
 
_6441194614667703750,1./_6154865401824487276 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
   mC_gLvnw5tkMWRQheRKr5 	 
 
     mflySGFqxQX_KaIEHAKSo 	 
    	  
    		   
     
     
 
_5829441678613027716 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     msGAdK1RZcxCitYemdpxc 	 
    	  
    		  mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   
     
     mSdpFB1uEgpzM3bVmlHgT 	 
    	  const uint32_t&_11093821926013 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
    mSH1h4yGhaMSu8y7JC_rY 	 
    	  
   std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		stringstream _706246330191125 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
_706246330191125 mISlN399eTfrWHnidEKGu 	 
    	  
    		   
     
     
_11093821926013 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
  	  mUnahx7x8KWu62epS7OxV 	 
    	  
    		   
    _706246330191125.str mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
     
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
  m_ECAXF5hGu1UMoS2l1KU 	 
    	  
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		 
    _14938529070154896274 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
 _6441194614667703750,"\x4d\x61\x70\x20\x50\x6f\x69\x6e\x74\x73\x3a"+_5829441678613027716 mOAy4qGUJpdHQSVbVPq9E 	 
    	_9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		map_points.size mTGJXDnkacX2UX9dooHQu 	 muC5cqYcHRXDD16noARI1 	 ,cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
    	Point mBGM118Iia8vm6zcNTuB6 	 
    	  
    	20,_6441194614667703750.rows-20 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
      msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		 
    _14938529070154896274 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
  _6441194614667703750,"\x4d\x61\x70\x20\x4d\x61\x72\x6b\x65\x72\x73\x3a"+_5829441678613027716 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
     map_markers.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
     
     
 
  muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  	,cv mwuvkepREHprpx4i3n2RV 	 
    	  
   Point mOAy4qGUJpdHQSVbVPq9E 	20,_6441194614667703750.rows-40 mVFG05ubhW6ia_rWdS_Tv 	 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
      mwkk1d6uUiyaKys71tsUv 	 
    _14938529070154896274 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
    _6441194614667703750,"\x4b\x65\x79\x46\x72\x61\x6d\x65\x73\x3a"+_5829441678613027716 mgGCFceAojKPG0bK5eWQT 	 
    _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    keyframes.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
     
  muC5cqYcHRXDD16noARI1 	 
    	  
    		 ,cv miuOs6oIdxnQEMrFFk2n_ 	 
Point mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
  20,_6441194614667703750.rows-60 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
 mXftmBtLFUrPFw3lasjuW 	 
    	   myu64GAT8DgGBhNOOCqvd 	 
    	  
    	
     mIBLQ6_qDoS3S2lLQGZ3e 	 
    	  
   _16937201858692939798 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
 0 mxIwd_EJpfr1C9jwU7IyL 	 
    	 
     mozBzR4ceXlDTd_eA9UWj 	 
    	  
    		  auto _175247760135:_14938569046430841631.ids mVmWtYm5gVtZj7Yq19XWE 	 
   mGc5v1UWfDU7ttNcZryQG 	 
    	  
    	_175247760135 mS3P8ZWKrLHg9h_5dW5He 	 
    	  
    		   
     
std me0ZKHp2Id3eLmP_6GMtk 	 
  numeric_limits mJCQ17ktBLqNw7sHF60R1 	 
    	  
    		   
    uint32_t mpBV2mt4yeFwcVEC5cxVw 	 
    	  
   miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
max mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
   mSBNIRK1XqZg3XlWW_b3d 	 
    _16937201858692939798 mTgR0xuTc2WA_FI5hAh2Q 	 
    	  
    		   
     
     
 
  mC_gLvnw5tkMWRQheRKr5 	 
    	  

    _14938529070154896274 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
  	 _6441194614667703750,"\x4d\x61\x74\x63\x68\x65\x73\x3a"+  _5829441678613027716 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
   _16937201858692939798 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
 ,cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
  Point mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     
 
  20,_6441194614667703750.rows-80 mJk4eXgp_IeFV2YvLaQC7 	 
    mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
      mxIwd_EJpfr1C9jwU7IyL 	 
 
     mKx3hnVGJH14s80udXZp_ 	 
    	  
    		   
  _6441194614667703750.size mFAl4ldpf7o2gKLWQ4bfu 	 
    	  .area mFAl4ldpf7o2gKLWQ4bfu 	 
    mS3P8ZWKrLHg9h_5dW5He 	 
    	 _16998117773731312345.size mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
   .area mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
  muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  
        _14938529070154896274 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
 _6441194614667703750,"\x49\x6d\x67\x2e\x53\x69\x7a\x65\x3a"+_5829441678613027716 mgGCFceAojKPG0bK5eWQT 	 
    	_16998117773731312345.cols mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
    +"\x78"+_5829441678613027716 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
 _16998117773731312345.rows muC5cqYcHRXDD16noARI1 	 ,cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
 
  	Point mBGM118Iia8vm6zcNTuB6 	 
    	  
 20,_6441194614667703750.rows-100 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
   mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 

     mR8MpflZg6lk1qLQLX9P9 	 
    	  
    		   
     
     
 
  _3005399805025936106 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
 
 mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
     
     
 
  
 mKLTKWdkdn_ESJc3B3MOJ 	 
    	  
    		   
  System mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
_14938529070154896274 mNQ6rNLARkxxSTP6tiTXG 	cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
 Mat &_175247760140,string _706246331661728,cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
   Point _2654435881  muC5cqYcHRXDD16noARI1 	 
    	  
   mXdnll4yjwVy4uBDSjUe3 	 
  
     mrIWO5AmcxVfFGpyNJzQE 	 
    	  
    		   
     
   _706246308256699 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
     
 
  float mUGrJMUolw0lb_KVyGK5N 	 _175247760140.cols muC5cqYcHRXDD16noARI1 	 /float mbXhD242DJoibBjdI1JtA 	 
    	  
  1280 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
  
    cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   
     
   putText mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		 _175247760140,_706246331661728,_2654435881,cv mrS2zvlmrTf4L4KBRRYAU 	 FONT_HERSHEY_SIMPLEX, 0.5*_706246308256699,cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
Scalar mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		 0,0,0 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
   ,3*_706246308256699 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
 mEm194VmPJuGh5y4tMUm5 	 
    cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    	putText mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
   _175247760140,_706246331661728,_2654435881,cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		FONT_HERSHEY_SIMPLEX, 0.5*_706246308256699,cv mvpMkjoDGcQujDevHDZnx 	 
    	  
   Scalar mSdpFB1uEgpzM3bVmlHgT 	 125,255,255 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
,1*_706246308256699 mJk4eXgp_IeFV2YvLaQC7 	 
 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		 
 msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
    
string System mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
     
getSignatureStr mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
  const mSH1h4yGhaMSu8y7JC_rY 	 
    	  
 
     mIaPM1ms991SDrw4x6KTt 	 
    	  
    		   
_2102381941757963317 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    _13507858972549420551 mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
   mXftmBtLFUrPFw3lasjuW 	 mEm194VmPJuGh5y4tMUm5 	 
 miXz43zs_DqtraKQW0m3N 	 
    	  
    		   
uint64_t System mExFPeJBflhTWJKuQVWoB 	 
    	 _13507858972549420551 mTGJXDnkacX2UX9dooHQu 	 
    	  
  const mi6BqZOVmQyrEy6BLProP 	 
    
    Hash _11093822380353 mqLizGA4Z8QZ_2GYQ1inC 	 
    	 
    _11093822380353 mPvI5zVkkxdTYTCdGOJ2J 	 
    	  
    		   
     
     
 _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
     
    getSignature mrXXIs5j4DqJtj32aOG5F 	 
  mQivdop_Gb4hqsWvOttc3 	 
    	  
    		  
    
    _11093822380353 mNPH65O81GD4PdziT5g9G 	 _14938569619851839146.getSignature mTGJXDnkacX2UX9dooHQu 	 
  mI30mSPxGJaQtkEjJfoQX 	 
    	  
   
    
     mmeJW_Q9h6ZBPzSBQVjMK 	 
    	  
    		int _2654435874 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     0 m_yMT4MKxrENTtLx5cA7n 	 
    _2654435874 mnpObQ1mWnyfQO24_ojBn 	 
    	  
    		   
     
     6 myu64GAT8DgGBhNOOCqvd 	 
    	  
  _2654435874 mgux57p4wBZIWFfq6waj5 	 
    	  
    		   
     
     
 
 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		_11093822380353 mtpa6CvplEq1shGwk4jxI 	 
    	  
    		 _17976495724303689842 mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
     
     
 
  	_2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
     
     mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		 
    
    _11093822380353.add mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
  _10576739190144361304 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   

    
    _11093822380353 mWaLwU5zB1H0AtUbS8Rz2 	 
    	  
    		   
     
     
 
_14938569046430841631.getSignature mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     
 
  	  mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 

    
    _11093822380353 moI4EWKnn9rwdcRf81yt6 	 
    	  
    		   
     
     
_13028158409047949416 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
    
    _11093822380353 mvcDBJfIynZthI5bz_HTe 	 
    	  
    		   
     
     
 
 _3857178690860967008 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
    
    
    _11093822380353 mtpa6CvplEq1shGwk4jxI 	 
 _17450466964482625197 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
    
    
    _11093822380353 mNPH65O81GD4PdziT5g9G 	 
    	  
    	_4913157516830781457.getSignature mGu_88Fdde5jsxW8v9whR 	 
 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
    
    
    _11093822380353 mvcDBJfIynZthI5bz_HTe 	 
    	  
    		   
     
     _2869602498954317713 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    	getSignature mjjfaXD3tH8warSj13sVr 	 
    	  
  m_yMT4MKxrENTtLx5cA7n 	 
    	  
  
    
    _11093822380353 mt01qaUz2R0SKmPFSq0jx 	_14463320619150402643 mEm194VmPJuGh5y4tMUm5 	 
    	  
    	
    _11093822380353 mraP1zuclX52fRr5CelTs 	 
    	  
    		   
     
    _10558050725520398793 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
     mIaPM1ms991SDrw4x6KTt 	 
    	  
 _11093822380353 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
  	 
 m_ECAXF5hGu1UMoS2l1KU 	 
    	  
    	



cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
 
  	 Mat System mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
  _4145838251597814913 mYcSgTugFLQcmWT7seaac 	 
    	  const Frame &_46082543180066935  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
    muH9A34QGuccPZkZDb32w 	 
    	  
    		   
     
     
 
    std mrS2zvlmrTf4L4KBRRYAU 	 
    	  vector mLS76iLDjnGxttL6L8yfX 	 
    	  
    		   
   uint32_t mW202Akoy5o2_FFUMtz7a 	 
    	   _4240939334638385660 myu64GAT8DgGBhNOOCqvd 	 
    
    vector mnpObQ1mWnyfQO24_ojBn 	 
    	  
    		   
     
     
 
pair mHg0YG9R0Gb6ZE5xIr3dz 	 
    	  
    		   
 cv mExFPeJBflhTWJKuQVWoB 	 
    	  
    	Mat,double mW202Akoy5o2_FFUMtz7a 	 
     mW202Akoy5o2_FFUMtz7a 	 
    	  
    		    _5923954032168212568 mC_gLvnw5tkMWRQheRKr5 	 
    	  
   
    vector miGVtxwiqbDQsG6KBslZU 	 
    cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
  Point3f mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
     
   _7045032207766252521 mEm194VmPJuGh5y4tMUm5 	 

    vector mbVOLbjVZO0YI60Vuguaq 	 
    	  
    		cv mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
     
Point2f maPL1kl9f9VlgIn9jnnN_ 	 
    	  
    		   
     
     _7045032207766252456 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
   
     mFS3Bzv40ET2Bg_bjcFGO 	 
    	  
    		 auto _2654435878:_46082543180066935.markers mJk4eXgp_IeFV2YvLaQC7 	 
    	  
 mMm9FLNsNOoyX7Tyb7vpT 	 
    	  
    		   
     
     
 
  
         mxkHJa5wooqhzaSxK7_fd 	 
    	  
    		   
      mBGM118Iia8vm6zcNTuB6 	 
    	  
   _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    map_markers.find mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
_2654435878.id mJk4eXgp_IeFV2YvLaQC7 	 
    	  
   mS3P8ZWKrLHg9h_5dW5He 	 
    	  
    		   
     
     
 _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
  map_markers.end mrXXIs5j4DqJtj32aOG5F 	 
    	  mVmWtYm5gVtZj7Yq19XWE 	 mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
     
     

            ucoslam miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
 
  	 Marker &_6807036686937475945 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
     
     
 
_9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	 
    map_markers mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
     
     
 _2654435878.id mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   
     
     
 
  m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
   
            cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
Mat _9983235290341257781 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     _6807036686937475945.pose_g2m mEm194VmPJuGh5y4tMUm5 	 
    	
            
             mflySGFqxQX_KaIEHAKSo 	 
    	  
    		   _11093822296219 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    _6807036686937475945.get3DPoints mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
   mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
  	
            _7045032207766252521.insert mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
  _7045032207766252521.end mdbwYCIpGYWahFfTtU8zH 	,_11093822296219.begin mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
   ,_11093822296219.end mIJkWACd8Uom4Jv6selID 	 
    	  
    		 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
   mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     

            
            _7045032207766252456.insert mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     
 
  	_7045032207766252456.end mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     ,_2654435878.und_corners.begin mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
     ,_2654435878.und_corners.end mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
     
  mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     m_yMT4MKxrENTtLx5cA7n 	 
   
             mEhFK99MtLRsCBaPNqnDs 	 
   _1515389571633683069 mRDD8w83SsPKbGXy_JkEO 	 
    IPPE mI3QeEk0K_mj1WaUiowht 	 
 solvePnP mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 
_14938569619851839146.aruco_markerSize,_2654435878.und_corners,_46082543180066935.imageParams.CameraMatrix,_46082543180066935.imageParams.Distorsion mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		 mQivdop_Gb4hqsWvOttc3 	 
 
             mN_UNAeshLaooczmV1nkW 	 
    	  
    		   
     
auto _16937226146608628973:_1515389571633683069 muC5cqYcHRXDD16noARI1 	
                _5923954032168212568.push_back mbXhD242DJoibBjdI1JtA 	    make_pair mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
_16937226146608628973 * _9983235290341257781.inv mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		 ,-1 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
 mVmWtYm5gVtZj7Yq19XWE 	 
   mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
         mqVdZVftPR84WTjiOiVfT 	 
    	  
 
     msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
     
   
     mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
     
   mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     
 
  	_7045032207766252521.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
     
      mWQWZuZUxzgXcOZHMJMC_ 	 
    	  
    		   
     
     
 
  	 0 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
 return cv mExFPeJBflhTWJKuQVWoB 	 
    	Mat mGu_88Fdde5jsxW8v9whR 	 
    	  
   myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
    
     mvbe619pMTxqR0ISntFSZ 	 
    	  
  auto &_46082575779853237:_5923954032168212568 muC5cqYcHRXDD16noARI1 	 
 mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     
        vector mnpObQ1mWnyfQO24_ojBn 	 
    	  
cv mwuvkepREHprpx4i3n2RV 	 
    	  
    		 Point2f mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
     _1535067723848375914 mEm194VmPJuGh5y4tMUm5 	 
    	
        se3 _16937226146609453200 mXE5wWRmJGUY4EsEsgegT 	 
    	_46082575779853237.first mEm194VmPJuGh5y4tMUm5 	 
    	  
 
        project mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 
  	_7045032207766252521,_46082543180066935.imageParams.CameraMatrix,_16937226146609453200.convert mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
 ,_1535067723848375914 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		    mQivdop_Gb4hqsWvOttc3 	 

        _46082575779853237.second mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
0 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
  
         mIyrnAZ9pLZEaiK6Yst1L 	size_t _2654435874 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    	0 mxIwd_EJpfr1C9jwU7IyL 	 
    	  _2654435874 mLS76iLDjnGxttL6L8yfX 	 
    	  
    		   
     
     
 _1535067723848375914.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
    	 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
  _2654435874 mPTzP5ovoJRtpRWISSe82 	 
     mVmWtYm5gVtZj7Yq19XWE 	 

            _46082575779853237.second mNPH65O81GD4PdziT5g9G 	 
    	  
    		   
     
     
 
  	   mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     
 
  _1535067723848375914 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
     
     
 
  	_2654435874 mGPgWaVxS3WdTr7rWsMw4 	 
    	 .x- _7045032207766252456 mZ9T0z5VdOHGC7rra8Fzk 	 
    	  
    		   
    _2654435874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
.x mPaUdMg3fg2ipZY0Exj7X 	 
*  mTiWUgQKOeYLvNdGsR_oS 	 
_1535067723848375914 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
 _2654435874 mWi16Wz7P86SIJlTQEzCB 	 
    	  
    		   
     
     
 .x- _7045032207766252456 mRjEKX4QN9MTvSEtCTNd7 	 
    	 _2654435874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
    .x mSBNIRK1XqZg3XlWW_b3d 	 
    	  
  +  mBGM118Iia8vm6zcNTuB6 	_1535067723848375914 mwzFZRcSPi2Vsk45HpaLx 	 
_2654435874 mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		   
     
     
 
.y- _7045032207766252456 mRjEKX4QN9MTvSEtCTNd7 	 
    	  
    		   
     
     _2654435874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		   .y mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    	*  mgGCFceAojKPG0bK5eWQT 	 
    	 _1535067723848375914 msGAdK1RZcxCitYemdpxc 	 
    	 _2654435874 ml5d8mzmxNmQRMtpfZ82X 	 
   .y- _7045032207766252456 mVjuVop3osym9wWoq6p3w 	 
    	  
 _2654435874 ml5d8mzmxNmQRMtpfZ82X 	 
   .y mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
      mEm194VmPJuGh5y4tMUm5 	 
     mMGejH_coNc3kGxAdXVex 	 
    	  
    
    
    std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
sort mBGM118Iia8vm6zcNTuB6 	 
    	  
    		_5923954032168212568.begin mGu_88Fdde5jsxW8v9whR 	 
    	  
  ,_5923954032168212568.end mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
    , mZ9T0z5VdOHGC7rra8Fzk 	  mGPgWaVxS3WdTr7rWsMw4 	 
    	  mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     const pair mk9nSfh6XGyonOYMC8C3M 	 
    	  
    		   
   cv miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		  Mat,double mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
 &_2654435866,const pair mHg0YG9R0Gb6ZE5xIr3dz 	 
    	  
    		   cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
   Mat,double mJJosB3DZCYh837sWRpN7 	 
    	  
    		   
     
   &_2654435867 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
   mqlayz2fShj6ePxekxwRg 	 
    	  
    		 return _2654435866.second mLS76iLDjnGxttL6L8yfX 	 
    	  
    		   
     
     
 _2654435867.second mEm194VmPJuGh5y4tMUm5 	 
    	  
    		    msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   
     
     
 
  muC5cqYcHRXDD16noARI1 	 
  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
    
    
     mY5hSAdXT4P60CSAZFBBa 	 
    	  
    		   
   _5923954032168212568 mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
     
     
 
0 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
     
    .first mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
    
 miXz43zs_DqtraKQW0m3N 	 
    	
 mK81mHSyZucxh8c_K9rnU 	 
    	  
    		   
     System mvpMkjoDGcQujDevHDZnx 	 
    	  
    		 _2016327979059285019 mSdpFB1uEgpzM3bVmlHgT 	 Frame &_175247759917  mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
    mqlayz2fShj6ePxekxwRg 	 
    	  
    	
 mK81mHSyZucxh8c_K9rnU 	 
    	  
    		   
     
    _11093822302335 mwkk1d6uUiyaKys71tsUv 	 
    	  
    
     mr8s7pfvTmBWmxher3Oue 	 
    	 mSdpFB1uEgpzM3bVmlHgT 	 
   _175247759917.imageParams.isStereoCamera mdbwYCIpGYWahFfTtU8zH 	 
  mT3v8xdcVsSvUtbwmHC7j 	 mMm9FLNsNOoyX7Tyb7vpT 	 
    	  
 
          _11093822302335 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
 _15186594243873234013 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     _175247759917 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
   mwkk1d6uUiyaKys71tsUv 	 
    	
     mf0YJDuh2j5By5N13LunG 	 
    	  

    else mMm9FLNsNOoyX7Tyb7vpT 	 
    	  
    		
        _11093822302335 mR22jPCjbltZ3tbBmn_6w 	 
    _14954361871198802778 mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     
 
_175247759917 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  	 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 
  	 
     mMGejH_coNc3kGxAdXVex 	 
    	  
    
     mg9IHDbTXxljO0nSnQKYh 	 
    	  
    		 mCzaOxAWpFlV3gHYCg4ev 	_11093822302335 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		  return _11093822302335 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
    
    _17976495724303689842 mR22jPCjbltZ3tbBmn_6w 	 
    	  
   _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
 keyframes.back mjjfaXD3tH8warSj13sVr 	 
    	  
   .pose_f2g mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
    
    _10576739190144361304 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	keyframes.back mIJkWACd8Uom4Jv6selID 	 
    .idx mQivdop_Gb4hqsWvOttc3 	 

    _13028158409047949416 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
     
 
  true mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     

   mSXTPhnnQgIi6ocmukNcV 	 
    	  
    		true mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
 
 mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		  
 mfQABlcyhvI43vfjabcjx 	 
    	  
    		   
     
     
 
System mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
    _14954361871198802778 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
Frame &_175247759917  mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		 mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     
     
 
  	
     mbCI0BlZHp5kbKpNqa5Su 	 
    mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
   mkyly54GlrbXuNeECTTqk 	_2044193291895307872 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
  process mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 
 _175247759917,_9098980761384425343 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     
 
  	  mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
   mR8MpflZg6lk1qLQLX9P9 	 
   false mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
   
    
    
         mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
     
      mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     
 
  	  _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
 keyframes.size mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
     
 
 meN5YYBBVg5DStfnyA8Dd 	1  mtq_QCXPpv2kX7L8PRz8d 	 _9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
   map_points.size mGu_88Fdde5jsxW8v9whR 	 
     mW202Akoy5o2_FFUMtz7a 	 
    	  
    		   
  0 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
  mjXlfKOCTRjUV9apwYcb7 	 
    	  
        _175247759917.ids  mA7hUM4UKqFyb_LJLsook 	 
    	  
     _9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
     
     
 
keyframes.back mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
     
 
.ids mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
  	
     msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
  
    globalOptimization mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		 
    
     mxkHJa5wooqhzaSxK7_fd 	 
    	  
    		   
     
     mUGrJMUolw0lb_KVyGK5N 	 
    	  
  _9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
  map_markers.size mTGJXDnkacX2UX9dooHQu 	 
    	  
 mIHFqVJpFXgMDdHn2uhc3 	 
    	  
    		   
     
     
 
  	0 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    mi4REkBAebpTZrzlvFEpD 	 
    	  
         mr8s7pfvTmBWmxher3Oue 	 
    	  
    		   
      mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		    _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
     
     map_points.size mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
     
 
  	 mJCQ17ktBLqNw7sHF60R1 	 50 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    mSH1h4yGhaMSu8y7JC_rY 	
            _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	 
   clear mTGJXDnkacX2UX9dooHQu 	 
   mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
  
             mHUTuX3q6rB5eWWYYPWQD 	 
    	  
    		   
  false mwkk1d6uUiyaKys71tsUv 	 
    	  
    		  
         mf0YJDuh2j5By5N13LunG 	 
    	  
    		   
   
         mTWpMMn_ueGNGrVaZzL0Q 	 
    	  
    	_7847018097084079275 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
 
 1./_9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
 getFrameMedianDepth mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		  _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
 keyframes.front mJFtpHxfnoGMxp1wzTBMr 	 
    	  .idx mxAXsCfNkscq4iQtE2AeY 	 
    	  mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
        cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
    Mat _706246338944062 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
   _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   keyframes.back mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     .pose_f2g.inv mrXXIs5j4DqJtj32aOG5F 	 
    	 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
   
        
        
        _706246338944062.col mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		  3 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
   .rowRange mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
     
 0,3 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
  mvA2vjSvRD7UmknjmYP5U 	 
    	  
    		   
     
     
 
  _706246338944062.col mYcSgTugFLQcmWT7seaac 	 
3 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
 .rowRange mlfybwyvp98TOJj0yuqhF 	 
 0,3 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
*_7847018097084079275 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
 
        _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
keyframes.back mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
     
 
.pose_f2g mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
 _706246338944062.inv mGu_88Fdde5jsxW8v9whR 	 
    mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   

         
          mIyrnAZ9pLZEaiK6Yst1L 	 
    auto &_175247759380:_9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		 map_points mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
    mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
            _175247759380.scalePoint mBGM118Iia8vm6zcNTuB6 	_7847018097084079275 muC5cqYcHRXDD16noARI1 	 
     mQivdop_Gb4hqsWvOttc3 	 
    	  
  
         mMGejH_coNc3kGxAdXVex 	 
    
     mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
     

    _17976495724303689842 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
     
 
 _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		 keyframes.back mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
    .pose_f2g mC_gLvnw5tkMWRQheRKr5 	 
   
      mV4_AbWY8ymaWGsYOk0LC 	 true mI30mSPxGJaQtkEjJfoQX 	 

 mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
     
     
 
  	
 mgrODPzGHQfjmAyPsBdfg 	 
    	  
  System mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
     
 
  	 _15186594243873234013 mBGM118Iia8vm6zcNTuB6 	 
    	  
    		    Frame &_46082543180066935 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
  mi6BqZOVmQyrEy6BLProP 	 
 
     mFWW5xb6SDILpyTp5GBZD 	 
    	  
    		   
  _14938569619851839146.KPNonMaximaSuppresion mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    
        _46082543180066935.nonMaximaSuppresion mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
      m_yMT4MKxrENTtLx5cA7n 	 
    	 
     mjg3Ot05P13DpFXIgvY3M 	 
_8065948040949117953 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
     
     
 
 0 mqLizGA4Z8QZ_2GYQ1inC 	 

     mN_UNAeshLaooczmV1nkW 	 
    	  
    		   
     
    size_t _2654435874 mA7hUM4UKqFyb_LJLsook 	 
    	0 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
  _2654435874 mLS76iLDjnGxttL6L8yfX 	 
    	  
  _46082543180066935.und_kpts.size mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
 mwkk1d6uUiyaKys71tsUv 	 
  _2654435874 mY6fIyAOJfhz5nUdrWiVY 	 
    	  
   mXftmBtLFUrPFw3lasjuW 	 
  mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   
     

        
         mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     _46082543180066935.getDepth mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
    _2654435874 mJk4eXgp_IeFV2YvLaQC7 	 meN5YYBBVg5DStfnyA8Dd 	 
    	  
0  m_oqkmDs8rXEbW2q16xvJ 	 
    	  
  _46082543180066935.imageParams.isClosePoint mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		  _46082543180066935.getDepth mSdpFB1uEgpzM3bVmlHgT 	 
  _2654435874 mxAXsCfNkscq4iQtE2AeY 	 
    	   mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  	   mxpEdWbhRRjZ1JMh3yxwy 	 
    	  
       mc2SFiyFAyMaXElAGl89t 	 
    	  
    		   
     
    _46082543180066935.flags mVLLVWqNz0_lGN56vY03t 	 
    	  
    		   
     
     
_2654435874 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		  .is mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
  Frame mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    	FLAG_NONMAXIMA mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
  mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     

            _8065948040949117953 mDe1564r6NJrCTudA8x0w 	 
    	  
    mEm194VmPJuGh5y4tMUm5 	 
    	  

     mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
   
     mHbSWrX6OPeRP2Igmog8G 	 
    	  
    mOAy4qGUJpdHQSVbVPq9E 	 
    _8065948040949117953 mnpObQ1mWnyfQO24_ojBn 	 
    	  
    		   
   100 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
 
   mV4_AbWY8ymaWGsYOk0LC 	 
    	  
 false mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
  
    _46082543180066935.pose_f2g.setUnity mRAYh0ARHPOc62CfGHWWO 	 
    	  
    mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
  
    Frame & _16997199184281837438 mXE5wWRmJGUY4EsEsgegT 	 
  _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 addKeyFrame mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		  _46082543180066935 mSBNIRK1XqZg3XlWW_b3d 	 
    	   m_yMT4MKxrENTtLx5cA7n 	 
  
    
     mIyrnAZ9pLZEaiK6Yst1L 	 
size_t _2654435874 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		  0 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
  _2654435874 mRwYPGmWUou3ixNnKEWbv 	 
_46082543180066935.und_kpts.size mjjfaXD3tH8warSj13sVr 	 
    	  
    		   mC_gLvnw5tkMWRQheRKr5 	 
    	  
    _2654435874 mUvBFztQfvp6FxGFsyoMW 	 
    	  
    		   
     
     
 
  muC5cqYcHRXDD16noARI1 	 
    	  
 mjXlfKOCTRjUV9apwYcb7 	 
    	  
    		   
     
   
        
        cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
  Point3f _2654435881  mQivdop_Gb4hqsWvOttc3 	 
    	 
         mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		   
     
     
 
  	 mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     _46082543180066935.getDepth mlfybwyvp98TOJj0yuqhF 	 
    	  
   _2654435874 mSBNIRK1XqZg3XlWW_b3d 	 
    	 mpBV2mt4yeFwcVEC5cxVw 	 
    	  
0  mtq_QCXPpv2kX7L8PRz8d 	 
    	  
    		   
     
     
 
  	  _46082543180066935.imageParams.isClosePoint mUGrJMUolw0lb_KVyGK5N 	 
    _46082543180066935.getDepth mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
   _2654435874 mPaUdMg3fg2ipZY0Exj7X 	  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
    mLdCPhlCq1uVgMtM4YkSz 	 
    	  
    		   
    mkyly54GlrbXuNeECTTqk 	 
  _46082543180066935.flags mVLLVWqNz0_lGN56vY03t 	 
  _2654435874 mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		   
     
 .is mBGM118Iia8vm6zcNTuB6 	 
   Frame mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
     FLAG_NONMAXIMA mT3v8xdcVsSvUtbwmHC7j 	 
    	   msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
      mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   
  
            
            _2654435881 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
 
  	_46082543180066935.get3dStereoPoint mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
    _2654435874 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    	
             mEhFK99MtLRsCBaPNqnDs 	 
    	  
    		   
     &_175247759380 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
      _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
     
     
addNewPoint mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
  	 _16997199184281837438.fseq_idx mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
 
  mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		
            _175247759380.kfSinceAddition moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
 
1 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     

            _175247759380.setCoordinates mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
_2654435881 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		  m_yMT4MKxrENTtLx5cA7n 	 
    	  
    	
            _175247759380.setStereo mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    true mxAXsCfNkscq4iQtE2AeY 	 
    	  
   mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     

            _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		   
     
     
 
  	addMapPointObservation mgGCFceAojKPG0bK5eWQT 	_175247759380.id,_16997199184281837438.idx,_2654435874 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     

            _46082543180066935.ids msGAdK1RZcxCitYemdpxc 	_2654435874 mvFhi6DaS7eScbgWe07wY 	 
     moHeIYzwbcFb6VaM90Aa9 	 
    	  
    _175247759380.id mxIwd_EJpfr1C9jwU7IyL 	 
    	  
         miXz43zs_DqtraKQW0m3N 	
     mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
 
    
     mmeJW_Q9h6ZBPzSBQVjMK 	 
    	  
    		   
     
     
 
const  mS0R9s7sfcYa3Nx39taZW 	 
    	&_2654435878:_46082543180066935.markers  mPaUdMg3fg2ipZY0Exj7X 	 
 
        _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
   addMarkerObservation mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
    _2654435878.id,_16997199184281837438.idx mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     
 
  	 myu64GAT8DgGBhNOOCqvd 	 
    	  
     mFWbNGU5e6cuqyQa3XUry 	 
    	  
 true mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
  	
 m_ECAXF5hGu1UMoS2l1KU 	
string System mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
    _2102381941757963317 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
 uint64_t _11093822380353 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    const muH9A34QGuccPZkZDb32w 	 

    string _706246330193866 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
  
    string _46082576163156525 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    	"\x71\x77\x65\x72\x74\x79\x75\x69\x6f\x70\x61\x73\x64\x66\x67\x68\x6a\x6b\x6c\x7a\x78\x63\x76\x62\x6e\x6d\x31\x32\x33\x34\x35\x36\x37\x38\x39\x30\x51\x57\x45\x52\x54\x59\x55\x49\x4f\x50\x41\x53\x44\x46\x47\x48\x4a\x4b\x4c\x5a\x58\x43\x56\x42\x4e\x4d" m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		
    uchar * _2654435884 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
    mbXhD242DJoibBjdI1JtA 	 
uchar * muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  	&_11093822380353 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
   
     mIBLQ6_qDoS3S2lLQGZ3e 	 
    	  
    		   
_2654435879 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
     sizeof mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     _11093822380353 mSBNIRK1XqZg3XlWW_b3d 	/sizeof mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   uchar  muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
     maE84VqXoUUX_dnxUsfES 	 
    	  
  int _2654435874 mvA2vjSvRD7UmknjmYP5U 	 
  0 m_yMT4MKxrENTtLx5cA7n 	 
  _2654435874 miGVtxwiqbDQsG6KBslZU 	 
    	  
    		   
     
     
 
  	 _2654435879 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
 _2654435874 mPTzP5ovoJRtpRWISSe82 	 
    	  
    		   
     
     
 
 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
   mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
     
     
 
  	 
        _706246330193866.push_back mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
     
 
_46082576163156525 mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
     
  _2654435884 mstJEG25u0Qv4VQocWgKl 	 
    	  
    		   
     
     
 
  	_2654435874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
 %_46082576163156525.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
     
 
  	  mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
     
      mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    	 mqLizGA4Z8QZ_2GYQ1inC 	 
    	 
     mqVdZVftPR84WTjiOiVfT 	 
  
     mLp5eeYn1TGnQEcop68VN 	 
    	  
    		   
     
  _706246330193866 mEm194VmPJuGh5y4tMUm5 	
 m_ECAXF5hGu1UMoS2l1KU 	 
    	  
 
 mFASROAG4Q9353J70qH7c 	 
    	  
System mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
     
     
 
_1513765969352381626 mlfybwyvp98TOJj0yuqhF 	 
  const Frame &_10614055813325501077,  const se3 &_10706799483371532009 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
 
  	 mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
    
    
    int64_t _644211886852851457 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
-1  m_yMT4MKxrENTtLx5cA7n 	 
    	  
  
     mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		   
     
     
 mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
   _14938569619851839146.detectKeyPoints mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  	
       _644211886852851457 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
    _9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
   getReferenceKeyFrame mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
_10614055813325501077,1 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
      mwkk1d6uUiyaKys71tsUv 	 

     mr8s7pfvTmBWmxher3Oue 	 
  mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
   _644211886852851457 mcozC0jwDOrxnYpsfODix 	 
    	  
    		   
 -1 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    	  mUnahx7x8KWu62epS7OxV 	 
    	  
   _644211886852851457 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     

    
     mxkHJa5wooqhzaSxK7_fd 	 
     mSdpFB1uEgpzM3bVmlHgT 	 
   _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
   map_markers.size mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
      mVrsJpNNblNXrk9CJ_J45 	 
 0 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
  mMm9FLNsNOoyX7Tyb7vpT 	 
    	  
    		   
     
    
         my5S_tF4_lSpButBKNitX 	 
    	  
    		 _10576739190144361304 mwkk1d6uUiyaKys71tsUv 	
     miXz43zs_DqtraKQW0m3N 	 
    	 
    
    vector moCEmVQeGy8LzV8cAuk79 	 
    	  
    	uint32_t mKJK3THIuAwgeFpuGLN8L 	 
    	  
    		   _4240713669852012646 mQivdop_Gb4hqsWvOttc3 	 
    	
     mozBzR4ceXlDTd_eA9UWj 	 
    	  
  auto _2654435878:_10614055813325501077.markers mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
      mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   

         mflySGFqxQX_KaIEHAKSo 	 
    	  
    		   
     
     
 
  _3005399795337363304 mvA2vjSvRD7UmknjmYP5U 	 
   _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		map_markers.find mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
   _2654435878.id mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
  mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  
         muDvj5aUdXshb2AqqeEiu 	 
    	  
     mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
      _3005399795337363304 my0vyIAimw3jadFZG1pnz 	 
    	  
  _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
  map_markers.end mJFtpHxfnoGMxp1wzTBMr 	 
    	   mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     muH9A34QGuccPZkZDb32w 	 
    	  
    
             mbCI0BlZHp5kbKpNqa5Su 	 
    	  mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
_3005399795337363304 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		  second.pose_g2m.isValid mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
     
 
   mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  _4240713669852012646.push_back mYcSgTugFLQcmWT7seaac 	 
    	  
    		_2654435878.id mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
 
   mI30mSPxGJaQtkEjJfoQX 	 
    
         mL9oWJQ1n2xKG3FtRNowa 	 
  
     mwiKr6psttEx97f2NsYO1 	 
  
    pair mbVOLbjVZO0YI60Vuguaq 	 
    	  
    		   
uint32_t,float mKJK3THIuAwgeFpuGLN8L 	 
    	  
  _18337238202410394478 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
    std mrPFLPKakBKjOOnkuhZUP 	 
    	  
numeric_limits mHg0YG9R0Gb6ZE5xIr3dz 	 
  uint32_t mW202Akoy5o2_FFUMtz7a 	 
    	  
    miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
     
 
 max mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
     
   ,std mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
     
     
 
  	 numeric_limits mnpObQ1mWnyfQO24_ojBn 	 
    	  float mW202Akoy5o2_FFUMtz7a 	 
    	  
    		   
     
     
 
 mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
 max mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
  mT3v8xdcVsSvUtbwmHC7j 	 
    mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 

     mWIOGoR1XyrR6fw03i9px 	 
    	  
    		 auto _3005399795337363304:_4240713669852012646 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
 
         mmeJW_Q9h6ZBPzSBQVjMK 	 
    	  
 const  mkcVgqnqADeTh3Pu1ogGF 	 
    	  
    		   
  &_46082543180066935:_9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
     
     
 map_markers mRjEKX4QN9MTvSEtCTNd7 	 
    _3005399795337363304 mQbYLzhvVQm8J2LNkC6S6 	.frames mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
   mXdnll4yjwVy4uBDSjUe3 	 
    	  

             mFTobXyS5Vx9ebVESwR0T 	 
  _2654435869 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
      _10706799483371532009 .t_dist mTiWUgQKOeYLvNdGsR_oS 	 
   _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
   keyframes mstJEG25u0Qv4VQocWgKl 	_46082543180066935 mOwAFTnFZjoBWI2gNeAO_ 	 
    .pose_f2g  mVFG05ubhW6ia_rWdS_Tv 	      mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
 
             mWYYMqZtRPklZ6ldYQlW8 	 
    	  
    		   
     mgGCFceAojKPG0bK5eWQT 	 _18337238202410394478.second mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    		   
     
     
 
_2654435869 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     
 
  	 _18337238202410394478 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
    mi4REkBAebpTZrzlvFEpD 	 
    	 _46082543180066935,_2654435869 mEjIWbivPeVc9WtxGDiWw 	 
    	 mC_gLvnw5tkMWRQheRKr5 	 
    	  
  
         mL9oWJQ1n2xKG3FtRNowa 	 
    	
     my5S_tF4_lSpButBKNitX 	 
    	  
    		   
     
  _18337238202410394478.first mQivdop_Gb4hqsWvOttc3 	 
    	  
   
 mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     
     
 
  	 
 mWsMr8mjNljMAriyUwgnE 	 
    	  
    		   
     
     
 System mMorzi7AHv5qXgdOZzcMd 	 
    	_3570943890084999391 mSdpFB1uEgpzM3bVmlHgT 	 
    	  
   Frame &_16940374161494853219,se3 &_13011065492167565582  mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		  mMm9FLNsNOoyX7Tyb7vpT 	 
    	  
    		   
     
     
 
  	 
     mAvI6WqVGKew5QUXF0T2l 	 
    	  
    		   
     mYcSgTugFLQcmWT7seaac 	 
    	  
    		_16940374161494853219.ids.size mGu_88Fdde5jsxW8v9whR 	 
     mrDas3egWRcEnvTodVRRA 	 
    	  
 0 msDy4S0F6Zdx78ZUnbARe 	 
    	  
   return false mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
     mAvI6WqVGKew5QUXF0T2l 	 
    	  
    		   
     
      mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
    _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
     
     
 
TheKFDataBase.isEmpty mIJkWACd8Uom4Jv6selID 	 
    	   mSBNIRK1XqZg3XlWW_b3d 	return false mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		
    vector mkHL8KJw4VjwmGdgQrteX 	uint32_t mpBV2mt4yeFwcVEC5cxVw 	 
    	  
    		   
   _5288382201172378343 mA7hUM4UKqFyb_LJLsook 	 
    	  
_9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		   
     
     
 
  relocalizationCandidates mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
   _16940374161494853219 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
  	 
     mXYEIB3KYwzJOpssgkZxP 	 
   mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   _5288382201172378343.size mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
  mosqH7AZUNZeyz6yX3nN1 	 
    	  
    		   
     
     
 
  	 0 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
    return false mwkk1d6uUiyaKys71tsUv 	 
    	  
    		  
     mS8RHH9YrzfK1kS8XUlWM 	 
    	  
    		   
     
   _16997332234748947065 mjXlfKOCTRjUV9apwYcb7 	 
   
        se3 _11424282724131190187 mI30mSPxGJaQtkEjJfoQX 	
         mN4RvsK7_XXMC2cNCwITM 	 
    	  
    		   
     
     
 
_18251222464377478020 moHeIYzwbcFb6VaM90Aa9 	 
  0 mQivdop_Gb4hqsWvOttc3 	 
    	 
        std mNQimRrYQ8Mz6YI9KM7Fn 	 
  vector mLS76iLDjnGxttL6L8yfX 	 
    	uint32_t meN5YYBBVg5DStfnyA8Dd 	 
 _6253874806036432733 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
        std miuOs6oIdxnQEMrFFk2n_ 	 vector mkHL8KJw4VjwmGdgQrteX 	 
    	  
    		   
     
     
 
 cv mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
     
     
 
 DMatch mzCa3iYOTZk3vOb9xFPuf 	 
    	  
    _12720020569689445873 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
    
     mMGejH_coNc3kGxAdXVex 	 
    mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		
    vector mbVOLbjVZO0YI60Vuguaq 	 
    	  
    		 _16997332234748947065 mJJosB3DZCYh837sWRpN7 	 
    	  
    		   
     
   _1524129789187101628 mNQ6rNLARkxxSTP6tiTXG 	 
    	_5288382201172378343.size mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
  mT3v8xdcVsSvUtbwmHC7j 	 
    	 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		  
    FrameMatcher _16937386958649118140 mQivdop_Gb4hqsWvOttc3 	 

    _16937386958649118140.setParams mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     
 
  _16940374161494853219,FrameMatcher mMorzi7AHv5qXgdOZzcMd 	 
    	  
    MODE_ALL,_14938569619851839146.maxDescDistance*2 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
    mEm194VmPJuGh5y4tMUm5 	 
 
#pragma omp parallel for
     mFS3Bzv40ET2Bg_bjcFGO 	int _175247762874 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     0 mC_gLvnw5tkMWRQheRKr5 	 
    	_175247762874 mk9nSfh6XGyonOYMC8C3M 	 
    	  
    		   
     _5288382201172378343.size mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
    mI30mSPxGJaQtkEjJfoQX 	 
_175247762874 mgux57p4wBZIWFfq6waj5 	 
     msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
 mMm9FLNsNOoyX7Tyb7vpT 	
         mkcVgqnqADeTh3Pu1ogGF 	 
    	  
    		   
     
     
 _175247760268 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		 _5288382201172378343 mZ9T0z5VdOHGC7rra8Fzk 	 
    	  
    		   
     
     
 _175247762874 mtEI4bSjtkyV5O0qz_vBz 	 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		
         mcRuULuI_AYJWzFSu1kB4 	 
    	  
    		   
     
     
 
  	 &_3005399814901981436 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
  _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  keyframes mVLLVWqNz0_lGN56vY03t 	 
    	  
_175247760268 mtEI4bSjtkyV5O0qz_vBz 	 
   mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
        _1524129789187101628 mMo20fFU0rdQJ7l5qqDaX 	 
_175247762874 mWi16Wz7P86SIJlTQEzCB 	 
    	  
    		   
 ._12720020569689445873 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   _16937386958649118140.match mbXhD242DJoibBjdI1JtA 	_3005399814901981436,FrameMatcher mrS2zvlmrTf4L4KBRRYAU 	 
  MODE_ASSIGNED mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
    m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 
  
        
         mN_UNAeshLaooczmV1nkW 	 
    	  auto &_2654435878:_1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	 
    	  _175247762874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
    ._12720020569689445873 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     mjXlfKOCTRjUV9apwYcb7 	 
    	  
   
            std mI3QeEk0K_mj1WaUiowht 	 
    	 swap mSdpFB1uEgpzM3bVmlHgT 	 _2654435878.queryIdx,_2654435878.trainIdx muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
 myu64GAT8DgGBhNOOCqvd 	 
    	  
  
            _2654435878.trainIdx mR22jPCjbltZ3tbBmn_6w 	 
    	  
    _3005399814901981436.ids mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
 _2654435878.trainIdx mvFhi6DaS7eScbgWe07wY 	 
    	  
     mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
  
         mEjIWbivPeVc9WtxGDiWw 	 
    	  
  
        
         mcAnVuQmAnGunjGyL6dhh 	 
    	  
    		   int _2654435874 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
     0 mC_gLvnw5tkMWRQheRKr5 	 
   _2654435874 mJCQ17ktBLqNw7sHF60R1 	 
    	  _1524129789187101628 msGAdK1RZcxCitYemdpxc 	 
    	  
_175247762874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
     
     
 ._12720020569689445873.size mecU92YjgSbB3VkEoZVK3 	 mqLizGA4Z8QZ_2GYQ1inC 	 
 _2654435874 mMbWC8gQeXmnMqYEj20Wf 	 
    	   mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
  mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
 
             mS0R9s7sfcYa3Nx39taZW 	 
    	  
    		   
     
 &_175247759380 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     _1524129789187101628 mVjuVop3osym9wWoq6p3w 	 
    	  
    		  _175247762874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
    		   
     
   ._12720020569689445873 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
     
  _2654435874 mAH84ftHkJMUldxM9fJHE 	 
    	  
    		   
  .trainIdx mQivdop_Gb4hqsWvOttc3 	 
    	  
   
             myfOHlfTLtRL7im7qSaYm 	 
    	  
    		   
     
     
 
  	  molF5K16MuyVvkFE7X8JI 	 
    	  
    		   
 _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
map_points.is mOAy4qGUJpdHQSVbVPq9E 	_175247759380 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
  mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   

                _1524129789187101628 mVLLVWqNz0_lGN56vY03t 	 _175247762874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
     
 ._12720020569689445873 mstJEG25u0Qv4VQocWgKl 	 
    	  _2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		 .trainIdx mtmFAz7pcnIFLgYGMf4eK 	-1 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		  
             myfOHlfTLtRL7im7qSaYm 	 
    	  
    		   
   _9098980761384425343 mSwbK3nBcNZkvGxSXNOZy 	 
    	  
    		   
map_points mZloAr3_PPw7622AVrUCe 	 
    	  
    		   
     
     
 
  _175247759380 mAH84ftHkJMUldxM9fJHE 	 
    	  .isBad mGu_88Fdde5jsxW8v9whR 	 
    mT3v8xdcVsSvUtbwmHC7j 	 
    	 
                _1524129789187101628 mZ9T0z5VdOHGC7rra8Fzk 	 
    	  
    		   
     
     
 _175247762874 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
    		 ._12720020569689445873 msGAdK1RZcxCitYemdpxc 	 
    	  
    		   
     
     
 
  	_2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
   .trainIdx mA7hUM4UKqFyb_LJLsook 	 
    	 -1 mxIwd_EJpfr1C9jwU7IyL 	 
   
         mqVdZVftPR84WTjiOiVfT 	 
    
        remove_unused_matches mNQ6rNLARkxxSTP6tiTXG 	 
    	  _1524129789187101628 mVjuVop3osym9wWoq6p3w 	 
    _175247762874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
 ._12720020569689445873 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
 mxIwd_EJpfr1C9jwU7IyL 	
         mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		  mOAy4qGUJpdHQSVbVPq9E 	 
    	  
 _1524129789187101628 msGAdK1RZcxCitYemdpxc 	 
    	  
  _175247762874 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
    		   
     
     ._12720020569689445873.size mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
      mLS76iLDjnGxttL6L8yfX 	 
    	  
    25 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
  continue mQivdop_Gb4hqsWvOttc3 	
        _1524129789187101628 msGAdK1RZcxCitYemdpxc 	 
    	  
    		   
     
_175247762874 mWi16Wz7P86SIJlTQEzCB 	 
    	  
    		   ._11424282724131190187 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
 _3005399814901981436.pose_f2g mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     

         
        PnPSolver mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   solvePnPRansac mTiWUgQKOeYLvNdGsR_oS 	_16940374161494853219,_9098980761384425343,_1524129789187101628 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
     
    _175247762874 mQbYLzhvVQm8J2LNkC6S6 	 
    	._12720020569689445873,_1524129789187101628 mstJEG25u0Qv4VQocWgKl 	 
    	  
   _175247762874 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
  ._11424282724131190187 mVFG05ubhW6ia_rWdS_Tv 	 
    	   m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
  
          muDvj5aUdXshb2AqqeEiu 	 
    	  
    		   
  mgGCFceAojKPG0bK5eWQT 	 
    	  
  _1524129789187101628 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
     
     
 
  _175247762874 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
     
   ._12720020569689445873.size mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
    mHg0YG9R0Gb6ZE5xIr3dz 	 
    	  
   15 mSBNIRK1XqZg3XlWW_b3d 	 
    continue myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
  
        
        _1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   _175247762874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
  ._12720020569689445873 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
      _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    matchFrameToMapPoints  mUGrJMUolw0lb_KVyGK5N 	 
    _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
   TheKpGraph.getNeighborsVLevel2 mYcSgTugFLQcmWT7seaac 	 
  _175247760268,true mSBNIRK1XqZg3XlWW_b3d 	 
    	  
 , _16940374161494853219,  _1524129789187101628 mVLLVWqNz0_lGN56vY03t 	 
    	  
    		   
   _175247762874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		 ._11424282724131190187 ,_14938569619851839146.maxDescDistance*2, 2.5,true mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		  mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 
 
         muDvj5aUdXshb2AqqeEiu 	 
    	  
    		   
     
   mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
_1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	 
    	_175247762874 mfF196cGKZ_LkBPN8ZWlr 	 ._12720020569689445873.size mjjfaXD3tH8warSj13sVr 	 
    	  
   moCEmVQeGy8LzV8cAuk79 	 
    	  
    		   
     
     
30 mPaUdMg3fg2ipZY0Exj7X 	 continue mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   

        
        PnPSolver mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
solvePnp mBGM118Iia8vm6zcNTuB6 	 
_16940374161494853219,_9098980761384425343,_1524129789187101628 mMo20fFU0rdQJ7l5qqDaX 	_175247762874 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
    		  ._12720020569689445873,_1524129789187101628 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
   _175247762874 mtEI4bSjtkyV5O0qz_vBz 	 
    	  
    		   
     
     
._11424282724131190187 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
  mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
 
          mHbSWrX6OPeRP2Igmog8G 	 
    mgGCFceAojKPG0bK5eWQT 	 
    _1524129789187101628 mbtzLVjzLgaxYxNNltfyM 	 
 _175247762874 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
     
     
._12720020569689445873.size mecU92YjgSbB3VkEoZVK3 	 mbVOLbjVZO0YI60Vuguaq 	 
    	  
    		   
    30 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
 
  continue mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		  
        _1524129789187101628 mZloAr3_PPw7622AVrUCe 	 
    	  
    		   
     
     
 
  _175247762874 mWjWwCxBA7LLBixCoRsYZ 	 
. _6253874806036432733 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
 _16940374161494853219.ids mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   

         mTy5S_mcphfNLzuJQ30Xe 	 
 auto _46082575882272165: _1524129789187101628 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
     
     
 _175247762874 mQbYLzhvVQm8J2LNkC6S6 	 
._12720020569689445873 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
            _1524129789187101628 mwzFZRcSPi2Vsk45HpaLx 	_175247762874 ml5d8mzmxNmQRMtpfZ82X 	 
    	  
    		   
     
     
 ._6253874806036432733 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
     
  _46082575882272165.queryIdx mvFhi6DaS7eScbgWe07wY 	 
    	 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    _46082575882272165.trainIdx mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   

     msBPMso4NRYFcn5Y1myF_ 	 
    	  
    
    std me0ZKHp2Id3eLmP_6GMtk 	 
   sort mNQ6rNLARkxxSTP6tiTXG 	  _1524129789187101628.begin mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     
     
 
  ,_1524129789187101628.end mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
   , mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
  mOwAFTnFZjoBWI2gNeAO_ 	 
    	  mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
const _16997332234748947065 &_2654435866,const _16997332234748947065 &_2654435867 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
 mXdnll4yjwVy4uBDSjUe3 	 
return _2654435866._12720020569689445873.size mjjfaXD3tH8warSj13sVr 	 
    	  
 mJJosB3DZCYh837sWRpN7 	 
    	_2654435867._12720020569689445873.size mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
     
 
  myu64GAT8DgGBhNOOCqvd 	 
    	  mf0YJDuh2j5By5N13LunG 	 
    	  
    		   
     
     
 
  	 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
 
     mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
   mOAy4qGUJpdHQSVbVPq9E 	 
    	  _1524129789187101628 mMo20fFU0rdQJ7l5qqDaX 	0 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
     
 ._12720020569689445873.size mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     mVIm1AJSzhahLlgKO9xQK 	 
    	  
    		   
     
     
 
30 msDy4S0F6Zdx78ZUnbARe 	 
 mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
 
        _13011065492167565582 moHeIYzwbcFb6VaM90Aa9 	 
    	  _1524129789187101628 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
     
     
 
  0 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
 ._11424282724131190187 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  	
        _16940374161494853219.ids mR22jPCjbltZ3tbBmn_6w 	 
    	  
    	_1524129789187101628 msGAdK1RZcxCitYemdpxc 	 
    	  
    		   
0 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    ._6253874806036432733 mQivdop_Gb4hqsWvOttc3 	 
   
         mV4_AbWY8ymaWGsYOk0LC 	 
    	  
    		   
     
     
 
  	true mwkk1d6uUiyaKys71tsUv 	 
    	  
    		
     mqVdZVftPR84WTjiOiVfT 	 
    	  
  
     mcCwozNc9ZEKnXkmsh9Fj 	 
    	  
    		   
     
 my5S_tF4_lSpButBKNitX 	 false mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
  
 msxc6utIaOFXg4WI3vB0q 	 
    	  
    		   

 mFqi0ZIcB_YhZ2B8QBIQg 	 
    	  
    System miuOs6oIdxnQEMrFFk2n_ 	_14569675007600066936 mbXhD242DJoibBjdI1JtA 	 
    	  
 Frame &_2654435871,se3 &_13011065492167565582  mVmWtYm5gVtZj7Yq19XWE 	 mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
 
     mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
     
     
 
   mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
   _2654435871.markers.size mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
      mlEF62Izit24hGT_NqPIJ 	 
0 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  return false mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
    
    vector mnpObQ1mWnyfQO24_ojBn 	 
    	  
    		 uint32_t mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
     
     
  _7895328205142007059 mC_gLvnw5tkMWRQheRKr5 	 

     mWIOGoR1XyrR6fw03i9px 	 
   mFTobXyS5Vx9ebVESwR0T 	 
    	  
    		   
     
     
 &_2654435878:_2654435871.markers mT3v8xdcVsSvUtbwmHC7j 	  mi4REkBAebpTZrzlvFEpD 	 
    	  
    		   
 
         mFTobXyS5Vx9ebVESwR0T 	 
    _8332348524113911167 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
  _9098980761384425343 mSwbK3nBcNZkvGxSXNOZy 	 
    	  
    		   
     
     
map_markers.find mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
  _2654435878.id mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
 mC_gLvnw5tkMWRQheRKr5 	 
   
         mz0gDEk4XJJySbEeCgC9P 	 
    	  
    		_8332348524113911167 mS3P8ZWKrLHg9h_5dW5He 	 
 _9098980761384425343 mdMNbPkq6p5KBhEVf3OFw 	 
    	  
    		   
   map_markers.end mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
     mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
             mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
      _8332348524113911167 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
     
   second.pose_g2m.isValid mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
     
 
  mSBNIRK1XqZg3XlWW_b3d 	 
    	  
  
                _7895328205142007059.push_back mlfybwyvp98TOJj0yuqhF 	 _2654435878.id muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
    mxIwd_EJpfr1C9jwU7IyL 	 
    	
     mf0YJDuh2j5By5N13LunG 	 
    	  
    		   
     
    
     mbCI0BlZHp5kbKpNqa5Su 	 
     mNQ6rNLARkxxSTP6tiTXG 	 
  _7895328205142007059.size mTGJXDnkacX2UX9dooHQu 	 
    	 mw_MIhwcw8TZ9gTF3_mEt 	 
 0 muC5cqYcHRXDD16noARI1 	 
    	  
    		   return false mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
 
  _13011065492167565582 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
      _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    getBestPoseFromValidMarkers mBGM118Iia8vm6zcNTuB6 	 
   _2654435871,_7895328205142007059,_14938569619851839146.aruco_minerrratio_valid mSBNIRK1XqZg3XlWW_b3d 	 
    	  
  mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 
  	 
   mY5hSAdXT4P60CSAZFBBa 	 
    	  
    		   
    _13011065492167565582.isValid mdbwYCIpGYWahFfTtU8zH 	 
    	  mxIwd_EJpfr1C9jwU7IyL 	
 mf0YJDuh2j5By5N13LunG 	
  muh7SNXP3UdOZu6GOuG0_ 	 
    	  
    		   
     
     
 
  	 System mExFPeJBflhTWJKuQVWoB 	 
    	  
  _16487919888509808279 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
Frame &_2654435871, se3 &_13011065492167565582 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
    mi4REkBAebpTZrzlvFEpD 	 
    	  
    		
    _13011065492167565582 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
 se3 mGu_88Fdde5jsxW8v9whR 	 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   

     mxkHJa5wooqhzaSxK7_fd 	 
    	  
    		   
     
  mNQ6rNLARkxxSTP6tiTXG 	  _14569675007600066936 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     _2654435871,_13011065492167565582 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
      mLp5eeYn1TGnQEcop68VN 	 
    	 true mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
  
     mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		  mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
  	_3570943890084999391 mYcSgTugFLQcmWT7seaac 	 
_2654435871,_13011065492167565582 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  	   mFWbNGU5e6cuqyQa3XUry 	 
    	  
    		   
    true mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     

     mUnahx7x8KWu62epS7OxV 	 
   mT9nS5aSA2ErLjcHqOPSA 	 
    	  
 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     

 msBPMso4NRYFcn5Y1myF_ 	 
    	  
    	


std me0ZKHp2Id3eLmP_6GMtk 	 
    	  
  vector mbVOLbjVZO0YI60Vuguaq 	 
    cv mrS2zvlmrTf4L4KBRRYAU 	 
    	DMatch meN5YYBBVg5DStfnyA8Dd 	 
    	  
    		   
     
     
 
  System mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
  _11946837405316294395 mOAy4qGUJpdHQSVbVPq9E 	 
    	Frame & _16940374161810747371, Frame &_5918541169384278026,  mrg1QVINMqbRYZWngNWmj 	 
    	  
 _1686565542397313973,  mrjcvI9ucBIaCRtqGyrWD 	 
    	  
    		   
     
     
_4500031049790251086 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
 
 mi4REkBAebpTZrzlvFEpD 	 
    	
    
    std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
    vector miGVtxwiqbDQsG6KBslZU 	 
    	  
    		   
     
     
 
  cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
 DMatch mYbzFOKSwwNsD71cP1DkA 	 
     _6807036698572949990 mQivdop_Gb4hqsWvOttc3 	 
    	  
    	
     mN_UNAeshLaooczmV1nkW 	 
    	  
    		   
     size_t _2654435874 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     0 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    	_2654435874 mnpObQ1mWnyfQO24_ojBn 	 
    	  
_5918541169384278026.ids.size mrXXIs5j4DqJtj32aOG5F 	 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		  _2654435874 mtIfgwpprqjFMhHY9FVrL 	 
    	  
    		   
      mPaUdMg3fg2ipZY0Exj7X 	 
    	  
     mi4REkBAebpTZrzlvFEpD 	 
    
         mQYacSpatR0AsiZrXS4cE 	 
    	  
   _11093822294347 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
   _5918541169384278026.ids mZ9T0z5VdOHGC7rra8Fzk 	 
    	  
    		   
_2654435874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    		   
     
     
  mEm194VmPJuGh5y4tMUm5 	 
    
         mxkHJa5wooqhzaSxK7_fd 	 
    	  
    		   
 mYcSgTugFLQcmWT7seaac 	 
    	 _11093822294347 mcozC0jwDOrxnYpsfODix 	 
    	  
    		   
     
   std mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
     
     
 
numeric_limits mbVOLbjVZO0YI60Vuguaq 	 
    	  
  uint32_t mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
     
     
 
  	 mrPFLPKakBKjOOnkuhZUP 	 
    	  
max mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
     
 mJk4eXgp_IeFV2YvLaQC7 	 
     mJdlQJg0rG2m7KHUChC3R 	 
    	  

             mg9IHDbTXxljO0nSnQKYh 	 
    	   _9098980761384425343 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		   
     
     
 
 map_points.is mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
   _11093822294347 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   mXftmBtLFUrPFw3lasjuW 	 
  mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
 
                MapPoint &_3005399799907669332 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
     
 _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
     map_points mZloAr3_PPw7622AVrUCe 	 
    	  
    		   
     
    _11093822294347 mWi16Wz7P86SIJlTQEzCB 	 
    	  
 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
   
                 mAvI6WqVGKew5QUXF0T2l 	 
 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
_3005399799907669332.isBad mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		  continue mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
                 mkcVgqnqADeTh3Pu1ogGF 	 
    	  
_11093822300120 mtmFAz7pcnIFLgYGMf4eK 	_16940374161810747371.project mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
    _3005399799907669332.getCoordinates mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
    ,true,true mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
      mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
                 mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
   isnan mYcSgTugFLQcmWT7seaac 	 
    	  
    		 _11093822300120.x mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     
 
continue myu64GAT8DgGBhNOOCqvd 	 
  
                
                 mU7LO3jg27wf5nw3n8LF7 	_175247759755 mhL9dWuOWzLGBfRjwvYlN 	_16940374161810747371.scaleFactors mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
  _5918541169384278026.und_kpts mstJEG25u0Qv4VQocWgKl 	 
    	_2654435874 mtEI4bSjtkyV5O0qz_vBz 	 
    .octave mGPgWaVxS3WdTr7rWsMw4 	 
     m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 
 
                 mise5YGBUx6xBGs9EUolB 	 
    _3005399801676750422 mA7hUM4UKqFyb_LJLsook 	 
    	  
   _5918541169384278026.und_kpts mMo20fFU0rdQJ7l5qqDaX 	 
    	  
    		   
     
     
 
  	_2654435874 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
     
     
 .octave mQivdop_Gb4hqsWvOttc3 	 
    	  
  
                std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
     
 
  	vector mJCQ17ktBLqNw7sHF60R1 	 
    	  
    		   
     
     
uint32_t maPL1kl9f9VlgIn9jnnN_ 	 
    _10924592426265627429 moHeIYzwbcFb6VaM90Aa9 	 _16940374161810747371.getKeyPointsInRegion mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
 _11093822300120,_4500031049790251086*_175247759755,_3005399801676750422,_3005399801676750422 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
   
                 mrIWO5AmcxVfFGpyNJzQE 	 
    	  _16940367568811467085 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
     
     _1686565542397313973+0.01,_16992066385107317811 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
 
  std mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
   numeric_limits mk9nSfh6XGyonOYMC8C3M 	 
    	 float mpBV2mt4yeFwcVEC5cxVw 	 
    	  
    		   
     me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     
     
max mTGJXDnkacX2UX9dooHQu 	 
    	  
    	 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		
                 mbdlGyMOiuL6kjlXvSqqd 	 
    	  
    		   
     
     
_6806984971934960832 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
std mrPFLPKakBKjOOnkuhZUP 	 
    	numeric_limits mbVOLbjVZO0YI60Vuguaq 	 
    	  
    		   
     
     
 uint32_t mpBV2mt4yeFwcVEC5cxVw 	 
    	  
     mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
  max mrXXIs5j4DqJtj32aOG5F 	 
    	  
  mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
 
                
                 mIyrnAZ9pLZEaiK6Yst1L 	 
    	  
    auto _175247760278:_10924592426265627429 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 
  	 mjXlfKOCTRjUV9apwYcb7 	 
 
                     mHbSWrX6OPeRP2Igmog8G 	 
    	  
    		   
     
  mlfybwyvp98TOJj0yuqhF 	 
    	   _16940374161810747371.und_kpts mbtzLVjzLgaxYxNNltfyM 	 
   _175247760278 mAH84ftHkJMUldxM9fJHE 	 
    	  
    		   
     
.octave  mtDWQOqRguVWSWehbKECr 	 
    	  
    		   
     
     
 
  	 _5918541169384278026.und_kpts mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
_2654435874 mWjWwCxBA7LLBixCoRsYZ 	 
    	  
    		 .octave  mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		    mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
    
                         mRIlZ0NriRkVMhRpycZqI 	 
    	  _16940392174182767813 mR22jPCjbltZ3tbBmn_6w 	 
    	   MapPoint mrPFLPKakBKjOOnkuhZUP 	 
    	 getDescDistance mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     
 
  _5918541169384278026.desc,_2654435874, _16940374161810747371.desc,_175247760278 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     

                         mr8s7pfvTmBWmxher3Oue 	 
    	   mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		    _16940392174182767813 mkHL8KJw4VjwmGdgQrteX 	 
    	  
    		   
     
  _16940367568811467085 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   mjXlfKOCTRjUV9apwYcb7 	 
 
                            _16940367568811467085 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
   _16940392174182767813 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
 
                            _6806984971934960832 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
     
 
 _175247760278 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     

                         mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
  
                         mcCwozNc9ZEKnXkmsh9Fj 	 
    	  
    		   
    mt3m0c1_35lMMq0E3cZsZ 	 
    	  
    		   
    mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
 _16940392174182767813 mRwYPGmWUou3ixNnKEWbv 	 
    	  
    		   
     
     
 
  	 _16992066385107317811 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
  mqlayz2fShj6ePxekxwRg 	 
    	
                            _16992066385107317811 mRDD8w83SsPKbGXy_JkEO 	 
    	 _16940392174182767813 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		  
                         mqVdZVftPR84WTjiOiVfT 	 
    	  

                     miXz43zs_DqtraKQW0m3N 	 
                 msBPMso4NRYFcn5Y1myF_ 	 
                
                 muDvj5aUdXshb2AqqeEiu 	 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     _6806984971934960832 mmk2RogyswbtTiHnbCghT 	 std mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
     
     
 
  	 numeric_limits mRwYPGmWUou3ixNnKEWbv 	 
  uint32_t mKJK3THIuAwgeFpuGLN8L 	 
    	  
  mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     
 max mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		     mtq_QCXPpv2kX7L8PRz8d 	 
    	  
    		   
     
     
 
 _16940367568811467085 mkHL8KJw4VjwmGdgQrteX 	 
    	  
    		    0.7*_16992066385107317811 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
  mXdnll4yjwVy4uBDSjUe3 	 
    	  
                    cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     
     
 DMatch _175247759376 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 
  	 
                    _175247759376.queryIdx  mR22jPCjbltZ3tbBmn_6w 	 
    	  
    	 _6806984971934960832 mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
   
                    _175247759376.trainIdx  mIqjSmilXv9ILvDddB7nD 	 
    	   _3005399799907669332.id mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
  	         
                    _175247759376.distance  mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
 _16940367568811467085 mqLizGA4Z8QZ_2GYQ1inC 	 
   
                    _6807036698572949990.push_back mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
  _175247759376  mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
   m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		 
                 mMGejH_coNc3kGxAdXVex 	 
  
             msxc6utIaOFXg4WI3vB0q 	 
         m_ECAXF5hGu1UMoS2l1KU 	 
    	  
    		   
     
     
 
  
     m_ECAXF5hGu1UMoS2l1KU 	 
    	  
    		   
 
    filter_ambiguous_query mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
     
_6807036698572949990 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
    mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
  
     mV4_AbWY8ymaWGsYOk0LC 	 
    	 _6807036698572949990 mxIwd_EJpfr1C9jwU7IyL 	 
    	  

 msxc6utIaOFXg4WI3vB0q 	 
    	  
    


se3 System mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    _11166622111371682966 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		 Frame &_16940374161810747371,se3 _14387478432460351890 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
  mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   
 
        
    std mvpMkjoDGcQujDevHDZnx 	 
    	  
vector mRwYPGmWUou3ixNnKEWbv 	 
    	  cv mNQimRrYQ8Mz6YI9KM7Fn 	 
  DMatch mW202Akoy5o2_FFUMtz7a 	 
    	  
    		    _637068542992099399 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  	 
    se3 _5769551021164122736 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
 _14387478432460351890 m_yMT4MKxrENTtLx5cA7n 	    
    
      mAvI6WqVGKew5QUXF0T2l 	 
    	  
    		   
     
    mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
 _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		   
     map_points.size mRAYh0ARHPOc62CfGHWWO 	 
    	  
     meN5YYBBVg5DStfnyA8Dd 	 
    	  
    		   
     
     
 
  	0 msDy4S0F6Zdx78ZUnbARe 	 
    	   mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
 
 
          muDvj5aUdXshb2AqqeEiu 	 
    	  
    		   
     
    mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     
     
 
 mkyly54GlrbXuNeECTTqk 	 _14463320619150402643.empty mecU92YjgSbB3VkEoZVK3 	 
   mxAXsCfNkscq4iQtE2AeY 	 
  
             _5769551021164122736 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
 _14463320619150402643*_5769551021164122736.convert mJFtpHxfnoGMxp1wzTBMr 	 
  mC_gLvnw5tkMWRQheRKr5 	 
    	  
    	
        _16940374161810747371.pose_f2g mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
     
 
  _5769551021164122736 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
 
        
        _637068542992099399 mvA2vjSvRD7UmknjmYP5U 	 
_11946837405316294395 mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 
  	_16940374161810747371,_4913157516830781457,_14938569619851839146.maxDescDistance*1.5,_14938569619851839146.projDistThr mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
    mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		
         mIBLQ6_qDoS3S2lLQGZ3e 	 
    	  
    		   
     
     
_9870110657242862171 mhL9dWuOWzLGBfRjwvYlN 	 
   0 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
         mHbSWrX6OPeRP2Igmog8G 	 
    	  mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     
 _637068542992099399.size mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
     
 
   mJJosB3DZCYh837sWRpN7 	 
    	  
    		   
   30   msDy4S0F6Zdx78ZUnbARe 	 
  mjXlfKOCTRjUV9apwYcb7 	 
    	  
    		   
     
     
             mEhFK99MtLRsCBaPNqnDs 	 
    	  
    		   
     
     _14671559813105454070 mXE5wWRmJGUY4EsEsgegT 	 
    _5769551021164122736 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
            _9870110657242862171 mRDD8w83SsPKbGXy_JkEO 	 
    	  PnPSolver mExFPeJBflhTWJKuQVWoB 	 
    	  
    	solvePnp mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
 _16940374161810747371,_9098980761384425343,_637068542992099399,_14671559813105454070,_10576739190144361304 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
   mEm194VmPJuGh5y4tMUm5 	 
  
             mFVNERjMRO_ZEKm0TY73X 	 
    	  
    		   
     
     
 
  mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
     
 
 _9870110657242862171 mpBV2mt4yeFwcVEC5cxVw 	 
    	  
    		   
     
     
 30 mJk4eXgp_IeFV2YvLaQC7 	 
 _5769551021164122736 mA7hUM4UKqFyb_LJLsook 	 
    	  
    		   
     
     _14671559813105454070 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
         mMGejH_coNc3kGxAdXVex 	 
    	  
    		   
     
     
 
 
        else mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		   
    
            
            FrameMatcher _16997326787393468537 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
FrameMatcher mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
TYPE_FLANN mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  mC_gLvnw5tkMWRQheRKr5 	 
    	  
    	
            _16997326787393468537.setParams mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
      _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	keyframes mZloAr3_PPw7622AVrUCe 	 
    	 _10576739190144361304 mAH84ftHkJMUldxM9fJHE 	 
    	  
    		   
   ,FrameMatcher mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    MODE_ASSIGNED,_14938569619851839146.maxDescDistance*2,0.6,true,3 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    	 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
 
            _637068542992099399 mA7hUM4UKqFyb_LJLsook 	 
 _16997326787393468537.match mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
     _16940374161810747371,FrameMatcher mrPFLPKakBKjOOnkuhZUP 	 
 MODE_ALL mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
   mI30mSPxGJaQtkEjJfoQX 	
             mg9IHDbTXxljO0nSnQKYh 	 _637068542992099399.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    		 mYbzFOKSwwNsD71cP1DkA 	 
    	  
    		   
     
 30 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 mqlayz2fShj6ePxekxwRg 	 
    	  
    		   
     
                
                 mWIOGoR1XyrR6fw03i9px 	 
    	  
    		auto &_2654435878:_637068542992099399 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
     
                    _2654435878.trainIdx mH9fKsRtHWNu77RGN1xmn 	 
    	  
  _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    	keyframes mZ9T0z5VdOHGC7rra8Fzk 	 
  _10576739190144361304 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
    .ids mRjEKX4QN9MTvSEtCTNd7 	 
   _2654435878.trainIdx mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		    mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     

                 mEhFK99MtLRsCBaPNqnDs 	 
    	_14671559813105454070 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     _5769551021164122736 mEm194VmPJuGh5y4tMUm5 	 
    	  
    
                _9870110657242862171 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
     
 
  	PnPSolver miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
    solvePnp mOAy4qGUJpdHQSVbVPq9E 	 _16940374161810747371,_9098980761384425343,_637068542992099399,_14671559813105454070,_10576739190144361304 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
  mI30mSPxGJaQtkEjJfoQX 	 
    	  
  
                 mt3m0c1_35lMMq0E3cZsZ 	 
    	  
   mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     
 
  	 _9870110657242862171 mNF0G2xPBB22gI9XzMk2L 	 
    	  
    		   
30 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     _5769551021164122736 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
 _14671559813105454070 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
             msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		 
             mEYy4vDSh1urfYj6Y0xAX 	_9870110657242862171 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
     
     
 
  0 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
 
         msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
 
         mrjcvI9ucBIaCRtqGyrWD 	 
 _3763415994652820314 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		
         mr8s7pfvTmBWmxher3Oue 	 
    	   mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
    _9870110657242862171 mNF0G2xPBB22gI9XzMk2L 	30 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    mJdlQJg0rG2m7KHUChC3R 	 
  
            _3763415994652820314 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    	4 mwkk1d6uUiyaKys71tsUv 	
             mWIOGoR1XyrR6fw03i9px 	 auto _2654435878:  _637068542992099399  mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
   mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
     
   
                _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
    map_points mZloAr3_PPw7622AVrUCe 	 
    	  
    		   
     
    _2654435878.trainIdx mvFhi6DaS7eScbgWe07wY 	.lastFIdxSeen moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		 _16940374161810747371.fseq_idx mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		
                _9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
    		   
     
     
 map_points mRjEKX4QN9MTvSEtCTNd7 	 
    _2654435878.trainIdx mvFhi6DaS7eScbgWe07wY 	 
.setVisible mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
     mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  
             msxc6utIaOFXg4WI3vB0q 	 
 
         mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     
   
        else mJdlQJg0rG2m7KHUChC3R 	 
            _637068542992099399.clear mIJkWACd8Uom4Jv6selID 	 
    	  mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
 
 
            _3763415994652820314 mvA2vjSvRD7UmknjmYP5U 	 
  _14938569619851839146.projDistThr mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		  
         mL9oWJQ1n2xKG3FtRNowa 	 
    	  
    		   
     
    
        
         mf5rJKHDmIhT9kr_E2lnd 	 
    	  
  _3521005873836563963  mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
      _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
     
   matchFrameToMapPoints  mlfybwyvp98TOJj0yuqhF 	 
    _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
     
 
TheKpGraph.getNeighborsVLevel2 mNQ6rNLARkxxSTP6tiTXG 	 
   _10576739190144361304,true mVmWtYm5gVtZj7Yq19XWE 	  , _16940374161810747371,  _5769551021164122736 ,_14938569619851839146.maxDescDistance*2, _3763415994652820314,true mT3v8xdcVsSvUtbwmHC7j 	 
    	  
 mqLizGA4Z8QZ_2GYQ1inC 	 
        
        _637068542992099399.insert mbXhD242DJoibBjdI1JtA 	 
    	_637068542992099399.end mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
     
     
 
  	 ,_3521005873836563963.begin mIJkWACd8Uom4Jv6selID 	 
    	  
    		   
     
     ,_3521005873836563963.end mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
     
  mXftmBtLFUrPFw3lasjuW 	 
    	  mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
        filter_ambiguous_query mlfybwyvp98TOJj0yuqhF 	_637068542992099399 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
   mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
 
     mEjIWbivPeVc9WtxGDiWw 	 
    	  
    		   
     
 
      muoE4XIKfPRSXmzic7wiv 	 
    	  
    		_8650310500205049352 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
     
PnPSolver mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
     
solvePnp mBGM118Iia8vm6zcNTuB6 	 
    	  
  _16940374161810747371,_9098980761384425343,_637068542992099399,_5769551021164122736,_10576739190144361304 msDy4S0F6Zdx78ZUnbARe 	 
    	  mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
 
 
    
    
     muh7SNXP3UdOZu6GOuG0_ 	 
    	  
    		 _6535949166237672095 mIqjSmilXv9ILvDddB7nD 	 false mxIwd_EJpfr1C9jwU7IyL 	 
    	  
     mHbSWrX6OPeRP2Igmog8G 	 
    	  
    		   
     
      mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
 _16940374161810747371.markers.size mGu_88Fdde5jsxW8v9whR 	 
    	  
     mW202Akoy5o2_FFUMtz7a 	 
    	  
    		   
     
  0 mxAXsCfNkscq4iQtE2AeY 	 
    	   mXdnll4yjwVy4uBDSjUe3 	 
  
         mN4RvsK7_XXMC2cNCwITM 	 
    	  
    		   
     
    _9870110666330890270 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
   0 mEm194VmPJuGh5y4tMUm5 	 
    	  
    
        
         mFS3Bzv40ET2Bg_bjcFGO 	 
    	  
    		   
     
     
 size_t  _2654435874 mhL9dWuOWzLGBfRjwvYlN 	 
    	  0 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
_2654435874 mJCQ17ktBLqNw7sHF60R1 	   _16940374161810747371.markers.size mTGJXDnkacX2UX9dooHQu 	 
    	  
    		   
 mo9Lbpy0Ap4RTl5O5Or1C 	 _2654435874 mgux57p4wBZIWFfq6waj5 	 
    	  
    		   
     
     
 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
   mqlayz2fShj6ePxekxwRg 	 
    
            
             mBUCZuaNioFkzVtaa2sRQ 	 
    	  
    	_11093822290813 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    	_9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		   
  map_markers.find mlfybwyvp98TOJj0yuqhF 	 
    _16940374161810747371.markers mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		  _2654435874 mOwAFTnFZjoBWI2gNeAO_ 	 
 .id mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
   
             mg9IHDbTXxljO0nSnQKYh 	 
    	  
    		   
     
     
_11093822290813 mlEF62Izit24hGT_NqPIJ 	 
    	  
    		 _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
map_markers.end mjjfaXD3tH8warSj13sVr 	 
     mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    continue m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
   
             mHbSWrX6OPeRP2Igmog8G 	 mbXhD242DJoibBjdI1JtA 	 
   mteJvtUMKI6kC6j6RtZKr 	_11093822290813 msDVYCHuU_j2g_TdgX4Ta 	 
    	second.pose_g2m.isValid mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
    mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
    continue mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
            _9870110666330890270 mMbWC8gQeXmnMqYEj20Wf 	 
    	  
  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		 
            
             mr8s7pfvTmBWmxher3Oue 	 
    	  
    		   
     mbXhD242DJoibBjdI1JtA 	 
    	  
    		 _16940374161810747371.markers mZloAr3_PPw7622AVrUCe 	 
    	  
    		   
   _2654435874 ml5d8mzmxNmQRMtpfZ82X 	 
    	  
    		   
     
     
 
  	 .poses.err_ratio  mbVOLbjVZO0YI60Vuguaq 	 
    	  
     _14938569619851839146.aruco_minerrratio_valid mVFG05ubhW6ia_rWdS_Tv 	 
    	  continue mC_gLvnw5tkMWRQheRKr5 	 
            _6535949166237672095 mR22jPCjbltZ3tbBmn_6w 	 
    true myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     

            break mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
         mwiKr6psttEx97f2NsYO1 	
         mAvI6WqVGKew5QUXF0T2l 	 
    	  
    mgGCFceAojKPG0bK5eWQT 	 
   _9870110666330890270 mJJosB3DZCYh837sWRpN7 	 
    	  
    		   
 1 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
      _6535949166237672095 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		   
     
   true mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
 

     m_ECAXF5hGu1UMoS2l1KU 	 
    	  
    		   
     
     
     mHbSWrX6OPeRP2Igmog8G 	 
    	  
 mBGM118Iia8vm6zcNTuB6 	 
    	 _8650310500205049352 moCEmVQeGy8LzV8cAuk79 	 
    	  
    		   
  30  mfLSKCXSc1DHeN38jALNR 	 
    molF5K16MuyVvkFE7X8JI 	 
    	  
    		   
     
 _6535949166237672095 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     mJdlQJg0rG2m7KHUChC3R 	 
    	  
    		  
      mSXTPhnnQgIi6ocmukNcV 	 
    	  
    		   
     
   se3 mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
 mC_gLvnw5tkMWRQheRKr5 	 
    	 
     mwiKr6psttEx97f2NsYO1 	 
    	  
    		   
     
   
    
     mmeJW_Q9h6ZBPzSBQVjMK 	 
    	  size_t _2654435874 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
   0 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
_2654435874 moCEmVQeGy8LzV8cAuk79 	 
    	  
    		   
     
     
 
 _637068542992099399.size mdbwYCIpGYWahFfTtU8zH 	 
    	  
    		   
   mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   _2654435874 mtIfgwpprqjFMhHY9FVrL 	 
    	  
    		   mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
      mXdnll4yjwVy4uBDSjUe3 	 
    	  
    		   
   
            _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
    		 map_points mVjuVop3osym9wWoq6p3w 	 
 _637068542992099399 mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		_2654435874 mWi16Wz7P86SIJlTQEzCB 	 
    	  
    		   
.trainIdx mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
     
    .setSeen mecU92YjgSbB3VkEoZVK3 	 
    	 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 
  	 
            _16940374161810747371.ids mbtzLVjzLgaxYxNNltfyM 	 
    	  
    _637068542992099399 mZ9T0z5VdOHGC7rra8Fzk 	 
    	  
    		   
     
     _2654435874 ml5d8mzmxNmQRMtpfZ82X 	 
    	  
    		   
     
     
 
  	.queryIdx mAH84ftHkJMUldxM9fJHE 	 
    	  
  mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
_637068542992099399 mVLLVWqNz0_lGN56vY03t 	 
    	  
    		   
     
   _2654435874 mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
     
     
.trainIdx mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
             mHbSWrX6OPeRP2Igmog8G 	 
    	  
    		    mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
    _637068542992099399 mbtzLVjzLgaxYxNNltfyM 	 
    	  
    		   
  _2654435874 mQbYLzhvVQm8J2LNkC6S6 	.imgIdx mIHFqVJpFXgMDdHn2uhc3 	 
    	  
    		   
   -1 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     
 
  	 
                _16940374161810747371.flags mwzFZRcSPi2Vsk45HpaLx 	 
    	  
    		   
     
     _637068542992099399 mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
 _2654435874 mAH84ftHkJMUldxM9fJHE 	 
    	  
   .queryIdx mfF196cGKZ_LkBPN8ZWlr 	 
    	  
    		   
     
    .set mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     
 
  Frame mvpMkjoDGcQujDevHDZnx 	 
    	  
   FLAG_OUTLIER,true mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
   m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 
  	
     miXz43zs_DqtraKQW0m3N 	 
    	  
    		   
     mIaPM1ms991SDrw4x6KTt 	 
    	  
    		   
     
     
 
 _5769551021164122736 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
  
 miXz43zs_DqtraKQW0m3N 	 
    	  
    		   
     
    
 mgBFSWJlmkK48wSOW4b6N 	 
System mrS2zvlmrTf4L4KBRRYAU 	_14031550457846423181 mbXhD242DJoibBjdI1JtA 	 
    	  
  cv mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
 Mat &_46082544231248938, mxTwhHDgHBwIAa0Dytqva 	 
    	  
_9971115036363993554 mPaUdMg3fg2ipZY0Exj7X 	 const mSH1h4yGhaMSu8y7JC_rY 	 
  
     mL8NdxI0A84_PQiCzjY0y 	 
    	  
   _706246330297760 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		  float mlfybwyvp98TOJj0yuqhF 	 
    	  
 _46082544231248938.cols mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
  	 /640.f mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
    
    cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
    	Point2f _46082575822903876 mlfybwyvp98TOJj0yuqhF 	 
    	  
    		 _706246330297760,_706246330297760 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
      mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
    
     mK81mHSyZucxh8c_K9rnU 	 
    	  
    		   
     
  _16987668682974831349 mIqjSmilXv9ILvDddB7nD 	 
    	  
    		   
     
     
false mwkk1d6uUiyaKys71tsUv 	 
    	
      mXYEIB3KYwzJOpssgkZxP 	 
    	  
    		   
     
    mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   _3857178690860967008 mVrsJpNNblNXrk9CJ_J45 	 
    	  
    		  STATE_TRACKING mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     
     
 
  
         mvbe619pMTxqR0ISntFSZ 	 
    	  
    		   
     
     
 
  size_t _2654435874 mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
   0 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 
  	_2654435874 mRwYPGmWUou3ixNnKEWbv 	 
    	  
    		   
  _14938569046430841631.ids.size mFAl4ldpf7o2gKLWQ4bfu 	 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
  _2654435874 mgux57p4wBZIWFfq6waj5 	 
    	  
 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
     
 
  	 
             mbCI0BlZHp5kbKpNqa5Su 	 
    	  
    		   
     
     mUGrJMUolw0lb_KVyGK5N 	 
    	  _14938569046430841631.ids mZ9T0z5VdOHGC7rra8Fzk 	 
    _2654435874 ml5d8mzmxNmQRMtpfZ82X 	  mOeb4QCF4tk5CXqIGmTlK 	 
    	  
    		   
     
     
 std mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
   numeric_limits mLS76iLDjnGxttL6L8yfX 	 
    	  
    		   
    uint32_t mKJK3THIuAwgeFpuGLN8L 	 
    	  
    		   
     
     
 
   mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
     
max mJFtpHxfnoGMxp1wzTBMr 	  mT3v8xdcVsSvUtbwmHC7j 	 
  mSH1h4yGhaMSu8y7JC_rY 	 
    	  
    		   
     
                 mWYYMqZtRPklZ6ldYQlW8 	 
    	  
    		   
     
    mUGrJMUolw0lb_KVyGK5N 	 
    	  
     mCzaOxAWpFlV3gHYCg4ev 	 
    	  
    		   
     _9098980761384425343 mxGJXkzb8EW07jCVTl0Jt 	 
    	  
   map_points.is mgGCFceAojKPG0bK5eWQT 	 
    	  
    		 _14938569046430841631.ids mVLLVWqNz0_lGN56vY03t 	 
    	  
  _2654435874 mAH84ftHkJMUldxM9fJHE 	 
    	  
    		   
     
     
 
 mT3v8xdcVsSvUtbwmHC7j 	 
 mJk4eXgp_IeFV2YvLaQC7 	 continue mQivdop_Gb4hqsWvOttc3 	 
    	  
    		 
                cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		   
     
     Scalar _46082574599890393 mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
  0,255,0 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 
  	 
                 mt3m0c1_35lMMq0E3cZsZ 	 
    	  
 mYcSgTugFLQcmWT7seaac 	 
  mc2SFiyFAyMaXElAGl89t 	 
    	  
    		   
     
     
 
  	_9098980761384425343 mgi5Boc5f0emw5eocZbgV 	 
    	  
   map_points mwzFZRcSPi2Vsk45HpaLx 	_14938569046430841631.ids mstJEG25u0Qv4VQocWgKl 	 
_2654435874 mOwAFTnFZjoBWI2gNeAO_ 	 
    	  
    		   
    mGPgWaVxS3WdTr7rWsMw4 	 
    	  
  .isStable mRAYh0ARHPOc62CfGHWWO 	 
    	  
    		   
     mxAXsCfNkscq4iQtE2AeY 	  mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
 _46082574599890393 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     
cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    		 Scalar mUGrJMUolw0lb_KVyGK5N 	 
 0,0,255 mxAXsCfNkscq4iQtE2AeY 	 
    	 mC_gLvnw5tkMWRQheRKr5 	 miXz43zs_DqtraKQW0m3N 	 
    	  
    		   
     
     
 
  
                cv mvpMkjoDGcQujDevHDZnx 	 
    	rectangle mlfybwyvp98TOJj0yuqhF 	 
    	  
_46082544231248938,_9971115036363993554* mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
    _14938569046430841631.kpts mRjEKX4QN9MTvSEtCTNd7 	 
 _2654435874 mQbYLzhvVQm8J2LNkC6S6 	 
    	  
    		   
     
   -_46082575822903876 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		,_9971115036363993554* mTiWUgQKOeYLvNdGsR_oS 	 
   _14938569046430841631.kpts msGAdK1RZcxCitYemdpxc 	 
    	  _2654435874 mGPgWaVxS3WdTr7rWsMw4 	 
    	  
    		   
     
   +_46082575822903876 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
  ,_46082574599890393,_706246330297760 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
  mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
 
             msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     
     
 
  	
             meoTw_X4Xqh45MaL_F2D7 	 
    	  
    		   
      mGc5v1UWfDU7ttNcZryQG 	 
    	  
    		   
     
     
 
   _16987668682974831349 msDy4S0F6Zdx78ZUnbARe 	 mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
 
 
                cv mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
Scalar _46082574599890393 mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
255,0,0 mXftmBtLFUrPFw3lasjuW 	 
    	  mQivdop_Gb4hqsWvOttc3 	 
    	  
    		  
                cv mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   rectangle mNQ6rNLARkxxSTP6tiTXG 	 
    	  
  _46082544231248938,_9971115036363993554* mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
_14938569046430841631.kpts mVjuVop3osym9wWoq6p3w 	 
    	  
    		   
     
     _2654435874 mvFhi6DaS7eScbgWe07wY 	 
    	  
    	-_46082575822903876 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
    ,_9971115036363993554* mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
 _14938569046430841631.kpts mVjuVop3osym9wWoq6p3w 	 
_2654435874 mWi16Wz7P86SIJlTQEzCB 	+_46082575822903876 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
  ,_46082574599890393,_706246330297760 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
     mxIwd_EJpfr1C9jwU7IyL 	 
 
             mwiKr6psttEx97f2NsYO1 	
     mMGejH_coNc3kGxAdXVex 	 
   
     mcce2fXWVHACmBftaJ9Re 	 
    	  
    		   
      mg9IHDbTXxljO0nSnQKYh 	 
    	  
    		   
  _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  isEmpty mJFtpHxfnoGMxp1wzTBMr 	 
    	  
    		   
     
     
 
 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
     muH9A34QGuccPZkZDb32w 	 
    	  
    		 
         mTy5S_mcphfNLzuJQ30Xe 	 
    	  
    mTWpr3m9V3RdtOrrhhpUi 	 
_2654435881: _14938569046430841631.kpts mxAXsCfNkscq4iQtE2AeY 	 
    	  
    
            cv mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
     
   rectangle mBGM118Iia8vm6zcNTuB6 	 
    	  
   _46082544231248938,_9971115036363993554* mYcSgTugFLQcmWT7seaac 	 
    	  
_2654435881-_46082575822903876 muC5cqYcHRXDD16noARI1 	,_9971115036363993554* mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
 _2654435881+_46082575822903876 mXftmBtLFUrPFw3lasjuW 	 
,cv mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
     
     
 Scalar mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     
 
  255,0,0 mSBNIRK1XqZg3XlWW_b3d 	 
 ,_706246330297760 mPaUdMg3fg2ipZY0Exj7X 	 
 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
  	 
     msBPMso4NRYFcn5Y1myF_ 	 
    	
    
     mvbe619pMTxqR0ISntFSZ 	 
    	  
    		   
   auto _5221496220235804833:_14938569046430841631.markers mVFG05ubhW6ia_rWdS_Tv 	 
     mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
     
 

        
        cv mrPFLPKakBKjOOnkuhZUP 	 
    	  
    		 Scalar _46082574599890393 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
 cv mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
  Scalar mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     
 0,244,0 mPaUdMg3fg2ipZY0Exj7X 	 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
   
         mcs2IPsFq8XN5a3t5KBLK 	 
    	  
    		   
     
      _9098980761384425343 mtNKEvBwMHNsmdH7BtZbM 	 
    	  
    		   
     
 map_markers.count mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
   _5221496220235804833.id mSBNIRK1XqZg3XlWW_b3d 	  mYCupqIOYDMlnjNznUUG5 	 
   0 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		 muH9A34QGuccPZkZDb32w 	 
    	  

             mKx3hnVGJH14s80udXZp_ 	 
    	  
    		   
     
   _9098980761384425343 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    		   
    map_markers.at mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
    _5221496220235804833.id mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 .pose_g2m.isValid mrXXIs5j4DqJtj32aOG5F 	 
  mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		  
                _46082574599890393 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
     
   cv me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    	Scalar mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
   255,0,0 mSBNIRK1XqZg3XlWW_b3d 	 
  mwkk1d6uUiyaKys71tsUv 	
            else
                _46082574599890393 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		   
     
 cv mNQimRrYQ8Mz6YI9KM7Fn 	Scalar mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
     
  0,0,255 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
   
         mEjIWbivPeVc9WtxGDiWw 	 
        
         mTy5S_mcphfNLzuJQ30Xe 	 
    	  
    		   
     auto &_2654435881:_5221496220235804833.corners mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
  _2654435881 mccsFNEYvw261klEKqukf 	 
_9971115036363993554 mwkk1d6uUiyaKys71tsUv 	
         mcAnVuQmAnGunjGyL6dhh 	 
    	  
    		   
     
 auto &_2654435881:_5221496220235804833.und_corners muC5cqYcHRXDD16noARI1 	 
    	 _2654435881 mB6lie_LwNp2j7sbjYel_ 	 
 _9971115036363993554 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
 
        
        _5221496220235804833.draw mbXhD242DJoibBjdI1JtA 	 
    	 _46082544231248938,_46082574599890393 mJk4eXgp_IeFV2YvLaQC7 	 
 mC_gLvnw5tkMWRQheRKr5 	 
    	  
     mEjIWbivPeVc9WtxGDiWw 	 
    	  
    
 m_ECAXF5hGu1UMoS2l1KU 	 
    
 mgBFSWJlmkK48wSOW4b6N 	 
    	  
    		   
     
    System me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   globalOptimization mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
   mi6BqZOVmQyrEy6BLProP 	 
    	  
   
     mf5rJKHDmIhT9kr_E2lnd 	 
    	  
    		   _11093822300040 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
    		  GlobalOptimizer me0ZKHp2Id3eLmP_6GMtk 	 
    	  
    		   
     
     
 
  create mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
 _14938569619851839146.global_optimizer mVmWtYm5gVtZj7Yq19XWE 	 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
    
    GlobalOptimizer mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    	ParamSet _3005399798454910266 mYcSgTugFLQcmWT7seaac 	 
    	  
     debug mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
   Debug mvpMkjoDGcQujDevHDZnx 	 
    	  
    		   
   getLevel mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
      mFlx7sCaCoQxsjHSq_umO 	 
    	  
    		 11  mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
 
  mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     
     
 

    _3005399798454910266.fixFirstFrame moHeIYzwbcFb6VaM90Aa9 	true mQivdop_Gb4hqsWvOttc3 	 
    	  
    _3005399798454910266.nIters mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
 10 mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     

    _3005399798454910266.markersOptWeight mXE5wWRmJGUY4EsEsgegT 	 
    	  
    		   
    getParams mGu_88Fdde5jsxW8v9whR 	 
    	  
    		   
    .markersOptWeight myu64GAT8DgGBhNOOCqvd 	
    _3005399798454910266.minMarkersForMaxWeight mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
getParams mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		   
     
  .minMarkersForMaxWeight mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
    _11093822300040 mevHkLo7kL5WL0_0mLIhr 	 
    	  
    	optimize mgGCFceAojKPG0bK5eWQT 	 
    	  
    _9098980761384425343,_3005399798454910266  mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
 
  	 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 

    _9098980761384425343 mcvX0B8TDw1gEtqXtgT4T 	 
    	  
    		removeBadAssociations mBGM118Iia8vm6zcNTuB6 	 
    	  
    		   
     _11093822300040 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
   getBadAssociations mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
,2 mSBNIRK1XqZg3XlWW_b3d 	 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
     
 mwiKr6psttEx97f2NsYO1 	 
    	  
    		   
     
     
 
  	 
 mY8NZr9zd5VcrqfZxKQJH 	System mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   getLastProcessedFrame mdbwYCIpGYWahFfTtU8zH 	 
    	  const mbqHQotWhg0sv6ViuZXc3 	 
    	  
    		   
     
   return _14938569046430841631.fseq_idx m_yMT4MKxrENTtLx5cA7n 	 
    	   msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   
     

 mgs_uDQ8mSosYV9hCvlQU 	 
    	  
    		   
     
     
 
  System mExFPeJBflhTWJKuQVWoB 	 
   setMode mbXhD242DJoibBjdI1JtA 	MODES _706246332824366 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  	  mJdlQJg0rG2m7KHUChC3R 	 
    	  
   
    _17450466964482625197 mR22jPCjbltZ3tbBmn_6w 	 
    	  
    		   
     
     
 
_706246332824366 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   

 mwiKr6psttEx97f2NsYO1 	 
  myeiBNDHA8i8jhuL3IHRb 	 
    	  
    		 System mNQimRrYQ8Mz6YI9KM7Fn 	 
    	  
    		   
     clear mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
  mqlayz2fShj6ePxekxwRg 	
     _2869602498954317713 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     
 
  std mvpMkjoDGcQujDevHDZnx 	 
    	  
    		make_shared mRwYPGmWUou3ixNnKEWbv 	 
    	  
    		   
     
MapManager mVIm1AJSzhahLlgKO9xQK 	 
    	  
    		   
     
     mGu_88Fdde5jsxW8v9whR 	 
    	  
    		 m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 
  	
     _13028158409047949416 mRDD8w83SsPKbGXy_JkEO 	 
    	  
    		 false mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
     
 
  
     _3857178690860967008 mtmFAz7pcnIFLgYGMf4eK 	 
    	  
   STATE_LOST mC_gLvnw5tkMWRQheRKr5 	
     _9098980761384425343.reset mjjfaXD3tH8warSj13sVr 	 
    	  
    		   
     
    mC_gLvnw5tkMWRQheRKr5 	
     _2044193291895307872 moHeIYzwbcFb6VaM90Aa9 	 
    	  
    		   
     
     
 
  	 std miuOs6oIdxnQEMrFFk2n_ 	 
    	  
make_shared mkHL8KJw4VjwmGdgQrteX 	 
    	  
    		   
     
     
 
MapInitializer mKJK3THIuAwgeFpuGLN8L 	 
    	 mrXXIs5j4DqJtj32aOG5F 	 
    	  
    		   
     
 mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
   
     _14463320619150402643 mH9fKsRtHWNu77RGN1xmn 	 
    	  
    		   
     
     
 
 cv mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     
     
 
 Mat mecU92YjgSbB3VkEoZVK3 	 
    	  
    		   
     
      mC_gLvnw5tkMWRQheRKr5 	
     _10558050725520398793 mhL9dWuOWzLGBfRjwvYlN 	 
    	  
    		   
     
     -1 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   
     
    
  msxc6utIaOFXg4WI3vB0q 	 
    	  
    
  myeiBNDHA8i8jhuL3IHRb 	 
    	  
    		   
     
     
 System mrPFLPKakBKjOOnkuhZUP 	 
    	 saveToFile mTiWUgQKOeYLvNdGsR_oS 	 
    	  string _16997227483604144380 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  	 mi6BqZOVmQyrEy6BLProP 	 
    	  
    		   
     
     
 
     waitForFinished mFAl4ldpf7o2gKLWQ4bfu 	 
    	  
    		    mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
 
     
     fstream _706246330143775 mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
  	 _16997227483604144380,ios_base mrS2zvlmrTf4L4KBRRYAU 	 
    	  
    		   
     
     
 binary|ios_base miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
     
out  mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    	 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	 
      mGc5v1UWfDU7ttNcZryQG 	 
  mB0fx5ZWEe2g8Ci7LIhmM 	 
_706246330143775 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
    throw std miuOs6oIdxnQEMrFFk2n_ 	 
    	  
    		   
  runtime_error mSdpFB1uEgpzM3bVmlHgT 	 
 string mgGCFceAojKPG0bK5eWQT 	 
    	 __PRETTY_FUNCTION__ mJk4eXgp_IeFV2YvLaQC7 	 
    	  
+"\x63\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x77\x72\x69\x74\x69\x6e\x67\x3a"+_16997227483604144380 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
 
  myu64GAT8DgGBhNOOCqvd 	 
    	  
    		 
     
     io_write mLS76iLDjnGxttL6L8yfX 	 
    	  
    		   
     
    uint64_t meN5YYBBVg5DStfnyA8Dd 	 
    	  
 mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		  182312,_706246330143775 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		  mxIwd_EJpfr1C9jwU7IyL 	 
    	  
    		   

     _9098980761384425343 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
    toStream mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
  _706246330143775 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
     mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    	
      
     _14938569619851839146.toStream mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
   _706246330143775 mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
   mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
     
     _706246330143775.write mUGrJMUolw0lb_KVyGK5N 	 
    	  
    mTiWUgQKOeYLvNdGsR_oS 	 
    	  
 char* mXftmBtLFUrPFw3lasjuW 	 
    	  
&_17976495724303689842,sizeof mbXhD242DJoibBjdI1JtA 	 
    	  
 _17976495724303689842 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
     
 
  msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
   mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     
     
     _706246330143775.write mbXhD242DJoibBjdI1JtA 	 
    	   mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
   char* muC5cqYcHRXDD16noARI1 	 
 &_10576739190144361304,sizeof mUGrJMUolw0lb_KVyGK5N 	 
    	  _10576739190144361304 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     
 
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
  	
     _706246330143775.write mgGCFceAojKPG0bK5eWQT 	 
    	  
    		   
     
     
 mTiWUgQKOeYLvNdGsR_oS 	 
    	  char* mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
  &_13028158409047949416,sizeof mYcSgTugFLQcmWT7seaac 	 
 _13028158409047949416 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    	 msDy4S0F6Zdx78ZUnbARe 	 
    	  
     mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
   
     _706246330143775.write mYcSgTugFLQcmWT7seaac 	 
    	  
     mBGM118Iia8vm6zcNTuB6 	 
    	  
   char* mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
   &_3857178690860967008,sizeof mlfybwyvp98TOJj0yuqhF 	 
    	  
  _3857178690860967008 msDy4S0F6Zdx78ZUnbARe 	 
    	  
 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    mxIwd_EJpfr1C9jwU7IyL 	 
 
     _706246330143775.write mOAy4qGUJpdHQSVbVPq9E 	 
   mYcSgTugFLQcmWT7seaac 	 
    char* msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     
 
&_17450466964482625197,sizeof mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     
 
 _17450466964482625197 mVmWtYm5gVtZj7Yq19XWE 	 
 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
    mI30mSPxGJaQtkEjJfoQX 	 
    	  
    		   
     
  
     _14938569046430841631.toStream mbXhD242DJoibBjdI1JtA 	_706246330143775 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
   mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
 
     _4913157516830781457.toStream mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     _706246330143775 mPaUdMg3fg2ipZY0Exj7X 	 
    	 myu64GAT8DgGBhNOOCqvd 	 
    	  
    		   
     
   
     _3944249282595574931 mdMNbPkq6p5KBhEVf3OFw 	toStream mlfybwyvp98TOJj0yuqhF 	 
    	  
_706246330143775 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     
    mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		   
     
     
 
  	 
     _2869602498954317713 mtNKEvBwMHNsmdH7BtZbM 	 
 toStream mOAy4qGUJpdHQSVbVPq9E 	 
    	  
    		   
  _706246330143775 muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
    
     toStream__ mBGM118Iia8vm6zcNTuB6 	 
 _14463320619150402643,_706246330143775 mVFG05ubhW6ia_rWdS_Tv 	 mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    		
     _706246330143775.write mYcSgTugFLQcmWT7seaac 	 
     mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
char* mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
     
    &_10558050725520398793,sizeof mYcSgTugFLQcmWT7seaac 	 
  _10558050725520398793 mVFG05ubhW6ia_rWdS_Tv 	 
 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   mQivdop_Gb4hqsWvOttc3 	 
   
     _706246330143775.write mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     mUGrJMUolw0lb_KVyGK5N 	char* msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
 &_13033649816026327368,sizeof mNQ6rNLARkxxSTP6tiTXG 	 
    	_13033649816026327368 msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
     mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
 mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
     _706246330143775.flush mdbwYCIpGYWahFfTtU8zH 	 
    	  
 mEm194VmPJuGh5y4tMUm5 	 
  msBPMso4NRYFcn5Y1myF_ 	 
    	  
    		   

  mlwxuKRzwZKw4d0ABP68H 	 
    	  
    		   
     
     
 System mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
     readFromFile mTiWUgQKOeYLvNdGsR_oS 	 string _16997227483604144380 mVFG05ubhW6ia_rWdS_Tv 	 
    	   muH9A34QGuccPZkZDb32w 	 
    	  
     ifstream _706246330143775 mlfybwyvp98TOJj0yuqhF 	 
    	  
    _16997227483604144380,ios mI3QeEk0K_mj1WaUiowht 	 
    	  
    		   
   binary mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
 
  	  mEm194VmPJuGh5y4tMUm5 	 
    	  
    
      mGc5v1UWfDU7ttNcZryQG 	 
    	  
    		 mc2SFiyFAyMaXElAGl89t 	 
    	  _706246330143775 mPaUdMg3fg2ipZY0Exj7X 	 
throw std mwuvkepREHprpx4i3n2RV 	 
    	  
    		   
     
     
runtime_error mBGM118Iia8vm6zcNTuB6 	 
    	  
    		string mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
     
  __PRETTY_FUNCTION__ msDy4S0F6Zdx78ZUnbARe 	 
    	  
    		   
     
  +"\x63\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x6f\x70\x65\x6e\x20\x66\x69\x6c\x65\x20\x66\x6f\x72\x20\x72\x65\x61\x64\x69\x6e\x67\x3a"+_16997227483604144380 mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
     
     
 
  mxIwd_EJpfr1C9jwU7IyL 	 
 
      mAvI6WqVGKew5QUXF0T2l 	 
     mNQ6rNLARkxxSTP6tiTXG 	 
 io_read mnpObQ1mWnyfQO24_ojBn 	 
    	  
    		   
     
     
 
  	uint64_t mW202Akoy5o2_FFUMtz7a 	 
    	  
    		   mTiWUgQKOeYLvNdGsR_oS 	 
    	  
  _706246330143775 mVmWtYm5gVtZj7Yq19XWE 	 mglbnc94mbkalEyCkkDhv 	182312 mXftmBtLFUrPFw3lasjuW 	 
    	  
    		    throw std mExFPeJBflhTWJKuQVWoB 	 
    	  
    		   
     
 runtime_error mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     
string mlfybwyvp98TOJj0yuqhF 	 
    	  
  __PRETTY_FUNCTION__ mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		  +"\x69\x6e\x76\x61\x6c\x69\x64\x20\x66\x69\x6c\x65\x20\x74\x79\x70\x65\x3a"+_16997227483604144380 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     

     _9098980761384425343 mRDD8w83SsPKbGXy_JkEO 	 
    std mMorzi7AHv5qXgdOZzcMd 	 
    	  
    		   
 make_shared miGVtxwiqbDQsG6KBslZU 	 
    	  
    		   
     Map mJJosB3DZCYh837sWRpN7 	 
    	  
    		   
     
     
 
  mTGJXDnkacX2UX9dooHQu 	 
    	 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
    		   
     

     _9098980761384425343 mVfb3IHZLk8rmg75VuqQZ 	 
    	  
    		   
     
fromStream mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 
_706246330143775 mSBNIRK1XqZg3XlWW_b3d 	 
   mqLizGA4Z8QZ_2GYQ1inC 	
     _14938569619851839146.fromStream mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
 _706246330143775 mVFG05ubhW6ia_rWdS_Tv 	 
     mwkk1d6uUiyaKys71tsUv 	 
    	  
   
      _706246330143775.read mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		 mTiWUgQKOeYLvNdGsR_oS 	 
    	  
    		   
   char* mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
     
 &_17976495724303689842,sizeof mlfybwyvp98TOJj0yuqhF 	 
    	  
    		   
     
   _17976495724303689842 mxAXsCfNkscq4iQtE2AeY 	 
     mSBNIRK1XqZg3XlWW_b3d 	 
    	  
   mwkk1d6uUiyaKys71tsUv 	 
    	  
    		   
     
     
 
     _706246330143775.read mbXhD242DJoibBjdI1JtA 	 
    	  
   mNQ6rNLARkxxSTP6tiTXG 	 
    	  
   char* mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
&_10576739190144361304,sizeof mbXhD242DJoibBjdI1JtA 	 
    	 _10576739190144361304 mVFG05ubhW6ia_rWdS_Tv 	 
     mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		    m_yMT4MKxrENTtLx5cA7n 	 
    	  
    		   
     
     
 
  	
     _706246330143775.read mlfybwyvp98TOJj0yuqhF 	 mBGM118Iia8vm6zcNTuB6 	 
char* mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     &_13028158409047949416,sizeof mYcSgTugFLQcmWT7seaac 	 _13028158409047949416 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
 
  mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		 mqLizGA4Z8QZ_2GYQ1inC 	 
    	  
   
     _706246330143775.read mBGM118Iia8vm6zcNTuB6 	 
 mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
    char* mxAXsCfNkscq4iQtE2AeY 	 
    	  
    		   
&_3857178690860967008,sizeof mUGrJMUolw0lb_KVyGK5N 	 
    	  
    		   
     
     
 _3857178690860967008 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
   mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
 
     _706246330143775.read mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		   
     
     
 
 mgGCFceAojKPG0bK5eWQT 	 
    	  
    	char* mPaUdMg3fg2ipZY0Exj7X 	 
    	  
    		   
     
     
 
  &_17450466964482625197,sizeof mlfybwyvp98TOJj0yuqhF 	 
    	_17450466964482625197 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
    muC5cqYcHRXDD16noARI1 	 
    	  
    		   
     mQivdop_Gb4hqsWvOttc3 	 
    	  
    		   
     
     
 
 
     _14938569046430841631.fromStream mbXhD242DJoibBjdI1JtA 	 
    	  
    		   
     
     
 _706246330143775 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
     
     mwkk1d6uUiyaKys71tsUv 	 

     _4913157516830781457.fromStream mYcSgTugFLQcmWT7seaac 	 
    	  
    		   _706246330143775 mSBNIRK1XqZg3XlWW_b3d 	 
     mEm194VmPJuGh5y4tMUm5 	 
    	  
    		   
     
     
 
 
     _3944249282595574931 msDVYCHuU_j2g_TdgX4Ta 	 
    	  
    		 fromStream mSdpFB1uEgpzM3bVmlHgT 	 
    	  
    		 _706246330143775 mT3v8xdcVsSvUtbwmHC7j 	 
    	  
    		   
 mxIwd_EJpfr1C9jwU7IyL 	 
    	  
  
     _2869602498954317713 mj3rSXJDWd4j4OSGbS2oX 	 
    	  
    		   
     
     
fromStream mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     _706246330143775 mJk4eXgp_IeFV2YvLaQC7 	 
    	  
    		   
   mQivdop_Gb4hqsWvOttc3 	 
    	  
    	
     fromStream__ mBGM118Iia8vm6zcNTuB6 	 
_14463320619150402643,_706246330143775 mVmWtYm5gVtZj7Yq19XWE 	 
    	  
    		   
     
     
  mo9Lbpy0Ap4RTl5O5Or1C 	 
    	  
    
     _706246330143775.read mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
     mNQ6rNLARkxxSTP6tiTXG 	 
    	  
    		   
     
     
 
  	char* mSBNIRK1XqZg3XlWW_b3d 	 
    	  
    		   
     
   &_10558050725520398793,sizeof mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
     
    _10558050725520398793 mVFG05ubhW6ia_rWdS_Tv 	 
    	  
    		   
     
     
 
   mXftmBtLFUrPFw3lasjuW 	 
    	  
  mqLizGA4Z8QZ_2GYQ1inC 	 
     _706246330143775.read mUGrJMUolw0lb_KVyGK5N 	 
    	  
 mYcSgTugFLQcmWT7seaac 	 
    	 char* mXftmBtLFUrPFw3lasjuW 	 
    	  
    		   
     
     
 
  &_13033649816026327368,sizeof mYcSgTugFLQcmWT7seaac 	 
    	  
    		   
_13033649816026327368 mPaUdMg3fg2ipZY0Exj7X 	 
    	  
 mVmWtYm5gVtZj7Yq19XWE 	 
   mC_gLvnw5tkMWRQheRKr5 	 
    	  
    		   
  
 
  mwiKr6psttEx97f2NsYO1 	 
    	  
    		   

  mqVdZVftPR84WTjiOiVfT 	 
    	  
    

#ifdef _4257555960817013426
#undef  mEhFK99MtLRsCBaPNqnDs 
#undef  mx0IHqzgubYGvmr3US2dG 
#undef  mLS76iLDjnGxttL6L8yfX 
#undef  mQFhSiloYfIS2jNU3eZwh 
#undef  myfkTa1upxif9QPCqJYGo 
#undef mepF4kKPTKcm3_3zOgvFYIzxp7qltNj
#undef  mtmFAz7pcnIFLgYGMf4eK 
#undef  mIqjSmilXv9ILvDddB7nD 
#undef  mrIWO5AmcxVfFGpyNJzQE 
#undef  m_Ww9T_ZoqJhMiIY0i1PJ 
#undef  mr8s7pfvTmBWmxher3Oue 
#undef mVNaGXNPhIIKr2hUgGHX4UaeDEMfi42
#undef  mbqHQotWhg0sv6ViuZXc3 
#undef  mAmoJDTG6Of2SbVxLbNlJ 
#undef  muLh_AegzBLvbYcxrsotS 
#undef  mfQABlcyhvI43vfjabcjx 
#undef  mbtzLVjzLgaxYxNNltfyM 
#undef  mfvgAAx_p4DiD5VQWew30 
#undef  mHUTuX3q6rB5eWWYYPWQD 
#undef  mdUyI4aAbhQ4X6fne1qVo 
#undef  mUnahx7x8KWu62epS7OxV 
#undef mPJW22oQ5EY7l3brt_yM6tZ98O1MaSS
#undef  mVzJJ8Dxt5T_4dzWC9bRk 
#undef  mW202Akoy5o2_FFUMtz7a 
#undef  mNQ6rNLARkxxSTP6tiTXG 
#undef  mgT33OczCogeSJ9uFzScS 
#undef  mzPBrKZLupkxN5F1reNis 
#undef  mZloAr3_PPw7622AVrUCe 
#undef  mZtjXWMVRX5W1YY5htRHo 
#undef  mMAhLBm751iJ4jZTmz1eQ 
#undef mgw8BkP8SNV8jndx61xg0o50h_c5mif
#undef  mT9nS5aSA2ErLjcHqOPSA 
#undef  mvbe619pMTxqR0ISntFSZ 
#undef  mkcVgqnqADeTh3Pu1ogGF 
#undef mBPRy7dwggVK7T8mnFH4k3IHP5LNgxA
#undef  mSwbK3nBcNZkvGxSXNOZy 
#undef  mLMQAhvQYOFXZbKccuW7F 
#undef  mkQFhH7KKo8wEpsoToABe 
#undef me_x3XD35s4SQm68rZAxnDPyEScI4ko
#undef  mRfik4dXiQLAdpjBrSV8e 
#undef  muh7SNXP3UdOZu6GOuG0_ 
#undef  mvA2vjSvRD7UmknjmYP5U 
#undef  mozBzR4ceXlDTd_eA9UWj 
#undef  mKdE4ZCfdDaB2HjFWW9ZV 
#undef  muW_4n008TrPdz3qsiq99 
#undef  mSSwrqUuoNnhMtvhM2vr3 
#undef  mXftmBtLFUrPFw3lasjuW 
#undef  mOE4ALZahxLkvGqMRmxIK 
#undef  mUrzesNXiQhLYupQ11MEa 
#undef  mANVdtEFAyD7H8nVwStxw 
#undef  mmtdRAqKU38Wmq22hGoY2 
#undef  msDVYCHuU_j2g_TdgX4Ta 
#undef  mMW4T9X7Ncvxkcl9tdmuW 
#undef  mc6a7gZ5y0kWaTfPKjZL0 
#undef  mSH1h4yGhaMSu8y7JC_rY 
#undef  mZqpoIg7XHbhgu_6iW7PX 
#undef mCOsHuy_LgH97Sv8cUUn62iDLX97wwR
#undef  mMa2nYH1z474KyDSW_2Vs 
#undef  mrg1QVINMqbRYZWngNWmj 
#undef  mvpMkjoDGcQujDevHDZnx 
#undef  maPL1kl9f9VlgIn9jnnN_ 
#undef mJhsXXxCEc7EzwcyisUS8yU1EArDvv5
#undef  mbzQLzB5_GI6yqNIVcKo7 
#undef  mWYYMqZtRPklZ6ldYQlW8 
#undef  mpmXJjJFMEII76TcUeF6n 
#undef  mHg0YG9R0Gb6ZE5xIr3dz 
#undef  mVWXLsp7dzQ63mhYH8afG 
#undef  mVjuVop3osym9wWoq6p3w 
#undef mqjfrgUiAEDDEjlRkjAD2lLTvBK4_wM
#undef  mtNKEvBwMHNsmdH7BtZbM 
#undef mWi0N1XQtqS4eplLhvTPtL7YVDTI0uk
#undef  miCOYqGikWLzThHPaHJqa 
#undef  m_j66qmf_xp1aP8o87JsC 
#undef  mZTdKHHWXvp9nTqOl4Xs2 
#undef mv1RKc7QVwxlWT9SXxD8SO31MO6ME0P
#undef  mLF5wNIO93YQsDKnsE8CQ 
#undef  mxpEdWbhRRjZ1JMh3yxwy 
#undef mYXPVOM37XZ0D0TXXL_pa4oEPuGbOPa
#undef  mniwdnkZe0XDlHpwvfS6f 
#undef  mVmEiQKd2V4SMp8srf2ip 
#undef  mtXIBsLV4PNo4xplHiuYW 
#undef  mgs_uDQ8mSosYV9hCvlQU 
#undef  mR8MpflZg6lk1qLQLX9P9 
#undef  m_l2K0T8_C6RujcQWcodT 
#undef  mC7hzb7yA8ZYeXu1CO69e 
#undef  mXE5wWRmJGUY4EsEsgegT 
#undef md0oVktsx1pBS882l8zyIRjNfobA6ch
#undef  mL8NdxI0A84_PQiCzjY0y 
#undef  mrrE9iifrKAQukpCdUvSg 
#undef  mi6BqZOVmQyrEy6BLProP 
#undef  maWf7apYek19lMvO8A9jX 
#undef  mdokA2SxdolKVBlsRM2BI 
#undef mE0T41d6zsvRVEKQweSBUEh_uGhgu22
#undef  mtnnWCdgrIMkg48Nfdksz 
#undef  mfLSKCXSc1DHeN38jALNR 
#undef  meN5YYBBVg5DStfnyA8Dd 
#undef mJuuoPKr40SU5zHhNbbXqctl3TiKplZ
#undef  mwuvkepREHprpx4i3n2RV 
#undef  mVfb3IHZLk8rmg75VuqQZ 
#undef  mKJK3THIuAwgeFpuGLN8L 
#undef  mx4lt8TnYlZ5ZXw4BS3wS 
#undef  mAJj0tPIZvDaIRCwd81bO 
#undef mKBHPoItjfMlV0wiBB4zhY7eGHfZlUN
#undef  mN_UNAeshLaooczmV1nkW 
#undef  mLp5eeYn1TGnQEcop68VN 
#undef  mb1P_epCWN8Wxasz2RKsj 
#undef  muzrhxIoqthv8PfiNihnX 
#undef  mP7ddfBDehHbRqP8iGbq8 
#undef  mNU1gzy6st0M0XRy_b50x 
#undef  muC5cqYcHRXDD16noARI1 
#undef  muDvj5aUdXshb2AqqeEiu 
#undef  mMorzi7AHv5qXgdOZzcMd 
#undef mzuxgOk7A21FkrdsUSuvnxnfwzSM4d1
#undef  mtDWQOqRguVWSWehbKECr 
#undef  mQYacSpatR0AsiZrXS4cE 
#undef  md3vFKQB1r7mKsD_TtoYY 
#undef  mTWpr3m9V3RdtOrrhhpUi 
#undef mkw8lGlDbQZaKMTP_YDPjvJLCWzkF1F
#undef  mk9nSfh6XGyonOYMC8C3M 
#undef  mvVEux0tzfHTcHloJ_PHd 
#undef  ml5d8mzmxNmQRMtpfZ82X 
#undef  mJJosB3DZCYh837sWRpN7 
#undef mXk6lthHPSZVm77eowhQeQawrY_9rFf
#undef  mRjEKX4QN9MTvSEtCTNd7 
#undef  mGeB1HfXInE4uBPHmIDCN 
#undef mgp30WAQApKqfYJi7b665A_Fsk0fLph
#undef  mGPgWaVxS3WdTr7rWsMw4 
#undef  mQIYDh6QMMrUx6uxn_6So 
#undef  mr0Gwya5kzUd694oxNDs4 
#undef  mJ1vGQuHCiSCbbgKlE1zh 
#undef  mjjfaXD3tH8warSj13sVr 
#undef  miKAllCm5PMbA2fU3LrvT 
#undef  mR22jPCjbltZ3tbBmn_6w 
#undef  mxkHJa5wooqhzaSxK7_fd 
#undef  myMDc1DgE9_RLElsHtK4r 
#undef  muH9A34QGuccPZkZDb32w 
#undef  mZ_OIrsB5IK5mggFkrgFu 
#undef  mrJcfxt4GvOx7AQVScfu1 
#undef  mIyrnAZ9pLZEaiK6Yst1L 
#undef mVpqXAw8OwPya0In1DtR6DVSoVt5E4W
#undef  myX_vRc3UBQw14UHIrg7D 
#undef  mrDas3egWRcEnvTodVRRA 
#undef  mNF0G2xPBB22gI9XzMk2L 
#undef  mvcDBJfIynZthI5bz_HTe 
#undef  mS0R9s7sfcYa3Nx39taZW 
#undef  mlfybwyvp98TOJj0yuqhF 
#undef  mbCI0BlZHp5kbKpNqa5Su 
#undef  mcAnVuQmAnGunjGyL6dhh 
#undef  mt3d6r2BuFfOvfXdOmaLX 
#undef  mHlvGgqu6yYQkoBxoydv2 
#undef  mELweLHSjak68niq3oUpw 
#undef  msz82ko2ZHqbIoF2aTtnd 
#undef  mXdnll4yjwVy4uBDSjUe3 
#undef  mTWpMMn_ueGNGrVaZzL0Q 
#undef  mQ28kUfMOhNPxGTJTErTr 
#undef  mK81mHSyZucxh8c_K9rnU 
#undef  mMGejH_coNc3kGxAdXVex 
#undef  mi05fm9uStmGibkKInn9I 
#undef  mypSLdUZlHtNg6EWZ4tk4 
#undef mYEx6E3frdynb1tbeRHMsq4qjzx5lJI
#undef  mgrzSPnq5U03KE8vGp17K 
#undef  mqLizGA4Z8QZ_2GYQ1inC 
#undef  mVIm1AJSzhahLlgKO9xQK 
#undef msMTjEcQRbmNfhQK9JCSaxiULsTRddS
#undef  mwJXVmZ8MTqFBwgPAlydy 
#undef  mV6teN3KtTJ8vHmQAuPWz 
#undef  mO5kQTjyeAtuoPXAKG8Fc 
#undef  mZlJv5AWGo4iJ2lUt_qL9 
#undef mf1FVfgOgk3KwNVS6KX1X3r7wnpFHZm
#undef  myu64GAT8DgGBhNOOCqvd 
#undef  mY5qtQdkZ0Cq7TxfD2D9r 
#undef mfBrVitNz1gcglM0S0d_GaB2XQ6qIBt
#undef me5NQ5q4nzTEd8Focp_lQ2efTIGblTf
#undef  mmk2RogyswbtTiHnbCghT 
#undef  mz0gDEk4XJJySbEeCgC9P 
#undef  mdEGS_9gShKEEsK9RPbfj 
#undef mUx6m64LorImkLdiamz4MNnKfJ8Dgqd
#undef  mAH84ftHkJMUldxM9fJHE 
#undef  mWjWwCxBA7LLBixCoRsYZ 
#undef mXn6_dCt1InpPoeN7PJzsfcX40Bsl36
#undef  mkufZC7kHsvxllmN0YBQv 
#undef  mxt_R_jw78RlV2eo0D9pJ 
#undef  mlnjjjDeP_rHq0Q8WRLNl 
#undef myRBBsHypjh2pwIDUsBulCaJVULSzBl
#undef  mlwxuKRzwZKw4d0ABP68H 
#undef mZ1ddPtgQf1469AgXd_hnhYWrItjdpa
#undef  mmBcOrqJdEmcu_DE5N2Gx 
#undef  me2H4L3LXGkdv1CjOYaxx 
#undef  m_ECAXF5hGu1UMoS2l1KU 
#undef  mFTobXyS5Vx9ebVESwR0T 
#undef  mZCDcAPDXTOUnUkMgttvA 
#undef  moI4EWKnn9rwdcRf81yt6 
#undef  mf5rJKHDmIhT9kr_E2lnd 
#undef mU4MGy3eTQcSf54RC1cbEcjQ3muIwTt
#undef  mXbu2bQmZ_EIA6T8Pxs5C 
#undef  mwzFZRcSPi2Vsk45HpaLx 
#undef  mE8uUKPmY8c0aMaRDvuqZ 
#undef  mDe1564r6NJrCTudA8x0w 
#undef momc0dVPjZSCmkiCD0NsIvJpksvAEq6
#undef mUn7QGLA73p6W5WWUA8kXR068R1LLaE
#undef  mq2gz5KAY_yWyHzw3C8AU 
#undef  mA7hUM4UKqFyb_LJLsook 
#undef  mUgtpRAYJj43Mf4SpepZP 
#undef  mIBLQ6_qDoS3S2lLQGZ3e 
#undef  mccsFNEYvw261klEKqukf 
#undef  mLdCPhlCq1uVgMtM4YkSz 
#undef  mwkk1d6uUiyaKys71tsUv 
#undef  mtY6LxHDMoBxNaXBgiMYo 
#undef  mg9IHDbTXxljO0nSnQKYh 
#undef  mafwB2WCPijyRRTuHGVwE 
#undef mica9L0obWHIAMj8olmooNyaERwYWWb
#undef  mVEKXpiuZW9uJtiJR96kC 
#undef  mNKI4p1bbhsctoprpzZld 
#undef  mEbO1A7RXmhmRG12Qtq2A 
#undef  mVFG05ubhW6ia_rWdS_Tv 
#undef  mZ4lxIR9Ss2_Hj_UqJEdU 
#undef  mFruyY5vdoiszED1tVpm7 
#undef mVSnQ5bRFB6wfDS_yNBNbNu5E0uONgN
#undef  mt01qaUz2R0SKmPFSq0jx 
#undef  mDUeb65ug1HYJ31338ssa 
#undef  mtEI4bSjtkyV5O0qz_vBz 
#undef  mfKtZiRp2HOdQqoTplnaI 
#undef mtpK6cfRKaQfLmD5NlKZxIgtqI0KH8H
#undef  mW0689NsIXj0x_tZl_0ut 
#undef mP58CIh6ze6yAP6qZBUSJEJWLJ4Ud8m
#undef  mEpG5N2fixtWboWua15h2 
#undef  mdpN8SwUj7WdZrfZEdHOU 
#undef  mt3m0c1_35lMMq0E3cZsZ 
#undef mtbFfPEOTUo9ZxMxuvpH7h3G0y34BUQ
#undef  mgGCFceAojKPG0bK5eWQT 
#undef  mWQWZuZUxzgXcOZHMJMC_ 
#undef  mEYy4vDSh1urfYj6Y0xAX 
#undef  mevHkLo7kL5WL0_0mLIhr 
#undef  mhzXsKXJN7mpztq4AcAJP 
#undef mPapA0sQobBdMYxf8n5k_d1XfFYtgTj
#undef  mWW5XPXuQhAy0ULFUxjSy 
#undef  mlEF62Izit24hGT_NqPIJ 
#undef  mIaPM1ms991SDrw4x6KTt 
#undef  mnpObQ1mWnyfQO24_ojBn 
#undef  mkbfWNsvNHk84u7zcYWL3 
#undef  mNPH65O81GD4PdziT5g9G 
#undef  mbKsAIYA4KftCqyFCiVR0 
#undef mfsUOzV7P_RilmCCGvwoeIlw4YJVgaK
#undef  mI30mSPxGJaQtkEjJfoQX 
#undef mIyyG3AKrblBJKxNwgTHaAp64amaZec
#undef  mS8RHH9YrzfK1kS8XUlWM 
#undef  mFqi0ZIcB_YhZ2B8QBIQg 
#undef  mmAvkrWz9or7FSKyep8Gr 
#undef  mjS5rO91VKWACucamZJvF 
#undef  mQivdop_Gb4hqsWvOttc3 
#undef mItOvmgvVaCfcAbau5lsMFJBHZNgxMF
#undef  mRIlZ0NriRkVMhRpycZqI 
#undef mvPDntQyNRw6Z8gi8TqyeJNRh3HJzNV
#undef  muoE4XIKfPRSXmzic7wiv 
#undef  mbkARxvbbfyf_buO00mpB 
#undef  myfOHlfTLtRL7im7qSaYm 
#undef  mopnBBbnH3fttLLMFPoqR 
#undef  mfF196cGKZ_LkBPN8ZWlr 
#undef  mhaG6yS3EwOInKAwIBoQN 
#undef  ma1pkHKHRslLKg1N_R3cS 
#undef  mVAe2KWVqd9ISAzz02MVl 
#undef  mY7ZY9aprChsLCuD7yOm0 
#undef  mK1g7l2eLzcTEZMoreGi3 
#undef  mfRi_C6KlnAxop81XDZsV 
#undef  mTy5S_mcphfNLzuJQ30Xe 
#undef  mysXizvfs_r5HUdOYChFS 
#undef mCtyM05tQpMzDpEgPuGhYcokT6M4tjW
#undef  mrPFLPKakBKjOOnkuhZUP 
#undef  mIJkWACd8Uom4Jv6selID 
#undef  mSdpFB1uEgpzM3bVmlHgT 
#undef  mQRLqWWTfqtTF6fXNey7C 
#undef  mFAl4ldpf7o2gKLWQ4bfu 
#undef  mglbnc94mbkalEyCkkDhv 
#undef  mTiWUgQKOeYLvNdGsR_oS 
#undef mTZV4xO_u33gH0m2pSZ0Kb_3WBL3eAy
#undef  my5S_tF4_lSpButBKNitX 
#undef  mpjTyiESCVWYRDiT2x2RD 
#undef m_FIu8SC1mV9u96yGGq517GuyZBOKN2
#undef  mB6lie_LwNp2j7sbjYel_ 
#undef  mU7LO3jg27wf5nw3n8LF7 
#undef mzIN4oy49lJQAPj1sTO7CuJrW8zh8vn
#undef  mhwa9v40jbZGyHdjZKnp7 
#undef  mTkuNOxSsNhHKtS5Aoyjl 
#undef  mJPHiCuIoYoltwiwwrI8_ 
#undef  muPAQsfjksFeL917cY2qY 
#undef  miuOs6oIdxnQEMrFFk2n_ 
#undef  mLdvrbXgkmVAVnc3aEbWU 
#undef  myrvDyRCtal5mdHB28ZIe 
#undef  mfuDqjzDT73kQihIjSHez 
#undef  mecU92YjgSbB3VkEoZVK3 
#undef  mB0fx5ZWEe2g8Ci7LIhmM 
#undef  mol5p_9C0R9o_YMjX6nxS 
#undef mAgeWodR4T4ZrkJewFh58A0i0ajDXAw
#undef  mY8NZr9zd5VcrqfZxKQJH 
#undef  mRPDwBN1TFChGSxh15CwJ 
#undef mLJzZsWnOmMS6V2RrU8dPGyS1KjXdWu
#undef  mwiKr6psttEx97f2NsYO1 
#undef  mVOBFEtNftMS2NFrVW8bV 
#undef  mumKmtKc8SEEXbYxYxnDh 
#undef mFGsmz168M0g5OuX5mDGXvoCfCP6cOP
#undef  mbXhD242DJoibBjdI1JtA 
#undef  mcvX0B8TDw1gEtqXtgT4T 
#undef  mYbzFOKSwwNsD71cP1DkA 
#undef  molF5K16MuyVvkFE7X8JI 
#undef  miEkJpdzqdOiFySBrwOfd 
#undef  mY6fIyAOJfhz5nUdrWiVY 
#undef  mWg9bTDKGk1fMQGpnNkAs 
#undef  mI3QeEk0K_mj1WaUiowht 
#undef  mgBFSWJlmkK48wSOW4b6N 
#undef  mgCpjhgiW1siuOOx31UVB 
#undef  miPlatUaObQVOYOiw6SZF 
#undef  mF1AFCmj7FNvcdn7hZ9B9 
#undef  mO5I_G9WPuW9VC4inj5mo 
#undef  mfnsIHmSLQOabKyJkuQOT 
#undef mVwXME5C65fIa3AvF3qdC4s8VSuRCn1
#undef mU6DxMMDeS8jnWvjm1Pm4JPiFG0vlkw
#undef  mYcSgTugFLQcmWT7seaac 
#undef  mQsihVvqkuYoG8jvPTYFO 
#undef  mljwEkmom23bYFuTS0b0b 
#undef  mYiyQbEDdMYkmeehBx6jp 
#undef  mkyly54GlrbXuNeECTTqk 
#undef  meH5OaCcZwH0xkfm5lpWj 
#undef myUjQEd8RpnmXHqwk8e1AWLvQ6gzt5H
#undef  msDy4S0F6Zdx78ZUnbARe 
#undef mr5W62IjRnZD0dRSEjUmruLxKfdAo6z
#undef  mqlayz2fShj6ePxekxwRg 
#undef  miGVtxwiqbDQsG6KBslZU 
#undef mjJaL6ka1Was97xj02ttOG_WmmWOzk7
#undef  ma6O7Vg8NwpyGvRwfbCOg 
#undef  mO_k7IEuqtZq_e47ILYU9 
#undef  mTmmYcodZhxYb9bt39OUl 
#undef  mFllaSnZNjV3YvL2YmAFh 
#undef  mLTPi46EjqETKRikMKXiU 
#undef  mJM70H6b9NGcqtHePCrZv 
#undef  mcKERBksFL6yXYOLd7kWz 
#undef  m_1_RZETM1QJ8vycOakwy 
#undef mKyEK_R1QxAe18GNGI1HAEUse28S19p
#undef  mExFPeJBflhTWJKuQVWoB 
#undef  mCytWUAf5qvM6IOdaLIC3 
#undef  mDWwKMm0Bw8nxvI3ZwZnM 
#undef  mO02z_ujA2bhihPtTtFSA 
#undef  mzoah9JwBIdWZVJcSU27j 
#undef  mdoDIGlHHE7UO_4pXUSmQ 
#undef  mTgR0xuTc2WA_FI5hAh2Q 
#undef  mPdND7yG0gLP1HGO5Lkvl 
#undef  myWBdZwdHWpQZqZ09m0Jq 
#undef  mise5YGBUx6xBGs9EUolB 
#undef  mjeCTifvlIBEl0lPx4S9g 
#undef  mRwYPGmWUou3ixNnKEWbv 
#undef  mtIfgwpprqjFMhHY9FVrL 
#undef  mhL9dWuOWzLGBfRjwvYlN 
#undef  mC4FNAhGk_5NQroya9r4E 
#undef  mltszUqwX6pYfxYVtnKha 
#undef  mMm9FLNsNOoyX7Tyb7vpT 
#undef  mxp2hpvJDbBGG9galOMeH 
#undef  mdIyvr_duNyurtIQ2sC_1 
#undef  mquP6o79T92Q5e7Uu95ew 
#undef  mJqFpzb57ph2rWKCmAfkM 
#undef mxTZSmMRscCjViBKa0Vr5qsi2p7WINa
#undef  mOHlEjbyW9EyIFVYqPfh9 
#undef  mWRzp9vubS9UNcl2Anz32 
#undef  mtq_QCXPpv2kX7L8PRz8d 
#undef mKHQi_mCIV4qkj6rPUW3efpMPD0wNm5
#undef mUdlAesF5AuSJR8ScuRRyVZqheDCzBs
#undef  mrJARF3qaYOfBun2j_jcD 
#undef  mAzTBw5jTPnBNbyO0BIkm 
#undef  mUvBFztQfvp6FxGFsyoMW 
#undef mEWPzjcYD7moMgjqWTXhQ08Ljc0mNua
#undef  mC_gLvnw5tkMWRQheRKr5 
#undef mNop_E1tZVTfrIm1pI_Weo9Woj9KEvB
#undef  mKH2zPRtp0X4JTntk4h2u 
#undef  mUGrJMUolw0lb_KVyGK5N 
#undef mvmBqbIMsPhg4_ieHPNPA2054e72fsf
#undef mpzFaHYiXFWUKP8NPmYNuC3erXnFHiz
#undef mUqaV4ZLGbvoX5uC3jxjOgaRtmgJvhY
#undef  mJFtpHxfnoGMxp1wzTBMr 
#undef  mqZevfxEDPOS7RkGEtJFp 
#undef  mcBKtNACwQ_SnJx26otEZ 
#undef  mqUxZEnHM0zID6J2vVqke 
#undef mbyFB_zuYrlaUAZ0YvrMZ0qMUWQI1_m
#undef  mPvI5zVkkxdTYTCdGOJ2J 
#undef  mPaUdMg3fg2ipZY0Exj7X 
#undef  mdMNbPkq6p5KBhEVf3OFw 
#undef mOPUy9orrqKqHEN_9xN7pePKUGcDrG7
#undef  mBxIiY0bxajrRw6WjYleG 
#undef  mCehD1sxzTv6MH7ymj2xb 
#undef  mEm194VmPJuGh5y4tMUm5 
#undef  mKQv8aH2lM5yjPYl5F768 
#undef  mVmWtYm5gVtZj7Yq19XWE 
#undef  mYvqzY31mCrOAE70tjB7u 
#undef  mpC65FoK2NLadlWUAo9ps 
#undef  mp1kzPPa8GX6cfigPyiyD 
#undef  mxTwhHDgHBwIAa0Dytqva 
#undef  mhJ97TQsVn_CNDDcdyvCc 
#undef  mgux57p4wBZIWFfq6waj5 
#undef  myydjxqnidOfg3YXIPfCh 
#undef mmPZkSy7hkphGU4PA4IHQSP49HWrI6I
#undef  mFWbNGU5e6cuqyQa3XUry 
#undef  mBGciDWaUfaa6OV3swXep 
#undef  mKWQLdAVzYxp5QuNZ1ytt 
#undef  m_yMT4MKxrENTtLx5cA7n 
#undef  mweJTmqyXMKSMhERfzuxN 
#undef  me0ZKHp2Id3eLmP_6GMtk 
#undef  mhDfF2VEdGrCP55eTHYvN 
#undef  mhifiLHf3tBluSeI6D_kg 
#undef  mstJEG25u0Qv4VQocWgKl 
#undef  mQIaw42evZrZGmIhV_U05 
#undef  muUPvA5lgBIdnaP2X6gZ9 
#undef  mP2Ml_iMNTficIMe44TSF 
#undef  mhNH3dNZkhrgawU6wbA6V 
#undef  mfaXcqsSkd6ad3maNOmpF 
#undef  mdx9gS37IsjwWpaOb1ODY 
#undef  mL9oWJQ1n2xKG3FtRNowa 
#undef  mV4_AbWY8ymaWGsYOk0LC 
#undef  mFlx7sCaCoQxsjHSq_umO 
#undef  mDHmz3NSVqdDEn8FHaIo5 
#undef  mbJiX6F_a_O98JuQH2rHf 
#undef  mCFTZ4KBJ1F7Fkl00Fjcu 
#undef mRPo0fFJbYzO3rl5SpSmQCkuEOXjwjR
#undef mJx1hfXrHT_dfDmEhQBC_Pvh6H5muIx
#undef  mf0E07qXAg4sDu7JIwESC 
#undef  mBFhfgDfkdod6qHz7NdvN 
#undef  mCzaOxAWpFlV3gHYCg4ev 
#undef  mgrODPzGHQfjmAyPsBdfg 
#undef  mn5MlHVieFj6s1Arh9Q10 
#undef  mo9Lbpy0Ap4RTl5O5Or1C 
#undef  mO9LYCrftPnMJePmJnE8_ 
#undef  mUgQbNDLTz7hiX8p2shmY 
#undef  mGc5v1UWfDU7ttNcZryQG 
#undef  mi4REkBAebpTZrzlvFEpD 
#undef  mdN8xdqycKdYT96rU4KUK 
#undef  mZilF4nRNVEneBzggpX7Z 
#undef  mz_QhADZTe0uCEYYRSweR 
#undef  mgi5Boc5f0emw5eocZbgV 
#undef  mAtWayYkoRILYXB8QtRbg 
#undef  mZb18dCucFvoBd0bsf01O 
#undef  mH7U1EdrCKalrHJxxWz_s 
#undef  mH9fKsRtHWNu77RGN1xmn 
#undef  mFWW5xb6SDILpyTp5GBZD 
#undef  mBUCZuaNioFkzVtaa2sRQ 
#undef  mNAtfKYOf6ADB9rVjcJk_ 
#undef mHNb3kVFhkHg9E01geZBsldl9Bqqteh
#undef  mQ3_UtHSGY3eARbSl_X7q 
#undef  mwEEBMzfZV6O26soeDHeI 
#undef  mFASROAG4Q9353J70qH7c 
#undef  mXYEIB3KYwzJOpssgkZxP 
#undef  mJCQ17ktBLqNw7sHF60R1 
#undef  mZLojCl8cVD1576VM0g8u 
#undef  mutzl2HCpJ5IWzF1P08Yd 
#undef  mjXlfKOCTRjUV9apwYcb7 
#undef  mRDD8w83SsPKbGXy_JkEO 
#undef  mYOSSG7sSqnMh0YV5DIrw 
#undef  mvFhi6DaS7eScbgWe07wY 
#undef  mraP1zuclX52fRr5CelTs 
#undef  mWIOGoR1XyrR6fw03i9px 
#undef  mzDmJqPikCTXlN8BGk0M9 
#undef  mIHFqVJpFXgMDdHn2uhc3 
#undef  maE84VqXoUUX_dnxUsfES 
#undef  mWi16Wz7P86SIJlTQEzCB 
#undef  mYJhSIZr793lUcg7mTDWT 
#undef mrklVs4e18EG0isgYms8QLiA8VS3ndK
#undef  mHOvssFtYMllM6IBWHFls 
#undef  mYMxwp5lzvb08Oa8FUKdp 
#undef  mOwAFTnFZjoBWI2gNeAO_ 
#undef  mT3v8xdcVsSvUtbwmHC7j 
#undef  mIgWcCjmm9URqJ9HNYW2A 
#undef  ml5pooDWTz1HG4AXabzV3 
#undef mOrS38s7h3Veesv9767f3xN2895kQdx
#undef  mOeb4QCF4tk5CXqIGmTlK 
#undef  msGAdK1RZcxCitYemdpxc 
#undef  monDVXoqIbwYZt9x_asGf 
#undef  mgB7jkTLiZWzEF7KqbAfY 
#undef  mKLTKWdkdn_ESJc3B3MOJ 
#undef  mrCE0fSuXGTiQ_zkRfAJ7 
#undef  mxCgC8LoLiSZGVUV0OQXG 
#undef  mYg3RpRsnYTFl5_yP9Off 
#undef  mBGM118Iia8vm6zcNTuB6 
#undef mpMKiDYPHUkbcUrOidGijQq7UOxlcWw
#undef  mhfoVR7GfGGYByYoTirWE 
#undef  mVLLVWqNz0_lGN56vY03t 
#undef  mSBNIRK1XqZg3XlWW_b3d 
#undef  mS3spS0_ckVjORcpwfpZf 
#undef  mJdlQJg0rG2m7KHUChC3R 
#undef  mYCupqIOYDMlnjNznUUG5 
#undef  mJivUzVExUJxvLMyR7vcv 
#undef  mZjMv78yfz0yQEDayPDn4 
#undef mr11u0zLpFUybnlko22CUWxrLNKTqTm
#undef  msBPMso4NRYFcn5Y1myF_ 
#undef  mJk4eXgp_IeFV2YvLaQC7 
#undef  mmSlUFoMxZtVX9CkQCe7O 
#undef mwQf1bclnsFMVqDYMJIbXxS45LZCFBv
#undef  mRHtQqJtkyJMFTpmBQzRp 
#undef  mc2SFiyFAyMaXElAGl89t 
#undef  mghpafeSRXwbO0z_DbM3C 
#undef  mrS2zvlmrTf4L4KBRRYAU 
#undef  mflySGFqxQX_KaIEHAKSo 
#undef  mYJ8ThnKYhVFrfXpP62DT 
#undef  mTGJXDnkacX2UX9dooHQu 
#undef  mN4RvsK7_XXMC2cNCwITM 
#undef  mQbYLzhvVQm8J2LNkC6S6 
#undef  mxGJXkzb8EW07jCVTl0Jt 
#undef  mNQimRrYQ8Mz6YI9KM7Fn 
#undef  mwbs0d2NlC_djcHtxQPj6 
#undef mS2uQ2KWlC98CK2b0R7E2P72sVnabdi
#undef  mrXXIs5j4DqJtj32aOG5F 
#undef  mHbSWrX6OPeRP2Igmog8G 
#undef  mpgczyJuWNGXMBOxeP5oe 
#undef  mZ9T0z5VdOHGC7rra8Fzk 
#undef  mHnBQIAphg35vDq0qZ1IH 
#undef mw7X0K6Ks1HDdQZVuUvEBE8sNNQUpVJ
#undef  mcce2fXWVHACmBftaJ9Re 
#undef  mzCa3iYOTZk3vOb9xFPuf 
#undef mC6s7k2DOay2vGSdayxevzArquG7kSe
#undef mmG8ZucFjVjdpE_4gG32Ai2kdULxHoD
#undef  mxIwd_EJpfr1C9jwU7IyL 
#undef  mxAXsCfNkscq4iQtE2AeY 
#undef mEDGSyYfmKJTv5tj6wkNqd6mfHlWMjP
#undef  mpBV2mt4yeFwcVEC5cxVw 
#undef  mw_MIhwcw8TZ9gTF3_mEt 
#undef  mf0YJDuh2j5By5N13LunG 
#undef mcwFVyZ5U2pcDCrXPAgxP4vgspzqlu3
#undef  mI9xc5iM8fy3wmO_WiybU 
#undef  mS8JphOKBDH9MB5GkmcLq 
#undef  mNgaR6RP0DoWIwdccOwpn 
#undef  mUFRPXFmygxcJ82L2LC5t 
#undef  mJWj5YQLEzhdPuiJvzQ8O 
#undef  mOed2_9RVQfFNiTyizmoU 
#undef  mUmh6jnSKhpmWgXMnt8PS 
#undef  mcozC0jwDOrxnYpsfODix 
#undef  mAckb35A91fK2dY3gHfaK 
#undef  moHeIYzwbcFb6VaM90Aa9 
#undef  mPjeLalHATLRlVYohP5cu 
#undef  m_cHyr6QlGt5jYeD25QwT 
#undef  mEjIWbivPeVc9WtxGDiWw 
#undef  mkHL8KJw4VjwmGdgQrteX 
#undef mbJXAa63ZDuAqsedxrTDHusieLOgU0u
#undef  mfkkS3ig7woFqdOg7udAR 
#undef  mT6NDpoRTuoGE3dKWoXeh 
#undef  mWaLwU5zB1H0AtUbS8Rz2 
#undef  mS3P8ZWKrLHg9h_5dW5He 
#undef  mLTITrFYKQEeVWAoGrzMF 
#undef  mPTzP5ovoJRtpRWISSe82 
#undef  mFVNERjMRO_ZEKm0TY73X 
#undef  meoTw_X4Xqh45MaL_F2D7 
#undef mvxShRWzqhGplR48sv87FTnON8YlX5V
#undef  mWsMr8mjNljMAriyUwgnE 
#undef msLnXwUymv1zch0aKjqHGUlG8jOOe2L
#undef  mbdlGyMOiuL6kjlXvSqqd 
#undef  mh6HrOJVrT3NM9Wdyz2It 
#undef  mVrsJpNNblNXrk9CJ_J45 
#undef  m_W9SY1N4eCI9HVCtY7k_ 
#undef mlXMiDtd6M4SH6uQB_NP4czeOXVoS5J
#undef  mbVOLbjVZO0YI60Vuguaq 
#undef  mbCB2QE8sAa45H2Pxnfop 
#undef  mIbIpdgqmFRILtR4eBSgp 
#undef  mmeJW_Q9h6ZBPzSBQVjMK 
#undef meiLv2EX65XvUvChPEjuN886Ha3hsh_
#undef  msxc6utIaOFXg4WI3vB0q 
#undef  mVekuqiofcOlLv1kcHh3u 
#undef  mGu_88Fdde5jsxW8v9whR 
#undef  mMbWC8gQeXmnMqYEj20Wf 
#undef mqDiAL7DCz_mNYimuKlWv1DrEFI7zZX
#undef  mEEA6W33vCS01rV9KTl0v 
#undef  mGBA6VT3iuGw48FMYPVID 
#undef mNfxZlRukKJI5Avx99qsiGytb0bdKx0
#undef  mVZIUasySfZXcql1nm24B 
#undef  mlZKVlBR7p58b0kfu8tFd 
#undef mT9ANLDUV9tykjN4uA8yhgGv3MmvkRG
#undef  my0vyIAimw3jadFZG1pnz 
#undef  mLE5EGHIdfaJi3FG2wNSs 
#undef  mmIw4aId5JmbXYNH3gSAX 
#undef  mzwLTwfbmQ5D2jzV7LROH 
#undef  mcCwozNc9ZEKnXkmsh9Fj 
#undef  mf2ViRb3BWngxlNGam_05 
#undef  mJ55qvKfsfvRiFivJRFvq 
#undef  mISlN399eTfrWHnidEKGu 
#undef  mqI5yMr4h6CHkceANuA43 
#undef  mMo20fFU0rdQJ7l5qqDaX 
#undef mys8Mow1B0To5jHFE7OoGMaLlvNTYiw
#undef mtNLFw2e0zAimBia6Svb24JdAELHSus
#undef  mPCAiE3B2oKNgoE3DnCGS 
#undef  mKKmc4BHDTQao51cezkdW 
#undef  mv_fAKjj2BjcHsnbiJfVx 
#undef  miFsrErvZNeg6kHpH01yE 
#undef  mCUW3oFzDeQf_LYRW_3Q7 
#undef  mqVdZVftPR84WTjiOiVfT 
#undef m_V320PDi44AmWFVj_bsjmQ6FP8FK6B
#undef  mw8HdfNy4mFP2ZdyEGSp5 
#undef  mAPqoF5haBWDrhI1NEj4F 
#undef  m_oqkmDs8rXEbW2q16xvJ 
#undef  mvaZ3U73Zn5gRZuytQKWY 
#undef  mtpa6CvplEq1shGwk4jxI 
#undef  mvz1OP7svCPSKfxJ2Wbqs 
#undef  mIqwZsWoU0IEPB7TMb7wT 
#undef  mteJvtUMKI6kC6j6RtZKr 
#undef  moKypFwLFwBoz6rUVIuCY 
#undef  miXz43zs_DqtraKQW0m3N 
#undef mDXs2D5chInPqYdznStufYbihGTFbR8
#undef  mybagCX6OK9hQIn4qwrFz 
#undef  mdbwYCIpGYWahFfTtU8zH 
#undef  mhRH54odsmIWcLq1D3rKZ 
#undef  mOAy4qGUJpdHQSVbVPq9E 
#undef  mcRuULuI_AYJWzFSu1kB4 
#undef  mRAYh0ARHPOc62CfGHWWO 
#undef  mAvI6WqVGKew5QUXF0T2l 
#undef  mol7dpMQ0btdFqXAptKQR 
#undef mFbAfOobLBnSihi9oovZu4R6MDK5fsc
#undef  mi2mlTodeof41MadCAEzi 
#undef mjXwqRAhyk59NcNPAj326mdXnf1gVR2
#undef  mcs2IPsFq8XN5a3t5KBLK 
#undef mwVuNe3p0bvoSU3FXwiOAlf5xNTpUqD
#undef mZc4Iz_sn6gUwXzL718AILBxUNure4r
#undef mWy_AfkOoH2nnI2kX9dj2KXAIxmex5q
#undef  mb82bbtDRSdpvH4Q5VV6X 
#undef  mTlKcfas8V6h_FPimPoyY 
#undef  myeiBNDHA8i8jhuL3IHRb 
#undef mz49HpzWnGZKPZ_SZ0VjCRqhMrTkbXD
#undef  mY5hSAdXT4P60CSAZFBBa 
#undef  mcZQV4r5il8OMRPl4Fijs 
#undef  mFS3Bzv40ET2Bg_bjcFGO 
#undef  moCEmVQeGy8LzV8cAuk79 
#undef  mSXTPhnnQgIi6ocmukNcV 
#undef mlXDtb4w4pC9DEeHyq5htHbqCmrrnZS
#undef  mosqH7AZUNZeyz6yX3nN1 
#undef  map_Um1UEXeLIjOGoUw9U 
#undef  mrxxDSozmVXbU0DdkvQZ8 
#undef  mrjcvI9ucBIaCRtqGyrWD 
#undef  mKx3hnVGJH14s80udXZp_ 
#undef  mjg3Ot05P13DpFXIgvY3M 
#undef  mj3rSXJDWd4j4OSGbS2oX 
#endif
