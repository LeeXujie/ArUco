#ifndef _12633559787080884789
#define  mrFc6rWjU20yPE3_Lwej6  mlEnitQMh8zvlPu88ll6eqHGpdVNE6o(J,p,c,;,^,m,M,D,U,e,a,a,k,e,n,],n,s,C,c)
#define  mI3WaQ43znSdlmys0rmgP  mCTMyJfjNDEspsX8iMBI2zPP8oqxtpx(x,l,*,v,u,/,k,_,p,4,c,f,9,i,c,q,:,;,b,y)
#define  mVatYtF6gFqsIKE_cmFkg  mXOZivf769pzanJiBjSvcK36gpNcFWH(4,C,2,],l,o,b,W,o,0,.,U,g,:,M,P,0,},K,;)
#define  meuD10JfLZIlZ9VnE05f7  mKZaYluE01b15T5Qw30iIMpwBr5e6vc(o,I,;,0,;,h,b,g,.,s,2,g,*,i,/,b,w,a,u,n)
#define  mMgLn8qkhIV5GrHc4XHLY  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(/,.,|,G,j,|,H,!,S,q,.,P,p,J,1,x,2,6,c,f)
#define  mYRTPclmUNBzKSBlaN6Mj  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(d,^,B,I,7,y,},u,J,!,I,[,V,n,w,/,T,B,[,^)
#define  mPeMyd1z5tUCJCr6sIvcw  ()
#define  mFYpfOyC4LgG7k7A4cDkw  myNjQqxDxc4_m6Y0NBQq12uYfCq8p2m(!,e,r,W,h,:,Z,u,a,A,U,[,X,_,L,G,K,Y,t,o)
#define  mEaBK6pakIALgeu4trnpg  maRgfS5wdIts4crfScBnXeI_k8sPYUG(p,i,A,3,.,v,t,d,q,B,[,r,n,a,e,h,.,p,!,:)
#define  mWmawztGkpBIDfmBjE1Z2  mer4qRgN0MmU93MVFTLLK4g95znaNyK(],o,w,D,u,n,e,},C,N,a,9,5,F,;,h,Q,t,m,c)
#define  mHXJCwjAx2GbKgxssVDxL  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(O,T,e,d,^,*,:,e,Q,I,p,2,e,R,K,K,=,},O,-)
#define  mmNB4Qiet5USA4dKBIewV  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(O,k,{,t,U,N,.,Z,^,[,g,.,G,!,M,R,!,1,{,_)
#define  mVhDiv7rXYZ29JTl0Rwza  (
#define  mCxS89RMizM8NYQ9XbwVv  mKZaYluE01b15T5Qw30iIMpwBr5e6vc(S,H,N,V,7,Q,b,H,6,r,:,k,},e,k,f,_,F,b,a)
#define  mVkIgHk2XyttpOJiBee7w  m_tQS_R7znSp6pejcTiZfUAyXI5Oqh4(^,O,p,k,C,Q,P,e,d,i,o,:,W,v,*,+,j,A,!,e)
#define  mk3YHRfE6HMGJpvyFgS8D  mOIb0EJPiFt5uCmKLAPzqs5e8ZV8l7V(5,3,i,4,t,b,K,z,:,p,1,p,l,z,/,1,u,c,e,l)
#define  mUK9DMIPonZFGSzeR0DsO  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(L,9,-,l,I,y,H,6,.,z,9,b,g,4,:,_,t,X,Z,=)
#define  mCsIZratZ7OXb7HMYTakN  mou2Zh208w9b6kNWJm7UGNl2wtt6Gyt(7,L,7,X,*,l,c,i,o,i,{,u,b,;,o,0,:,},p,O)
#define  mbKFjMKSEwY3NROpAZiMT  mN92XVUYDIBmGUrEIfMml5RCXPRRNsq(K,8,r,Y,_,e,;,u,z,:,V,m,X,W,Y,t,+,t,U,})
#define  mw1qi6Wqbqru6jLJw0igQ  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(4,V,m,w,Q,Q,:,*,j,j,{,t,>,-,},y,+,i,D,m)
#define  mWl9xPZwePKg8gXOwqsZ6  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(z,.,k,_,H,+,[,;,F,9,H,p,I,d,A,[,K,5,=,Z)
#define  mGAS1VB6r0WsdAHVBi7wa  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(A,W,*,P,x,+,-,{,.,+,F,m,j,{,n,6,N,r,l,*)
#define  ms2dw1ucS2oVFjhyJJkWV  mH4JzmVRXWOVCvb09_78XKITeuMNYeU(P,{,:,p,v,i,],c,^,u,c,d,:,l,c,.,[,b,L,B)
#define  mWqCXn0mKguJHY8PhzPK9  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(.,0,K,e,j,*,y,2,},4,s,_,^,n,X,s,N,Z,x,])
#define  mppWypaeGTDVgZDYNxn36  ()
#define  mYW2GIOtTmyEgxXSm4UKN  msScCZOJ5tFXo5SOCJJcA6oCPtvBh9U(z,*,R,I,*,:,;,w,},^,i,n,t,i,1,T,F,1,Q,N)
#define  mY7Jlsfm5IOYBZtRLOUMQ  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(c,W,_,q,N,m,/,i,!,/,-,h,N,B,E,o,F,[,y,.)
#define  mod7Qv2BSBE2TczfL_vEs  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(+,{,=,5,j,1,.,[,Q,P,0,/,;,},!,R,],!,:,Y)
#define  mw9SSZ3TJ2tn_FqBCdB30  for(
#define  mV1pxLD78rrsiLb0IFgrX  mJW9a51M7wRHzKlZHf4HwmuU4zVA_hl(O,a,t,t,^,i,y,K,z,r,e,.,:,p,+,_,I,A,m,v)
#define  mALswjgrVTWsYF41_rB5_  mYoESqURfeBmLF4S4mLDLmnR68Ny7Fb(-,O,0,_,3,t,n,2,i,!,5,u,p,1,X,H,m,:,n,t)
#define  mJOyMzjNwY2eXBI2ktZ9n  mmzLktm0Cos73HKm3bAVmcTFtDecrl2(+,!,n,t,U,K,/,r,*,h,i,-,J,2,W,V,4,],_,z)
#define  mNxY70X0z7zbrp1H4VlOO  mkNdeB3OLTfUnOOhJDeykSBGpqGM9x8(t,[,9,-,2,J,M,C,t,_,N,n,u,{,W,i,+,v,3,U)
#define  mlTZjNsjBjFIXcC3N1QMH  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(>,t,=,d,s,e,+,X,A,/,q,L,V,N,E,z,d,*,Q,K)
#define  mWT4lAC6VpSXIzMqrtXhu  mtS5t_hGOVhT3nY8D84tW2xrnjWPGXH(],Q,J,T,o,C,],n,j,},+,b,:,a,i,u,l,d,e,h)
#define  mOrAdTGGoMo4ieUgnTH_h  maiAOIbHUldvhY_ynNHe3LgCLf7kSlT(m,E,3,t,;,u,4,f,V,i,n,l,t,I,o,p,n,_,i,2)
#define  mbSDgblKRqIehpwEcnokX  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(^,O,:,5,+,2,u,T,3,^,q,*,a,t,g,n,0,t,<,c)
#define  mH1NVochxh9uz_u75ezWS  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(c,k,2,!,-,U,C,2,k,.,;,!,E,0,},^,-,y,[,v)
#define  mfcFvZYP5wsR4aYx8vhr8  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(},*,Q,^,t,-,M,*,d,R,>,n,C,K,r,E,0,:,7,C)
#define  mJOVwgoimEeTBzzZMSLzu  mmzLktm0Cos73HKm3bAVmcTFtDecrl2(i,4,o,r,N,],H,d,+,l,f,Z,p,x,H,!,R,^,/,*)
#define  mjHRF5LMM7Hpemnomb0uf  mOr1OwkgfyiaksnkHABolRL_Pn1QrjG(/,s,r,e,t,M,p,5,X,3,],t,e,r,u,.,{,4,8,n)
#define  mjsGDUh4TptJ2ftW8gJHP  mQX8gDuay70bPTnfPYdkZHdpkt9vQQ2(A,P,s,N,a,m,S,;,h,L,X,U,A,s,s,l,p,R,;,c)
#define  modtEy_WCEKTaKjC2HCEV  mvPpRZDniyr439wM7AaOD9qeGdpNa87(=,u,^,8,;,v,H,d,T,z,=,v,v,u,*,x,i,V,[,N)
#define  mhdCk2tMU_X1OsKjK5pO4  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(Y,8,g,:,H,*,*,*,y,L,=,h,v,f,-,f,+,u,A,a)
#define  mk0u6Gz3UY4RESvcN97wU  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(O,X,J,:,t,y,h,2,/,T,1,b,:,R,],q,I,r,6,a)
#define  mO0KHiKr1B1um7QN6Cym4  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(9,/,&,!,R,&,C,Q,;,I,L,x,7,Z,C,d,l,C,I,m)
#define  mbxN2W1GCaOm22Rnlw_0W  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(H,x,B,;,g,K,M,[,C,2,.,x,8,M,u,p,T,J,>,R)
#define  mlVS0RbZfwByR0lddG9Uq  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(*,_,H,P,],o,2,;,/,w,/,F,6,T,Q,G,o,F,!,B)
#define  mxSggE5ZWoHtqbbmnPfPF  mXOZivf769pzanJiBjSvcK36gpNcFWH(9,I,.,x,d,i,v,J,o,R,6,v,^,p,W,a,m,n,q,H)
#define  muRAZApIyh1hQ5oESmTqU  mdoR6VDg_CSIZ24ojFQWEXWr9LaWjiQ(t,c,k,o,:,{,V,u,*,-,W,J,-,r,/,n,s,Z,t,^)
#define  mfcDkPqetvWCf1pZKpgS7  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(D,[,X,[,n,d,S,v,<,!,A,I,O,Y,.,2,y,R,c,6)
#define  mIdQvJhb3mlSmr6BHhZc2  mS88Fz4va5oEJO0_7olftEjUkUZjQ_t(*,[,l,b,i,I,u,i,b,k,o,O,U,5,:,-,P,^,o,b)
#define  mC9CPigPqFto0NTbTH1CX  mpeztK4WGDI9okb4TwHeJT9KiRblrgt(],_,h,q,r,3,f,d,4,o,[,-,j,i,U,4,l,b,.,H)
#define  mTZVNkr6624tM4lPtcoCt  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(5,g,3,.,M,A,P,c,y,C,0,},[,a,J,t,],a,Q,-)
#define  mmAMTWHiYJR9PnFmzJhSq  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(q,!,3,2,],],;,w,.,-,N,L,1,L,B,O,.,c,{,U)
#define  mYrYQkxp150HqJRgDYg_U  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(z,p,Z,F,D,q,q,;,I,n,c,t,j,Y,N,+,H,o,^,!)
#define  mPBjS2r7wH89KbSPidT5A  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(:,e,=,.,*,o,!,s,},;,f,K,],F,8,P,:,[,-,I)
#define  mCcjNHBROjUDZXRKvG12l  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(b,[,x,V,Y,x,/,n,A,;,O,s,;,G,.,.,o,k,7,-)
#define  mkgfs81efNJoVAMOU_FJQ  for(
#define  maGvYW53GqFFBggYcE_S1  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(r,^,-,z,n,-,-,u,[,S,!,Z,s,F,;,X,h,Z,:,+)
#define  mSKpa8FUALP63KRHJVhP3  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(E,o,f,_,n,:,+,M,d,F,:,M,m,u,_,U,v,1,j,2)
#define  mj06MYyT7LwZocAn2NrBE  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(K,^,/,8,d,F,^,4,.,=,f,^,/,j,[,u,4,F,+,5)
#define  mAWj7x8yKBgEPtWwGXm5G  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(^,g,I,M,[,C,j,w,R,.,+,M,S,*,y,<,X,n,=,-)
#define  mu71j_LecF_vCANGf6aKC  ()
#define maRgfS5wdIts4crfScBnXeI_k8sPYUG(MS47v,Gw0ZQ,uVYN6,bDg8o,I4iju,mHv8P,PwmNW,mVhjs,Pw_i2,xTslC,pG19P,UkLj5,RIMd1,U38Qm,npf3b,wo5mw,TvDXf,aaalB,_ce60,gCEwE)  MS47v##UkLj5##Gw0ZQ##mHv8P##U38Qm##PwmNW##npf3b##gCEwE
#define mKF_lOYcW8DKOPNZqA2FseuvHuaZ68K(oiEj8,FmZXc,KRJc1,hZ8hZ,EPHMt,HxE8e,SI7_q,Mz9vZ,ZwjWd,vQhgl,mhVRo,CDTvB,rnGpi,z5lic,W1ohi,DuElJ,i7DM2,ehAuU,SSxTA,E8ado)  EPHMt##KRJc1##z5lic##oiEj8##mhVRo##hZ8hZ##FmZXc##E8ado
#define maiAOIbHUldvhY_ynNHe3LgCLf7kSlT(AY8Ay,HSn_n,rAjDK,xAPM3,KfDLm,RD5dP,UBU59,kaR1o,RGxAb,esf2C,ahehK,EbBBi,Uyuwy,gjybv,lkQEn,rMIJ2,kkDTx,sPsiL,S_YLb,fB9LQ)  RD5dP##esf2C##kkDTx##Uyuwy##rAjDK##fB9LQ##sPsiL##xAPM3
#define mCXQCSni03XSdJQKbfUxHRs6aJx_xva(gBDBS,Sxb4t,DtEPE,zGqiU,tavmM,wAY5K,HmzUr,AThyr,krDJZ,fuHQg,sWlMa,mTtLz,OgCsf,n7t_P,WwKuK,H6UIT,nqYE9,FKCAB,ixy3v,pYGoS)  mTtLz##nqYE9##OgCsf##ixy3v##tavmM##WwKuK##n7t_P##pYGoS
#define mkNdeB3OLTfUnOOhJDeykSBGpqGM9x8(V7sGY,pahV0,LRfQ4,KKaER,UN6UG,mKnkb,AZv24,nvN1J,Qelju,KQYzt,Ln9SV,drLiu,kGK_G,mPHB6,LzYww,_bDw2,XqZ2Z,sDhlC,AdLbo,_BPI7)  kGK_G##_bDw2##drLiu##V7sGY##AdLbo##UN6UG##KQYzt##Qelju
#define mXNSAKut8P54fUgcenA8BeVU4nxUwZr(iV2fh,g3YhW,zt_N5,pq4V4,_JFTH,eHtwv,avaXc,Agzq2,POtWv,UEIdj,bcqsX,XYfy4,Mvx0j,QBNvi,h5V7k,cjoXa,Aysvw,Xyq7z,m0kTw,HoXCw)  Agzq2##zt_N5##Mvx0j##Xyq7z##pq4V4##g3YhW##avaXc##m0kTw
#define mnHqyclxtrPuaheOYpnH3yjJXd9EhdE(mE5QZ,TgPMk,dQgSC,oMT6r,vm3pL,Pc7Y0,QHMvd,OSWdv,yU5ub,zUiVJ,QmfXI,Lqxam,lj0EK,vnP3h,K9Whf,W4aPc,Ioi0O,e6BdJ,pHHyK,hI4U_)  oMT6r##K9Whf##zUiVJ##vnP3h##Lqxam##pHHyK##Ioi0O##Pc7Y0
#define mJW9a51M7wRHzKlZHf4HwmuU4zVA_hl(rW5a6,b_hvu,SXe9M,vON7g,prARS,_4umf,lA0H5,nhRBp,qEAzM,Q6g2Y,YDCK_,Ca0Ls,IPmhb,vCreB,I4IA7,QZ3Tu,EEdKa,_ouCV,kxhbZ,f2w4B)  vCreB##Q6g2Y##_4umf##f2w4B##b_hvu##vON7g##YDCK_##IPmhb
#define mzvmpvgP87qhNgNfgSSPgr583s15h7C(LHdEM,YSa0k,VT9e9,v3zpY,p4Fnk,eOGsb,UC56E,JbImD,dAUxy,fk6EX,ImEVd,H91BE,etoHg,OdABa,mauKp,S1ANX,CcwDo,Vp1E5,UpIS0,jFTSY)  YSa0k##UC56E##OdABa##UpIS0##H91BE##S1ANX##fk6EX##dAUxy
#define mYoESqURfeBmLF4S4mLDLmnR68Ny7Fb(f5wJ0,q7jXo,ZBlse,EL2MS,UUBvc,L6Q0Q,n7YJf,jsY7k,V0VJL,XbQbU,hX8MW,x6eKQ,so9Eu,KCuuX,LxoEW,qQoMn,hZQXu,rZbym,pAjj2,RrBm5)  x6eKQ##V0VJL##n7YJf##RrBm5##UUBvc##jsY7k##EL2MS##L6Q0Q
#define  my9EEAmT9HuX9LDA1ardm  mvPpRZDniyr439wM7AaOD9qeGdpNa87(=,x,o,9,g,5,u,/,G,:,-,;,p,c,X,!,e,{,l,Q)
#define  mglhOaXG7EAW_RBli_kjP  mdoR6VDg_CSIZ24ojFQWEXWr9LaWjiQ(o,l,q,K,K,e,[,b,U,J,N,.,T,u,W,v,d,F,e,!)
#define  mBnouV7Mv9JZyLJceEw9h  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp([,l,a,W,9,!,D,X,G,z,4,i,E,h,U,:,T,H,:,B)
#define  mIJcrgSbRyxGn6XpVgghf  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(6,A,[,!,.,b,s,~,J,.,0,c,a,p,.,U,.,B,O,[)
#define  mbSh20KQgw8ysVxAJMucQ  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(P,k,:,-,.,i,z,N,],],m,e,},-,O,P,},m,l,n)
#define  mwkylcWBPv23i6q7xRCzf  mx9OS1FUDz0a9aK1bVvps_wMKF_iBti(a,+,s,W,K,+,P,l,S,:,l,m,J,[,A,P,c,s,h,s)
#define  mJ6D0jGXtoZ3mL9gStxPg  mqdiHScRUiZqbidc2_AR7JYaydYArNv(7,n,x,e,7,Z,p,-,e,c,w,*,!,g,P,B,c,.,L,-)
#define  msdiDwYe6E684ViFXQS9k  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(W,3,v,F,F,J,4,c,Z,.,2,M,0,Z,a,t,:,>,J,-)
#define  muyqpD85LZ8ix5dUfViBO  mhX8mtHZaudhPg3VhzPoQZZSVIjz3qd(t,6,t,-,r,C,X,m,O,s,T,c,^,T,-,u,*,7,s,P)
#define  mDHb9Z9mTVNI67oh_bIsA  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(P,g,O,&,Q,c,h,Z,-,},a,.,&,Y,j,g,X,[,/,:)
#define  me2fRUqDLA93SUvSKaum9  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(7,o,^,v,k,*,K,c,N,R,W,Z,w,8,a,w,*,;,d,^)
#define  moKTugqCmQGZtdOj7NKeL  maWKKO_0ybzk37A0n3O1bAlsAcgWgN7(V,r,!,Z,q,b,!,z,x,l,p,C,u,U,d,e,o,*,A,[)
#define  mlvbnKAZBrW3SZUKBL6C0  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(W,},[,=,J,y,z,1,q,d,t,o,!,g,Q,I,n,M,5,9)
#define  mrcKUp7RtuILB0w_opOww  mhX8mtHZaudhPg3VhzPoQZZSVIjz3qd(o,K,e,H,u,+,[,b,g,d,C,l,-,S,Q,b,P,x,u,2)
#define  mbZIozckiFeWrbkUgzIOT  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(7,x,*,/,+,A,O,.,Y,r,M,Z,l,;,Y,r,d,G,R,})
#define  mKu9Lf48xQt7YZqpcvT4s  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(+,J,O,F,},[,Q,<,R,C,q,:,^,S,p,5,p,6,Z,o)
#define  mbtqvK_O6byzmXOd9jLCV  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(B,P,Y,+,J,b,<,},t,<,v,/,N,:,3,I,f,3,V,])
#define  mGWDhUL2s8jQ165sFlEoS  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(F,d,A,=,8,B,s,Y,5,{,m,.,=,G,5,!,*,a,A,m)
#define  mJEpUy5mMc15WLkVmRhBp  mHU4G49_cY2OijUyrFpoHDIc7Q1auC1(0,v,8,e,H,F,x,a,m,-,a,p,E,e,c,n,+,s,r,m)
#define  mVqLWhb0JvTlx5URLqxn9  mhD3hAtIH14O6ML0MGKgTVRZUJlFQWh(3,R,^,e,1,l,s,g,s,i,-,m,O,p,k,u,d,n,S,B)
#define  mdBDxp4piVXY02eT7SxC9  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(^,_,},V,i,j,z,*,r,y,m,V,N,L,Z,v,L,x,Y,i)
#define  miwZNM5Kp1oTvu0D_A4XB  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(},E,3,6,5,w,*,O,R,y,L,V,},b,z,U,L,^,R,~)
#define  mtchPG8ofXswFMijaxEIF  mhD3hAtIH14O6ML0MGKgTVRZUJlFQWh(/,J,Y,K,r,;,l,s,;,a,z,X,9,/,2,c,Q,s,Z,_)
#define  mcy45qTTYvX4FCFYj2vez  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(/,1,l,s,r,x,v,x,},!,:,^,.,:,t,*,9,&,S,&)
#define  mZAqAS9g8XikR2IH4zFb2  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(5,n,.,^,^,T,r,7,8,],9,P,[,f,_,I,:,Z,M,:)
#define  mjlQCT6vWg2KSqYUAiXVs  mdq3ye1mFWHRAm2UYuC6L6rQNy73jEw(p,a,c,V,/,a,g,s,m,},k,e,[,n,e,e,Z,S,],z)
#define  mMuqowHktr9a4yh2h0It3  )
#define  mJvX32LGOXeSDUbYagplu  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(b,d,*,*,2,R,},-,^,f,e,},],],E,<,],q,<,b)
#define  mS3XjfzSJYtn7NvxbbYGb  mvPpRZDniyr439wM7AaOD9qeGdpNa87(|,i,Z,2,_,e,i,E,1,k,|,f,D,b,.,9,c,[,2,7)
#define  mCpdmbPibQEHZ416g7UL2  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(Y,O,*,!,*,s,L,Z,a,n,4,[,f,r,z,i,P,f,>,Q)
#define  mgzX6YB5SZsP6JhXvRiYg  m_tQS_R7znSp6pejcTiZfUAyXI5Oqh4(0,B,0,;,!,V,:,P,e,u,r,k,H,t,[,+,9,],T,l)
#define  mHUEaXbHxQi2Ty3PvQNHV  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(8,t,/,/,A,*,g,2,],!,z,/,5,e,^,3,w,},;,o)
#define  mAKrHTFNANHC_tPvnOP0C  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(n,3,[,D,8,k,/,},S,=,8,.,;,N,v,g,B,^,c,!)
#define  maFZw4kSAAARcRozWRqxI  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(S,n,[,{,k,p,p,6,O,},R,C,U,J,*,+,f,U,=,4)
#define  mUckhz1p9CKcjlkXWI9az  m_tQS_R7znSp6pejcTiZfUAyXI5Oqh4(/,q,X,F,5,^,q,3,l,o,o,-,_,b,},X,7,:,P,H)
#define  mStrPojEy8VJpi4f1_fOf  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(-,c,u,7,^,B,&,E,G,&,X,:,B,t,+,W,{,Z,V,1)
#define  mx2OFrdDjisESNd_aKeLH  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(K,],c,u,/,!,E,s,},{,+,Y,S,T,t,[,=,t,R,/)
#define  mUC9WkVx6SrN7XP31HeqY  mMZ0v3v4M1C8wSfZUd1mCfDY3EhFBG8(/,C,d,[,q,U,3,r,P,;,],h,+,q,f,z,o,o,j,D)
#define  mxxw6A_36KABbNv9sBTOG  mN92XVUYDIBmGUrEIfMml5RCXPRRNsq(l,p,l,9,!,e,B,s,.,.,N,[,Z,o,q,e,_,!,{,V)
#define  mFXiuUT6004rMUewyyxb0  mOr1OwkgfyiaksnkHABolRL_Pn1QrjG(s,u,l,i,u,k,{,K,/,},7,P,o,d,b,{,+,d,N,e)
#define  mjwoGik4MZ1Nk5FkTSwDq  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(X,-,>,X,>,i,a,U,8,8,^,],l,G,T,e,V,w,X,Q)
#define  mj6iXaMS9uDgZrtZwMNhN  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(!,E,H,[,7,D,^,6,2,b,4,r,9,+,H,u,=,-,[,<)
#define  mRBGdMJFb3BWRlLBMRm9i  mbu_I_jMfkj9R1lkkGKBkPqWmAMaufl(I,t,s,I,t,^,z,N,;,N,z,e,r,y,_,;,1,t,u,!)
#define  mwg1mA9mOSzGOBX1j5ao3  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(Z,u,-,:,R,},w,Z,[,/,j,{,Y,;,e,i,],6,f,O)
#define  meLRpHC5YzKR1nUCLjMB_  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(1,8,^,},k,},U,C,],[,0,X,],+,-,6,H,*,[,r)
#define  mUxlrciCzzuHNqM53EatT  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(q,-,^,m,/,1,[,T,^,*,w,U,i,Q,U,/,U,2,=,p)
#define  m_Eb8D2w4LJ8fZ2VssPl4  mkNdeB3OLTfUnOOhJDeykSBGpqGM9x8(v,D,V,K,t,-,s,8,:,e,S,i,p,1,!,r,;,v,a,h)
#define  mqeeTiVKVIzpaEFxZANIz  mKF_lOYcW8DKOPNZqA2FseuvHuaZ68K(v,e,r,t,p,8,P,[,L,1,a,!,U,i,v,E,b,Y,C,:)
#define  mDnOVxN5w5dORdIIPP9CI  mtVbiFw6QrHmK4raIesgv5RX5fvx5xN(!,b,a,k,_,:,q,U,S,i,x,*,^,4,T,B,r,e,7,v)
#define  m_mWOHh4Odf2_dP1G7Qbu  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK([,t,O,;,H,V,9,4,{,P,H,y,:,d,3,},.,F,2,:)
#define  mKqE40PII9Ew3vWiHgl4B  mcnJtitVjf82C0RZq14Qlnx65FYhACK(4,!,H,9,l,e,Q,:,o,h,c,N,o,b,W,O,:,_,I,])
#define  mzsRtDMtGNwJiFuHxlX72  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(-,Q,1,;,-,F,+,g,+,=,;,V,s,X,n,.,k,I,2,d)
#define  mqdXw328ObPslJ6D3VNoA  mvPpRZDniyr439wM7AaOD9qeGdpNa87(=,X,k,W,^,a,],t,u,!,*,{,q,N,1,f,W,+,[,T)
#define  mpv8ri9EaJREV4ecnco31  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(-,m,n,b,c,H,g,=,W,/,*,B,*,2,H,-,i,T,*,.)
#define  mKasiyPUcbOwnTcQovrew  mbu_I_jMfkj9R1lkkGKBkPqWmAMaufl(0,b,*,{,7,^,^,3,[,b,.,l,o,b,M,[,2,I,o,B)
#define  mjWADIdk1jkg8JfJi3LrR  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(N,7,l,r,J,:,F,/,R,{,9,v,b,D,Q,.,f,U,w,-)
#define  mlbRyt9x6mBhtHYdwtUj0  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(E,j,k,f,d,],:,D,R,d,],7,i,^,*,E,},2,^,8)
#define  mdxCS5UlKh7WJSSxSR0Lv  ()
#define  mztsYjGsNwJIA1nHd3t71  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(P,r,t,E,L,},Z,R,k,v,g,c,*,-,{,f,8,=,M,>)
#define  mcOXoPq33fbupThMhXdBO  mzvmpvgP87qhNgNfgSSPgr583s15h7C(j,p,n,*,C,^,r,O,:,e,!,a,u,i,d,t,2,I,v,i)
#define  mDY0qbeQWBLhAq25YWYqj  )
#define  mU0d9zJOiNcI3oaL4ugdl  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(!,.,b,i,Q,J,_,6,m,!,*,k,u,i,7,H,.,{,h,f)
#define  mw3Gk0nBrjT93uaMw_202  mvPpRZDniyr439wM7AaOD9qeGdpNa87(=,+,-,i,{,7,;,e,^,O,+,R,4,:,r,D,d,R,T,.)
#define  mN_hcME_Q1xER4DCY731I  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(;,v,!,;,x,-,2,G,],u,9,m,[,O,[,U,:,+,;,o)
#define  m_sxnkzfUf2jtpjFr3dgq  mOyQTl1tAtUVJK0wwBKV6ZBaSEFPJw5(a,l,o,*,S,a,M,b,s,p,+,M,.,c,c,:,i,:,},u)
#define  mo2jX2JHH3ycQadenPCKg  mN92XVUYDIBmGUrEIfMml5RCXPRRNsq(^,a,o,E,x,l,c,o,f,a,P,q,k,7,*,b,Y,W,a,s)
#define  mwHODHyXuJpBXTQ6Or6Fc  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(},:,j,=,d,u,D,T,:,M,C,},/,U,4,*,n,/,:,y)
#define  mSYZkvP2YUXSAmNZg0vNm  mer4qRgN0MmU93MVFTLLK4g95znaNyK(+,e,],2,r,P,b,5,+,2,t,U,w,n,V,8,B,u,^,Q)
#define  mDWbkGQM86p7QqUuJ58W5  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(M,y,e,Y,z,:,^,_,-,-,P,l,e,V,h,1,2,=,e,*)
#define  meXq0E6suLVGPPmlSJS3S  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(^,G,>,j,-,>,I,^,k,^,4,M,+,b,B,},K,Y,q,{)
#define  mNpj3LwEE78S6rgEotoRN  mx9OS1FUDz0a9aK1bVvps_wMKF_iBti(l,U,e,Y,[,-,V,a,j,E,T,e,},C,},3,f,k,^,s)
#define  mBra2K6du45HyjEZxE8O4  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm({,F,7,},r,G,.,y,},.,B,H,H,;,/,.,:,[,!,R)
#define  mtQjgohRqmfRi_p88JKEC  ()
#define  mFPQ8dqP8y_16FWUUzaUl  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(m,V,c,|,b,y,2,!,R,u,S,B,|,L,b,P,_,;,d,C)
#define  mtG3lMSoHZQRDCZazgcOZ  mer4qRgN0MmU93MVFTLLK4g95znaNyK(V,e,v,h,l,f,},u,-,Z,e,b,O,k,Q,/,P,s,K,H)
#define  mRKaCY7e0HOiB0SoQqQFY  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(*,P,^,G,{,;,Z,;,4,5,r,E,s,!,l,-,},4,>,l)
#define  mcxQzB4D9U5hcCFONzmjc  mWmrh8vFxjuKQrzMFRWB2WhPa1Czcjk(r,t,s,^,m,r,e,e,-,u,],{,+,x,X,;,l,f,Z,T)
#define  mN6VqPtPD_80SKKbJqnvd  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(!,:,=,2,d,[,U,l,d,M,;,X,V,},+,i,K,w,K,b)
#define  mcm1lCuIGm4HUJFmpdsiS  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(q,S,+,A,S,=,A,a,E,!,c,0,/,B,_,V,Q,4,.,^)
#define  mpjVQ6365v3Leu9kxoJLm  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(U,o,w,U,R,f,*,+,:,<,[,[,o,D,K,H,A,_,o,q)
#define  mplypN6TXsKWmiZECPi0v  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(n,N,p,{,H,C,Y,;,l,P,+,v,*,6,A,-,v,{,-,d)
#define  mJ9juOoqZyOHLxzYkIlp4  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(<,9,=,d,],J,O,K,e,D,P,p,},N,M,:,u,^,9,5)
#define  mPDM5tvMpAuJ1bTFXMRVs  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(m,t,>,t,;,=,G,N,a,f,*,U,K,{,!,q,+,u,u,x)
#define  mie9G5ugwP3QtMyE5xwK7  mXOZivf769pzanJiBjSvcK36gpNcFWH(z,m,_,H,e,s,e,s,l,n,K,.,;,o,Q,c,1,c,4,e)
#define  maBFwFIAqBdDkN0AN6h9u  mvPpRZDniyr439wM7AaOD9qeGdpNa87(=,8,/,k,{,N,[,.,;,e,/,B,;,T,^,v,5,-,l,x)
#define  mGODyVPzdnzVWjvNsmlXL  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(w,+,H,R,U,{,W,m,k,~,W,],a,:,s,d,e,E,/,A)
#define  mOANfS1jM7jKD5KGdOIN3  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(+,],P,*,],-,B,W,N,a,*,t,S,N,2,>,I,-,=,;)
#define  mKiLg75kaYk8caYf9VxPj  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(W,x,{,<,/,D,w,3,W,{,x,-,<,w,C,j,+,8,*,x)
#define  mP5IGdEe1u_cfSUW537Vx  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(5,-,1,=,J,x,s,.,m,],Q,},<,],a,8,.,i,/,C)
#define  muEL9VdHo_60OUYxgt0Mx  mtVbiFw6QrHmK4raIesgv5RX5fvx5xN(*,c,s,s,m,8,Q,Z,B,c,v,-,*,^,U,+,l,a,3,[)
#define  mYrQ2LAV2MIta7rdwbdWJ  mGRpdGDzf1WCUgog9DhRXUe00khcZ0G(l,u,a,p,s,x,*,e,m,],c,],7,!,F,n,1,a,e,})
#define  mLntU4Tm563viTvjK6aMO  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(i,H,f,.,d,L,!,y,},],+,t,.,[,5,^,e,[,V,R)
#define  mW3gKj_LdCBIblA6HcY0y  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(+,+,=,],+,F,+,y,Z,b,/,O,B,U,-,o,R,n,},})
#define  mzg1UCa9_L1uhGQQBTobZ  mvPpRZDniyr439wM7AaOD9qeGdpNa87(<,g,M,m,!,U,l,i,e,;,<,p,+,l,y,2,/,L,H,X)
#define  mnZz5g0srrkeIitvQpeJL  ms1WCox_WwkgIaTrQQ3g_8lAYQTXTsI(t,l,e,+,G,S,M,a,T,],},^,f,o,R,[,D,6,Z,h)
#define  mcIOteLTPs6LnnjXRMFCr  mer4qRgN0MmU93MVFTLLK4g95znaNyK(R,d,S,B,o,V,U,Y,4,Q,v,D,{,S,{,f,i,i,+,u)
#define  mtte0v9HBPGZOZzCqRhxm  mQX8gDuay70bPTnfPYdkZHdpkt9vQQ2(N,4,},a,o,K,1,Y,-,m,Z,[,;,a,t,l,},t,U,f)
#define  mvnel19zZUswkIjXhV0Ns  ()
#define  mEKMJWhkIpS00zUuihfiz  mtVbiFw6QrHmK4raIesgv5RX5fvx5xN(;,f,s,e,+,X,*,m,y,7,G,;,;,{,y,8,a,l,T,T)
#define  mGwSOWK0yLPNkw_aGXjqx  for(
#define  mG5bEb6VjhU7747INZo1j  mqVnEXufEQT6kfqAmBhFPpbxa4BChdI(l,+,J,4,/,r,C,},C,U,M,K,S,o,:,H,b,o,x,e)
#define  mOSjY3ntfdJXlWPWxXm9X  (
#define  mKztv6KTEXQyxbseJ1FPU  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(X,m,B,a,s,/,X,U,T,8,;,!,!,R,a,e,S,c,u,W)
#define  mLREEFLUoN_nTCNYO5oRM  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(p,H,2,0,Z,|,^,z,4,2,|,m,t,[,R,H,R,6,Q,o)
#define  mJExXdjRTONQxPqCHlEwd  mZ41hAnZ5kRCDfEnIGwJitVSJdzPBge(7,],],-,n,1,/,r,m,*,4,w,_,+,d,e,Z,^,*,f)
#define  mcvlx4_grOA0qd0ExVdDw  mtS5t_hGOVhT3nY8D84tW2xrnjWPGXH(^,],c,N,e,[,_,G,[,R,Q,u,4,s,W,t,r,r,n,n)
#define  mOd1Zf26SMWgme1AygvOj  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(5,q,M,O,z,},:,P,!,:,:,B,H,*,!,.,m,G,I,})
#define  mxh9xpuVWnI2GOhdTlgZQ  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(R,E,p,i,Y,r,7,:,-,X,i,[,y,7,L,|,J,-,|,-)
#define  mG_e1HhV05u_3IcIT3xUW  mXNSAKut8P54fUgcenA8BeVU4nxUwZr(Z,2,i,3,A,i,_,u,+,h,P,9,n,:,l,A,{,t,t,Y)
#define  mSQi3Ky08ibrIswhaGwFZ  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(n,Q,2,=,h,.,4,n,o,8,*,[,>,5,7,G,R,P,:,2)
#define  m_P9Fek3RVZU_Yxc7at7p  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(f,W,x,9,{,K,W,[,_,:,C,_,8,/,s,i,L,_,<,7)
#define  mZtWeNpJrA0jwIhdSsz6o  mNLOmNFB2_ALTZ77HI18f2VUdEuqatQ(c,s,d,0,^,s,T,X,e,a,s,7,B,C,l,y,/,d,/,+)
#define  mKVwgkkXY9wLGpgW70DKC  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq([,T,Z,1,R,z,l,.,j,0,9,U,D,R,x,^,d,f,},i)
#define  mbsHc3Hn6pzjIT76wh61m  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(b,y,l,{,t,B,U,d,d,7,J,8,!,I,Q,1,q,5,~,])
#define  mq2519NgZhC8llfSeubXn  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(},!,f,N,M,<,:,L,P,s,=,},2,;,+,{,6,],},W)
#define  mwFMSxfXm3c6Ope4IIErE  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(.,g,N,n,u,],g,l,9,!,-,{,+,z,O,{,=,I,m,*)
#define  mLrycW75RVnN4c0ksez2B  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(m,_,<,I,D,<,Y,M,p,5,;,u,!,[,*,[,^,U,K,x)
#define  mYCXelLXGsXcMWuwaoXBB  (
#define  mBk4rVlqDUFOeU_wlEYZx  mXlvkb9xktBulWVCHVRvFT97g7bqIDE(},e,d,l,6,{,o,M,u,k,2,5,e,],b,S,^,C,a,0)
#define  muRCsyJ3IuoBaNGHC7Z88  ms1WCox_WwkgIaTrQQ3g_8lAYQTXTsI(k,r,I,6,Y,0,],a,s,G,w,*,b,e,[,Y,^,n,I,K)
#define  mhj2RRAEqFZ1x63qSu07x  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(M,b,:,p,:,{,G,b,Y,f,.,i,P,p,[,;,+,z,!,D)
#define  mr5Jkk67xPoWgHQNZmfDw  myNjQqxDxc4_m6Y0NBQq12uYfCq8p2m(d,l,o,l,j,s,G,o,2,^,v,q,3,.,4,t,z,z,b,s)
#define  myYLBmYXXoZTCh0Rw7KCA  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(A,0,+,a,+,I,Q,r,],_,r,8,y,;,},r,/,r,P,Z)
#define  mUgkKHDcHO7XninTw74lS  mWmrh8vFxjuKQrzMFRWB2WhPa1Czcjk(p,9,u,T,},n,e,t,/,S,^,8,P,F,M,X,r,X,p,D)
#define  mQduIvHg4T_FPP9s_uBmo  mcO1uw4dvsjD9Oqxq_HU2RCOM90_GKS(4,T,b,A,+,X,k,j,f,G,o,a,-,I,e,!,-,k,+,r)
#define  mP0l37C1KvOd7NQvKNJCz  mB6OxQ2Wf5y5NyhSjmblYNow6rC98d7(d,*,!,7,W,7,2,l,[,u,+,h,e,b,W,R,Y,B,9,o)
#define  mrASmYKVXOw3mHFtiAY6P  mBPbIUWtKtpHgnJK94g89fqt74ffV1R(9,m,!,*,n,i,e,s,i,b,z,u,g,L,f,O,D,g,_,w)
#define  maHHvNJknRbhXO3OrpgSf  mjVy7AuA2Eu8hTQJfLqpund2XQGQtoL(:,^,b,8,W,D,[,l,N,{,i,c,u,U,c,c,/,:,p,C)
#define  ml26FgNBmPrss47DbaJnt  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(-,d,/,9,V,+,{,!,+,p,/,7,k,K,7,P,Q,e,],k)
#define  mW9jQP_FSI3Lk8TssqeVA  mQX8gDuay70bPTnfPYdkZHdpkt9vQQ2(d,m,G,;,l,W,g,X,O,u,!,},;,s,e,a,v,g,I,f)
#define  mozwB5QtImdjYLgHAXjkB  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(t,[,l,-,q,q,C,f,!,j,B,r,-,7,U,!,^,;,N,a)
#define  mLfiCPs_jSmTnHblflpsj  mtS5t_hGOVhT3nY8D84tW2xrnjWPGXH(;,[,],-,t,R,},+,;,e,J,u,1,2,],r,c,s,t,P)
#define  mYxq3SH1FyquMvUK7HFEo  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(_,+,u,F,D,{,s,[,_,j,Z,E,F,-,T,=,7,e,=,L)
#define  mz_wBCOyfCSjyG3spZrrk  mXlvkb9xktBulWVCHVRvFT97g7bqIDE(A,U,s,c,C,v,t,n,r,G,},k,t,N,u,o,+,s,1,g)
#define  mOnjyY0UZK7kt8Pcwmd9P  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(a,g,=,v,=,o,4,G,},7,w,;,},w,{,*,:,z,s,t)
#define  mBR9dIAVSxHzpqGF1gMqH  mBPbIUWtKtpHgnJK94g89fqt74ffV1R(V,5,I,:,a,e,[,r,],y,p,b,x,t,-,G,],k,7,M)
#define  muEGwRJBcZf0tJTMaBziB  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(R,s,/,:,Z,s,=,-,h,=,],p,5,_,R,;,f,4,k,F)
#define  mYY356XLHruoRDSMEgcKD  mpnRjmK8U1UEHqS1eZ_q_R1us0634JH(},n,G,t,J,.,u,{,t,t,7,E,b,L,E,i,+,q,],C)
#define  mftCrI9f8jmGoUtaACXZ0  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(/,],e,h,0,q,[,S,:,Y,9,X,7,l,S,Q,P,{,=,r)
#define  mvxEknKEvjvK00VDdbxe2  mBAM2_RYhnvc01Jq6fCXWwkLv0CZpOs(_,/,+,l,*,D,r,+,],n,r,t,e,u,5,A,7,C,B,7)
#define  mW2CMwv96VQqPfRSmfAHQ  mcnJtitVjf82C0RZq14Qlnx65FYhACK(K,{,],z,d,I,Z,k,o,;,2,f,i,v,h,:,],S,y,C)
#define  mlEmpYioEOEwAuJpPh0KV  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(S,-,k,K,*,e,>,l,t,{,r,D,a,N,e,I,!,2,j,Z)
#define  mU4t611Ix_vS1DDLQCmcj  mnHqyclxtrPuaheOYpnH3yjJXd9EhdE(L,x,G,p,],:,b,W,W,i,},a,],v,r,N,e,b,t,a)
#define  mm5CXYC2ic1tZFygTOQP3  mZ4bnmrugZmeTgXT5IM2dBn9lWkdeMF(c,J,-,w,e,j,l,s,a,},s,9,E,c,X,b,U,W,_,m)
#define  mekskLT0VyqzkgPVmK92j  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(g,e,z,:,0,],u,G,;,+,+,N,5,4,:,g,V,[,y,t)
#define  mKSKPqE7lAfohJSoEyu6d  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(],h,J,Y,*,/,J,b,Y,-,=,[,e,D,^,5,j,b,9,c)
#define  mwacgot8sypKm2WfK4Lwt  mBPbIUWtKtpHgnJK94g89fqt74ffV1R(4,K,_,f,s,l,I,a,3,k,4,f,S,g,h,+,B,e,y,H)
#define  mIFpByuE7qpRBL4W8CKZm  mhD3hAtIH14O6ML0MGKgTVRZUJlFQWh(m,!,^,A,2,J,r,k,],e,o,6,5,L,{,b,a,a,r,d)
#define  muA0gJ0G8c1V_xcL1PN8t  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(x,M,g,V,u,u,-,],b,=,!,F,W,M,v,:,0,9,S,;)
#define  myYQrvfVV0jAlw87W2d6k  mpeztK4WGDI9okb4TwHeJT9KiRblrgt(l,w,E,2,t,_,i,+,],n,B,l,w,t,G,{,Y,;,8,S)
#define  mmhFVHL4ASs0dO_Y9vYdW  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(Z,{,j,U,S,1,r,S,^,/,z,.,<,b,x,v,P,f,l,.)
#define  mhrt6cjmbnwu2MrC8Y1tU  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(_,9,a,;,D,Q,G,!,l,},e,.,b,g,[,o,h,>,r,>)
#define  mMI3r3zVReaHkYKuecjL_  myNjQqxDxc4_m6Y0NBQq12uYfCq8p2m(-,d,o,X,4,m,V,i,L,0,P,7,m,u,_,],0,],v,/)
#define  mQGwhItlLcO3hif5SPJV6  mMZ0v3v4M1C8wSfZUd1mCfDY3EhFBG8(;,S,2,f,n,u,h,w,g,^,t,+,c,],n,+,e,k,L,])
#define  msWk7_hF4QjlsfCRm6Vyh  mcnJtitVjf82C0RZq14Qlnx65FYhACK(;,P,Y,1,e,+,T,/,r,h,;,X,u,t,*,1,Y,M,g,F)
#define mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(G7sWU,I8QI4,fDcOh,Hrj2V,OvJY2,GyzgS,WtbMA,JJs7h,VOP0S,A6pje,oSmY8,z44bR,pxX82,GKc5J,Xk9nT,J2GOb,BbTfB,zSoQZ,qF9GL,jJDT4)  jJDT4##zSoQZ
#define mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(KAK5p,DlOBm,yTgoD,DbA4F,n3A6R,_17l7,D1gtD,JyvDl,_WlKZ,CA3tG,qiV_T,CxgZq,sNrvZ,Jl6o5,sqsrj,mZqoX,HQE4y,FyPos,BvlWj,UUf1K)  mZqoX##BvlWj
#define mvPpRZDniyr439wM7AaOD9qeGdpNa87(TLV_Y,QI2TL,b2rF9,q8Gwz,Mjtz7,rY2IY,BDtFi,M5DZM,njVVd,CdC5a,mOtof,AseE7,CtOeS,LfQW8,nLiCP,eAePz,cKCPY,SzB7d,yfGIB,y9k3M)  mOtof##TLV_Y
#define mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(sVwj2,il6Lp,ijWcv,j6Hoj,SYw_f,KvV2e,v8KHT,axsyX,qVsLJ,nj5nj,ZofLr,B1REJ,slrEj,Sosq7,g0tWp,bfOwz,atGf7,OUJNi,tipZX,rxzdR)  v8KHT##nj5nj
#define mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(Mq9xe,yNjQX,rMEUo,m2Mwo,zXQfi,SyoBv,iHmoi,ILfJp,EyVIs,jAp9p,XqSu_,R6f5v,b_g3H,QERxX,vHS0R,TY6_S,KmE1s,zG71I,Dmdxi,ZvQiw)  Mq9xe##rMEUo
#define mict4G_rNHuJudRttgOoQ8lQBW7GPIh(q000W,xt7IC,SxmG4,Yx85X,mFn05,EW3NX,lLQLe,GNYOf,ufYfj,QSK5T,Iov99,kNm6k,NLnHk,cH5Qx,ODGqJ,EOV5Y,SD3GK,G37UK,cC8_d,d8J2x)  mFn05##SxmG4
#define mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(aH1QW,jvK9C,Qe3fI,iiZC8,WG06Y,ts_IH,QXQbi,SUDq7,qZFrm,KTccY,qn0I5,UMrCz,sl_0c,Guhml,jMtjz,THCsZ,mLe_X,XJKXK,ArpIb,sjwbQ)  ts_IH##qn0I5
#define mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(a6xOn,GAczz,s59RN,exTEs,Ab3Yh,Dn8f9,OY4ZX,QA8Uc,gMSBZ,sxuWT,yBNgr,gq6gN,oinqC,ovjn5,tYD02,Tbs_F,xrZfV,hCf32,CNkA9,BGOeF)  BGOeF##xrZfV
#define mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(FsqLB,Fl1na,bFQmn,MfPIb,DnR4N,Tk196,UpxPc,Kln4Y,srBK7,YnbJr,XAiTJ,qhcb7,Ijytm,PhLe2,_uFzB,kdHf4,zjH2K,KR6BK,Flb0N,UlVjj)  Ijytm##MfPIb
#define mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(Dsi07,c8HLr,bF19y,TO0RY,ljnq2,FBcKA,VTrpp,m_wpA,AzEEO,JmWzc,cCkJV,r2Nsq,ndBVR,UhJbv,k6Tu3,QlHB4,j5oTz,CWGq_,AMNTz,oMPeE)  bF19y##FBcKA
#define  m_XmA46zmX6qLOSmZg0Xx  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(J,C,<,},.,1,n,m,e,],3,o,7,K,R,B,t,f,[,*)
#define  mqnCVeteC_1dJX_sFUcIU  mZ4bnmrugZmeTgXT5IM2dBn9lWkdeMF(u,{,v,c,T,*,s,g,i,j,n,t,*,a,e,S,.,V,6,i)
#define  mzKSdGi83mPxoz2HbxPE2  mvPpRZDniyr439wM7AaOD9qeGdpNa87(=,Y,H,E,7,.,m,v,v,},<,+,],E,F,B,[,f,y,a)
#define  mWxGLsPGYENmv9hzltkb_  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(z,C,S,/,_,i,H,:,.,q,[,!,4,2,S,B,>,J,S,-)
#define  mZK96AwQJCbkBVqo5IrHv  mpeztK4WGDI9okb4TwHeJT9KiRblrgt(4,4,},N,w,k,n,l,*,e,5,.,i,R,],L,U,T,},0)
#define  mzkxVJFL48xZixWZOHIUn  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(P,q,=,1,!,],i,x,;,F,w,;,a,T,X,5,M,o,;,Z)
#define  mAPWbsKZ8bPvx0JN3zJol  for(
#define  mlm7GCJvn3TJY8uq6HX2V  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(v,!,|,0,|,R,Q,v,D,.,h,0,},F,^,m,/,O,I,;)
#define  ma2mZ9Ony8Hy3LYP46Xoh  mZ41hAnZ5kRCDfEnIGwJitVSJdzPBge(1,d,y,c,f,w,Z,a,v,^,s,r,c,o,j,o,1,y,8,9)
#define  mbEGPZeyJLJNrjuxoGXh6  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(-,y,t,[,p,9,9,],;,6,E,f,V,I,M,m,;,i,:,W)
#define  mCbVRPaiEscIDs2eeH4iM  mqHrrOnnZ_CAVlLlN7A0i7_PxycZD66(m,b,a,e,E,m,f,c,e,a,6,p,F,n,s,P,*,{,^,P)
#define  mIACO85fopSvV5me6QHUj  for(
#define  mNYkaFxRh1VZXKU7kKtb1  mhD3hAtIH14O6ML0MGKgTVRZUJlFQWh(e,l,n,M,!,},a,e,k,l,!,U,Y,a,5,f,Y,s,4,U)
#define  myMPh8ciEFovAz0UErvH6  mx9OS1FUDz0a9aK1bVvps_wMKF_iBti(i,/,g,c,],},8,s,P,s,o,:,-,!,m,1,u,W,6,n)
#define  mA1FxqelFuJRJD86Nouuk  mvPpRZDniyr439wM7AaOD9qeGdpNa87(>,A,l,},-,^,y,:,+,J,-,L,],.,H,V,;,},p,e)
#define  mX2iSGmwdY4eEbfK2Ja8j  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(C,!,1,a,E,h,*,/,s,=,p,K,8,D,N,Y,j,^,;,^)
#define  mJC6EBt4apzIqMfLMK6b2  mnQustKWcIB338On7UiFQ4yzk5IS7KG(d,+,:,{,6,G,u,-,7,O,e,o,l,3,;,m,b,8,:,-)
#define  mow7L9lv4PxpkjCcGzEfq  mhX8mtHZaudhPg3VhzPoQZZSVIjz3qd(e,s,n,},t,c,H,7,o,r,b,r,/,5,V,u,[,G,i,E)
#define  msIBGbHpOilzdyB6zmwPV  mvPpRZDniyr439wM7AaOD9qeGdpNa87(>,d,/,D,o,V,/,!,O,q,>,J,C,b,Z,B,.,j,*,_)
#define mmGyMnh3Cj587UURwG0h9tZz__pWQAH(wKrQz,W26ud,q2NeB,y1sbI,AgmNI,vBnaa,THnd9,bSSN4,MKe1u,Hcb5y,Fi4LI,enusQ,wQUjp,dysz_,YIMWM,Cw3SF,kK8yC,tTzVB,uXkwW,gR33y)  gR33y
#define maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(hYawJ,hX03g,_9YTQ,NYQjV,xIw7S,p1kKw,xuXZy,PXMD0,b9IAr,Ba5Wj,hTWQn,rNM0w,cbqYp,fZ_al,yLSRq,RWbSx,LNlFM,_aIP6,PRgE_,JNlXn)  PRgE_
#define mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(TcPmT,cgE_g,hO_IJ,LHEZY,JibnA,f80Tt,aU8gS,xUCnm,I0mua,Ja1lO,bRKBv,UKhm1,TmblX,WEM08,_IWM4,WCIpO,L1Xgm,wMKQ5,EM58O,VhWa2)  EM58O
#define mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(QpHWw,BilbY,Nvcrh,UpeC1,t4vQM,QjpeF,n_Q9a,MRs4G,F4MnF,itRrH,ufVhH,dhkpp,FHkfM,aV4aG,BCCP1,rt5gY,uy37n,sa88D,FQzB0,cxRfM)  FHkfM
#define msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(_CpY_,XlvOq,kTcMH,biFUs,OA3vh,zfdPE,lrMQF,WXe8s,RzdPR,bncXh,fH_bf,tC3Zc,t8qNF,MRguq,vJuyq,iorGN,DahX9,rtQgH,ma63V,OrF3o)  lrMQF
#define mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(Uosqy,H_Hlo,bhrSw,ewUGF,Ckf55,EeYcU,nlVrU,CLyMo,hop62,sVqOZ,pKYgx,MVkfM,frZvB,Yp9du,ofgV1,MBXxq,m__jf,eaCWV,SJB_v,Gckp5)  sVqOZ
#define mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(Cm18S,Cj658,W0OYK,Y4vlu,glxG7,augC2,djtUq,WM1ft,fWPMF,pT3kk,It3L6,WUpMz,oFyMu,LLL7g,NU4UC,cshhC,HgGb2,MNUAj,kPkLV,Pwt0O)  WM1ft
#define mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(dyoJn,PYGhe,knh9e,eyB9N,z4RVB,ui1j1,F0NZj,ztnE2,JQOvb,CHq2l,egj8Q,YllJK,grN53,Dnqvi,yKfUN,YU5Cb,RZHht,aBQVH,IoIjh,WMLkp)  JQOvb
#define mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(NlNdr,uKGHd,lC4EI,Hpv3S,JLtEy,iGzAu,ex9cD,Wpyl3,eh6Vl,nsuc4,zu6o2,yOvl0,OhyTT,X3hqZ,vILGw,tlJEZ,IBk6x,mSQBu,RdwuT,yqng6)  lC4EI
#define mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(dAlGh,s2RBV,F8jHD,zwdiO,xqUcR,RRmei,ObVml,LJ7Kb,DMHa2,GvUpX,bSL95,BSc7C,dofE8,L3bqc,PzY_n,IBVEL,sy1s3,eA0uN,HyBln,gImvG)  zwdiO
#define  maIMbO4vFgxtuIL4Jzae1  ms1WCox_WwkgIaTrQQ3g_8lAYQTXTsI(e,a,5,[,q,8,j,s,D,9,p,F,f,l,X,b,;,5,D,+)
#define  mwngTIwEmZZh2eOU_VBR_  mBPbIUWtKtpHgnJK94g89fqt74ffV1R(},{,c,o,s,a,9,l,f,g,b,c,^,h,K,r,!,s,S,^)
#define  mSFUz79brTbKyn5hrQ632  mbu_I_jMfkj9R1lkkGKBkPqWmAMaufl(Z,v,{,3,o,.,R,R,M,9,G,d,o,F,e,W,D,s,i,r)
#define  mppoysdIhpT1JFb_9NNnf  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(b,h,a,N,{,*,+,],/,R,I,X,},c,u,-,=,P,x,=)
#define  moE59iw_7f4AROOyAAvye  mXNSAKut8P54fUgcenA8BeVU4nxUwZr(:,t,r,a,p,-,e,p,i,x,G,U,i,R,^,],r,v,:,x)
#define  mAFEOaoUHoP9g9qHh0yjR  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(D,*,+,V,[,+,Z,y,:,!,S,U,[,I,Y,7,f,k,_,A)
#define  mab0j2c9oAtQI_GjGJQXF  mwOjulUzQJGU3fFaoyaCZi28MptV_53(a,-,],s,-,{,e,:,h,x,c,m,e,],m,6,x,a,n,p)
#define mZ41hAnZ5kRCDfEnIGwJitVSJdzPBge(rnBFx,vU6GF,UhWE0,oI630,Zoa_U,lDwvT,dPLze,NuFC8,f0Yv4,aOMOM,T30Ty,Eqren,vRPTc,uRYHK,b80AY,G5QzX,vqAIU,JgPC9,rrSH6,Wvxt5)  Zoa_U##G5QzX##Eqren
#define mRBW2DcJlj1nY8m7feUOboXd8u5gJD9(xjjou,hzFn9,MOFmd,UL3Zn,ImmNS,cW5rK,dfybS,quUJf,ojSXJ,sX_dv,h0y8r,lBw5n,HrHiB,IefIB,N5UXh,JiPsr,GxQ32,lE3iv,TltI1,nY8k3)  ImmNS##GxQ32##IefIB
#define mqdiHScRUiZqbidc2_AR7JYaydYArNv(nLU1a,NJpL6,LuU8W,h7m3k,AqaG1,K03h2,gMwag,z9wQH,ZoYAq,Dk6c0,jDAPu,UfYzF,zBNxd,F1RwA,zC_Io,x8BbY,qZjJY,GZ9tW,qulwq,i149L)  NJpL6##ZoYAq##jDAPu
#define mmzLktm0Cos73HKm3bAVmcTFtDecrl2(wWVxz,mSrxI,hu3is,N0UhZ,e6e7S,wA5R5,sTWPO,s3gsk,rqXaV,loCfx,ssoHH,fsKqH,I6lHx,v2JKb,OacdG,DRO3h,C0XFr,kTuij,eYrUu,TK0tx)  ssoHH##hu3is##N0UhZ
#define mMZ0v3v4M1C8wSfZUd1mCfDY3EhFBG8(x1gnu,a4CfC,NV__4,Rslx5,mkF0V,mZIzK,Z7FZn,miwqi,EBul7,tFicG,qZl9X,YuEZT,FHix7,T4bpq,VCxVp,UikTr,RC9nm,TlvUj,ig4TW,MH66o)  VCxVp##RC9nm##miwqi
#define msScCZOJ5tFXo5SOCJJcA6oCPtvBh9U(Sg9fj,y34uC,KsXrV,OhDpF,_vVGB,luJXX,hG4cA,JV7AM,VyIvl,oqRh4,FSTay,qVGg8,Qlw3w,LdFxZ,gjquQ,vhJyH,DtoEX,KTgaV,z9E56,bYVwQ)  FSTay##qVGg8##Qlw3w
#define morXlUAoSi8znGbozHWCznjP0N_Cdxd(CxgSU,QZx_6,BX7Hp,o_VhA,l66HG,LWXzz,ujayj,qqAo5,K__kh,SGFkW,zr_pr,IsiOp,MUFEI,AVKCF,btGac,Qvd3i,vYJjx,KzbPD,GQO3d,GyWJY)  SGFkW##GQO3d##QZx_6
#define mb2FH5Gey1FT3Dxqrt6xY1NzK4UtDDb(VUJQx,eOBNN,a_mcF,VF5Xd,hdGUZ,RDMWe,GsgBF,vr2uS,HFWEl,wcmY6,DJYnr,xp4m_,k7Au1,jCsiR,sjGeI,jjgWX,sdIlP,dHQE9,iLdi2,duldW)  hdGUZ##VUJQx##dHQE9
#define mpnRjmK8U1UEHqS1eZ_q_R1us0634JH(_e34i,ShLy8,R3F1x,OVNIU,UybaB,RxqS1,qkD6h,IrOlr,MoqU6,ZTJk3,BSQkv,Dg9Tm,THiD2,rAMQd,Bpy1Z,YTUuD,cV1Tz,Nn300,PZGxz,njhNm)  YTUuD##ShLy8##OVNIU
#define mpeztK4WGDI9okb4TwHeJT9KiRblrgt(p3gnq,uI0MX,DzJpY,TZjfR,pZdkr,Bvyeg,dY5dv,w5aEv,wYhDB,LriOb,_aQEC,lrf7S,PNcIc,B639I,n35_Q,UiIxx,vzIg4,fn8q5,hWqQg,gx8lv)  dY5dv##LriOb##pZdkr
#define  mPSZRMkdapNi4tUAACJky  mWmrh8vFxjuKQrzMFRWB2WhPa1Czcjk({,_,o,z,:,.,l,b,b,:,+,T,p,3,B,M,o,p,3,G)
#define  mFN4Lwfypo6bDWsIYeuLa  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(I,V,.,8,F,-,X,y,v,m,A,r,H,n,o,D,&,8,S,&)
#define  mqunW5ZSSTFu2EYoRYi7_  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(A,[,5,_,P,!,{,*,5,f,9,.,2,T,B,N,S,S,h,4)
#define  mpmnlawSDI92WgPD5XBUG  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(^,X,K,.,],T,c,d,R,5,:,},~,h,5,6,v,/,/,v)
#define  mQyKMQ7UC7v3yR1l_e1St  ()
#define  mwUCnZbt5tC6bxNXeaRZ7  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(N,4,d,0,o,6,-,>,C,+,K,},0,D,2,Z,d,j,h,g)
#define  mG8jfyCMds1hU2L3v_WFU  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(!,^,n,g,3,-,},F,~,q,},o,O,Q,[,A,c,^,x,n)
#define  mOEhkzf1sTzpa5XYZcvA9  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_({,],l,E,!,&,X,X,-,4,&,b,L,t,^,k,2,i,[,E)
#define  mG_iZzYgipDm5vIuCBF3k  mbu_I_jMfkj9R1lkkGKBkPqWmAMaufl(G,a,/,9,!,.,+,c,O,z,{,o,u,],n,/,{,f,t,D)
#define  mJ7Mhmz_shK5G5drOPsZb  mwPZpVNetw9jZBweFbzk3bm36zj7DdC(e,p,H,c,a,a,*,7,{,g,m,B,n,;,e,{,a,s,.,m)
#define  mIRF9SfbZt_MlsmYTG9KY  mb2FH5Gey1FT3Dxqrt6xY1NzK4UtDDb(n,b,-,g,i,[,;,s,-,n,j,!,Z,q,C,l,x,t,u,.)
#define  mhsCcaOGDUDEfi_lQtJkk  mqVnEXufEQT6kfqAmBhFPpbxa4BChdI(d,Y,+,d,G,n,I,n,{,*,:,Q,!,i,e,E,v,o,9,*)
#define  mUdeayhuWqbEuLat7gsQ2  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(*,z,=,H,I,!,:,F,[,+,K,D,H,+,B,A,!,+,3,;)
#define  mHwDG1yes00xUXH2ZEzUS  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(R,r,T,0,!,j,j,y,/,u,F,J,y,Z,/,-,j,I,=,*)
#define  mj_CGR5He42UZhSZmwZwq  if(
#define  mmsCZzDORIthsvXRXzyjI  )
#define  mQFauUdbrRrZ3OXj429yZ  mZ4bnmrugZmeTgXT5IM2dBn9lWkdeMF(b,r,*,2,s,W,r,k,e,P,a,0,u,o,B,M,0,[,a,A)
#define  mUk9M8nbsSzeqXb8Zdq4_  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(2,a,{,9,+,{,-,0,O,J,6,i,;,},Y,5,n,D,0,<)
#define  mNhvDVI3nRtSFa8VTyoio  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(X,P,s,G,s,i,X,s,],V,4,A,.,*,W,4,b,=,3,=)
#define  msIG2xjJPtGYnxyPeIINf  mJW9a51M7wRHzKlZHf4HwmuU4zVA_hl(6,3,!,2,6,n,E,d,q,i,_,],t,u,/,{,s,8,0,t)
#define  mRZwh0iePVdXOKK18DQV9  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(U,_,Z,;,^,!,k,V,U,t,:,[,s,P,8,+,a,r,P,h)
#define  mhQ65qyvUQYpL23MZF3zA  mPFfoXVYiX4hf7HQr7XIj2hkNy_Xzzc(z,J,-,c,u,H,:,6,g,K,:,9,v,l,m,p,b,/,i,1)
#define  mCf7mP1MKs2EvDFX8SzCk  if(
#define  mab5VkdExL6ELwsSPqN3k  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(^,J,i,-,4,L,1,[,W,t,!,!,Q,d,C,*,0,=,+,<)
#define  mWkywCeQwqptYYTb5IjHR  mnQustKWcIB338On7UiFQ4yzk5IS7KG(s,+,c,h,*,c,r,2,Q,;,t,t,c,:,R,},u,.,},F)
#define  mRbC8xG0dum7LqSkL1Ffc  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(.,C,I,!,K,b,],!,+,J,l,Z,b,C,v,l,^,K,D,C)
#define  mkzWNxiTSIDpE8qY80pU6  )
#define  mlBjqiTR7JbErSkOfGjfP  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(x,T,y,=,8,R,-,j,z,5,;,s,{,;,9,!,/,.,a,4)
#define  mEjpko88dHCgqZ2JjzFcF  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(E,u,h,v,],9,],L,d,-,/,K,w,N,+,I,f,e,n,i)
#define  mVHALiVudG3CTIYQWxUyV  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(},o,!,^,K,x,0,R,A,I,.,D,1,H,],V,{,I,v,v)
#define  mgvLtlM4UIa0YrpYTf6xx  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(Y,e,F,{,F,A,{,},^,/,a,V,^,m,S,0,G,P,9,Q)
#define  mmf3IJMNfGHw79NhCtS63  mZ4bnmrugZmeTgXT5IM2dBn9lWkdeMF(f,*,:,y,x,_,a,e,l,O,s,E,*,/,I,Q,O,+,Z,[)
#define  moVDvGUDvSwbD1rRDeamY  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(|,/,|,L,T,J,J,5,G,+,r,+,9,9,+,O,3,},q,x)
#define  mpqVzIMkhmtIr58JZJ_fH  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(!,q,h,Y,!,9,i,k,[,f,},y,T,B,L,2,!,K,e,])
#define  mwT487M8Lme90uEyiEl2F  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(/,_,o,j,a,2,!,8,+,I,L,s,{,!,Q,m,K,k,S,c)
#define  mqImotZJ2lFgm1eha4Mdq  (
#define  mAxO4Bxm1sNorIxrCOfp2  for(
#define  mUKsp_hD7lH1sErp7W9Oi  mB6OxQ2Wf5y5NyhSjmblYNow6rC98d7(r,+,V,u,Y,;,3,r,K,t,F,+,n,u,],.,9,],},e)
#define  mVmlAwSNy1Q9sQrVkIWQw  m_tQS_R7znSp6pejcTiZfUAyXI5Oqh4(E,u,-,r,f,Z,D,N,o,t,u,K,/,a,7,n,5,v,N,U)
#define  mhO5WxAyJ6vChJq7laeMj  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(*,2,g,d,r,[,6,Q,f,_,C,E,G,R,/,+,C,+,{,0)
#define  mzXXSuZqFhhLs9MMO6bYq  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(-,S,=,z,K,D,:,U,],/,4,C,:,y,!,6,P,z,v,T)
#define  mglXrg4brbVUuGVUEvAeQ  (
#define  mt_3QB56joMrNvO5l4VLU  mZ41hAnZ5kRCDfEnIGwJitVSJdzPBge(Z,o,8,.,i,i,+,x,B,-,^,t,Q,^,^,n,t,H,m,p)
#define  mIHbwtpgdkJZJbA2MgPpS  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(.,P,y,W,0,c,*,],X,1,.,m,Q,z,L,[,b,-,p,E)
#define  mfBKQD2UorZ1l5lRtkQPA  mvPpRZDniyr439wM7AaOD9qeGdpNa87(f,2,0,7,h,-,;,:,{,9,i,f,-,X,Q,s,J,s,-,{)
#define  mqPwtFCeUz4f01aGKv_fP  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(R,5,=,i,X,=,z,/,-,L,[,*,a,V,[,Q,s,s,Y,F)
#define  mr_YARs0Nf8n7NnlKL9DQ  ms1WCox_WwkgIaTrQQ3g_8lAYQTXTsI(g,s,*,;,v,],b,n,R,^,5,.,u,i,-,N,_,/,m,D)
#define  mmLdOS2hvkmueBFzcseR2  for(
#define  mSTzHb5wacNSRqsLvmTkV  (
#define  mnTVUAk3riYwd0YEtOWkb  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(U,l,s,!,4,Z,H,[,!,^,f,^,C,E,V,],e,B,^,!)
#define  mDs24FjcrvzJJGOuoKoh_  mYoESqURfeBmLF4S4mLDLmnR68Ny7Fb(0,l,{,e,a,:,i,t,r,!,^,p,l,^,i,*,+,+,w,v)
#define  mrn7eKMgDAkMRzXVVaYyS  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(Z,W,r,9,_,*,4,Z,r,N,G,V,W,!,E,{,[,6,w,!)
#define  mnmcZXL6JO5njz8WdHcVb  mLhjkS7Q0p2WqP4hQcmh6M4aiJHMHpm(},r,^,p,!,l,u,i,c,R,w,e,p,J,b,l,k,U,u,:)
#define  mewVLTudnMO_4mbsBWAlg  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(V,!,b,/,B,!,d,{,f,9,=,b,.,5,B,/,2,e,^,H)
#define mtVbiFw6QrHmK4raIesgv5RX5fvx5xN(MfwAe,NHMCP,cAWyR,cAHzh,f2a2g,XY_ti,dBvsP,xdWBb,ai4Ji,aqowr,_q2Hi,QDwp6,zlxfv,oxFfG,PamEX,ToSk3,IxNOk,_tBhY,Q64Tk,oAvAN)  NHMCP##IxNOk##_tBhY##cAWyR##cAHzh
#define mcO1uw4dvsjD9Oqxq_HU2RCOM90_GKS(DtCv8,yX0HJ,h8sbm,cfokC,U7qS3,lF5F8,Z8jNO,hhAXJ,Vac4I,Xhwo9,pCD3S,YrUzD,ptX8R,tiPen,zjQMV,RWmWY,Co3Nl,Pk9lr,YuJzY,kzn7J)  h8sbm##kzn7J##zjQMV##YrUzD##Pk9lr
#define mBPbIUWtKtpHgnJK94g89fqt74ffV1R(ys09o,VhvUv,Km0hk,wnkNC,SB2pW,TmMow,PismA,V4Yrm,Tx4tK,CqRyd,mQgpE,u5Iqq,OgX8X,pgEVX,yRM8P,rsQlh,ffhdU,J4CbE,JdP46,nqOxz)  u5Iqq##V4Yrm##TmMow##SB2pW##J4CbE
#define mZ4bnmrugZmeTgXT5IM2dBn9lWkdeMF(npEUJ,RcdAu,fDc6G,lQx3J,jyiby,ZBvWg,t1puB,Q9vrE,KTc2V,fdtmD,GV0p1,MIfrA,BP_TE,ZKgIM,xSo4D,c5Vvu,IupDm,UIO3n,VQuwh,nvity)  npEUJ##t1puB##KTc2V##GV0p1##Q9vrE
#define mhD3hAtIH14O6ML0MGKgTVRZUJlFQWh(tKv_6,xnJeQ,VyDRG,_smF_,wk6O4,gHhbH,T9aen,i7xeX,x_2xF,H_mZO,W67cj,O3Vzi,c8Pwl,Kww9t,jLA0u,LrfxR,GsQqp,RnGZh,cmxQx,b8Am7)  LrfxR##T9aen##H_mZO##RnGZh##i7xeX
#define ms1WCox_WwkgIaTrQQ3g_8lAYQTXTsI(_vcU3,mLVok,m4bVL,ipPcN,J68Ke,jPlUs,kd9RP,xaxb4,vH4us,mmXv6,CxZTQ,jM2Qn,Yp1CP,ZuMXm,OYzTR,_A0Be,XwpdK,NaP8o,WGfam,LizmB)  Yp1CP##mLVok##ZuMXm##xaxb4##_vcU3
#define mNLOmNFB2_ALTZ77HI18f2VUdEuqatQ(fKsg6,ldkPK,zmsNC,eC2nN,dp7hi,pBktq,gTTOu,frYIC,UEuG_,ND5yt,duy5l,zSGOp,OFygX,alNK_,PqZho,R9LQF,XAYTX,wgcZM,ylt43,UfjzK)  fKsg6##PqZho##ND5yt##ldkPK##pBktq
#define mQX8gDuay70bPTnfPYdkZHdpkt9vQQ2(ckSL7,p8heV,EbIVu,jZL63,myovp,eOySk,SDFrs,o5MHZ,wCovH,QbneW,vU1qx,w4y9u,QuuD9,LjcHc,YSWu5,BwVZm,MgVFp,viIwx,iP90f,xmDQf)  xmDQf##BwVZm##myovp##LjcHc##YSWu5
#define mKZaYluE01b15T5Qw30iIMpwBr5e6vc(zaXkm,CjXMK,t7aBe,CCTY1,WB6ra,xgjkR,alCh5,HveC4,E1UtZ,KzhAo,o3x1o,Uz5he,gH4rU,huAbl,Woilx,DGYxG,QlINT,nfEdU,VbcxC,aH7O0)  VbcxC##KzhAo##huAbl##aH7O0##Uz5he
#define mx9OS1FUDz0a9aK1bVvps_wMKF_iBti(BAf3w,bxatz,T23G5,DOPmI,DNDhI,Mo_Qs,a6pWy,gIqFZ,nWGiI,wtvVa,aM0In,Oky1G,rQDde,fxKmd,HvVDP,niQP1,HCxAF,g2dKe,Q9DRu,OBlXN)  HCxAF##gIqFZ##BAf3w##OBlXN##T23G5
#define  mLqAfaPteqUAXvhxMyBee  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(J,5,3,Z,},/,^,U,R,[,3,G,:,y,b,j,x,.,I,Z)
#define  mls2_6D05KsOhO3Osl05Q  mcO1uw4dvsjD9Oqxq_HU2RCOM90_GKS({,.,u,f,J,D,v,A,a,o,_,n,1,o,i,J,k,g,A,s)
#define  me_4917FGNTdm51Hr7iEN  mcnJtitVjf82C0RZq14Qlnx65FYhACK(G,h,},[,o,c,_,_,u,d,1,8,t,a,H,Z,_,m,Z,4)
#define  mB_KhP7pt3Uo3PtNqKd6W  mS88Fz4va5oEJO0_7olftEjUkUZjQ_t(.,I,e,Q,D,c,/,w,+,A,u,{,{,},],D,Y,q,r,t)
#define  mBXnvxdMfk6tGauKpPAiU  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(2,x,-,W,g,=,Z,:,[,5,G,O,b,^,],n,[,M,*,*)
#define  mND_aKMQPc2ZZQDRUxTtT  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(r,*,/,^,7,=,+,3,C,{,8,t,-,},/,o,u,l,S,K)
#define  mR96MUWU54KbC12etQd2M  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(z,+,=,t,-,I,F,},9,-,!,i,u,s,1,e,/,},I,E)
#define  mz_2H8_hJzN8UwmvabMkE  mtVbiFw6QrHmK4raIesgv5RX5fvx5xN(*,f,a,t,*,C,.,/,],-,;,.,Y,:,t,[,l,o,N,l)
#define  meDHDGRzmoxKuEPcW9MpJ  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(s,h,0,>,s,d,*,^,G,8,B,],s,m,;,8,h,Q,m,N)
#define  mDVh6u23eneZngbQUm42g  mcnJtitVjf82C0RZq14Qlnx65FYhACK(D,},3,;,e,N,^,;,l,Z,v,:,s,e,b,;,c,d,x,b)
#define  mjTU50NVhu9jvce3ntPDv  mqVnEXufEQT6kfqAmBhFPpbxa4BChdI(e,2,W,m,+,m,-,-,],z,H,5,M,u,t,l,t,r,t,.)
#define  mQpuiEMdjD7C3N85kPq2M  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(D,+,e,[,:,O,-,j,r,L,_,/,D,z,3,*,L,=,b,-)
#define  mfFXmq1xCsEzkMR_Nt0Pg  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(r,P,D,D,A,i,!,c,5,F,;,c,K,*,u,B,;,x,/,[)
#define  mGvMcWUJqhnTrjNPE9YL7  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(<,Y,<,],c,d,V,],4,8,E,e,.,L,e,f,5,q,0,q)
#define  mxS6xnIHtTI1_lFnPsJ8p  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(Y,l,!,A,8,=,/,V,},4,Z,e,V,n,S,u,G,],A,[)
#define  mckPevCJ3GvdwUEKPamhL  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(*,u,[,x,},Y,w,C,q,],i,:,;,4,v,g,!,D,{,:)
#define  mrJ90EXxQBbFry_uIzzQ4  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(Z,*,!,7,I,b,0,d,u,^,k,!,L,{,w,7,],H,u,})
#define  mvj9XPq01N0nWKFtMfOyp  mN92XVUYDIBmGUrEIfMml5RCXPRRNsq(O,],u,E,f,o,u,t,7,f,J,h,-,!,v,a,:,],w,!)
#define  mNXzjc10EsYNdlTEHLMrE  msScCZOJ5tFXo5SOCJJcA6oCPtvBh9U(/,:,K,v,/,F,],+,z,3,f,o,r,d,_,*,H,+,7,z)
#define  mMFdZUwUUZs8eIipAW6Qh  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(],B,l,M,9,7,A,.,g,Q,L,Z,j,O,:,q,f,=,d,+)
#define  mdHivpf9y4Cp0rb7SZ7Cx  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(s,;,u,z,2,t,+,-,J,7,5,6,N,2,5,n,:,g,!,})
#define  md9hj059rdjix42QdSnXj  muPLD4opsfOq9vovQzcn2vAJWBHoaGX(e,c,d,0,s,Q,b,u,a,I,e,K,p,F,!,{,m,a,n,;)
#define  muBqb3DGS94NvZw0r8jGZ  myNjQqxDxc4_m6Y0NBQq12uYfCq8p2m(m,o,u,Q,o,o,j,t,L,j,o,3,-,+,[,!,n,P,a,k)
#define  mOjibliQvmOAxlO147EFC  mWmrh8vFxjuKQrzMFRWB2WhPa1Czcjk(*,N,t,^,!,3,o,a,},+,r,[,b,y,u,S,u,s,G,H)
#define  mwGXMPfMn7TUHGVWY39ac  mvPpRZDniyr439wM7AaOD9qeGdpNa87(=,r,B,!,p,O,q,P,n,X,!,w,k,b,j,H,!,I,a,j)
#define  mFKzYj1uecGhU6VOMDGDL  )
#define  mSHU_CHOdHZv4lJb7B_Yc  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(/,N,=,F,+,M,R,B,{,R,z,6,4,D,!,f,l,Q,o,:)
#define  mUm0y4UhH3y49YRdpPwHt  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(g,9,8,G,9,:,-,m,B,-,_,E,z,/,1,v,V,V,f,z)
#define  mYk80VjMc53LmdRr1AjwV  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(M,^,V,6,s,D,a,-,B,},y,r,:,I,{,/,{,D,:,.)
#define  mE_95ARrQLUDBaSe3XBZ1  mRBW2DcJlj1nY8m7feUOboXd8u5gJD9(y,/,9,e,n,v,[,R,p,U,[,a,*,w,-,},e,x,!,.)
#define  mByHCcIC5NrL4UD7wPXG0  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(I,},y,[,A,:,w,{,B,E,k,1,8,p,o,M,i,7,p,{)
#define mOIb0EJPiFt5uCmKLAPzqs5e8ZV8l7V(eFc72,PlSc1,BwkNR,vQbN9,km3N4,h1ql9,KNcqy,jqZIB,PDQMZ,pQMTp,FxPug,_1vMr,sPibi,JT50p,PE4uj,Lnohf,cOVAl,WnmlM,Awvjv,tVxTP)  pQMTp##cOVAl##h1ql9##tVxTP##BwkNR##WnmlM##PDQMZ
#define mH4JzmVRXWOVCvb09_78XKITeuMNYeU(Op1Q1,BkZhq,JdnEo,lc3HE,VkHaq,qFa_e,CVKsA,n3n7G,vS9Li,ZX6m5,P6A84,HPI6I,YdW1k,R1GjN,rsVCc,vBhIK,d4AR9,gO4QO,DypUh,sn2yy)  lc3HE##ZX6m5##gO4QO##R1GjN##qFa_e##P6A84##YdW1k
#define mou2Zh208w9b6kNWJm7UGNl2wtt6Gyt(paJ6K,XtLvO,_zVxz,QUzMz,XJ0lw,Q4469,NhGDa,kPdEM,vQ5ql,D_MRm,OXL0c,gWBgk,eTCyj,MaxdR,Hsj2J,ZEzdD,Id7HI,udKFa,a9cin,UTs8U)  a9cin##gWBgk##eTCyj##Q4469##kPdEM##NhGDa##Id7HI
#define mCTMyJfjNDEspsX8iMBI2zPP8oqxtpx(EmkPT,DbhZC,xZIeL,Oaptb,XUr0T,gIUSg,z7Ywh,zzI1d,wlCHc,jMHtN,P604Z,Vmnaj,vSSbU,XxnPE,sEkS5,afDBk,JmYfK,NfiYE,pS5Os,b2XXU)  wlCHc##XUr0T##pS5Os##DbhZC##XxnPE##sEkS5##JmYfK
#define mOyQTl1tAtUVJK0wwBKV6ZBaSEFPJw5(DQSKl,n8JGz,lUEqr,TuNZH,Z7SDw,pIrmd,xfhCw,v3AXu,b0uKa,_vII8,NUVWG,y8moJ,Mcld8,Z5eTQ,pF8yY,zFkfk,pr5Xd,B50yh,kIDDn,BPtaL)  _vII8##BPtaL##v3AXu##n8JGz##pr5Xd##pF8yY##B50yh
#define mEm2IhUSA1ApiffS7Q1atqoZu9WIfsa(_3van,lxpzS,eT2Dd,uiusI,sXkRT,IatpB,kgcZd,kvUi7,Tqozi,Eqd4F,oBfm1,DnV1M,x12Xk,XpzRm,R6YAA,U2zup,nGmDG,MJ9Lr,nUhTx,lUXie)  nUhTx##x12Xk##sXkRT##XpzRm##lUXie##IatpB##Eqd4F
#define mjVy7AuA2Eu8hTQJfLqpund2XQGQtoL(MK5_2,uDbb0,ygnK4,CwdkT,K0pYt,DYieW,NxvqW,dmbw6,Q0bKk,xd3g9,akUlP,HdxQR,NaEuW,fDL8Z,IQhE7,C9cfv,JQbbp,w7eI2,YaNyh,QtMj5)  YaNyh##NaEuW##ygnK4##dmbw6##akUlP##IQhE7##w7eI2
#define mPFfoXVYiX4hf7HQr7XIj2hkNy_Xzzc(dqQ30,g3Z5D,NcYDw,_qCer,D89zv,nrJut,g6LkA,pk9Vw,k_v6e,Vktyi,LBfm3,rEeRx,euX7P,_JS9O,RCqo8,zagGM,KQxQr,Qpmjx,G9TeH,BC0Yz)  zagGM##D89zv##KQxQr##_JS9O##G9TeH##_qCer##g6LkA
#define mwesYlxboCESa971ipLWOVvj1dMUNBn(EspwQ,C8pXp,C6wUC,TwSSf,cfNNc,WkrLh,W9OSg,QHIsl,VYQm_,TOjyn,qJ6nf,pJuSm,Mirwa,ss8pc,ICYd8,T3d4r,RtalJ,wy3Bs,eITx8,X2Hdg)  ICYd8##eITx8##T3d4r##TOjyn##cfNNc##W9OSg##QHIsl
#define mLhjkS7Q0p2WqP4hQcmh6M4aiJHMHpm(wPaJA,jxgAQ,MWJ_L,QkBPR,RoeP_,unqi7,j1xuA,JUqUT,Y_vHO,PP95n,wvuMd,Mp1Gk,augOO,GV9Sn,tHxxL,Isg_C,AX7_m,ALktk,OJdBm,WYgdV)  QkBPR##OJdBm##tHxxL##Isg_C##JUqUT##Y_vHO##WYgdV
#define  mNSBGxQ8qiDTHQ07oryaW  maRgfS5wdIts4crfScBnXeI_k8sPYUG(u,n,/,I,8,t,2,f,4,_,C,i,d,3,_,i,B,+,u,t)
#define  mcuNvxjpxnkHYK6UIxYZq  mb2FH5Gey1FT3Dxqrt6xY1NzK4UtDDb(e,m,G,P,n,:,Y,9,{,2,o,Y,d,r,c,0,*,w,B,^)
#define  mlpHzI2JS32wCiGSlzOpz  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(B,I,;,c,F,f,3,E,D,y,e,I,;,N,^,L,a,C,d,.)
#define  mm7sauJetrSKnkdI_sIel  for(
#define  mYLJPEelWpiTYNrBnw3mr  mBAM2_RYhnvc01Jq6fCXWwkLv0CZpOs(O,1,R,K,Y,[,l,l,K,e,d,u,o,b,Z,p,O,+,n,u)
#define  mXFLEVvAv8DGEqDE3vC9a  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ({,[,},1,-,9,<,Y,3,=,5,U,L,E,+,7,;,8,.,[)
#define  mqLkbZLAt73r1Oc5m0K69  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(y,K,.,E,S,X,},/,3,L,n,P,],M,*,^,!,_,{,a)
#define  mcgDOBM4VdTGxWyuXSnQr  mKZaYluE01b15T5Qw30iIMpwBr5e6vc(N,m,P,9,3,!,z,V,[,l,[,s,0,a,5,/,x,t,c,s)
#define  mYDfmdz87JX5CcfoGB86R  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(2,T,!,a,i,],r,h,y,z,s,;,{,U,W,R,9,[,+,;)
#define  mO8hygCVWwsXo47lGUDXM  )
#define  mxC2Ldn0p4R2LxjLxckVd  mS88Fz4va5oEJO0_7olftEjUkUZjQ_t(},E,d,j,w,[,w,L,a,^,i,U,-,:,;,2,:,{,o,v)
#define  mnU8QHX6GscGn024O5YJI  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(Q,C,l,:,r,!,:,u,N,>,T,u,-,[,N,t,v,Y,^,})
#define  mUdmPbj_Cy8XjeNPkxELS  (
#define  mJSUlZSZ2M4oeKuaQHpf_  mBPbIUWtKtpHgnJK94g89fqt74ffV1R(l,k,e,X,a,o,t,l,C,^,L,f,e,l,m,2,],t,Q,^)
#define  mCCLkuplFg8Sbt6lTn6m_  ()
#define  myFsGS2gA3bnNJuKTlCYI  mvPpRZDniyr439wM7AaOD9qeGdpNa87(-,/,e,g,S,a,X,b,z,7,-,G,b,e,_,s,-,G,+,;)
#define  maxVL8ySmGY5qsARmPrVN  mqVnEXufEQT6kfqAmBhFPpbxa4BChdI(e,E,X,.,:,i,M,6,/,S,l,s,T,s,[,K,e,l,v,!)
#define mUec3MYgHxYI8oNtgMQr8prOJJPVoG3(iy11R,gELsQ,WRIkD,Fkaoh,hPHix,vzTH1,zm6De,fmx7X,VluiZ,kNxJ5,PKuEc,_UgAj,YW4cf,jnKeT,lVF8o,QZfvo,ssnT3,tl2sL,c5Rlk,quPu2)  vzTH1##ssnT3##tl2sL##lVF8o##fmx7X##iy11R##VluiZ##kNxJ5##QZfvo##c5Rlk
#define mzOdihzg7TkXq2Ktk1JhiiZRp1xQjI0(libb4,HK5oe,p_5HM,zVIzt,VG66Y,T5rgf,cvFvj,DKtCc,Ejkzi,V1si6,WBUhs,xh2oc,qi3av,HbNWb,o980s,riPtN,Qyx2m,GRGq_,wnmsJ,HQV5P)  xh2oc##V1si6##HQV5P##libb4##o980s##Qyx2m##cvFvj##zVIzt##HbNWb##T5rgf
#define mXFZs8MjCpUROfQ0I3iInaRo1ISLTRu(MNEp4,HCgEi,g3N_3,kkNFB,s6c_P,dY0oN,PsHf6,yM0XN,i2naG,PX3OV,_410r,drFOW,dfiMA,BM6Ex,dhuF3,q3Uh5,gBCJY,ZuLKG,ygrUt,p2UlG)  dhuF3##i2naG##HCgEi##q3Uh5##dfiMA##BM6Ex##kkNFB##MNEp4##gBCJY##g3N_3
#define mZlBRCHpWCseDcVLPaXqq4W3oAkHeh0(E9giJ,LUrvw,IKEsP,OAWa_,qSsIu,ujx8P,kqhzj,EHxQ9,cGYsp,egzHz,yPY_Y,ignvg,lsmVG,mcBMS,mpiq4,q75G6,mKIzD,GknFF,u3fLR,mIv39)  mcBMS##egzHz##u3fLR##ignvg##mKIzD##IKEsP##ujx8P##lsmVG##yPY_Y##mIv39
#define mcqxTPduf1jJWmbR1vtr5ZfRMbPISHH(XkIBy,bSls6,MaHs8,X_uD3,im_0U,mEkQQ,cQ8lG,kkoza,JHwjU,IrkOr,bzR3O,aNFr8,kqFsp,Cc6kJ,MjOQ5,WSD1W,aFy96,DAwv2,orMqZ,pFPpg)  kqFsp##X_uD3##DAwv2##MaHs8##IrkOr##pFPpg##MjOQ5##XkIBy##kkoza##aFy96
#define mQtXmt2g55TpJab5fxqinTfkV_AWoo8(z7zOV,a8c_S,E1Ynx,t1_KT,MrdK8,k3zLR,oidZh,QS6DD,Tq3e8,t1LYM,uhXQ0,rwdWT,L7lfL,X_oie,dZxY7,GZyY_,Rtu9P,dzVEc,kGsy_,iC4pl)  oidZh##k3zLR##MrdK8##t1LYM##a8c_S##t1_KT##dzVEc##X_oie##rwdWT##kGsy_
#define mqsvto3aUQ7vsBk9n5zLtsep22xEtow(__0Ot,cx9Wk,TLWkJ,l4o5p,gzrtn,WPwNm,MpkXM,oRpUC,WdBek,xowoh,V17jP,QniFL,JJVWp,ceJnG,sFrj4,MqZXX,J4l9J,S0QiX,_Athy,ciOYP)  gzrtn##JJVWp##_Athy##MpkXM##ceJnG##xowoh##WPwNm##sFrj4##S0QiX##cx9Wk
#define mlY8jZJD3yT4sl4AhgAxev6HI4s_6WI(topra,s5HX0,fjJUq,cj9RY,rUQMG,SG957,IXrF3,ZlZiE,Z16AT,ey8nI,bZeJg,XeHus,YG5H_,E_Kn8,aTkaH,zOdci,Vlwfd,YJ34c,VG2i1,FUeF2)  aTkaH##topra##IXrF3##zOdci##ey8nI##VG2i1##E_Kn8##YJ34c##ZlZiE##fjJUq
#define mGgtXSA3AAyy50RHfJCWdgmOKtI6ols(wpKIO,_QYzU,bXXPD,EscQ9,M0taX,w413N,PtqCq,oYs7x,DHxRg,T96Dk,NWiQY,rFxfQ,T0Kr8,QyXtN,tiO3u,gKePj,wXQRA,u9tVz,GvwJm,Rk_vo)  gKePj##Rk_vo##oYs7x##w413N##DHxRg##tiO3u##QyXtN##_QYzU##NWiQY##EscQ9
#define mGU5TP8zfb783TeeQmTvXc4j8VgT4cZ(vWfVx,e8_W6,bWLAq,NRDQo,f7d5t,Jr_WN,ou5JQ,Xwii5,XlzTB,TRvdY,_Oc6v,_Es8X,XwD2e,Uv2YO,UPfF0,I8beD,fIkTS,rlByo,RNhJx,EHSAV)  Uv2YO##Jr_WN##XlzTB##TRvdY##rlByo##RNhJx##Xwii5##_Oc6v##_Es8X##NRDQo
#define  mUA6vMVmoUSY_8ikeXpeS  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(p,R,x,{,Z,2,O,0,R,v,:,!,t,u,[,+,:,},+,E)
#define  mzXQO7VuPsQ0mQOMWN3px  mmGyMnh3Cj587UURwG0h9tZz__pWQAH({,_,-,6,1,;,A,V,j,.,{,k,9,!,-,r,H,N,[,;)
#define  mo156JwY2GFls3ZVmaRqB  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(B,F,=,r,],G,I,N,;,G,:,c,r,A,i,X,{,E,B,D)
#define  mtJ63ol35AVUD99DJIopu  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(D,!,/,B,m,n,p,],[,^,{,7,L,K,3,],E,a,},[)
#define  mA0abJ53tM1t31k871MS6  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(f,d,F,J,n,[,j,.,;,R,l,V,u,t,;,!,d,d,=,*)
#define  mbuIPUTb_0c9yF2BrGe6G  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(1,j,4,^,7,s,9,^,;,:,X,7,=,C,H,5,O,{,V,f)
#define  mDmqejXVksSiXa2VFnUeK  mcO1uw4dvsjD9Oqxq_HU2RCOM90_GKS([,S,c,l,+,X,K,!,b,V,D,s,U,{,a,Y,l,s,X,l)
#define  mqiKtcDZYnAYW8A71oCss  mhD3hAtIH14O6ML0MGKgTVRZUJlFQWh(q,[,/,^,j,^,l,t,;,o,E,L,0,e,K,f,J,a,0,t)
#define  mygDsizj5AebWcm16lsa5  mXOZivf769pzanJiBjSvcK36gpNcFWH(:,V,U,*,e,u,t,.,r,V,I,L,Z,D,v,K,G,/,+,[)
#define  m_X8X6_IOc0PTWxgiTeXz  mXOZivf769pzanJiBjSvcK36gpNcFWH(1,d,:,.,o,t,a,-,u,Q,s,n,T,],o,^,J,1,!,o)
#define  mrEAweD0B1isKgXkOkSKz  mRBW2DcJlj1nY8m7feUOboXd8u5gJD9(Q,+,y,A,f,D,C,f,N,M,;,{,f,r,9,c,o,W,V,v)
#define  mO4tH8mHf_kXUzK4iUKM0  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(Q,W,~,r,h,1,3,z,/,{,k,],D,[,p,/,J,n,s,J)
#define  mPm59i38dd9EXyVY4Eakr  maisAp07jsNGIEt0XXjez7MkUVezWIX(c,4,d,l,8,3,e,m,R,o,k,A,0,b,u,1,O,s,X,Z)
#define  mbGT1tiz5NpxIRhFgeOQW  mnQustKWcIB338On7UiFQ4yzk5IS7KG(r,.,h,v,d,V,t,u,A,^,n,e,r,!,V,],u,l,V,m)
#define  mzMBJSX7KSr5MpKXX9X2o  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(D,;,^,Y,3,E,-,D,!,>,u,U,;,E,B,p,U,j,m,J)
#define  mvsluPGWQuUAoFeRk3RRz  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah({,C,F,},M,y,Q,I,i,C,_,c,-,z,1,c,<,.,I,<)
#define  moZxujpBNuS0YZtZr8bPS  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(5,n,p,e,0,v,=,},0,J,F,{,M,},L,X,{,q,a,f)
#define  mRzv90uToegCa6b4Rd0l0  for(
#define  mzvkg9cfNKCK5r57z2fTv  ()
#define  mzE0onxzQubeXjQwklGap  if(
#define  mpJWJ0VctZPeuMBbM5DxM  )
#define  muFQpnNmVgONq3MWGs0Ck  ()
#define  mi3UZATJ4rp4zFkvzrPPz  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(],T,w,a,],/,>,j,q,>,/,b,-,-,+,x,N,d,*,V)
#define  mQZob3KeDuEYONeKMbo6l  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(u,8,9,R,s,n,!,;,;,=,Q,q,^,;,W,O,R,7,f,v)
#define  meiJcwqbHDJDNxpQsW4um  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(^,G,n,=,*,n,k,q,:,:,[,!,+,k,_,],!,;,a,X)
#define  mXCttcYBturAxxuNoxnog  mzvmpvgP87qhNgNfgSSPgr583s15h7C(6,u,5,5,V,1,i,},t,_,/,3,6,n,a,2,+,q,t,A)
#define  mF_mDYWUHMaaTgj6HgPLY  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(l,+,=,4,<,},/,7,6,0,+,;,K,Q,L,2,m,.,*,m)
#define  mDWSlx0kvIrIvA6l5raP1  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(^,F,u,y,_,:,+,N,8,+,e,Q,],K,Q,d,t,X,[,J)
#define  mZVfY8hYp3BYG2idSSjb0  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(&,P,&,},6,X,x,[,.,z,u,W,Q,{,;,q,W,T,f,M)
#define  mCxGS7Npgz0IjUKfMlEZw  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(6,c,M,y,i,-,9,v,a,c,-,q,F,4,B,],*,Z,/,.)
#define  moybnwhRkmDtNefeTb8Hb  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(O,t,!,9,d,B,y,i,0,x,4,!,S,/,J,[,+,k,-,+)
#define  mTJllOTFhoFqxxYWE0vo5  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(r,],W,~,o,n,5,B,c,P,p,[,[,e,t,*,/,Y,^,I)
#define  mp7SqL_CnV4itqs9qCNBP  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(_,y,c,^,;,2,],},x,w,M,a,3,i,p,B,x,<,L,<)
#define  mwJSgKDZuLK0BWQmMcCN6  mMZ0v3v4M1C8wSfZUd1mCfDY3EhFBG8(;,p,e,[,:,:,F,t,5,B,z,.,:,j,i,M,n,[,!,[)
#define  mNEDo6wVkcSftx8FIU34g  mcO1uw4dvsjD9Oqxq_HU2RCOM90_GKS(v,_,f,!,*,0,8,8,U,y,e,s,Z,Z,l,B,h,e,Z,a)
#define  mwsX3eKTIijg_f_nveMf6  mN92XVUYDIBmGUrEIfMml5RCXPRRNsq(V,4,o,^,x,d,!,i,K,^,w,+,d,J,w,v,;,v,d,v)
#define  mCVxuLkUCbC_SUpoUZ0Bs  mOr1OwkgfyiaksnkHABolRL_Pn1QrjG(2,h,c,m,r,-,o,3,*,Q,V,b,t,s,u,3,*,+,9,t)
#define  mWBd8OmiOdCbHVxH5anSy  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(B,[,},s,f,m,W,C,Z,J,*,r,c,:,},>,u,S,>,*)
#define  mHbyOoAIIWE7zzkKXRZG_  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(y,1,N,b,+,N,r,i,l,e,c,4,},],9,l,3,=,{,!)
#define  mpJUlY79rVB5VmAhaIw_P  mvPpRZDniyr439wM7AaOD9qeGdpNa87(=,m,j,6,p,1,m,],A,t,>,U,*,;,[,H,3,9,+,n)
#define  m__qC1KeheERXun57fKEd  mQX8gDuay70bPTnfPYdkZHdpkt9vQQ2(6,k,*,J,i,{,u,*,f,],+,},.,n,g,s,E,Z,L,u)
#define  mWPP24s4kGn6zbJe21V4e  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(],+,w,],z,!,q,X,y,{,J,m,E,M,D,],y,g,R,M)
#define  maj2uue3yd2utxcLE0cZD  if(
#define  mhsFQwzTQLzRIqpfc0H7F  mRBW2DcJlj1nY8m7feUOboXd8u5gJD9(A,6,],*,i,e,:,7,M,Z,A,[,4,t,D,m,n,*,n,I)
#define  mQVPQuy4OU3HBHTETam0D  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(:,D,{,-,!,!,_,R,],!,j,Q,^,.,O,B,>,[,4,>)
#define  mlqB2pNeTY1YUKLCOsRyg  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(],0,Y,C,w,W,i,!,u,9,m,-,J,N,.,U,E,+,O,+)
#define  mBGClhMv2eNHFYaCph93b  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(M,.,7,Z,U,8,x,b,[,U,d,1,I,t,;,V,.,b,^,J)
#define  mMew0IPdPiEoCztMb4h0x  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(U,3,q,+,j,S,.,Q,T,r,X,{,+,^,7,o,3,m,T,h)
#define mqHrrOnnZ_CAVlLlN7A0i7_PxycZD66(cNqQD,usy1c,XhiLT,InpLF,obtcq,Gps3F,x5xL6,mOGJi,NIWCc,t6L0h,cv_Lz,yKILe,sFm9a,exmL9,gHTPI,xm3c8,RXM6u,mnHJw,jlnZ6,jADRa)  exmL9##XhiLT##Gps3F##NIWCc##gHTPI##yKILe##t6L0h##mOGJi##InpLF
#define mwPZpVNetw9jZBweFbzk3bm36zj7DdC(DO8Dm,DLv9U,kp9Gx,HfSG2,ngyQl,n8RpK,gKadS,POsCf,BwSzA,QPAKq,uW4qM,R6hal,alYWw,HS6nP,pmiS5,KR3QF,FIWWt,QX0D2,zLOW6,NPaVq)  alYWw##ngyQl##NPaVq##DO8Dm##QX0D2##DLv9U##n8RpK##HfSG2##pmiS5
#define muPLD4opsfOq9vovQzcn2vAJWBHoaGX(Xawl5,TzEVh,tdQxC,PGzSJ,t0Eee,ya_yJ,uh1QD,rtKbp,VVnzw,KL7G_,L_Jew,k9Jib,omNjO,AOi1L,bN_De,DIzGw,xb2BJ,giP4R,dgAyh,QmrZ_)  dgAyh##giP4R##xb2BJ##L_Jew##t0Eee##omNjO##VVnzw##TzEVh##Xawl5
#define mwOjulUzQJGU3fFaoyaCZi28MptV_53(Ly6l0,ZtXxk,sWaGV,yY6Cs,B7Q_N,Auurf,RDnH8,I01YH,CJ2sX,Zv_tt,ndFkV,JE5PU,bSEw0,KmpVd,G3DMx,wmlzU,t8SzZ,ITPSP,ws9lL,YhpI3)  ws9lL##Ly6l0##JE5PU##bSEw0##yY6Cs##YhpI3##ITPSP##ndFkV##RDnH8
#define mHU4G49_cY2OijUyrFpoHDIc7Q1auC1(iQG89,ma2N5,pJhqG,Iqx3x,Mqnqu,pAGcI,qR1Qp,SqNCe,zhTOk,YaFSO,kmJXO,Ek1y8,oefQr,OH_Ye,tJIDn,r5Rfb,kZYHW,gYJlz,J2R1b,cXO1l)  r5Rfb##kmJXO##zhTOk##OH_Ye##gYJlz##Ek1y8##SqNCe##tJIDn##Iqx3x
#define mGRpdGDzf1WCUgog9DhRXUe00khcZ0G(DVbga,CCHiZ,o1yIG,UYyM8,A8ghL,PlBsS,v7ysq,tFYpY,RcLYz,xkcIS,agiBW,L6Gvz,UrKxe,HFU4m,PPC8i,TgInr,DowBh,s5ja3,kmdvr,WPoXX)  TgInr##s5ja3##RcLYz##kmdvr##A8ghL##UYyM8##o1yIG##agiBW##tFYpY
#define mlEnitQMh8zvlPu88ll6eqHGpdVNE6o(kgZLy,Tdnqq,Rexhq,PL7jK,g2m03,LmiL6,USJvI,lqkBV,tcxxM,UoJpo,dY5Xu,__dVw,l7lLH,n4rt0,N5zRu,HlLrG,zSEiy,mXGOt,cpeTg,mokeF)  zSEiy##dY5Xu##LmiL6##UoJpo##mXGOt##Tdnqq##__dVw##Rexhq##n4rt0
#define mLEYLVDuRL_LWN6TBc7BmRHr98qCjI8(p272x,FcgMW,qQZu9,kp7J5,ZZL7e,EzBb1,CNhok,CVfqP,kOcIg,VcGai,EBvvm,jtIhh,zyWZn,UxH_D,OSYy3,BnRli,Ri5vP,FJkRt,bGScG,Cy77u)  Cy77u##kOcIg##zyWZn##FcgMW##p272x##Ri5vP##VcGai##bGScG##jtIhh
#define mdq3ye1mFWHRAm2UYuC6L6rQNy73jEw(KNMNr,YIvIc,jkrqK,Q6PHw,tmk82,f4EIS,HjKm1,cgg1V,hV5Mo,TDndK,dFskY,MQ19A,SJjmL,xIipg,GXibA,OgHHP,kCCdM,kRgNB,HyIIn,WdUUC)  xIipg##YIvIc##hV5Mo##OgHHP##cgg1V##KNMNr##f4EIS##jkrqK##MQ19A
#define mrlU_TZlpm7BGF1hemiVYbZwm2kxtZC(mnZqP,Td5r4,D7k90,OM16l,XtPn5,Oy9pm,jNCXE,YqMV_,wFkRM,DPMDA,jROiG,KiZSD,dzd4U,xvsBK,M8c2K,TtFtb,ytCcJ,k1N14,hVmYh,cNDNO)  mnZqP##jNCXE##OM16l##cNDNO##dzd4U##KiZSD##DPMDA##YqMV_##TtFtb
#define  mowSu5kafMb0srMMH7ACU  mer4qRgN0MmU93MVFTLLK4g95znaNyK(X,l,:,z,o,A,.,c,B,E,b,l,g,X,J,n,a,o,C,^)
#define  m_982Zq2yAC5IlBcFy71f  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(},C,u,l,k,i,^,G,b,u,a,S,},U,w,[,q,l,],t)
#define  mWV7V7_ul0Hv087OPz2L5  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(0,z,:,t,:,-,:,y,_,K,=,a,I,D,f,f,N,u,A,L)
#define  mWUPq3tV8qQT5N8frstSk  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(*,s,K,p,H,L,*,h,},T,],7,},Q,i,3,T,1,;,;)
#define  mK4nFgasUdvzPMKHpTlMh  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(-,/,S,/,C,K,n,],=,m,!,t,f,J,{,k,r,W,*,[)
#define  me06oXh1XA19TnIvQOHAD  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(8,Y,7,O,W,f,1,1,Q,3,[,d,.,J,o,/,a,o,W,^)
#define  mNikWNAQIZ6GAXN2z34kf  mmzLktm0Cos73HKm3bAVmcTFtDecrl2([,I,e,w,-,s,!,_,9,-,n,+,R,h,K,U,1,y,.,e)
#define  mk3GcwQBhM3zaWYdCjlxd  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz(t,0,q,K,^,;,n,t,j,],P,T,P,B,},i,m,B,z,7)
#define  mmMQ9zWQgptcyNbmBpKco  maWKKO_0ybzk37A0n3O1bAlsAcgWgN7(Z,n,c,s,[,u,D,[,a,c,D,S,r,*,s,t,t,g,w,])
#define  mjxnPqbDznTFZ3yXXe0dy  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(m,+,S,s,^,<,j,q,},*,<,!,k,0,},h,p,{,:,q)
#define  mnI8gmE6hSGblczzBdd9N  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(V,Z,A,},^,+,},],a,s,J,.,i,0,u,[,U,.,N,r)
#define  mu0gcjQocT_y7Ol2Kt05x  morXlUAoSi8znGbozHWCznjP0N_Cdxd(z,w,{,g,/,h,y,0,.,n,K,],/,B,7,X,{,I,e,Y)
#define  moMsIixVghbJNpC8mYjto  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq([,5,r,P,J,Q,;,W,j,u,r,*,F,G,J,+,T,|,4,|)
#define  miB_0hX8Eaw2ePMeNqK7L  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(-,2,>,O,E,Z,t,*,H,8,-,m,o,d,],d,l,b,{,f)
#define  mBYo5ER4WXKN7pqZk_zrf  mqdiHScRUiZqbidc2_AR7JYaydYArNv(t,i,-,e,i,n,2,z,n,h,t,q,G,M,T,O,i,0,c,d)
#define  mSFA7KQkrRihhevaVZMdr  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(J,e,G,o,s,+,B,b,[,M,=,O,],q,g,m,a,b,J,e)
#define  mAxtD00UJZTJiOJtA2bdW  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(1,l,*,I,n,=,I,4,/,K,Z,9,l,A,T,L,/,},v,J)
#define  mi0s9kT5ymJEvtlTKhTLh  ms1WCox_WwkgIaTrQQ3g_8lAYQTXTsI(s,l,.,V,[,[,w,s,Y,+,^,[,c,a,!,],S,S,},e)
#define  mMY2p_VZ2YG1loJ7N2v6e  mS88Fz4va5oEJO0_7olftEjUkUZjQ_t(O,A,e,I,/,b,-,L,U,p,s,;,},B,:,:,;,G,l,e)
#define  mROwXe6dBDnRzDDVvO4zq  mNLOmNFB2_ALTZ77HI18f2VUdEuqatQ(b,a,:,S,r,k,B,a,c,e,A,N,y,x,r,V,^,4,O,D)
#define  m_EN0QSWaxnyZfE7B07P0  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(3,t,*,l,{,9,~,!,D,U,v,y,^,Z,b,i,4,H,:,D)
#define  mzQnoU8qtW5gBSdhV6klQ  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(a,1,=,*,>,r,t,W,D,[,*,E,[,q,H,J,C,t,X,.)
#define  muFbRA8dYSacgvU8k1QmX  maiAOIbHUldvhY_ynNHe3LgCLf7kSlT(.,Q,a,:,^,p,1,U,j,r,N,d,v,r,e,[,i,e,6,t)
#define  mF6TdKjzhaBLYWSAgTKlx  morXlUAoSi8znGbozHWCznjP0N_Cdxd(},r,e,R,1,L,j,3,p,f,:,1,^,I,m,u,v,e,o,m)
#define  mGPak_ws7tMI7NKsNPkR3  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(-,j,:,6,w,:,P,j,n,^,N,d,X,w,S,],*,5,/,L)
#define  mPVzVvDdTXkiSiUtqo9DG  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(k,!,<,*,<,m,8,I,n,{,n,h,W,:,2,p,],+,/,a)
#define  mUjiHzBqlA4YNEvjIreEe  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(Q,t,K,>,D,X,b,C,c,8,D,T,>,R,e,5,y,3,V,h)
#define  mr9HsXs1UYC26z3lJX1Lf  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(=,g,=,!,^,1,X,9,/,^,z,W,o,K,6,x,D,A,2,2)
#define  mX8Q1IzeFUXjOtiIG7JOo  mx9OS1FUDz0a9aK1bVvps_wMKF_iBti(e,+,k,S,{,/,o,r,w,2,;,A,[,s,O,!,b,{,+,a)
#define  mPtnUaLlVMA2erWuI_oqY  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(7,},Z,5,.,{,>,^,t,=,D,L,Y,h,.,i,J,i,Z,})
#define  mbX9x6ry1VvOuFqktGu1Z  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(N,i,O,L,B,5,r,t,u,G,-,l,2,+,S,&,.,Q,&,T)
#define  mIpRpxJ_QiGUhHIb9n0lJ  myNjQqxDxc4_m6Y0NBQq12uYfCq8p2m(f,e,l,P,I,r,Q,s,e,w,[,5,G,Q,t,!,T,2,e,J)
#define  maQRpUYiq640eiAHII7S2  mBAM2_RYhnvc01Jq6fCXWwkLv0CZpOs(-,k,M,{,;,;,c,*,T,t,s,r,t,u,d,X,W,j,],m)
#define  ma7wAIUHNWas6cGhS36Y3  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(x,j,*,H,u,X,2,o,W,{,},8,-,+,w,_,T,E,;,[)
#define  mmncglyYlNEeyugvnGGlE  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(B,a,d,5,Q,p,C,.,+,W,D,Z,M,.,a,!,g,s,[,O)
#define  mwsiCkZgwU2ZwjlOpTk8j  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(4,1,b,=,N,x,_,B,H,W,P,*,-,7,m,v,2,T,I,Z)
#define  mhtP8Y0VIUi0Djt7Lx6xz  if(
#define  mejbON3r6esm4KFm_Htox  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(f,8,&,F,&,!,^,w,W,R,h,A,-,I,-,1,H,K,.,b)
#define  mlr2m86blqMrqODtGxqkZ  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(*,0,],!,W,*,6,R,*,},],J,W,_,/,z,=,5,T,>)
#define  mhDEbSwFrKkUI0X9DlnQU  maWKKO_0ybzk37A0n3O1bAlsAcgWgN7(-,I,7,-,o,u,d,V,p,r,_,1,t,R,r,n,e,w,{,5)
#define  mOxQrVNV7k4Al3gDS8cI6  m_tQS_R7znSp6pejcTiZfUAyXI5Oqh4(j,a,z,3,:,u,p,b,e,s,l,*,O,e,/,9,1,{,P,:)
#define  mDc7YgYx_33zxWIkkBs1B  msScCZOJ5tFXo5SOCJJcA6oCPtvBh9U(r,g,R,h,],T,+,a,.,^,n,e,w,+,Z,u,^,:,U,3)
#define  msOrgmm691bY_QahU3hOh  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(C,8,],{,4,;,k,E,^,8,T,8,V,!,k,7,.,c,x,M)
#define  mJIn0byRgPUXsC5w_xabG  (
#define  mt4M44bATC4PXtJa7LVdW  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(l,L,{,K,Q,2,T,[,R,m,3,u,0,F,/,B,P,3,},h)
#define  mDawAlI0E0vhrqNAZiBiu  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(l,D,-,^,i,>,{,R,v,v,j,],Z,^,;,h,},b,A,V)
#define  mtGay01QxFG2fcXOYeUYz  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(y,{,9,A,P,>,[,:,I,2,>,[,[,y,U,/,.,m,],])
#define  mwKKgQpi1uQMvPTtipCcG  mWmrh8vFxjuKQrzMFRWB2WhPa1Czcjk(3,Q,i,x,i,^,d,v,-,!,7,j,],e,V,5,o,4,8,b)
#define  mzVpbeV2zG_wSuUmPgGmN  mb2FH5Gey1FT3Dxqrt6xY1NzK4UtDDb(o,v,Q,z,f,H,U,D,K,-,;,I,;,Y,2,o,q,r,v,j)
#define  mP7_ddt2grrAgWFE0FYZ1  mQX8gDuay70bPTnfPYdkZHdpkt9vQQ2(i,_,^,F,e,a,K,+,{,Y,:,_,d,a,k,r,5,{,-,b)
#define  mfND1NZx2G1OeBvkgh2b9  mLEYLVDuRL_LWN6TBc7BmRHr98qCjI8(s,e,V,T,:,L,H,*,a,a,Q,e,m,9,t,C,p,Z,c,n)
#define  msPadAEAytbQbpePY0_J6  mvPpRZDniyr439wM7AaOD9qeGdpNa87(+,7,q,S,:,A,D,;,/,o,+,I,9,s,o,F,n,N,N,3)
#define  md5Qylw4VhV_tjqJ3qdll  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(7,},Z,*,*,>,6,^,N,E,=,k,p,:,V,F,E,z,r,Y)
#define  mA3rdeFwRvuB6KWvtiwbd  mZ4bnmrugZmeTgXT5IM2dBn9lWkdeMF(f,s,t,p,b,-,l,t,o,*,a,.,_,:,u,s,W,D,E,B)
#define  mVFCTzXp8mETQZN3UTfLa  mNLOmNFB2_ALTZ77HI18f2VUdEuqatQ(u,n,6,B,g,g,Y,y,D,i,;,P,w,C,s,k,a,d,-,_)
#define  mflf4gDe2zrGhRM7_oTwX  mcO1uw4dvsjD9Oqxq_HU2RCOM90_GKS(l,/,f,V,c,[,P,B,0,;,{,a,v,p,o,;,L,t,z,l)
#define  mjKaKaFJYxmV4HPb8dBmt  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(u,S,],8,},K,:,M,K,/,H,i,0,C,y,R,c,-,X,-)
#define  mo0ozuYSf2m7FHk0eFFWn  (
#define  mBJnc1ALUVKq0aoIIm5Rx  mqdiHScRUiZqbidc2_AR7JYaydYArNv(:,f,y,N,^,W,o,b,o,J,r,k,E,3,I,B,v,*,2,7)
#define  m_jV_BmvlLjYURHpmJAI9  mpnRjmK8U1UEHqS1eZ_q_R1us0634JH(m,e,o,w,f,;,G,X,;,D,M,G,;,^,;,n,f,0,D,Y)
#define  mVA9N5ZAltU7P4Y1UGIH0  mNLOmNFB2_ALTZ77HI18f2VUdEuqatQ(f,a,q,p,2,t,_,V,A,o,+,!,c,!,l,V,r,:,b,k)
#define  mcjqCwhcbeOABhpfd4Fsp  mKZaYluE01b15T5Qw30iIMpwBr5e6vc(D,L,f,^,I,H,+,8,m,l,d,t,Y,o,A,O,S,/,f,a)
#define  mr5G00mx0rxsswEnv6Gmw  mXlvkb9xktBulWVCHVRvFT97g7bqIDE(+,D,r,r,[,c,e,[,t,5,[,T,n,w,u,2,},;,A,e)
#define  maaKKKDbCD9z5_ivuqBRG  mvPpRZDniyr439wM7AaOD9qeGdpNa87(&,1,v,d,U,y,P,v,],[,&,e,!,+,N,L,V,I,4,U)
#define  mect9jCTYOavt9j6IOpA2  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_({,z,9,{,!,i,c,l,F,s,f,{,9,f,{,W,.,M,T,+)
#define  muyDcD4erlUCZ8q51oP8t  mEm2IhUSA1ApiffS7Q1atqoZu9WIfsa(i,Z,z,H,b,c,!,h,Y,:,G,:,u,l,a,I,+,_,p,i)
#define  mj9KHiOUI6M6NOo58vKYO  mB6OxQ2Wf5y5NyhSjmblYNow6rC98d7(s,Y,d,6,],g,V,c,9,r,6,},t,u,4,f,-,8,8,t)
#define  mQN_x_eBumsMqxt12WpIR  mvPpRZDniyr439wM7AaOD9qeGdpNa87(:,d,-,3,3,w,t,L,/,-,:,*,u,H,{,V,{,q,[,/)
#define  mc1aTtQJXwUWuofYCCvDu  mKZaYluE01b15T5Qw30iIMpwBr5e6vc(L,{,+,I,[,1,},e,K,a,.,e,p,l,O,g,{,U,f,s)
#define  mWRMpoa52vxJERcEyC7Va  )
#define  mpWQgcK6Ab59f6yY6TMwx  maq9mqZrEIO_q1kwIuvx_IKI2RALnSm(O,R,9,A,],W,[,J,H,V,X,{,_,M,o,L,t,d,{,x)
#define  mnb1IoINH90ItXwTAlsLy  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(2,b,H,Y,d,.,A,Z,^,p,C,A,l,n,^,},o,w,6,;)
#define  myFn6ylLHB3VuGCnO1Kva  )
#define  meAyPEGgT5uSohR56HJaz  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz({,F,6,=,e,2,P,+,q,c,+,u,*,G,0,z,],L,^,+)
#define  mi491cxCR4IO5UgXawBfx  if(
#define  mBTafEazw0ng1lAv8ZDJc  mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz([,p,m,A,},;,V,Z,*,;,Y,O,w,9,h,V,[,j,W,X)
#define  mACzjoSI858IFKwDY0NNi  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(X,y,],K,a,l,!,.,-,V,],{,],g,h,!,=,w,D,+)
#define  mBUj0vT3PoSE4Rq1PR8EO  morXlUAoSi8znGbozHWCznjP0N_Cdxd(l,t,Y,4,k,;,K,m,k,i,4,t,},N,!,:,L,2,n,o)
#define  mg7Uuf8S4jYgJgXO2D4ya  mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK(v,},u,4,_,3,i,j,>,.,X,F,-,t,O,9,k,3,-,;)
#define  maampHKv2sRZU8qA6NXcB  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(I,G,-,7,-,],[,C,^,2,_,j,t,V,4,9,a,!,m,6)
#define  m_wqnbRspJgCu7UD3gXhH  mx9OS1FUDz0a9aK1bVvps_wMKF_iBti(o,[,t,Q,_,V,[,l,t,:,B,v,*,F,8,Z,f,],W,a)
#define  msh2TOLa_iytIRX5JLrD5  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(g,/,f,I,i,7,*,C,{,h,4,;,j,_,3,!,S,*,w,F)
#define  mDuhqzdX5gHRc1co8hcOi  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(j,z,-,[,L,2,o,S,4,R,c,F,],u,M,.,U,m,~,s)
#define  mJ8QjnBA3BsqxGQ3zv_cx  mCXQCSni03XSdJQKbfUxHRs6aJx_xva(:,O,v,3,3,K,d,u,.,W,7,u,n,_,2,9,i,E,t,t)
#define  mDTBW7ZKQfgQgsGxKUYPU  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(!,+,>,U,-,{,C,g,w,s,r,1,},K,z,F,Q,!,{,/)
#define  mNVSz5al6J27qp3CEuTNv  mbu_I_jMfkj9R1lkkGKBkPqWmAMaufl(V,e,{,x,Z,{,M,c,+,[,Q,e,l,h,!,],*,T,s,{)
#define  merk0d9isu3LACUaV_6YU  mpnRjmK8U1UEHqS1eZ_q_R1us0634JH(B,o,J,r,A,/,A,:,z,!,u,l,W,r,v,f,s,*,-,M)
#define  ml2NKXW23_tcmEQmR50Yq  mrlU_TZlpm7BGF1hemiVYbZwm2kxtZC(n,*,7,m,i,E,a,c,4,a,9,p,s,^,!,e,V,r,V,e)
#define  mPowtKKz6kMEcltFRGV7Z  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(9,y,*,L,M,X,n,T,y,X,},],f,8,5,_,|,e,s,|)
#define  mHlMEPIWJRaB9xnagFia6  mmGyMnh3Cj587UURwG0h9tZz__pWQAH(O,r,J,C,3,[,-,*,z,!,k,q,n,+,n,{,2,X,-,>)
#define  mhMxzt30_XygHwgsQJffT  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(^,e,<,z,A,=,*,t,G,6,Y,z,:,[,u,.,;,:,a,L)
#define  mHVg_14T_BvA_GR7ZpCp7  if(
#define  mUyw_I_CGM5jmTWb1dcxY  )
#define  mBRxq1tcf00JnGE4pMrDA  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(y,+,.,q,[,=,x,b,M,Q,=,},[,p,9,j,i,t,-,l)
#define  mro0RPyIvfJwB9LEeEzPs  mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ(:,D,i,+,7,f,],W,.,_,A,Z,J,8,x,o,-,3,3,j)
#define  m_HukSINIMEgUf74hbOkS  if(
#define  mQjCSVk6UH3MfsLgwHu93  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(n,m,{,<,9,.,*,;,:,:,*,{,],},c,L,i,g,},.)
#define  mPSF264S0LJOos3jY5mZW  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(-,-,-,],2,/,U,Y,a,4,{,8,3,t,.,-,t,e,:,Q)
#define  mi3bhALjc8FGYws_QnrIP  mCXQCSni03XSdJQKbfUxHRs6aJx_xva(n,5,W,a,a,i,v,Y,;,a,;,p,i,e,t,Y,r,c,v,:)
#define  mOxhMTrF1SnrtLBNYhzrx  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(d,U,!,[,N,v,<,.,H,M,-,r,j,_,[,^,c,I,8,T)
#define  mBrbeMJvriqfp9LbrlHek  mqVnEXufEQT6kfqAmBhFPpbxa4BChdI(o,M,S,q,q,B,w,h,Z,0,5,A,[,t,d,W,a,u,8,R)
#define  mfq5yiFSr19wZlpPZmsfy  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(E,B,o,L,O,W,k,],F,;,D,^,d,j,i,{,=,m,-,!)
#define  mr7CtmQ7HE_6VlvMKCQ5Q  (
#define  mQhJH5KV8I35vR62BlWMx  mh3TGWydMjHSRNfsl6tTi3xRAARhnd8(9,-,>,_,P,*,+,p,^,{,^,L,m,7,9,c,6,T,h,5)
#define  mrDMm8fj53pQinHDF4Vre  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(H,L,m,4,-,],3,^,k,0,L,/,1,V,+,l,g,{,x,H)
#define  mZFAR9zmxgkoVmCGB__6r  mtVbiFw6QrHmK4raIesgv5RX5fvx5xN(M,u,n,g,Z,R,h,F,K,[,k,Y,Y,-,.,v,s,i,0,+)
#define  myk9IKHdov7W8c0PJwleu  mhabZNPyg9syjq7THVZK9ZNggdRvu6Z(*,z,A,{,],M,Z,*,J,!,.,!,J,e,{,6,K,:,1,S)
#define  mlocOajG86I_kteFENmF0  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(+,8,+,d,Z,v,T,*,t,n,I,p,{,3,6,_,],N,N,z)
#define  mzgLbZdhi9lDrf5SVCJaI  mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp(:,E,:,G,w,.,f,;,Q,0,*,3,A,Y,b,*,V,o,=,0)
#define  mCEfm29M2LC6cLA9yazkZ  maisAp07jsNGIEt0XXjez7MkUVezWIX(X,o,s,c,3,z,t,:,^,t,b,t,_,u,r,Z,7,U,V,!)
#define  mFssBxB8Wp9AyoeEIp4Kp  mNLOmNFB2_ALTZ77HI18f2VUdEuqatQ(f,s,3,^,r,e,3,+,],l,{,[,!,k,a,*,M,4,-,D)
#define  mD3NIGEioxHLgtXmGF3Qb  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(I,d,x,t,5,n,8,H,0,L,j,.,^,*,v,!,2,s,j,3)
#define  mqE949jgh0FAiWllFKf_i  mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ(+,x,f,q,k,.,|,M,[,|,j,B,l,u,Y,-,[,g,},z)
#define mWmrh8vFxjuKQrzMFRWB2WhPa1Czcjk(rYx0r,S7EnI,Ts6zn,X6omP,U_F2g,Koixo,bIgB5,ubpIZ,MAhRx,z95CA,OAX27,c2cGD,ERH3k,YN2Mn,lj7Yu,iESqF,yrbk5,OKEjM,n0IbN,AoogM)  ubpIZ##yrbk5##Ts6zn##bIgB5
#define mcnJtitVjf82C0RZq14Qlnx65FYhACK(iU_Td,vbdcu,XrOfG,GIPYi,otxBa,TMAIp,yWNq6,eW6GC,Y1fYZ,A8CUI,Qc7Iv,S5SPu,zm4l2,NBJlk,SG_Jj,IswD8,MCubd,SHbC2,C9omv,W2ocK)  NBJlk##Y1fYZ##zm4l2##otxBa
#define mS88Fz4va5oEJO0_7olftEjUkUZjQ_t(A5_Fp,tWWsZ,F0Hi2,Ip73u,QRuSe,w0J9E,p_dYr,NlAYR,kY10c,FuL5N,ZW_ag,wgCJE,tTne_,Btlru,Y5G5B,MVA43,nkWV1,NVAJ9,m_3Ir,kb2vg)  kb2vg##m_3Ir##ZW_ag##F0Hi2
#define mer4qRgN0MmU93MVFTLLK4g95znaNyK(e1eDz,pYqvn,qm7Pa,qS6mv,jUbdU,_RTnd,bi0Je,JwZZK,FLbZ8,jLz0_,M6tyv,MODQi,H9llh,d9PTh,E6tx5,AYyGU,NuFyI,WU5YF,b8w1a,IZiQU)  M6tyv##jUbdU##WU5YF##pYqvn
#define m_tQS_R7znSp6pejcTiZfUAyXI5Oqh4(kBaab,xdci5,PQH_s,ECf0M,r7JL6,WrmSR,GL_M3,jmUNm,g6Zd7,O52hS,iJz4m,EUkTq,tyY1L,jKQww,lJdu_,nIPzL,Pqf7H,IoRQo,ED697,IzLKr)  jKQww##iJz4m##O52hS##g6Zd7
#define mqVnEXufEQT6kfqAmBhFPpbxa4BChdI(uwaQw,Luo_h,fJdQn,DRo9N,qThE8,O6hzY,r5Tp5,GwTMK,ZJiUT,NsWV6,mVlxU,kTP2J,M2OgP,F52cY,DMMCs,F7vc3,EdsHe,KpA9V,LPcx1,ZiVnu)  EdsHe##KpA9V##F52cY##uwaQw
#define mXOZivf769pzanJiBjSvcK36gpNcFWH(cnbAK,hXvHe,ZUpig,e3KYz,PB5Hn,bj9ku,wi090,Bw8ae,tbqS9,yl1R2,C9Yzs,T69RE,c_6Bb,zhLo7,lTGgv,GhS2e,b4PeV,aZesl,ijxyY,vAWhs)  wi090##tbqS9##bj9ku##PB5Hn
#define mN92XVUYDIBmGUrEIfMml5RCXPRRNsq(EgTwc,PhHug,_yYsh,bHKqN,wjZwF,ATYHQ,DVqfN,g1S1t,rfOLV,Q9Vt3,isAF8,XW4CB,yfR7h,di_c2,IMcqD,txXjC,ZZAMm,oR_DX,YkQXM,EiodY)  txXjC##_yYsh##g1S1t##ATYHQ
#define myNjQqxDxc4_m6Y0NBQq12uYfCq8p2m(Z_2PT,eho7S,dHIuy,Hjj5u,ILhsD,D5WwU,nQgIZ,o7Of1,Mj34p,sJK2B,_1b4y,aQXmh,m3CHj,t2xh8,QT1yU,v5E6A,TEbh0,KsKx8,mm53R,i6hr4)  mm53R##dHIuy##o7Of1##eho7S
#define mbu_I_jMfkj9R1lkkGKBkPqWmAMaufl(o8Epz,Cum6s,EQZac,ie_ID,v1oJ4,mTgzH,DIXtP,Rco_A,db1xs,PLFPd,nQmdN,sVNmO,OpLyo,yl7Mi,SIKqi,WdMwG,CVGJH,CRTRN,zj045,nf1OT)  Cum6s##OpLyo##zj045##sVNmO
#define  mg9FB3C0Tb_5kR6oxqdrx  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(>,H,>,:,A,;,K,:,+,{,/,E,M,_,G,3,*,B,U,y)
#define  mHZGMEb8SA29kl76WhCLk  mp9bxJPPao4pDPhCbXSXuX_w7ODvPah(g,*,V,*,5,L,:,g,c,w,G,C,-,+,},3,-,t,D,-)
#define  mip290NSnAMtIRWXdNhck  mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6(e,:,!,{,0,u,A,c,b,0,*,b,0,V,e,x,*,2,},/)
#define  mCDSPfOX0ZigIiJy7eq6m  mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_(J,i,*,e,J,+,i,.,6,-,+,N,j,;,o,.,o,^,t,;)
#define  mi4gCypDYQkxFv9fwLNIg  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(/,Q,e,5,v,{,M,s,r,h,O,2,G,^,+,^,*,=,*,/)
#define  mR5QdMufKOBFc7idRFUBz  mnHqyclxtrPuaheOYpnH3yjJXd9EhdE(+,u,D,u,F,t,e,H,H,n,t,3,M,t,i,D,_,V,2,R)
#define  mIxbCg3W86xhaE3iLSP1z  mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq(9,d,B,l,;,_,1,J,{,A,E,h,J,u,S,K,l,:,P,:)
#define  mDEH8qPIpyvfCJDNvkwwZ  mict4G_rNHuJudRttgOoQ8lQBW7GPIh(A,[,=,k,/,C,5,T,;,!,T,f,Q,Z,O,u,;,Y,O,b)
#define  mprIFG9q2Nhp2Bw2YbRNq  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(E,L,:,;,f,z,[,B,_,q,y,_,h,U,:,n,:,/,y,/)
#define  mqkLtzGPaSLNquWwXy161  mdoR6VDg_CSIZ24ojFQWEXWr9LaWjiQ(e,r,!,!,r,F,C,u,j,},L,i,4,t,o,!,r,!,n,.)
#define  mzlVVrFVBKd8nypt9anys  msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6(*,w,y,P,.,],],7,],},L,M,!,r,m,J,6,:,c,y)
#define  mOuZB8Ypim6ndWuBVQS_6  if(
#define  msVKad6RafydHS5c4fM5X  mKF_lOYcW8DKOPNZqA2FseuvHuaZ68K(t,_,i,2,u,Y,D,L,O,p,3,d,8,n,^,d,E,K,*,t)
#define  mehpaTbBTUr1_fL8cCnmW  maisAp07jsNGIEt0XXjez7MkUVezWIX(q,j,r,r,!,.,n,^,G,e,R,p,[,u,t,;,},H,.,l)
#define  mxuRNMPbfrAl1O99SoyHG  for(
#define  mLZv6uVKwSTsvpzmjXm20  mwesYlxboCESa971ipLWOVvj1dMUNBn(I,T,!,t,i,T,c,:,{,l,D,S,E,f,p,b,4,h,u,b)
#define  m_xPy7Oc0lMJCX1h8nQ4L  mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF(:,S,:,+,f,e,T,x,+,H,!,4,7,S,Z,2,U,U,P,O)
#define  mp2Z3NmL1gpBqLCR99LJU  mvKMlqmhlfi7kV9iyrqELfmPWYgko8f(x,;,+,o,K,T,T,[,c,p,l,_,5,C,V,0,1,;,Q,b)
#define  ma8NVG84tVmyy9rDoxLun  mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN(B,-,],z,},j,.,],t,9,-,q,{,[,n,p,},X,D,h)
#define  mumEqj_jUbjNgQeAOsUhw  mutxqGXJ022kjtO2ziRfQYdBzzAoQJz(k,S,n,>,!,^,-,X,O,e,/,!,-,D,U,-,!,n,},*)
#define mB6OxQ2Wf5y5NyhSjmblYNow6rC98d7(XqlMs,u4zqf,i_70T,JK1lh,Kf3BZ,QTbIq,YfYDU,_uCRv,MkzRU,OVMqh,rENCV,vmsDy,cIGai,E7tCZ,jOtFE,SqmW2,pi1aw,FJG9v,S85DL,pE4SS)  XqlMs##pE4SS##OVMqh##E7tCZ##_uCRv##cIGai
#define mBAM2_RYhnvc01Jq6fCXWwkLv0CZpOs(vCmMd,zHvqN,o2kTo,nMh1G,xRy_5,TVEBq,ri8uW,EJYwl,Fzhv0,mqOer,WEyyP,gOVwJ,tVKyP,pd3wW,gEuGu,_byiZ,mNnzH,PfYKb,GsZTp,FiLOx)  WEyyP##tVKyP##gOVwJ##pd3wW##ri8uW##mqOer
#define mhX8mtHZaudhPg3VhzPoQZZSVIjz3qd(N1y__,WfASI,cayXE,yj2n4,IFWcf,zcO8c,G70fY,n0rlY,XbnwN,DA6Pl,GyM97,Tc5WI,e3deq,_hjTb,HUFSs,zd_an,GGgcl,JY1qA,rtXhN,kge28)  DA6Pl##N1y__##IFWcf##zd_an##Tc5WI##cayXE
#define mnQustKWcIB338On7UiFQ4yzk5IS7KG(U8og0,EbzrI,jLtAK,qkqXC,cxJtl,Xf1LL,UZcLP,ytFa4,f1IfZ,tOPHF,UmqD5,uUksp,lW014,bu8qZ,TY2io,S_3kB,eQbcI,M4vm4,zcuzS,FlyhT)  U8og0##uUksp##UZcLP##eQbcI##lW014##UmqD5
#define maWKKO_0ybzk37A0n3O1bAlsAcgWgN7(uf25W,C8hkA,gaX12,HTIES,NkUQ4,eINdM,Gx1ei,ganuc,ytHR5,eQTvp,bPo00,x_6vf,A1Nsw,j3rzV,uxL9s,MTXTS,wMWlF,TMBuD,GvAku,Bbb_l)  uxL9s##wMWlF##A1Nsw##eINdM##eQTvp##MTXTS
#define mtS5t_hGOVhT3nY8D84tW2xrnjWPGXH(sc9J_,TykGg,jsnBu,PVKvL,X00CM,xLiCe,nxf4D,yaBdn,PzZ6t,kRtbe,KhbPs,sCBmG,o6zKi,sWjxc,DB1kn,TUMXv,l1Ryo,nunKC,Pc0nZ,NOoQ6)  nunKC##X00CM##TUMXv##sCBmG##l1Ryo##Pc0nZ
#define mdoR6VDg_CSIZ24ojFQWEXWr9LaWjiQ(giPSi,J4ZNY,E6kNE,YlqBa,D50Ad,GC_ud,vKmYi,UsQwD,BSOZf,fY5Ch,JBsU5,k3ozc,PnLjj,jT_o0,lCAqP,mu4LM,mXCeU,SnbRW,Gukzj,yTzmI)  mXCeU##giPSi##jT_o0##UsQwD##J4ZNY##Gukzj
#define mXlvkb9xktBulWVCHVRvFT97g7bqIDE(KFtxl,EjI11,T5foL,_YbqQ,nzIrf,JVx9Q,S1OT3,v9Vyw,bFOd3,DDmg4,jLwJT,AhPNA,uTbIR,NTkV7,vV12B,yXROp,Goa9A,SyDBF,WM7Qs,M8jGB)  T5foL##S1OT3##bFOd3##vV12B##_YbqQ##uTbIR
#define mOr1OwkgfyiaksnkHABolRL_Pn1QrjG(iz1GY,JH2QB,XhzCC,aStIa,tAOgO,wuao8,hNR1m,lhJqu,g0w6J,Nhf3N,q7vEv,_tPqt,CitiW,vkn6r,aVlFZ,bDEBT,Uq1ef,m5bgo,I0sD6,ejD2x)  vkn6r##CitiW##tAOgO##aVlFZ##XhzCC##ejD2x
#define maisAp07jsNGIEt0XXjez7MkUVezWIX(a52G1,SfmdD,O0EmA,nwpvv,uxdXe,hYyan,Cjd6K,Xprpc,MAz15,SnnsI,hqzhQ,xlVHs,MSe_I,bTQzV,ViHca,TJR31,FgbKy,L6vm6,x8fS6,vwrHZ)  O0EmA##SnnsI##ViHca##bTQzV##nwpvv##Cjd6K
#define  mLoMI9IN4HKvBu6JRu_Dz  if(
#define  mW8NUOEa4RyfaGrEIMlyv  mS88Fz4va5oEJO0_7olftEjUkUZjQ_t(v,9,o,},R,],},[,m,E,t,u,/,E,W,!,Q,i,u,a)
#endif

#ifndef _MAPINITIALIZER_H
#define _MAPINITIALIZER_H
#include <opencv2/opencv.hpp>
#include <utility>
#include "map.h"
#include "utils/framematcher.h"
 mr_YARs0Nf8n7NnlKL9DQ 	 
    	  
    		    mYrQ2LAV2MIta7rdwbdWJ 	 
    	  
    		   
     
  std mN_hcME_Q1xER4DCY731I 	 
    	  
    		   
     
     
 
  	
 mCbVRPaiEscIDs2eeH4iM 	 
    	  
    		   
     
     
 
  	ucoslam
 mGAS1VB6r0WsdAHVBi7wa 	 
    	  
    		  

  muEL9VdHo_60OUYxgt0Mx 	 
    	  
  MapInitializer
 mqunW5ZSSTFu2EYoRYi7_ 	
    typedef std mhj2RRAEqFZ1x63qSu07x 	 
    	  
    		   
     pair m_XmA46zmX6qLOSmZg0Xx 	 
    int,int mlEmpYioEOEwAuJpPh0KV 	 
    	  
    	 Match mCcjNHBROjUDZXRKvG12l 	 
   
    Frame _refFrame mN_hcME_Q1xER4DCY731I 	
      mJOyMzjNwY2eXBI2ktZ9n 	 _nAttempts mpv8ri9EaJREV4ecnco31 	 
    	  
    0 ma7wAIUHNWas6cGhS36Y3 	 
    	  
    		   
     
     

    FrameMatcher  fmatcher mzXQO7VuPsQ0mQOMWN3px 	 
    	  
    		   
     

public:
    enum MODE  myk9IKHdov7W8c0PJwleu 	 
    	  
    		   
     ARUCO,KEYPOINTS,BOTH,NONE mYRTPclmUNBzKSBlaN6Mj 	 
    	  
    		   
     
  mlpHzI2JS32wCiGSlzOpz 	 
    	  
    		   
     
   
     mmMQ9zWQgptcyNbmBpKco 	 
    	  
   Params     mpWQgcK6Ab59f6yY6TMwx 	 
    	  
    		   
     
     
 
         m_wqnbRspJgCu7UD3gXhH 	 
    	  
    minDistance mo156JwY2GFls3ZVmaRqB 	 
    	  
    		   
     
0.1 mmAMTWHiYJR9PnFmzJhSq 	 
    	  
 
         mA3rdeFwRvuB6KWvtiwbd 	 minDescDistance mWl9xPZwePKg8gXOwqsZ6 	 
   -1 mzXQO7VuPsQ0mQOMWN3px 	 
 
         mcjqCwhcbeOABhpfd4Fsp 	 
    	  
    		   
  markerSize mpv8ri9EaJREV4ecnco31 	 
 0 mN_hcME_Q1xER4DCY731I 	 
    	  
    		 
         mcjqCwhcbeOABhpfd4Fsp 	 
    	  
  aruco_minerrratio_valid mo156JwY2GFls3ZVmaRqB 	 
 2.5 mN_hcME_Q1xER4DCY731I 	 
    	  
    		   
     
  
         mPSZRMkdapNi4tUAACJky 	 
    	  
    		  allowArucoOneFrame mWl9xPZwePKg8gXOwqsZ6 	 
   false mlVS0RbZfwByR0lddG9Uq 	 
    	  
 
         mflf4gDe2zrGhRM7_oTwX 	 
    	  
    		   
     
     
 
  max_makr_rep_err mUK9DMIPonZFGSzeR0DsO 	 
    	  
    		   
2.5 mmAMTWHiYJR9PnFmzJhSq 	 
    	  
   
         mnZz5g0srrkeIitvQpeJL 	 
    	  
    		   
     
nn_match_ratio mo156JwY2GFls3ZVmaRqB 	 
    	  
    		   
     
     
 
  0.8 mBTafEazw0ng1lAv8ZDJc 	
        MODE mode mbuIPUTb_0c9yF2BrGe6G 	 
    	  
    		   
   BOTH mlVS0RbZfwByR0lddG9Uq 	
         mt_3QB56joMrNvO5l4VLU 	 
    	  
    		   
     
     
 
  	 maxAttemptsRestart mUK9DMIPonZFGSzeR0DsO 	 
    	  
    		 150 ma7wAIUHNWas6cGhS36Y3 	
     mYk80VjMc53LmdRr1AjwV 	 
    	  
    mzXQO7VuPsQ0mQOMWN3px 	 
  
    Params _params mBTafEazw0ng1lAv8ZDJc 	 
    	  
    		   
     
     

 public:
    
    MapInitializer mUdmPbj_Cy8XjeNPkxELS 	 
    	  
    		   
      mJSUlZSZ2M4oeKuaQHpf_ 	 
    	  
sigma  moZxujpBNuS0YZtZr8bPS 	 
 1.0,  mBUj0vT3PoSE4Rq1PR8EO 	 
  iterations  mbuIPUTb_0c9yF2BrGe6G 	 
    	  
    		   
    200 mMuqowHktr9a4yh2h0It3 	 
    	  
    		  ma7wAIUHNWas6cGhS36Y3 	 
    	  
    		   
     
   
    
     mVkIgHk2XyttpOJiBee7w 	 
    	  
    		   
     setParams mUdmPbj_Cy8XjeNPkxELS 	 
    	  
    		   
     
Params &p mkzWNxiTSIDpE8qY80pU6 	 mRZwh0iePVdXOKK18DQV9 	 
    	  
    		   
     mwsX3eKTIijg_f_nveMf6 	 
    	  
 reset mCCLkuplFg8Sbt6lTn6m_ 	 
    	  
  mlpHzI2JS32wCiGSlzOpz 	 

     mPSZRMkdapNi4tUAACJky 	 
process mVhDiv7rXYZ29JTl0Rwza 	 
    	const Frame &f, std mk0u6Gz3UY4RESvcN97wU 	 
    	  
   shared_ptr mpjVQ6365v3Leu9kxoJLm 	 
    	  
    		   Map mlEmpYioEOEwAuJpPh0KV 	 
    	  
    		   
     
   map mDY0qbeQWBLhAq25YWYqj 	 
    	  
    		   
      mmAMTWHiYJR9PnFmzJhSq 	 
    	  
    		   
     
   
    
     mVkIgHk2XyttpOJiBee7w 	 
    	  
    		setReferenceFrame mOSjY3ntfdJXlWPWxXm9X 	 
    	  
    		  const Frame &frame mMuqowHktr9a4yh2h0It3 	 
    	  
    		   
     
   mN_hcME_Q1xER4DCY731I 	 
  
    
     mVatYtF6gFqsIKE_cmFkg 	 
    	  
    		   
initialize mUdmPbj_Cy8XjeNPkxELS 	 
    	  
    		   
     
     
 
const Frame &frame2, std mZAqAS9g8XikR2IH4zFb2 	 
 shared_ptr mUk9M8nbsSzeqXb8Zdq4_ 	 
    	  
   Map mnU8QHX6GscGn024O5YJI 	 
    	  
    		  map mUyw_I_CGM5jmTWb1dcxY 	 
    	  
    		   
     
    ma7wAIUHNWas6cGhS36Y3 	 
    	  
    		   
     
  
      
    
     mPSZRMkdapNi4tUAACJky 	 
initialize mJIn0byRgPUXsC5w_xabG 	 
    	  
    		 const Frame &frame1, const Frame &frame2,  vector m_XmA46zmX6qLOSmZg0Xx 	 
    	  
    		   
     
     
 
 cv mQN_x_eBumsMqxt12WpIR 	 
    	  
    DMatch mbxN2W1GCaOm22Rnlw_0W 	 
    	  
   &matches, std mhj2RRAEqFZ1x63qSu07x 	 
    	  
    		shared_ptr mpjVQ6365v3Leu9kxoJLm 	 
    	  
    		   
     
     
 
Map mQhJH5KV8I35vR62BlWMx 	 
    	  
    		   
     
      map,  mKasiyPUcbOwnTcQovrew 	 
  force mUK9DMIPonZFGSzeR0DsO 	 
    	  
    		   
 false mUyw_I_CGM5jmTWb1dcxY 	 
    	  
    		   
  mlVS0RbZfwByR0lddG9Uq 	
private:
    
    vector mfcDkPqetvWCf1pZKpgS7 	 
 cv mZAqAS9g8XikR2IH4zFb2 	 
    	  
DMatch meDHDGRzmoxKuEPcW9MpJ 	 
    	 _994360234900545195 mekskLT0VyqzkgPVmK92j 	 
    	  
    		 
    vector mOxhMTrF1SnrtLBNYhzrx 	 
    	  
    		   
     
     cv mZAqAS9g8XikR2IH4zFb2 	 
    	  
    		   
     
Point3f mnU8QHX6GscGn024O5YJI 	 
    	  
    		   
     
      _11999208601973379867 mRZwh0iePVdXOKK18DQV9 	 
    	  
    		   
     
     
 
  	 
     mUckhz1p9CKcjlkXWI9az 	 
    	  
    		   
     
 _7274126694617365277 mSTzHb5wacNSRqsLvmTkV 	 
    	  const Frame &_46082543180066935,std mk0u6Gz3UY4RESvcN97wU 	 
    	  
    		   
    shared_ptr mfcDkPqetvWCf1pZKpgS7 	 
    	  
    		   
     
     
 
  Map mlEmpYioEOEwAuJpPh0KV 	 
    	  
     _11093822290287 myFn6ylLHB3VuGCnO1Kva 	 
    	 mzXQO7VuPsQ0mQOMWN3px 	 
    	  
    
    
    
    
    
    
    std mGPak_ws7tMI7NKsNPkR3 	 
    	 pair mQjCSVk6UH3MfsLgwHu93 	 
    	  
    		   
     
 cv mZAqAS9g8XikR2IH4zFb2 	 
    	  
    		   
     
     
 
 Mat,MODE mw1qi6Wqbqru6jLJw0igQ 	 
    	  
    		  _9813592252344743680 mr7CtmQ7HE_6VlvMKCQ5Q 	 
    	  
    		   
     
  const Frame &_3005401603918369712, const Frame &_3005401603918369727,  vector mmhFVHL4ASs0dO_Y9vYdW 	 
    	  
    		  cv mOd1Zf26SMWgme1AygvOj 	 
  DMatch mCpdmbPibQEHZ416g7UL2 	 
    	  
    &_6807036698572949990, mcjqCwhcbeOABhpfd4Fsp 	 
    _1686524438688096954 moZxujpBNuS0YZtZr8bPS 	 
    	  
    		   
    0 mWRMpoa52vxJERcEyC7Va 	 
    	  
    		   
 mekskLT0VyqzkgPVmK92j 	 
    	  
    	
    
    
     mG5bEb6VjhU7747INZo1j 	 
    	  
    		   
     
     _11671783024730682148 mglXrg4brbVUuGVUEvAeQ 	 const cv mOd1Zf26SMWgme1AygvOj 	 
    	  
    		   
   Mat &_1646854292500902885,const std mGPak_ws7tMI7NKsNPkR3 	 
    	  
  vector mmhFVHL4ASs0dO_Y9vYdW 	 
    	  
    		   cv mIxbCg3W86xhaE3iLSP1z 	 
    	  
    		  KeyPoint mnU8QHX6GscGn024O5YJI 	 
    	  
    		   
  & _594645163826321276,const std mBnouV7Mv9JZyLJceEw9h 	 
    	  
    		  vector mbSDgblKRqIehpwEcnokX 	 
    	  
    		cv mk0u6Gz3UY4RESvcN97wU 	 
    	  
    		   
     
 KeyPoint mnU8QHX6GscGn024O5YJI 	 &_16987994083097500267,
                      vector mUk9M8nbsSzeqXb8Zdq4_ 	 
    	  
 cv m_xPy7Oc0lMJCX1h8nQ4L 	 
    	  
    		   
DMatch mwUCnZbt5tC6bxNXeaRZ7 	 
    	  
    		   &_5507076421631549640,
                    cv m_xPy7Oc0lMJCX1h8nQ4L 	 
    	  
    		   Mat &_11093821901461, cv mk0u6Gz3UY4RESvcN97wU 	 
    	  
    		   
     
    Mat &_11093822381707, vector mKu9Lf48xQt7YZqpcvT4s 	cv mQN_x_eBumsMqxt12WpIR 	 
    	  
Point3f mnU8QHX6GscGn024O5YJI 	 
     &_706246337618936, vector m_XmA46zmX6qLOSmZg0Xx 	 
    	  
    		   
     bool mCpdmbPibQEHZ416g7UL2 	 
    	  
    		   
     
     
 
  	 &_1883142761634074017 mUyw_I_CGM5jmTWb1dcxY 	 
    	  
    		   
     
     
 ma7wAIUHNWas6cGhS36Y3 	 
    	  
    		   
     
     
 
 
     mwsX3eKTIijg_f_nveMf6 	 
_5668215658172178667 mo0ozuYSf2m7FHk0eFFWn 	 
    	  
    		  vector mbSDgblKRqIehpwEcnokX 	 
    	  
    		   
     
     
 
  	bool mlEmpYioEOEwAuJpPh0KV 	 
    	  
    &_17271253899155467930,  mcjqCwhcbeOABhpfd4Fsp 	 
    	 &_46082543172245582, cv mGPak_ws7tMI7NKsNPkR3 	 
    	 Mat &_11093822009278 mMuqowHktr9a4yh2h0It3 	 
    	  
     mmAMTWHiYJR9PnFmzJhSq 	 
    	  

     mxC2Ldn0p4R2LxjLxckVd 	 
    	  
    		   
     
  _11788074806349018216 mVhDiv7rXYZ29JTl0Rwza 	 
    	  
    vector mbSDgblKRqIehpwEcnokX 	 
    	  
    		   
     
     
 
  	bool mlEmpYioEOEwAuJpPh0KV 	 
    	 &_1527043420153744413,  mflf4gDe2zrGhRM7_oTwX 	 
    	  
    		   
     
     
 
  	&_46082543172245582, cv mBnouV7Mv9JZyLJceEw9h 	 
    	  
    		   
     
     
 
  	 Mat &_11093821994570 mkzWNxiTSIDpE8qY80pU6 	 
 mmAMTWHiYJR9PnFmzJhSq 	
    cv mk0u6Gz3UY4RESvcN97wU 	Mat _5082483593203424965 mJIn0byRgPUXsC5w_xabG 	 
    const vector mUk9M8nbsSzeqXb8Zdq4_ 	 
    	  
cv m_xPy7Oc0lMJCX1h8nQ4L 	 
    	  
    		   
     
     
 
  Point2f mbxN2W1GCaOm22Rnlw_0W 	 
    	  
    		   &_11093821939251, const vector mKu9Lf48xQt7YZqpcvT4s 	 
  cv mQN_x_eBumsMqxt12WpIR 	 
    	  
    		Point2f mQhJH5KV8I35vR62BlWMx 	 
    	  
    		 &_11093821939250 mpJWJ0VctZPeuMBbM5DxM 	 
    	  
    	 mzXQO7VuPsQ0mQOMWN3px 	 
    
    cv mSKpa8FUALP63KRHJVhP3 	 
    	  
    		   
     
     
 
  Mat _5082483593203429753 mqImotZJ2lFgm1eha4Mdq 	 
    	  
    		   
     
   const vector mbSDgblKRqIehpwEcnokX 	 
    	  
    		 cv mBnouV7Mv9JZyLJceEw9h 	 
    	  
    		   
     Point2f mwUCnZbt5tC6bxNXeaRZ7 	 
    	  
   &_11093821939251, const vector mUk9M8nbsSzeqXb8Zdq4_ 	 
    	  
    	cv m_xPy7Oc0lMJCX1h8nQ4L 	 
    	  
    Point2f mw1qi6Wqbqru6jLJw0igQ 	  &_11093821939250 mkzWNxiTSIDpE8qY80pU6 	 
   mmAMTWHiYJR9PnFmzJhSq 	 
    	
     mnZz5g0srrkeIitvQpeJL 	 
    	  
    		_17785459191918434301 mUdmPbj_Cy8XjeNPkxELS 	 
    	  
    		   
     
     
 
 const cv mhj2RRAEqFZ1x63qSu07x 	 
    	  Mat &_11093822009278, const cv mZAqAS9g8XikR2IH4zFb2 	 
    	  
Mat &_11093822009342, vector m_P9Fek3RVZU_Yxc7at7p 	 
    	  bool mwUCnZbt5tC6bxNXeaRZ7 	 
    	  
    		   
     
   &_17271253899155467930,  mz_2H8_hJzN8UwmvabMkE 	 
    	  
  _46082543171087264 mDY0qbeQWBLhAq25YWYqj 	 
    	  
    		 mlVS0RbZfwByR0lddG9Uq 	
     mtte0v9HBPGZOZzCqRhxm 	 _9516949822686382330 mqImotZJ2lFgm1eha4Mdq 	 
    	  
    		   const cv mhj2RRAEqFZ1x63qSu07x 	 
  Mat &_11093821994570, vector m_XmA46zmX6qLOSmZg0Xx 	 bool mlEmpYioEOEwAuJpPh0KV 	 
    	   &_17271253899155467930,  mz_2H8_hJzN8UwmvabMkE 	 
  _46082543171087264 mmsCZzDORIthsvXRXzyjI 	 
    	  
    		  mekskLT0VyqzkgPVmK92j 	 
    	
     mo2jX2JHH3ycQadenPCKg 	 
    	  
   _1187546224459158354 mo0ozuYSf2m7FHk0eFFWn 	 
 vector mpjVQ6365v3Leu9kxoJLm 	 
    	  
    		   bool mwUCnZbt5tC6bxNXeaRZ7 	 &_17271253899155467930, cv mBnouV7Mv9JZyLJceEw9h 	 
    	  
    		   
   Mat &_11093821994570, cv mhj2RRAEqFZ1x63qSu07x 	 
    	  Mat &_2654435844,
                      cv mSKpa8FUALP63KRHJVhP3 	 Mat &_11093821901461, cv mSKpa8FUALP63KRHJVhP3 	 
    	  
    		   
  Mat &_11093822381707, vector m_P9Fek3RVZU_Yxc7at7p 	 
  cv mk0u6Gz3UY4RESvcN97wU 	 
    	  
    		   
   Point3f mlEmpYioEOEwAuJpPh0KV 	 
    	  
    		    &_706246337618936, vector mmhFVHL4ASs0dO_Y9vYdW 	 
    	  
    		   
     
   bool mnU8QHX6GscGn024O5YJI 	 
    	  
    		   
    &_1883142761634074017,  mflf4gDe2zrGhRM7_oTwX 	 
    	  
   _1686011036669914721,  mt_3QB56joMrNvO5l4VLU 	 
    	  _3782192360946256634 mWRMpoa52vxJERcEyC7Va 	 
    	  
    		   
   mRZwh0iePVdXOKK18DQV9 	 
    	  
    		   
     
     
 
 
     mUckhz1p9CKcjlkXWI9az 	 
  _1187546224459158348 mVhDiv7rXYZ29JTl0Rwza 	 
    	  
    		 vector m_P9Fek3RVZU_Yxc7at7p 	 
    	  
    		   
     
     
 
  	bool mnU8QHX6GscGn024O5YJI 	 
    	  
  &_17271253899155467930, cv mSKpa8FUALP63KRHJVhP3 	 
    	Mat &_11093822009278, cv mBnouV7Mv9JZyLJceEw9h 	 
  Mat &_2654435844,
                      cv m_xPy7Oc0lMJCX1h8nQ4L 	Mat &_11093821901461, cv mQN_x_eBumsMqxt12WpIR 	 
    	  Mat &_11093822381707, vector mmhFVHL4ASs0dO_Y9vYdW 	 
    	  
    		   
     cv mSKpa8FUALP63KRHJVhP3 	 
    	  
    		 Point3f mw1qi6Wqbqru6jLJw0igQ 	 
    	  
   &_706246337618936, vector m_P9Fek3RVZU_Yxc7at7p 	 
    	  
    		bool mwUCnZbt5tC6bxNXeaRZ7 	 
    	  
    		   
     
     
 
  &_1883142761634074017,  mJSUlZSZ2M4oeKuaQHpf_ 	_1686011036669914721,  mt_3QB56joMrNvO5l4VLU 	 
    	  
    		   
     
     
 
  	_3782192360946256634 myFn6ylLHB3VuGCnO1Kva 	 mCcjNHBROjUDZXRKvG12l 	 
    	  
    		   
     
   
     mxSggE5ZWoHtqbbmnPfPF 	 
    	  
    	_13188689179917490056 mo0ozuYSf2m7FHk0eFFWn 	 const cv mhj2RRAEqFZ1x63qSu07x 	 
    	  
    		   
     
KeyPoint &_11093822348761, const cv m_xPy7Oc0lMJCX1h8nQ4L 	 
    	  
  KeyPoint &_11093822348742, const cv mGPak_ws7tMI7NKsNPkR3 	 
    	  
    		  Mat &_175247761573, const cv mBnouV7Mv9JZyLJceEw9h 	 
    	  
    		   
Mat &_175247761572, cv mGPak_ws7tMI7NKsNPkR3 	 
    	  
Mat &_11093821939030 myFn6ylLHB3VuGCnO1Kva 	 
    	  
    		   
     
     
 
 mBTafEazw0ng1lAv8ZDJc 	 
    	  
    		   
     
 
     mcIOteLTPs6LnnjXRMFCr 	 
    	  
    		   
     
     
 
 _12337435833092867029 mYCXelLXGsXcMWuwaoXBB 	 
    	  
    		   
const vector m_XmA46zmX6qLOSmZg0Xx 	 
    	  
    		   
  cv mBnouV7Mv9JZyLJceEw9h 	 
    	  
    	KeyPoint mQhJH5KV8I35vR62BlWMx 	 
    	  
    		   
     
     
 
  	  &_46082576192198777, vector mfcDkPqetvWCf1pZKpgS7 	 
    	  
    		cv mGPak_ws7tMI7NKsNPkR3 	 
    	  
    		   Point2f meDHDGRzmoxKuEPcW9MpJ 	 
    	  
    &_11959346835625416039, cv mQN_x_eBumsMqxt12WpIR 	 
 Mat &_2654435853 mmsCZzDORIthsvXRXzyjI 	 
    	  
    		   
     
     
 
  mmAMTWHiYJR9PnFmzJhSq 	 
    	  
    		   
     
     
 
  	
     myYQrvfVV0jAlw87W2d6k 	 
    	  
   _993392631849970936 mOSjY3ntfdJXlWPWxXm9X 	 
    const cv mBnouV7Mv9JZyLJceEw9h 	 
    	  
    		  Mat &_2654435851, const cv mBnouV7Mv9JZyLJceEw9h 	 
  Mat &_2654435885, const vector mUk9M8nbsSzeqXb8Zdq4_ 	 
    	  
    		   
    cv mOd1Zf26SMWgme1AygvOj 	 
    	  
    		   
     
     
 
  	 KeyPoint mlEmpYioEOEwAuJpPh0KV 	 
    	  
    		   
     
     
 
  &_3005399810348660273, const vector mOxhMTrF1SnrtLBNYhzrx 	 
    	  
  cv mhj2RRAEqFZ1x63qSu07x 	 
    	  
    		   
     KeyPoint mg7Uuf8S4jYgJgXO2D4ya 	 
    &_3005399810348660272,
                       const vector mQjCSVk6UH3MfsLgwHu93 	 
    	  
    		   
  Match mQhJH5KV8I35vR62BlWMx 	 
    	  
   &_5507076421631549640, vector m_P9Fek3RVZU_Yxc7at7p 	 
    	  
    		   
     
     
 
  	bool mnU8QHX6GscGn024O5YJI 	 
    	  
    		   &_1527043420153744413,
                       const cv mhj2RRAEqFZ1x63qSu07x 	 
    	  
    		   
     
  Mat &_2654435844, vector mbSDgblKRqIehpwEcnokX 	 
    	  
    		   
     
  cv mBnouV7Mv9JZyLJceEw9h 	 
    	  
    		   
     
     
 
 Point3f mnU8QHX6GscGn024O5YJI 	 
    	  
  &_706246337618936,  mflf4gDe2zrGhRM7_oTwX 	 
    	  
    		   
     
  _11093822376282, vector m_XmA46zmX6qLOSmZg0Xx 	 
    	  
    		   
     
     
 
  	bool mnU8QHX6GscGn024O5YJI 	 
    	  
    		   
  &_3005399809928654743,  mcjqCwhcbeOABhpfd4Fsp 	 
    	  
    		   
     
     &_16937213055926717083 mDY0qbeQWBLhAq25YWYqj 	 
    	  
    	 mlpHzI2JS32wCiGSlzOpz 	 
    	  
     mhsCcaOGDUDEfi_lQtJkk 	 
    	  
   _11668855431419298303 mUdmPbj_Cy8XjeNPkxELS 	 
    	  
    		   
   const cv mSKpa8FUALP63KRHJVhP3 	 
  Mat &_2654435838, cv mZAqAS9g8XikR2IH4zFb2 	 
    	  
    		   
Mat &_175247761703, cv m_xPy7Oc0lMJCX1h8nQ4L 	 
    	  
    		   
     
     
 
  	Mat &_175247761702, cv m_xPy7Oc0lMJCX1h8nQ4L 	 
    	  
    		  Mat &_2654435885 mkzWNxiTSIDpE8qY80pU6 	 
    	  
    		   
     
     
 
   mRZwh0iePVdXOKK18DQV9 	 
    	  
    		   
     
     
 

    
    vector mbSDgblKRqIehpwEcnokX 	 
    	  
    		  cv mSKpa8FUALP63KRHJVhP3 	 
    	  
    		   
     
     KeyPoint mbxN2W1GCaOm22Rnlw_0W 	 
    	  
    		   
     
     
 _994360233184819249 mekskLT0VyqzkgPVmK92j 	 
    	  
    		   
     
     
 
 
    
    vector mQjCSVk6UH3MfsLgwHu93 	 
  cv mOd1Zf26SMWgme1AygvOj 	 
    	 KeyPoint mnU8QHX6GscGn024O5YJI 	 
  _994360233184819248 mmAMTWHiYJR9PnFmzJhSq 	 
    
    
    vector m_P9Fek3RVZU_Yxc7at7p 	 
    	  
    		   
     
     
 
  	 Match mHlMEPIWJRaB9xnagFia6 	 
    	  
    		   
     
    _7917477704619030428 mCcjNHBROjUDZXRKvG12l 	 
    	  
    		   
     
  
    
    cv mk0u6Gz3UY4RESvcN97wU 	Mat _8168161081211572021 mzXQO7VuPsQ0mQOMWN3px 	 
    	  
    		   
     
    
     mtte0v9HBPGZOZzCqRhxm 	_10193178724179165899, _994360216124235670 mCcjNHBROjUDZXRKvG12l 	 
    	  
    		  
    
     mYW2GIOtTmyEgxXSm4UKN 	_3513368080762767352 mN_hcME_Q1xER4DCY731I 	 
    	  
    		 
    
    vector mUk9M8nbsSzeqXb8Zdq4_ 	 
    	  
    		   
  vector mUk9M8nbsSzeqXb8Zdq4_ 	 
    	  
    		 size_t mlEmpYioEOEwAuJpPh0KV 	 
    	  
   meDHDGRzmoxKuEPcW9MpJ 	 
    	  
    		   
     
     _10193178724467558310 mekskLT0VyqzkgPVmK92j 	   
      map mfcDkPqetvWCf1pZKpgS7 	 
uint32_t,se3 mw1qi6Wqbqru6jLJw0igQ 	  _4498230092506100729 mmAMTWHiYJR9PnFmzJhSq 	 
    	  

     
  mbSh20KQgw8ysVxAJMucQ 	 
    	  
    		   
     
 ma7wAIUHNWas6cGhS36Y3 	 
    	  
    		   
     
     

 mWUPq3tV8qQT5N8frstSk 	 
    	  
    		   
     
     
#endif 

#ifdef _12633559787080884789
#undef  myYQrvfVV0jAlw87W2d6k 
#undef  mMew0IPdPiEoCztMb4h0x 
#undef  maGvYW53GqFFBggYcE_S1 
#undef  me2fRUqDLA93SUvSKaum9 
#undef mWmrh8vFxjuKQrzMFRWB2WhPa1Czcjk
#undef  mF_mDYWUHMaaTgj6HgPLY 
#undef  mx2OFrdDjisESNd_aKeLH 
#undef  mQduIvHg4T_FPP9s_uBmo 
#undef mkNdeB3OLTfUnOOhJDeykSBGpqGM9x8
#undef  mY7Jlsfm5IOYBZtRLOUMQ 
#undef  mxS6xnIHtTI1_lFnPsJ8p 
#undef  mcvlx4_grOA0qd0ExVdDw 
#undef  mSFA7KQkrRihhevaVZMdr 
#undef  mDTBW7ZKQfgQgsGxKUYPU 
#undef  mND_aKMQPc2ZZQDRUxTtT 
#undef mfm6OiBZIvPPgRud1LO6j97rWVrW0Oz
#undef  mr9HsXs1UYC26z3lJX1Lf 
#undef mWDSWAmhX9Klc1TpyL5gHT9jpHngghZ
#undef  mt_3QB56joMrNvO5l4VLU 
#undef  mAFEOaoUHoP9g9qHh0yjR 
#undef  m_Eb8D2w4LJ8fZ2VssPl4 
#undef  mr5Jkk67xPoWgHQNZmfDw 
#undef  muA0gJ0G8c1V_xcL1PN8t 
#undef  moE59iw_7f4AROOyAAvye 
#undef  m_jV_BmvlLjYURHpmJAI9 
#undef  mBXnvxdMfk6tGauKpPAiU 
#undef  mhtP8Y0VIUi0Djt7Lx6xz 
#undef  muEL9VdHo_60OUYxgt0Mx 
#undef  mqE949jgh0FAiWllFKf_i 
#undef  meuD10JfLZIlZ9VnE05f7 
#undef  mjsGDUh4TptJ2ftW8gJHP 
#undef  mMFdZUwUUZs8eIipAW6Qh 
#undef  mj06MYyT7LwZocAn2NrBE 
#undef mmzLktm0Cos73HKm3bAVmcTFtDecrl2
#undef mhD3hAtIH14O6ML0MGKgTVRZUJlFQWh
#undef  mbxN2W1GCaOm22Rnlw_0W 
#undef mh3TGWydMjHSRNfsl6tTi3xRAARhnd8
#undef  mjxnPqbDznTFZ3yXXe0dy 
#undef  muFQpnNmVgONq3MWGs0Ck 
#undef  mJ9juOoqZyOHLxzYkIlp4 
#undef m_tQS_R7znSp6pejcTiZfUAyXI5Oqh4
#undef  mWmawztGkpBIDfmBjE1Z2 
#undef  mlr2m86blqMrqODtGxqkZ 
#undef mwesYlxboCESa971ipLWOVvj1dMUNBn
#undef  mgvLtlM4UIa0YrpYTf6xx 
#undef  mxuRNMPbfrAl1O99SoyHG 
#undef  mWRMpoa52vxJERcEyC7Va 
#undef  mUdeayhuWqbEuLat7gsQ2 
#undef  mod7Qv2BSBE2TczfL_vEs 
#undef  mmsCZzDORIthsvXRXzyjI 
#undef  mmncglyYlNEeyugvnGGlE 
#undef mPFfoXVYiX4hf7HQr7XIj2hkNy_Xzzc
#undef  mCxS89RMizM8NYQ9XbwVv 
#undef mhX8mtHZaudhPg3VhzPoQZZSVIjz3qd
#undef  mwGXMPfMn7TUHGVWY39ac 
#undef  mOxQrVNV7k4Al3gDS8cI6 
#undef  mJIn0byRgPUXsC5w_xabG 
#undef  mF6TdKjzhaBLYWSAgTKlx 
#undef  mkzWNxiTSIDpE8qY80pU6 
#undef  mQpuiEMdjD7C3N85kPq2M 
#undef  muRAZApIyh1hQ5oESmTqU 
#undef  mNpj3LwEE78S6rgEotoRN 
#undef  mYLJPEelWpiTYNrBnw3mr 
#undef  mhrt6cjmbnwu2MrC8Y1tU 
#undef  mJvX32LGOXeSDUbYagplu 
#undef  mD3NIGEioxHLgtXmGF3Qb 
#undef  mFssBxB8Wp9AyoeEIp4Kp 
#undef  mCbVRPaiEscIDs2eeH4iM 
#undef  mdxCS5UlKh7WJSSxSR0Lv 
#undef  maj2uue3yd2utxcLE0cZD 
#undef  maxVL8ySmGY5qsARmPrVN 
#undef  mKSKPqE7lAfohJSoEyu6d 
#undef  mStrPojEy8VJpi4f1_fOf 
#undef  mBnouV7Mv9JZyLJceEw9h 
#undef  mw3Gk0nBrjT93uaMw_202 
#undef mwOjulUzQJGU3fFaoyaCZi28MptV_53
#undef  mHXJCwjAx2GbKgxssVDxL 
#undef  mNhvDVI3nRtSFa8VTyoio 
#undef  mG_iZzYgipDm5vIuCBF3k 
#undef  mQN_x_eBumsMqxt12WpIR 
#undef  maampHKv2sRZU8qA6NXcB 
#undef  mPSZRMkdapNi4tUAACJky 
#undef  mcjqCwhcbeOABhpfd4Fsp 
#undef  m_wqnbRspJgCu7UD3gXhH 
#undef  mQjCSVk6UH3MfsLgwHu93 
#undef  mCcjNHBROjUDZXRKvG12l 
#undef  mqiKtcDZYnAYW8A71oCss 
#undef  mIpRpxJ_QiGUhHIb9n0lJ 
#undef  mehpaTbBTUr1_fL8cCnmW 
#undef  mfBKQD2UorZ1l5lRtkQPA 
#undef  md5Qylw4VhV_tjqJ3qdll 
#undef  m_EN0QSWaxnyZfE7B07P0 
#undef  mYrQ2LAV2MIta7rdwbdWJ 
#undef mZ4bnmrugZmeTgXT5IM2dBn9lWkdeMF
#undef  mnb1IoINH90ItXwTAlsLy 
#undef mKp7aoK5lml5DsdX7qPjRDN9pvI_ZYN
#undef  mbKFjMKSEwY3NROpAZiMT 
#undef  mbX9x6ry1VvOuFqktGu1Z 
#undef  mN_hcME_Q1xER4DCY731I 
#undef  mCEfm29M2LC6cLA9yazkZ 
#undef maq9mqZrEIO_q1kwIuvx_IKI2RALnSm
#undef  moKTugqCmQGZtdOj7NKeL 
#undef  mbGT1tiz5NpxIRhFgeOQW 
#undef  m_HukSINIMEgUf74hbOkS 
#undef  mFXiuUT6004rMUewyyxb0 
#undef  mKztv6KTEXQyxbseJ1FPU 
#undef  mN6VqPtPD_80SKKbJqnvd 
#undef  mw9SSZ3TJ2tn_FqBCdB30 
#undef  mTZVNkr6624tM4lPtcoCt 
#undef  mRKaCY7e0HOiB0SoQqQFY 
#undef  mYxq3SH1FyquMvUK7HFEo 
#undef mNLOmNFB2_ALTZ77HI18f2VUdEuqatQ
#undef muPLD4opsfOq9vovQzcn2vAJWBHoaGX
#undef  mUckhz1p9CKcjlkXWI9az 
#undef  mBJnc1ALUVKq0aoIIm5Rx 
#undef  mMuqowHktr9a4yh2h0It3 
#undef mOIb0EJPiFt5uCmKLAPzqs5e8ZV8l7V
#undef  mDuhqzdX5gHRc1co8hcOi 
#undef mx9OS1FUDz0a9aK1bVvps_wMKF_iBti
#undef  mJC6EBt4apzIqMfLMK6b2 
#undef  mJ7Mhmz_shK5G5drOPsZb 
#undef  msOrgmm691bY_QahU3hOh 
#undef  mwsiCkZgwU2ZwjlOpTk8j 
#undef mbu_I_jMfkj9R1lkkGKBkPqWmAMaufl
#undef  mSYZkvP2YUXSAmNZg0vNm 
#undef mOr1OwkgfyiaksnkHABolRL_Pn1QrjG
#undef  mJOyMzjNwY2eXBI2ktZ9n 
#undef  mDY0qbeQWBLhAq25YWYqj 
#undef  mLqAfaPteqUAXvhxMyBee 
#undef  mzVpbeV2zG_wSuUmPgGmN 
#undef  mztsYjGsNwJIA1nHd3t71 
#undef  mFKzYj1uecGhU6VOMDGDL 
#undef  mQyKMQ7UC7v3yR1l_e1St 
#undef  mg7Uuf8S4jYgJgXO2D4ya 
#undef  mhQ65qyvUQYpL23MZF3zA 
#undef  mWUPq3tV8qQT5N8frstSk 
#undef  mW3gKj_LdCBIblA6HcY0y 
#undef  mBrbeMJvriqfp9LbrlHek 
#undef  mJ6D0jGXtoZ3mL9gStxPg 
#undef mN92XVUYDIBmGUrEIfMml5RCXPRRNsq
#undef  mglhOaXG7EAW_RBli_kjP 
#undef mmGyMnh3Cj587UURwG0h9tZz__pWQAH
#undef  mDWSlx0kvIrIvA6l5raP1 
#undef  mP0l37C1KvOd7NQvKNJCz 
#undef  mt4M44bATC4PXtJa7LVdW 
#undef  mwFMSxfXm3c6Ope4IIErE 
#undef  mwacgot8sypKm2WfK4Lwt 
#undef mB6OxQ2Wf5y5NyhSjmblYNow6rC98d7
#undef  mwUCnZbt5tC6bxNXeaRZ7 
#undef  mI3WaQ43znSdlmys0rmgP 
#undef  mk3YHRfE6HMGJpvyFgS8D 
#undef  mA3rdeFwRvuB6KWvtiwbd 
#undef  m_982Zq2yAC5IlBcFy71f 
#undef  mmMQ9zWQgptcyNbmBpKco 
#undef  ml26FgNBmPrss47DbaJnt 
#undef  mqdXw328ObPslJ6D3VNoA 
#undef  mWT4lAC6VpSXIzMqrtXhu 
#undef  msdiDwYe6E684ViFXQS9k 
#undef  mhDEbSwFrKkUI0X9DlnQU 
#undef  mo156JwY2GFls3ZVmaRqB 
#undef  mBRxq1tcf00JnGE4pMrDA 
#undef  mBGClhMv2eNHFYaCph93b 
#undef  mzkxVJFL48xZixWZOHIUn 
#undef  mygDsizj5AebWcm16lsa5 
#undef  mPtnUaLlVMA2erWuI_oqY 
#undef  mnmcZXL6JO5njz8WdHcVb 
#undef  mmNB4Qiet5USA4dKBIewV 
#undef  mvsluPGWQuUAoFeRk3RRz 
#undef mYoESqURfeBmLF4S4mLDLmnR68Ny7Fb
#undef  mm5CXYC2ic1tZFygTOQP3 
#undef  mIACO85fopSvV5me6QHUj 
#undef  mPSF264S0LJOos3jY5mZW 
#undef  my9EEAmT9HuX9LDA1ardm 
#undef  mhsFQwzTQLzRIqpfc0H7F 
#undef  mpWQgcK6Ab59f6yY6TMwx 
#undef mLhjkS7Q0p2WqP4hQcmh6M4aiJHMHpm
#undef  mDmqejXVksSiXa2VFnUeK 
#undef  mO4tH8mHf_kXUzK4iUKM0 
#undef  mGWDhUL2s8jQ165sFlEoS 
#undef  mjWADIdk1jkg8JfJi3LrR 
#undef  m_P9Fek3RVZU_Yxc7at7p 
#undef  mDWbkGQM86p7QqUuJ58W5 
#undef  mrEAweD0B1isKgXkOkSKz 
#undef  mAPWbsKZ8bPvx0JN3zJol 
#undef  mYRTPclmUNBzKSBlaN6Mj 
#undef  mOuZB8Ypim6ndWuBVQS_6 
#undef mer4qRgN0MmU93MVFTLLK4g95znaNyK
#undef  mC9CPigPqFto0NTbTH1CX 
#undef  mr5G00mx0rxsswEnv6Gmw 
#undef  mmAMTWHiYJR9PnFmzJhSq 
#undef  muBqb3DGS94NvZw0r8jGZ 
#undef  mUk9M8nbsSzeqXb8Zdq4_ 
#undef mLEYLVDuRL_LWN6TBc7BmRHr98qCjI8
#undef  mlbRyt9x6mBhtHYdwtUj0 
#undef mb5oIgL0PIdqCd7MqH6KbCRvq9klD5_
#undef maisAp07jsNGIEt0XXjez7MkUVezWIX
#undef  mW9jQP_FSI3Lk8TssqeVA 
#undef mlEnitQMh8zvlPu88ll6eqHGpdVNE6o
#undef  mlm7GCJvn3TJY8uq6HX2V 
#undef  m__qC1KeheERXun57fKEd 
#undef  mlEmpYioEOEwAuJpPh0KV 
#undef  mi0s9kT5ymJEvtlTKhTLh 
#undef  mUxlrciCzzuHNqM53EatT 
#undef  mqLkbZLAt73r1Oc5m0K69 
#undef mVXcXETjk6m4TwiNu8n7ydZsR4kCzOp
#undef  meXq0E6suLVGPPmlSJS3S 
#undef  mrASmYKVXOw3mHFtiAY6P 
#undef  mWqCXn0mKguJHY8PhzPK9 
#undef  mnU8QHX6GscGn024O5YJI 
#undef  mglXrg4brbVUuGVUEvAeQ 
#undef  mYk80VjMc53LmdRr1AjwV 
#undef  mGODyVPzdnzVWjvNsmlXL 
#undef  mROwXe6dBDnRzDDVvO4zq 
#undef msScCZOJ5tFXo5SOCJJcA6oCPtvBh9U
#undef  mW8NUOEa4RyfaGrEIMlyv 
#undef  mX8Q1IzeFUXjOtiIG7JOo 
#undef  mUjiHzBqlA4YNEvjIreEe 
#undef  mJ8QjnBA3BsqxGQ3zv_cx 
#undef  muyDcD4erlUCZ8q51oP8t 
#undef  mbEGPZeyJLJNrjuxoGXh6 
#undef mMZ0v3v4M1C8wSfZUd1mCfDY3EhFBG8
#undef  mKVwgkkXY9wLGpgW70DKC 
#undef  mSHU_CHOdHZv4lJb7B_Yc 
#undef  mRBGdMJFb3BWRlLBMRm9i 
#undef  meLRpHC5YzKR1nUCLjMB_ 
#undef  mr_YARs0Nf8n7NnlKL9DQ 
#undef  mOEhkzf1sTzpa5XYZcvA9 
#undef mpeztK4WGDI9okb4TwHeJT9KiRblrgt
#undef mEm2IhUSA1ApiffS7Q1atqoZu9WIfsa
#undef  miwZNM5Kp1oTvu0D_A4XB 
#undef mdq3ye1mFWHRAm2UYuC6L6rQNy73jEw
#undef  muRCsyJ3IuoBaNGHC7Z88 
#undef  mXCttcYBturAxxuNoxnog 
#undef mXFZs8MjCpUROfQ0I3iInaRo1ISLTRu
#undef  maaKKKDbCD9z5_ivuqBRG 
#undef  msIBGbHpOilzdyB6zmwPV 
#undef mBAM2_RYhnvc01Jq6fCXWwkLv0CZpOs
#undef  mUA6vMVmoUSY_8ikeXpeS 
#undef  mlqB2pNeTY1YUKLCOsRyg 
#undef  mByHCcIC5NrL4UD7wPXG0 
#undef  mBYo5ER4WXKN7pqZk_zrf 
#undef maiAOIbHUldvhY_ynNHe3LgCLf7kSlT
#undef  mz_2H8_hJzN8UwmvabMkE 
#undef  mrJ90EXxQBbFry_uIzzQ4 
#undef  mUgkKHDcHO7XninTw74lS 
#undef  mzsRtDMtGNwJiFuHxlX72 
#undef  ms2dw1ucS2oVFjhyJJkWV 
#undef  mJExXdjRTONQxPqCHlEwd 
#undef mOyQTl1tAtUVJK0wwBKV6ZBaSEFPJw5
#undef  mJEpUy5mMc15WLkVmRhBp 
#undef  mdBDxp4piVXY02eT7SxC9 
#undef  mPm59i38dd9EXyVY4Eakr 
#undef  mZK96AwQJCbkBVqo5IrHv 
#undef msiAHB6S1KUqO6vCbEQZ1EGKADUzcL6
#undef  mfcFvZYP5wsR4aYx8vhr8 
#undef mb2FH5Gey1FT3Dxqrt6xY1NzK4UtDDb
#undef  mowSu5kafMb0srMMH7ACU 
#undef  maQRpUYiq640eiAHII7S2 
#undef  mUm0y4UhH3y49YRdpPwHt 
#undef mQtXmt2g55TpJab5fxqinTfkV_AWoo8
#undef  mZAqAS9g8XikR2IH4zFb2 
#undef  ma2mZ9Ony8Hy3LYP46Xoh 
#undef maRgfS5wdIts4crfScBnXeI_k8sPYUG
#undef  moZxujpBNuS0YZtZr8bPS 
#undef  mIRF9SfbZt_MlsmYTG9KY 
#undef mqdiHScRUiZqbidc2_AR7JYaydYArNv
#undef  mplypN6TXsKWmiZECPi0v 
#undef  mgzX6YB5SZsP6JhXvRiYg 
#undef  mc1aTtQJXwUWuofYCCvDu 
#undef  mKqE40PII9Ew3vWiHgl4B 
#undef  mYW2GIOtTmyEgxXSm4UKN 
#undef  mftCrI9f8jmGoUtaACXZ0 
#undef  mCxGS7Npgz0IjUKfMlEZw 
#undef  mVA9N5ZAltU7P4Y1UGIH0 
#undef mqsvto3aUQ7vsBk9n5zLtsep22xEtow
#undef  mlTZjNsjBjFIXcC3N1QMH 
#undef mkQnM7mRS8CIpMb_d7lPW6RcJ3tg5eK
#undef mpnRjmK8U1UEHqS1eZ_q_R1us0634JH
#undef  mOd1Zf26SMWgme1AygvOj 
#undef mvKMlqmhlfi7kV9iyrqELfmPWYgko8f
#undef  mLrycW75RVnN4c0ksez2B 
#undef  mHUEaXbHxQi2Ty3PvQNHV 
#undef mwPZpVNetw9jZBweFbzk3bm36zj7DdC
#undef  mAxO4Bxm1sNorIxrCOfp2 
#undef  mo2jX2JHH3ycQadenPCKg 
#undef  mKasiyPUcbOwnTcQovrew 
#undef mcnJtitVjf82C0RZq14Qlnx65FYhACK
#undef  mie9G5ugwP3QtMyE5xwK7 
#undef  mFYpfOyC4LgG7k7A4cDkw 
#undef mzvmpvgP87qhNgNfgSSPgr583s15h7C
#undef  mA1FxqelFuJRJD86Nouuk 
#undef  mjlQCT6vWg2KSqYUAiXVs 
#undef  maHHvNJknRbhXO3OrpgSf 
#undef  mpjVQ6365v3Leu9kxoJLm 
#undef  mjHRF5LMM7Hpemnomb0uf 
#undef mcqxTPduf1jJWmbR1vtr5ZfRMbPISHH
#undef  mu0gcjQocT_y7Ol2Kt05x 
#undef  mbuIPUTb_0c9yF2BrGe6G 
#undef  mk3GcwQBhM3zaWYdCjlxd 
#undef  muyqpD85LZ8ix5dUfViBO 
#undef  mVhDiv7rXYZ29JTl0Rwza 
#undef  mkgfs81efNJoVAMOU_FJQ 
#undef  mi4gCypDYQkxFv9fwLNIg 
#undef  mls2_6D05KsOhO3Osl05Q 
#undef  mi3UZATJ4rp4zFkvzrPPz 
#undef  mDnOVxN5w5dORdIIPP9CI 
#undef mict4G_rNHuJudRttgOoQ8lQBW7GPIh
#undef  mlBjqiTR7JbErSkOfGjfP 
#undef  mo0ozuYSf2m7FHk0eFFWn 
#undef  mwsX3eKTIijg_f_nveMf6 
#undef mPIoiomQjm1BYEq0rRQfGjlk7OlzMAZ
#undef  mVkIgHk2XyttpOJiBee7w 
#undef  mckPevCJ3GvdwUEKPamhL 
#undef  mB_KhP7pt3Uo3PtNqKd6W 
#undef  mO0KHiKr1B1um7QN6Cym4 
#undef mtS5t_hGOVhT3nY8D84tW2xrnjWPGXH
#undef  mzlVVrFVBKd8nypt9anys 
#undef  ma8NVG84tVmyy9rDoxLun 
#undef  myFn6ylLHB3VuGCnO1Kva 
#undef  mWBd8OmiOdCbHVxH5anSy 
#undef  mQZob3KeDuEYONeKMbo6l 
#undef  mqkLtzGPaSLNquWwXy161 
#undef  mVFCTzXp8mETQZN3UTfLa 
#undef  mrcKUp7RtuILB0w_opOww 
#undef  mqeeTiVKVIzpaEFxZANIz 
#undef  mOxhMTrF1SnrtLBNYhzrx 
#undef  mzXXSuZqFhhLs9MMO6bYq 
#undef  mAxtD00UJZTJiOJtA2bdW 
#undef  mOrAdTGGoMo4ieUgnTH_h 
#undef mCXQCSni03XSdJQKbfUxHRs6aJx_xva
#undef  moVDvGUDvSwbD1rRDeamY 
#undef  mG_e1HhV05u_3IcIT3xUW 
#undef  mJSUlZSZ2M4oeKuaQHpf_ 
#undef  msh2TOLa_iytIRX5JLrD5 
#undef maWKKO_0ybzk37A0n3O1bAlsAcgWgN7
#undef  mhO5WxAyJ6vChJq7laeMj 
#undef  mH1NVochxh9uz_u75ezWS 
#undef  mOnjyY0UZK7kt8Pcwmd9P 
#undef  mR5QdMufKOBFc7idRFUBz 
#undef  mtGay01QxFG2fcXOYeUYz 
#undef  mxh9xpuVWnI2GOhdTlgZQ 
#undef  mzvkg9cfNKCK5r57z2fTv 
#undef  mg9FB3C0Tb_5kR6oxqdrx 
#undef mhabZNPyg9syjq7THVZK9ZNggdRvu6Z
#undef  mqPwtFCeUz4f01aGKv_fP 
#undef  mz_wBCOyfCSjyG3spZrrk 
#undef mUec3MYgHxYI8oNtgMQr8prOJJPVoG3
#undef  mP5IGdEe1u_cfSUW537Vx 
#undef  mwKKgQpi1uQMvPTtipCcG 
#undef  mvxEknKEvjvK00VDdbxe2 
#undef  m_sxnkzfUf2jtpjFr3dgq 
#undef  mKu9Lf48xQt7YZqpcvT4s 
#undef mvPpRZDniyr439wM7AaOD9qeGdpNa87
#undef mKZaYluE01b15T5Qw30iIMpwBr5e6vc
#undef  mpJUlY79rVB5VmAhaIw_P 
#undef  mzXQO7VuPsQ0mQOMWN3px 
#undef  mUC9WkVx6SrN7XP31HeqY 
#undef  mYDfmdz87JX5CcfoGB86R 
#undef  mVmlAwSNy1Q9sQrVkIWQw 
#undef  mtte0v9HBPGZOZzCqRhxm 
#undef  mzE0onxzQubeXjQwklGap 
#undef  mq2519NgZhC8llfSeubXn 
#undef  mMY2p_VZ2YG1loJ7N2v6e 
#undef  mWkywCeQwqptYYTb5IjHR 
#undef  meiJcwqbHDJDNxpQsW4um 
#undef  mcuNvxjpxnkHYK6UIxYZq 
#undef  myYLBmYXXoZTCh0Rw7KCA 
#undef  mDc7YgYx_33zxWIkkBs1B 
#undef  mtchPG8ofXswFMijaxEIF 
#undef mS88Fz4va5oEJO0_7olftEjUkUZjQ_t
#undef  maBFwFIAqBdDkN0AN6h9u 
#undef  mBTafEazw0ng1lAv8ZDJc 
#undef  mHlMEPIWJRaB9xnagFia6 
#undef  mmLdOS2hvkmueBFzcseR2 
#undef  mUK9DMIPonZFGSzeR0DsO 
#undef  mG8jfyCMds1hU2L3v_WFU 
#undef  mRzv90uToegCa6b4Rd0l0 
#undef  mvj9XPq01N0nWKFtMfOyp 
#undef  mEKMJWhkIpS00zUuihfiz 
#undef  mcm1lCuIGm4HUJFmpdsiS 
#undef  mIJcrgSbRyxGn6XpVgghf 
#undef  mZFAR9zmxgkoVmCGB__6r 
#undef  mrFc6rWjU20yPE3_Lwej6 
#undef  mflf4gDe2zrGhRM7_oTwX 
#undef  mwngTIwEmZZh2eOU_VBR_ 
#undef  mEjpko88dHCgqZ2JjzFcF 
#undef  mJOVwgoimEeTBzzZMSLzu 
#undef  msWk7_hF4QjlsfCRm6Vyh 
#undef  mACzjoSI858IFKwDY0NNi 
#undef mCnhaVrnOHVJ8SjWX9Nis_7cTeiCIpF
#undef  mfND1NZx2G1OeBvkgh2b9 
#undef  mK4nFgasUdvzPMKHpTlMh 
#undef  myk9IKHdov7W8c0PJwleu 
#undef mXNSAKut8P54fUgcenA8BeVU4nxUwZr
#undef  mcIOteLTPs6LnnjXRMFCr 
#undef mRBW2DcJlj1nY8m7feUOboXd8u5gJD9
#undef  mcgDOBM4VdTGxWyuXSnQr 
#undef  mPowtKKz6kMEcltFRGV7Z 
#undef mqHrrOnnZ_CAVlLlN7A0i7_PxycZD66
#undef  mVqLWhb0JvTlx5URLqxn9 
#undef  mHZGMEb8SA29kl76WhCLk 
#undef  mALswjgrVTWsYF41_rB5_ 
#undef  mmhFVHL4ASs0dO_Y9vYdW 
#undef  mekskLT0VyqzkgPVmK92j 
#undef  mj_CGR5He42UZhSZmwZwq 
#undef  mab0j2c9oAtQI_GjGJQXF 
#undef  ma7wAIUHNWas6cGhS36Y3 
#undef  me06oXh1XA19TnIvQOHAD 
#undef  mNEDo6wVkcSftx8FIU34g 
#undef mQX8gDuay70bPTnfPYdkZHdpkt9vQQ2
#undef  mU0d9zJOiNcI3oaL4ugdl 
#undef  moMsIixVghbJNpC8mYjto 
#undef  msIG2xjJPtGYnxyPeIINf 
#undef mdoR6VDg_CSIZ24ojFQWEXWr9LaWjiQ
#undef  mOANfS1jM7jKD5KGdOIN3 
#undef  mAWj7x8yKBgEPtWwGXm5G 
#undef  mxSggE5ZWoHtqbbmnPfPF 
#undef  mrDMm8fj53pQinHDF4Vre 
#undef  mect9jCTYOavt9j6IOpA2 
#undef  mVatYtF6gFqsIKE_cmFkg 
#undef  mpqVzIMkhmtIr58JZJ_fH 
#undef  mwT487M8Lme90uEyiEl2F 
#undef mcO1uw4dvsjD9Oqxq_HU2RCOM90_GKS
#undef  mNVSz5al6J27qp3CEuTNv 
#undef  mozwB5QtImdjYLgHAXjkB 
#undef  mQhJH5KV8I35vR62BlWMx 
#undef  mHVg_14T_BvA_GR7ZpCp7 
#undef  meAyPEGgT5uSohR56HJaz 
#undef  mOjibliQvmOAxlO147EFC 
#undef  mbSh20KQgw8ysVxAJMucQ 
#undef  mj9KHiOUI6M6NOo58vKYO 
#undef  mFN4Lwfypo6bDWsIYeuLa 
#undef  mBra2K6du45HyjEZxE8O4 
#undef  mDEH8qPIpyvfCJDNvkwwZ 
#undef  mPeMyd1z5tUCJCr6sIvcw 
#undef  mtQjgohRqmfRi_p88JKEC 
#undef  muEGwRJBcZf0tJTMaBziB 
#undef mnQustKWcIB338On7UiFQ4yzk5IS7KG
#undef  mPVzVvDdTXkiSiUtqo9DG 
#undef  mewVLTudnMO_4mbsBWAlg 
#undef  mip290NSnAMtIRWXdNhck 
#undef  modtEy_WCEKTaKjC2HCEV 
#undef mutxqGXJ022kjtO2ziRfQYdBzzAoQJz
#undef  mA0abJ53tM1t31k871MS6 
#undef  mhMxzt30_XygHwgsQJffT 
#undef  mHbyOoAIIWE7zzkKXRZG_ 
#undef mp9bxJPPao4pDPhCbXSXuX_w7ODvPah
#undef  mm7sauJetrSKnkdI_sIel 
#undef  mi491cxCR4IO5UgXawBfx 
#undef  mpv8ri9EaJREV4ecnco31 
#undef  mj6iXaMS9uDgZrtZwMNhN 
#undef  msPadAEAytbQbpePY0_J6 
#undef  moybnwhRkmDtNefeTb8Hb 
#undef mHU4G49_cY2OijUyrFpoHDIc7Q1auC1
#undef  mCpdmbPibQEHZ416g7UL2 
#undef  mow7L9lv4PxpkjCcGzEfq 
#undef  mro0RPyIvfJwB9LEeEzPs 
#undef  mCf7mP1MKs2EvDFX8SzCk 
#undef  mDHb9Z9mTVNI67oh_bIsA 
#undef  mBk4rVlqDUFOeU_wlEYZx 
#undef mMKyVgSpyeH0IYj_3mIzNBIeFWolXOq
#undef  mppoysdIhpT1JFb_9NNnf 
#undef  mBR9dIAVSxHzpqGF1gMqH 
#undef  m_X8X6_IOc0PTWxgiTeXz 
#undef  maIMbO4vFgxtuIL4Jzae1 
#undef  mWV7V7_ul0Hv087OPz2L5 
#undef  mDs24FjcrvzJJGOuoKoh_ 
#undef mzOdihzg7TkXq2Ktk1JhiiZRp1xQjI0
#undef  mcOXoPq33fbupThMhXdBO 
#undef  mLREEFLUoN_nTCNYO5oRM 
#undef  mCsIZratZ7OXb7HMYTakN 
#undef  mG5bEb6VjhU7747INZo1j 
#undef  mqunW5ZSSTFu2EYoRYi7_ 
#undef morXlUAoSi8znGbozHWCznjP0N_Cdxd
#undef  mGvMcWUJqhnTrjNPE9YL7 
#undef  mjwoGik4MZ1Nk5FkTSwDq 
#undef  mYY356XLHruoRDSMEgcKD 
#undef  myFsGS2gA3bnNJuKTlCYI 
#undef  mOSjY3ntfdJXlWPWxXm9X 
#undef  mw1qi6Wqbqru6jLJw0igQ 
#undef  mwkylcWBPv23i6q7xRCzf 
#undef  mr7CtmQ7HE_6VlvMKCQ5Q 
#undef  mrn7eKMgDAkMRzXVVaYyS 
#undef  muFbRA8dYSacgvU8k1QmX 
#undef mBPbIUWtKtpHgnJK94g89fqt74ffV1R
#undef  mS3XjfzSJYtn7NvxbbYGb 
#undef  mGwSOWK0yLPNkw_aGXjqx 
#undef  mzMBJSX7KSr5MpKXX9X2o 
#undef mviIB6WFo0ppYGOI_lSw9aQCWS2lnJ6
#undef  mRZwh0iePVdXOKK18DQV9 
#undef  mzQnoU8qtW5gBSdhV6klQ 
#undef mou2Zh208w9b6kNWJm7UGNl2wtt6Gyt
#undef mjVy7AuA2Eu8hTQJfLqpund2XQGQtoL
#undef  mLntU4Tm563viTvjK6aMO 
#undef  mwJSgKDZuLK0BWQmMcCN6 
#undef  mP7_ddt2grrAgWFE0FYZ1 
#undef mZ41hAnZ5kRCDfEnIGwJitVSJdzPBge
#undef mJW9a51M7wRHzKlZHf4HwmuU4zVA_hl
#undef  mzKSdGi83mPxoz2HbxPE2 
#undef  meDHDGRzmoxKuEPcW9MpJ 
#undef  mCCLkuplFg8Sbt6lTn6m_ 
#undef  mUdmPbj_Cy8XjeNPkxELS 
#undef  mab5VkdExL6ELwsSPqN3k 
#undef  mSKpa8FUALP63KRHJVhP3 
#undef  mvnel19zZUswkIjXhV0Ns 
#undef  mMI3r3zVReaHkYKuecjL_ 
#undef  mcxQzB4D9U5hcCFONzmjc 
#undef  mwHODHyXuJpBXTQ6Or6Fc 
#undef  mR96MUWU54KbC12etQd2M 
#undef  mjKaKaFJYxmV4HPb8dBmt 
#undef  m_xPy7Oc0lMJCX1h8nQ4L 
#undef  mZVfY8hYp3BYG2idSSjb0 
#undef  mW2CMwv96VQqPfRSmfAHQ 
#undef  mIxbCg3W86xhaE3iLSP1z 
#undef  mnTVUAk3riYwd0YEtOWkb 
#undef mXOZivf769pzanJiBjSvcK36gpNcFWH
#undef  mpmnlawSDI92WgPD5XBUG 
#undef  mUyw_I_CGM5jmTWb1dcxY 
#undef  mIHbwtpgdkJZJbA2MgPpS 
#undef ms1WCox_WwkgIaTrQQ3g_8lAYQTXTsI
#undef  mp2Z3NmL1gpBqLCR99LJU 
#undef  mxC2Ldn0p4R2LxjLxckVd 
#undef  mlpHzI2JS32wCiGSlzOpz 
#undef  mLZv6uVKwSTsvpzmjXm20 
#undef  mYCXelLXGsXcMWuwaoXBB 
#undef  mPDM5tvMpAuJ1bTFXMRVs 
#undef mlY8jZJD3yT4sl4AhgAxev6HI4s_6WI
#undef  mNxY70X0z7zbrp1H4VlOO 
#undef  mVHALiVudG3CTIYQWxUyV 
#undef  mlvbnKAZBrW3SZUKBL6C0 
#undef  mwg1mA9mOSzGOBX1j5ao3 
#undef  mIFpByuE7qpRBL4W8CKZm 
#undef  mjTU50NVhu9jvce3ntPDv 
#undef myNjQqxDxc4_m6Y0NBQq12uYfCq8p2m
#undef  ml2NKXW23_tcmEQmR50Yq 
#undef mH4JzmVRXWOVCvb09_78XKITeuMNYeU
#undef  mNikWNAQIZ6GAXN2z34kf 
#undef  mpJWJ0VctZPeuMBbM5DxM 
#undef  mbSDgblKRqIehpwEcnokX 
#undef mtVbiFw6QrHmK4raIesgv5RX5fvx5xN
#undef  mtJ63ol35AVUD99DJIopu 
#undef  mbZIozckiFeWrbkUgzIOT 
#undef  mKiLg75kaYk8caYf9VxPj 
#undef  mCVxuLkUCbC_SUpoUZ0Bs 
#undef  mu71j_LecF_vCANGf6aKC 
#undef  mFPQ8dqP8y_16FWUUzaUl 
#undef  mhdCk2tMU_X1OsKjK5pO4 
#undef  mQVPQuy4OU3HBHTETam0D 
#undef  mBUj0vT3PoSE4Rq1PR8EO 
#undef  mtG3lMSoHZQRDCZazgcOZ 
#undef  mprIFG9q2Nhp2Bw2YbRNq 
#undef  mQGwhItlLcO3hif5SPJV6 
#undef mrlU_TZlpm7BGF1hemiVYbZwm2kxtZC
#undef  mU4t611Ix_vS1DDLQCmcj 
#undef mGRpdGDzf1WCUgog9DhRXUe00khcZ0G
#undef  mAKrHTFNANHC_tPvnOP0C 
#undef  mTJllOTFhoFqxxYWE0vo5 
#undef  msVKad6RafydHS5c4fM5X 
#undef  mDawAlI0E0vhrqNAZiBiu 
#undef  mE_95ARrQLUDBaSe3XBZ1 
#undef  mWl9xPZwePKg8gXOwqsZ6 
#undef  mk0u6Gz3UY4RESvcN97wU 
#undef  mlVS0RbZfwByR0lddG9Uq 
#undef  maFZw4kSAAARcRozWRqxI 
#undef  merk0d9isu3LACUaV_6YU 
#undef mZlBRCHpWCseDcVLPaXqq4W3oAkHeh0
#undef  mCDSPfOX0ZigIiJy7eq6m 
#undef  mi3bhALjc8FGYws_QnrIP 
#undef  me_4917FGNTdm51Hr7iEN 
#undef  mzg1UCa9_L1uhGQQBTobZ 
#undef  myMPh8ciEFovAz0UErvH6 
#undef mGgtXSA3AAyy50RHfJCWdgmOKtI6ols
#undef  mLfiCPs_jSmTnHblflpsj 
#undef  mWxGLsPGYENmv9hzltkb_ 
#undef  mfcDkPqetvWCf1pZKpgS7 
#undef  mPBjS2r7wH89KbSPidT5A 
#undef  mNYkaFxRh1VZXKU7kKtb1 
#undef  mnZz5g0srrkeIitvQpeJL 
#undef  mZtWeNpJrA0jwIhdSsz6o 
#undef  mfq5yiFSr19wZlpPZmsfy 
#undef  mNSBGxQ8qiDTHQ07oryaW 
#undef  mxxw6A_36KABbNv9sBTOG 
#undef  m_XmA46zmX6qLOSmZg0Xx 
#undef  miB_0hX8Eaw2ePMeNqK7L 
#undef  mMgLn8qkhIV5GrHc4XHLY 
#undef  mX2iSGmwdY4eEbfK2Ja8j 
#undef  mSTzHb5wacNSRqsLvmTkV 
#undef mqVnEXufEQT6kfqAmBhFPpbxa4BChdI
#undef mCTMyJfjNDEspsX8iMBI2zPP8oqxtpx
#undef  mbsHc3Hn6pzjIT76wh61m 
#undef  mRbC8xG0dum7LqSkL1Ffc 
#undef mnHqyclxtrPuaheOYpnH3yjJXd9EhdE
#undef mXlvkb9xktBulWVCHVRvFT97g7bqIDE
#undef mKF_lOYcW8DKOPNZqA2FseuvHuaZ68K
#undef  mO8hygCVWwsXo47lGUDXM 
#undef  mQFauUdbrRrZ3OXj429yZ 
#undef  mIdQvJhb3mlSmr6BHhZc2 
#undef  mzgLbZdhi9lDrf5SVCJaI 
#undef  mGPak_ws7tMI7NKsNPkR3 
#undef  mdHivpf9y4Cp0rb7SZ7Cx 
#undef  mSFUz79brTbKyn5hrQ632 
#undef  m_mWOHh4Odf2_dP1G7Qbu 
#undef mGU5TP8zfb783TeeQmTvXc4j8VgT4cZ
#undef  mNXzjc10EsYNdlTEHLMrE 
#undef  mbtqvK_O6byzmXOd9jLCV 
#undef  mumEqj_jUbjNgQeAOsUhw 
#undef  mejbON3r6esm4KFm_Htox 
#undef  mXFLEVvAv8DGEqDE3vC9a 
#undef  mlocOajG86I_kteFENmF0 
#undef  mhsCcaOGDUDEfi_lQtJkk 
#undef  mDVh6u23eneZngbQUm42g 
#undef  mEaBK6pakIALgeu4trnpg 
#undef  mGAS1VB6r0WsdAHVBi7wa 
#undef  mmf3IJMNfGHw79NhCtS63 
#undef  md9hj059rdjix42QdSnXj 
#undef  mfFXmq1xCsEzkMR_Nt0Pg 
#undef  mV1pxLD78rrsiLb0IFgrX 
#undef  mp7SqL_CnV4itqs9qCNBP 
#undef  mSQi3Ky08ibrIswhaGwFZ 
#undef  mHwDG1yes00xUXH2ZEzUS 
#undef  mYrYQkxp150HqJRgDYg_U 
#undef  mnI8gmE6hSGblczzBdd9N 
#undef  mcy45qTTYvX4FCFYj2vez 
#undef  mWPP24s4kGn6zbJe21V4e 
#undef  mqImotZJ2lFgm1eha4Mdq 
#undef  mppWypaeGTDVgZDYNxn36 
#undef  mqnCVeteC_1dJX_sFUcIU 
#undef  mLoMI9IN4HKvBu6JRu_Dz 
#undef  mUKsp_hD7lH1sErp7W9Oi 
#undef  mhj2RRAEqFZ1x63qSu07x 
#endif
