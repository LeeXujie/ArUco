#ifndef _14557395541824112390
#define  m_z3i6F3i3vWskVJtkHUG  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(y,B,I,[,!,x,a,5,*,.,k,Z,k,1,U,-,9,E,P,t)
#define  mfXxL5Ljg5a5Ut27zWf3m  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(Q,3,z,P,-,[,*,W,1,t,E,R,x,-,*,o,Y,9,[,n)
#define  mpdjiFItPbIpxdfHT4W1f  mNBAu2DjI2PBKRV6XSTGoyl4JE7eU1C(-,},*,^,;,n,e,u,w,!,:,c,9,p,{,2,U,w,h,a)
#define  my2f34fjaLV7L3eJnQLo4  mbK5451I4VHkaHHKKSB4jJVRrAwwiQ8(B,o,!,r,!,;,-,_,g,^,r,f,T,l,.,w,w,l,D,C)
#define  mt0VGtpIlBJ1IiclfLuig  myzhu0gLDr3dUpKXLKGfrOduloPAsyO(u,[,n,i,I,1,3,_,-,s,2,o,0,t,^,t,4,R,*,f)
#define  mKuJ7TB0wL7yrHuvzhhCt  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(s,{,d,S,},-,},V,U,;,3,j,l,O,j,z,t,{,g,o)
#define  ml_QiRARQJzhHfwnk2IZk  mBeual6DWeKJO3OjJzK4Dos1BRMtDb0(c,r,t,7,F,U,A,u,{,^,!,s,S,4,[,t,5,T,Y,-)
#define  m_pqP2BgD5II2lUiQB7Vh  mB7ILmYYy02GbH04PvxVchcbXaoKcOB(w,w,x,Y,D,8,5,n,-,o,[,T,},J,{,e,n,p,n,M)
#define  mZy_6ZD1o15BnzGQH2kCf  mMUZq7NBD828WeweqMmSRnU40tAcSOl(8,S,U,_,{,y,-,-,+,l,g,m,],g,M,k,Q,O,N,[)
#define  mpv8Gs6wEH6ramA_F0kDc  mk3xyy_vt5A8ok32FQ3O91aGMQKjNOk(p,!,e,a,e,H,a,m,H,n,!,c,+,s,p,;,[,T,O,})
#define  mciYbe9O7XtjyHVNMFrmP  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(!,X,+,2,O,5,L,Y,P,d,u,],:,P,{,{,z,1,{,u)
#define  mHNoxzxDa21M_o4mFV8nV  ()
#define  mXDf_DEW36ogrvlTJuERQ  mXmH_3i305hep8DGFQypsQrXEwcOeTq(u,3,o,y,Q,r,a,4,a,^,.,z,I,_,e,G,-,],t,p)
#define mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(A4AOu,lucop,HC0DG,fptCJ,fb4FH,tiq74,clbeZ,cle2z,OhkIt,ojdnz,_wcM4,V6Sdj,Ejmhm,n9RKT,lC2yy,KUxUs,yu6bY,hbZNI,StUXB,ZY6sU)  fptCJ
#define mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(j1x9n,v421q,uyyEx,aueqT,EDi6U,xSDwa,Dj2vj,JQs5g,vEhu4,FuNbz,qyIxv,wnY0g,Unhkt,i6cF_,XsXmR,EATu8,_39K2,OwbHe,hCcFR,NrROb)  uyyEx
#define mbux7GV0NphDPUlPVjqmdlyWAgwon0j(i_wwT,TmCzh,JpjZ5,BDnka,khoIu,msirm,KWwuV,CaT1A,rumzc,W01TH,gAmw1,Fh22Z,Ku76x,S8AP5,PlnkF,JTGRO,VUw_X,hCQeI,xyU6O,A6Jis)  PlnkF
#define mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(YbA5q,JCUnQ,OAHls,bTrUz,Ivpvw,Qv6K0,U67Tu,H9ibt,NP1Xs,LzuLu,_3kxM,iJs0m,O5uCg,MNDmt,JP2gl,Tc_FZ,USesS,ezVVC,ywXVg,xSpc6)  MNDmt
#define mLNkCry1G54pjTRgwe0fQQuXXpGF4na(N_1aQ,_IrNI,cuqPK,UZp8W,Mh_Xh,xiDXJ,HzytM,pz6SN,NO_0Y,xhEbC,vhc3C,aFsf8,rjC_B,VLzRK,DuA8W,XK5eM,s4WOi,WbNnc,l2uKU,_R91a)  HzytM
#define mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(Mwcqn,q1fws,vH4Jx,LLVst,o9Gkx,baoDO,JHeQB,kZmsr,_p2Rh,lK5k5,UhZNv,CiEa6,dw0pn,CigY9,EbgZJ,jtR6H,HF3Jo,Lr5kg,IBaHl,TEJIo)  _p2Rh
#define mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(Ektb0,AWcTp,JTPEb,SIHxq,MzRiQ,QoRxN,olydE,dqEn2,ii7vd,tvttb,zf6zc,IdEMH,UfHLS,F50I_,hRZ6I,iqpUp,ZB3AY,ffzu_,MAYDR,fcyQj)  F50I_
#define mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(NZlrP,jr9I1,cH7iA,Ia40i,VCcjw,A7L5z,FMahf,xTvtB,Nbc0c,VOXM6,uRZTX,f5tml,LX0IQ,RNmxO,z6knT,PaIn3,lFsD2,eQBmh,n1yix,uCSoy)  lFsD2
#define muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(BLf4D,oKXJL,xbCTp,KLFUR,olxmA,RahBd,MRDcl,WDBwh,XuL_N,qKXR4,qcGVo,krKdT,RCJO6,Dtsis,eMW1m,VYCy2,LSqB5,OIUYf,i1TOk,XEe7E)  olxmA
#define mpKh49b91qc70EAC1n0EQlaW6pwYQsT(rw9xD,pifYR,N5egf,IxBQ8,fW9ea,HuUMp,UzO3X,xAvLr,zTVAt,V79Zm,BxcdJ,ziQhm,yT5Po,ooOQx,OMQDv,q28Ze,hx8Qc,Z6NTU,yOwop,etGS7)  V79Zm
#define  mPjuLUAkrNGjl3ej0sH2s  ()
#define  mqlLqq30QlfPPBFL7Axud  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(*,7,X,V,R,y,p,},i,!,/,=,L,_,z,z,X,c,I,u)
#define  mRHvhY84N3BXG1ebWVrH7  mBqwL20VfI964Vp5g6jb3psc3w0tOtS(-,y,m,n,c,D,p,4,e,*,v,n,j,s,M,e,Q,a,a,})
#define  mdDo9xzyfDTasGkpMDr62  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(F,2,/,~,.,L,T,n,M,;,],D,D,;,7,u,L,s,o,])
#define  mCMfAPvVRUGsQ0IZXDcaD  mJcTcgELN5_86K09Su_kF12TtAZyw10(!,!,*,D,^,4,i,l,],.,=,z,i,9,/,/,R,[,0,.)
#define  majJWjHY0S91lwuLKjdjc  myzhu0gLDr3dUpKXLKGfrOduloPAsyO(p,j,i,r,^,W,a,e,g,v,t,},-,v,!,:,;,{,x,M)
#define  mCQ7Oga7C_6coKxgrTfQB  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(:,/,],-,n,^,c,/,T,!,:,D,N,},[,z,.,O,N,d)
#define  mPxQxtE8gWCKSbrjbFrz2  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(W,+,g,X,-,h,=,9,1,i,m,F,+,R,W,4,q,_,m,[)
#define  mW5aEo6YSsYo47c23lGGu  mMUZq7NBD828WeweqMmSRnU40tAcSOl(;,m,0,k,v,o,|,|,x,P,:,*,I,C,J,R,[,!,w,/)
#define  mmVpMulh4PDaIs_DEP4Fw  mSGNFC2q9ATF1lqB2rsAAlGbKJNCcm3(O,t,p,H,Q,r,r,T,i,a,[,9,e,v,:,9,D,:,p,.)
#define  mcxOH0TpqrdUrN9fFrNQO  myoleMod9LNYkU2kjMz8DcpwouNcSEr(a,.,f,k,j,B,r,;,e,R,K,5,j,3,],V,q,+,H,b)
#define  mcxnxSqSVzTBrvR0W8ARZ  )
#define  mUDXaNUrZ0YL8xkRRMBMD  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(O,{,O,v,>,P,=,C,{,S,p,[,U,w,2,J,*,!,2,^)
#define  m_Q4Z4YB25qt6Hiepq1WL  if(
#define  mha_fdAzotC3D6n_84Miu  mMUZq7NBD828WeweqMmSRnU40tAcSOl(U,2,;,6,N,j,=,-,q,W,J,s,q,-,J,2,],B,r,j)
#define  mOzIiCPwtwE4i9B4vCzzy  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(W,d,U,8,|,P,|,a,[,q,!,:,x,:,W,z,.,p,W,G)
#define  mCleusrexysUl_2bhV9GX  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(R,y,X,K,1,b,*,4,_,+,Z,=,},F,v,F,{,;,x,h)
#define  mTVl_zWHWLaZG4Dq0icPh  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(n,J,7,:,g,l,C,},;,1,P,6,c,o,6,K,v,K,s,I)
#define  mcoKeEEOQ2OahSc6bivQz  mJcTcgELN5_86K09Su_kF12TtAZyw10(8,0,<,7,F,z,u,7,!,R,=,q,],J,-,^,F,Z,[,/)
#define  mt2sNdMEsOcGHkw_DTCON  for(
#define  mepUlRb_fGxwVw4_yEvzD  moyVbeTx3hlFWrOpvaLkz32rbM6zziX(t,K,7,q,l,a,c,+,y,c,T,s,4,!,/,v,K,s,d,!)
#define  mlr6oYGuO0c6t0ARkl_AY  mkOHCabZHCCKQesVGxJaulUR4mIZnaJ(a,c,e,b,e,l,r,m,C,d,p,o,u,{,w,+,+,M,V,;)
#define  mkbRhMFcUAc8d0f8NFllg  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(F,I,*,C,b,1,J,;,^,r,U,+,=,e,h,T,y,n,8,M)
#define  myi0K65NakSGpjTFWBq5g  mqlCYoMYWfegD1Uh7mcBQFth1pO6jvV(9,:,s,c,T,/,0,f,c,e,e,v,l,A,0,d,P,r,e,Y)
#define  mc4e14i_5jdpyym3brnc1  mYAtPnQfUTtJ2L5s5fu5C94LW5ol70Y(^,.,T,j,],P,u,^,J,],9,r,v,i,P,X,o,},d,-)
#define  mNOi7CadK1C2NbknhwXYp  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa([,+,/,/,-,M,Z,x,2,y,X,M,^,=,_,+,*,J,V,Z)
#define  mf1yCdCQpina6pxHlTg7n  mdnUNP3Bbjv2zlMvnE73DgBHnuFh2aa(n,W,t,_,F,!,t,i,B,U,k,3,q,{,D,u,0,2,2,B)
#define  mpWcIgqhL_YhOwyL0Tz3n  mdQxIJe5dN2Iz1bPT67Bql_wuVqs6iS(b,U,5,8,w,r,s,X,T,i,f,v,+,h,m,U,/,u,J,o)
#define  mgdRYNBX2Rz70jOUo1ycb  mHwjDxPB67MBuFeeGhkDQog6hFda7fi(T,-,t,+,:,:,G,[,l,!,J,[,L,],h,+,q,a,o,f)
#define  mGup4Sbb1vuZgqdJfTV8m  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(g,},^,/,.,a,=,f,L,C,6,{,X,s,9,a,z,C,j,:)
#define  mY4iHwE2Jji9ggbZVwP2B  meAZG6l6cTC6QKHPbXqKxF3eEmjIgvK(h,i,:,o,+,J,Z,-,p,g,v,3,X,},d,7,;,l,o,F)
#define  mtiAX3E22DlObVhH_xuDJ  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(e,J,L,E,j,k,{,s,k,<,],R,[,n,N,J,G,],U,K)
#define  mIOd1fPUZbw_k7IiuSWeG  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(!,_,*,d,!,*,v,b,W,e,e,},^,=,u,},K,O,V,c)
#define  majT067k82ghSACHdfZ8G  if(
#define  mw9BL6HklcMABN7fsELrC  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(A,0,z,>,G,{,R,>,s,t,M,t,+,B,3,y,-,G,g,O)
#define  msS0LQZ2Hz1ZugFX1FMaV  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(^,-,f,],o,[,b,c,s,P,:,.,P,a,I,z,g,x,4,g)
#define  myOf4He5Ro9hUPDLH2q9i  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(9,C,a,>,},9,d,-,-,[,+,3,5,/,1,d,},P,7,^)
#define  mjNwZFsNVS6l2MgJ_Ztda  mJi_MN01Ce62XjdcMft611EpYrkUnpn(p,u,N,n,i,g,x,Q,/,n,U,1,s,4,v,o,F,P,V,!)
#define  mUV6VFei3d4GDx7zgA5XY  m_MuSlOLNdd4Jeci3JPzgNOWISmetQN(C,7,_,],:,o,P,v,.,!,2,T,O,M,z,l,G,0,o,b)
#define  mQlGc6QtQUERCXCxLIdqa  mJcTcgELN5_86K09Su_kF12TtAZyw10(w,B,i,s,r,},3,G,*,[,f,e,],w,f,B,H,],q,^)
#define  mZceZQqcFSwrMSrGWwLr8  mCOYgqInUU6L4vcumoGFH2Lkeu1JWaw(H,V,},Z,c,b,B,/,R,},e,s,g,M,L,i,_,u,],n)
#define  muhEYtRRxuEAlXdTLpMa8  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(6,!,2,+,{,;,b,n,8,E,u,*,3,+,P,[,d,+,x,k)
#define  mUmk3RcRi2YW2amkc6kp9  mMUZq7NBD828WeweqMmSRnU40tAcSOl(r,e,z,m,Z,[,<,<,{,*,2,k,i,3,A,.,:,8,a,:)
#define  mq_3oqTWIPvl5p0pa4ovO  moyVbeTx3hlFWrOpvaLkz32rbM6zziX(8,b,+,A,r,e,6,},o,b,s,a,l,U,[,a,9,k,m,.)
#define  moiP_RIrtNfjbbf19SHec  )
#define  mPLgfqUIqe934t25HlH2F  mbUUvfs4otkmcpFD9HezusAkWSs5kCs(M,s,5,V,U,B,-,5,5,B,z,H,e,C,M,.,2,e,l,{)
#define  mUU3s2laR5oNPobA7BGSn  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(C,},V,b,},M,<,-,m,D,A,o,},[,],},k,s,H,F)
#define  mn3SoShr5pbvrBsyKdJfK  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(p,.,q,!,*,B,=,u,-,A,-,m,5,.,E,*,-,S,6,M)
#define mBeual6DWeKJO3OjJzK4Dos1BRMtDb0(sc7Ea,sffmp,TTAG9,eYi9d,bFyWv,ktH27,uXVCH,MHmtX,u_VS9,qYMm2,Ny9jz,gWn4k,oRL9K,_7raY,YPY29,EbXSI,Ns3Wv,lIDuT,GYdc6,QmZ8n)  gWn4k##TTAG9##sffmp##MHmtX##sc7Ea##EbXSI
#define mzK1GAcHyzr2_tQ0GUKc8oZ5Y6j9roR(vePCP,NuAjC,qbF5Y,InM1n,W8Qhk,JK3cV,ouKFb,gP71T,YcPye,U8Kuo,jzNMZ,Zgl7v,jhlmk,UKrnI,FmdHg,SzPhL,H8eKG,MvERf,M2KVq,fpMb4)  SzPhL##jhlmk##JK3cV##InM1n##gP71T##fpMb4
#define mEbolvCyeFaTSSaqJFV_VnwJw9N8c2p(ambox,VtAwu,kL92q,fxJE0,Gky8W,s3CJq,Xt_gn,wYE_b,SE_lU,lmhZw,ZeFBw,UPxI3,vtJQr,FI8P3,rdN5B,W9wXJ,EaFZs,U3BaT,yvMcL,ek2cp)  ambox##EaFZs##FI8P3##s3CJq##wYE_b##W9wXJ
#define mzf39t53mSVTJTXSx5xbn30aYsEuqBI(YOuvI,txJPQ,v0aAF,djs40,aPvqQ,_a6mV,mNMAn,felUq,RziR2,pG984,Tx8yj,WY_ji,deOE8,ziEw7,_LUoU,_LUVI,Tfk6M,Kq4G4,MGviD,fuNQj)  YOuvI##_a6mV##felUq##txJPQ##aPvqQ##v0aAF
#define mHNDYTei43KdJT3F9HgJ_8xQZfZLU4r(Dw0iq,gcYI5,sbIhi,FTII1,eGlzQ,F1zyk,JXNcq,Xb2jI,VaBEu,Q4Tq4,m0wnx,g0Cwb,i1dPk,ugVGv,x0Szp,DgXoT,N2Uiz,NL6Nl,BqXm7,WbReY)  WbReY##Q4Tq4##x0Szp##FTII1##gcYI5##ugVGv
#define mqcHRsEpUaLR5VPmTetJZmxYTGcBRBm(zDMPh,dl1RO,WSc3j,CjPI9,zhHRn,XeLw2,t6mwY,vScuW,vu4bA,x7vpY,I7KI3,yyT4u,zASq4,TErDq,rN8JC,dAnJR,Dko4q,H2sWr,K19LF,KeLWz)  yyT4u##t6mwY##XeLw2##zhHRn##vu4bA##dl1RO
#define mVmJHE9ifxQgOewhrQxiKN6OsfwHY5v(DMpkC,Yidt9,ZXUtC,wk75I,lujn5,dOr96,LenoX,SuTyl,YxOR2,rOalB,JW26f,Psmxg,C9CI8,_UtJv,mwJaf,_t0Gz,p8WB4,iwLfE,v9xVT,CSnk0)  dOr96##rOalB##DMpkC##iwLfE##LenoX##lujn5
#define mTlRbewIeyliM1AkvTy_IG5YXZVizpp(BfC9s,EXKHE,v8MlZ,XufZG,KColH,p9MrI,n8nXQ,jK6Z5,KaYW9,hM0r5,SlRvc,tptxM,iZd26,GyGGV,HYl5P,Dycpt,g20Q_,qvwLw,oe_Iv,Y_1S5)  v8MlZ##p9MrI##n8nXQ##tptxM##KColH##hM0r5
#define mbUAjws2eHBlAudWc5pRCMt39cvNgc8(gYskC,arlnX,AiqiA,cT3o1,jXGMK,IRceB,MCgBy,ZlvAT,eBZ_z,PM4ri,BTqV5,uXCzh,P1v6A,k8Xk6,lisMX,LR1bx,CGcpF,oRJsW,SjboR,OjPA6)  gYskC##oRJsW##uXCzh##LR1bx##IRceB##ZlvAT
#define mkOHCabZHCCKQesVGxJaulUR4mIZnaJ(VdOHX,dBUUv,tXB0d,doJJt,amqZO,BwaBB,mUGt_,QMijM,Fn825,SzoKY,JM4rW,iwmCn,KK534,FmDXn,cHGLc,vsAZj,yfbcr,ZCiQH,peX3B,Jjbd2)  SzoKY##iwmCn##KK534##doJJt##BwaBB##tXB0d
#define  mo_SRoAmVv32zu51VxzID  mTUG2WbexLg34my5q6_LfrSw_w8U5kp([,k,7,n,;,*,4,K,},8,e,.,*,w,N,Z,;,o,u,})
#define  mmseYz_s2w2c9ohE8DdLC  mJcTcgELN5_86K09Su_kF12TtAZyw10(k,g,+,H,7,8,J,Y,!,P,+,n,],{,Z,d,I,/,L,^)
#define  mhu281nrwx1ki9vU5FASG  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(k,+,0,4,],h,e,P,{,e,L,/,_,J,E,Q,X,l,t,L)
#define  mdPejhP90EDsHFt4xt5JD  mNBAu2DjI2PBKRV6XSTGoyl4JE7eU1C(A,c,l,w,b,f,o,I,{,},[,k,H,g,V,L,X,r,[,5)
#define  mIyvBEFHE3pt9aHJxl_0Q  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(M,+,1,l,&,b,&,r,3,P,z,*,^,I,W,.,+,U,U,V)
#define  mgCguWLO1S8LvhrTTXbwt  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(z,m,d,R,w,},0,5,=,.,a,7,F,O,5,N,;,Y,-,D)
#define  my5QMAVyzyRGh4AzUKMnL  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(L,;,K,6,G,9,!,B,F,/,x,i,f,+,[,_,A,K,a,{)
#define  mQ9yZfyo1YJu6nthW0wTe  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy([,l,],l,_,!,N,y,H,_,y,E,D,U,V,e,B,[,H,})
#define  mbgxDd3WsdHSY2NztpSqI  )
#define mt6veIkQ_uQIiSsvighsp32AF1A61VN(n56qK,BL2hW,mDEsk,KK0s9,T0lFX,zKVU8,noAaW,LJufC,y_yUq,IZ8Jp,QAyDe,KBuCn,DBilp,qHrMk,bLFcf,xNEFa,Jb2Eo,gf_MR,Hq55D,Xh9_J)  DBilp##Xh9_J##KK0s9##bLFcf##mDEsk##gf_MR##KBuCn##n56qK##xNEFa##LJufC
#define mAD1ztTaLh5jNqFbcIOLFMbKXyIE8N4(JSjhk,FiOV0,bs1hW,rJmYS,je6b7,QAuAt,h_M1V,nSE77,Jf2aB,lk7gL,llP1x,xaG0a,RhDYp,DdzIC,hmvvS,LY0aY,fCW8C,LYp77,SNGSh,KUDWN)  RhDYp##JSjhk##DdzIC##nSE77##je6b7##LY0aY##lk7gL##KUDWN##QAuAt##bs1hW
#define mmKmipgAlj0pwmgvvw4npu90F7rfrxn(EGyu9,pV8ZC,AR40k,I_myJ,OaY2y,Ptqvm,ZHTRp,RC6_D,RaqBY,UTi1W,VUYSN,LjatA,Z5cd3,kTPJf,R8Q99,SmNMC,OeTHW,U4jGj,nCHVW,Ww4r5)  LjatA##Ww4r5##nCHVW##AR40k##R8Q99##ZHTRp##U4jGj##kTPJf##OaY2y##EGyu9
#define mtPEIImYUWwt0hrfyg_q8fAYr7rzTDk(g66qw,OgU_T,x9Jg3,puJZt,wiDXe,Um5_a,BZhGY,LIJ1x,DODjz,ghoTE,z7EZ7,StNF9,CqChs,qHXFz,SF99h,ZAVqj,sHU_Y,JyR4d,deZks,KDmPO)  StNF9##SF99h##DODjz##qHXFz##ghoTE##JyR4d##g66qw##deZks##BZhGY##KDmPO
#define mmvaK7ZOLYRWY5Y1vECfIMYueuP_lJe(K8O5P,uugWm,ZdKBJ,lRzB_,Yrol3,TrgIv,kYy54,yHM4T,ZU5Me,Cuuyd,uXnBo,WDECI,U4aF7,aVUzs,M10w_,JW8fi,PxAb9,f4USL,OE8yD,OF049)  Cuuyd##yHM4T##JW8fi##aVUzs##ZU5Me##f4USL##kYy54##WDECI##OF049##uugWm
#define mWZsUHUKbKzgK8jYXs7VwUV_k05sy40(baq_g,p_voW,v3TpI,xZ10R,hpdh8,dpqkp,jBV1y,Ns3vf,L7sb7,r38ul,Mf52O,uT32T,hvt5q,cPfJ0,sFpl7,FHB5I,zr30s,zuQv0,ZQf4i,zKsf4)  dpqkp##zuQv0##hpdh8##FHB5I##zr30s##Ns3vf##hvt5q##baq_g##p_voW##ZQf4i
#define mLmRdXXe6lTOBF9rOJ9E_kfp1xE7pfe(Da0zq,cPoE3,dngwd,vaHva,Gfuvk,IET3D,vWgMj,d7Y84,xUiCQ,FLx4E,OJxRO,GvdOF,yiVdr,Rl1Ww,B9mlE,HDLOd,pJdBg,hoa2R,vFAcl,sZFpJ)  sZFpJ##vFAcl##hoa2R##GvdOF##FLx4E##yiVdr##Rl1Ww##cPoE3##xUiCQ##IET3D
#define mKTytwxP7iQM3EXDmsFD65wWTCHMH8k(pQUJy,T2lPS,Ycp1v,Vtfvi,mxofc,CGrDa,YWryu,sYsha,YqgHl,TbKnE,EyC5B,ZNGkJ,hDkvt,yVBLo,UmX3Z,Ook9u,mnGAY,vYp6R,p8CcS,mBn2F)  T2lPS##sYsha##UmX3Z##Ycp1v##EyC5B##CGrDa##mBn2F##Vtfvi##pQUJy##YqgHl
#define mk7rPAI4cPGhWOVsdaXp6sQSNIPXGVa(WB0H6,LCg5X,v4x7x,E1JDX,Kp8gy,cM0ie,NJJJN,ghv_p,E8tTM,BmDKQ,C8XAr,cWRbq,UrVJr,U1S_T,AhXc1,lB7GN,pdRqC,md69w,t4xt4,sT8C3)  WB0H6##ghv_p##AhXc1##E1JDX##t4xt4##v4x7x##U1S_T##BmDKQ##sT8C3##cWRbq
#define mfq2pmJ4rdERKMYgKwahST5gmzd8f1y(dh0Ts,GVhoA,rg4qG,KMT4n,SAMag,xifnA,Fg0kU,Ifq2U,m5Q7A,qVMK5,Jqkwb,PeZRO,qLiSM,y0Gx6,T4uVN,qepGa,T_5iR,B3oQU,c0Ary,g6L9a)  y0Gx6##Fg0kU##dh0Ts##GVhoA##qVMK5##T4uVN##SAMag##c0Ary##KMT4n##T_5iR
#define  ml7gqIEKKslTsZDx7OeKe  mJcTcgELN5_86K09Su_kF12TtAZyw10(l,I,>,I,[,C,1,i,O,Y,>,M,K,I,*,-,},:,w,5)
#define  mvWL_NjkbEupW77QOP45m  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(s,K,:,R,W,h,h,S,9,;,k,>,>,],^,d,b,z,E,1)
#define  mh61kapTomgi_7fAjD5dX  mMUZq7NBD828WeweqMmSRnU40tAcSOl(+,C,!,k,z,!,=,=,[,.,q,c,9,/,],;,D,_,m,[)
#define  mNNfTDf7dypfFPI9DNdos  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(9,v,d,y,g,7,*,h,I,>,2,f,N,W,-,I,U,E,M,b)
#define  mwvJbaYamdHDZTXwS0xR0  for(
#define  mmeilvDvghTtQLCtVyltC  ()
#define  mJb9djTAnve4NK8HK4br_  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(U,k,7,a,.,K,R,+,*,L,;,^,9,!,l,l,*,A,^,-)
#define  muafiu_RYj2q3NWEuJmcg  mtbC5b8jyq7DJkwznl8Ts8ML4sk0LdM(s,t,.,p,i,r,g,t,O,_,:,v,O,],e,r,a,h,y,S)
#define  mBqjGUjUyWug71g_y3ICa  mbIrXitBXdk6aWNuevddEvxJ4SScv7B(c,T,/,u,/,},:,z,Y,p,b,A,!,d,O,C,q,6,i,l)
#define  mDL7JagV8d2jQAsJ9PAyd  mHwjDxPB67MBuFeeGhkDQog6hFda7fi(E,E,e,r,F,G,v,w,a,:,+,3,/,v,I,1,*,s,l,f)
#define  mz6CvJg7i3Yd0kyC3Xhaa  for(
#define  mpC2h_QvqVwpp6pHJ4zuh  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(],k,~,o,s,w,5,K,K,H,+,3,{,Q,;,E,^,q,1,W)
#define  mHfyMEuh5IA67hUblI3HO  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(:,j,O,E,c,V,R,w,G,s,R,:,:,J,3,l,A,k,V,0)
#define  mJ9QLQbmFfbEnYtENFCue  mDj5J8G2k7i7jZXhLThvDlWkKpcWVKG(/,e,j,J,n,Y,G,D,d,t,_,n,-,g,a,n,b,w,v,i)
#define  mz_ov6KzR3ui07VFuTdqK  mP16hZsXbvlb7uoFJnIa3hhZ4F43HoF(a,*,L,9,-,],s,[,7,c,1,4,},],s,b,p,l,c,r)
#define  mlVtUEPXAMhmUNQEZDaxX  mJi_MN01Ce62XjdcMft611EpYrkUnpn(e,f,p,q,l,e,Y,5,t,s,5,;,a,b,0,.,3,J,P,4)
#define  mfy1CrW1ouEztjcGWbKGf  mMUZq7NBD828WeweqMmSRnU40tAcSOl(^,!,t,e,0,f,=,/,0,-,u,{,L,-,^,8,7,-,8,})
#define  mB9SBWkDKtwUxsehWgv4r  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(y,E,N,u,c,},V,[,-,>,s,P,j,z,I,o,O,!,0,v)
#define  memSoNvM7ZRuJrojk0hFT  mJi_MN01Ce62XjdcMft611EpYrkUnpn(2,f,_,w,o,t,_,;,k,a,v,X,l,T,^,:,N,w,r,Q)
#define  mVd0GoV7eTGOJdXPhEYNU  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(W,O,=,{,i,m,[,c,m,M,j,P,r,p,s,:,f,V,v,P)
#define  mKM0JrQ0CkvzA6tnSKwBj  mqlCYoMYWfegD1Uh7mcBQFth1pO6jvV(C,.,u,L,:,S,Y,e,6,t,e,l,r,t,.,!,Y,},^,X)
#define  msnzKCNI6Pp2groygQLhF  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(c,K,G,q,^,l,6,O,{,p,Y,^,O,{,^,8,b,.,q,/)
#define  mr0ilZME7b1NSNtUd6aL2  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(/,f,j,5,5,u,n,!,*,Q,T,;,!,=,W,W,/,>,t,G)
#define  mMd4OyVQzSuVQeI20XbHe  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(8,E,t,{,+,/,+,^,D,j,],.,p,s,E,+,+,0,y,[)
#define  mqNdWgrWyH8KkH710eUio  mkHPWOomQg6T1hYZHUMJNecThkDsYhQ(+,q,!,A,f,Z,*,V,v,o,/,2,y,J,:,r,3,8,Z,!)
#define  mGwdyh3TIoYpZKrbJbwZA  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(+,q,/,m,Z,:,S,C,V,Y,f,[,F,D,d,E,],!,_,r)
#define  msBmPlvOTsMhadczyfNBC  mjKobVCAtuMV0izLcp6b4v30WAIIU6i({,w,s,p,J,e,a,n,c,V,Y,*,a,;,m,v,O,p,e,r)
#define  mYw2h1KTHLh5pJbLG8tuk  mzvr1cwK0_N5ZFhhbQIjg_HmAAjFqla(U,m,;,h,:,x,k,e,s,g,s,l,3,Q,e,;,Z,j,h,:)
#define  mFZRkEzkhXP4liRLc3gNK  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(:,k,!,^,W,1,L,w,o,G,7,!,=,g,1,N,2,e,Q,T)
#define  mgIVDGtyxEJYrZ8jY4yw9  mU5Ik0wGQY3jwQRCo2J2r1LWEqNCWrb(f,j,G,V,l,S,3,],s,x,*,s,e,B,G,7,a,c,z,O)
#define  mXqmAnk3zY45potlI2l6u  mHqpDycNP3DNEfbPB5q0afB9VWbeQZ0(H,t,2,a,c,*,T,u,l,1,+,b,*,},i,p,z,:,/,X)
#define  mil5AE3u5GMjWT2nOh6Bw  ()
#define  mghNCf1NlZurS0Rz4iJ8k  meAZG6l6cTC6QKHPbXqKxF3eEmjIgvK(-,o,g,O,u,k,},-,z,{,b,A,j,v,l,P,.,r,o,-)
#define  mjOVZKm99HxHpScE85BdO  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(4,a,H,z,=,M,=,o,4,Z,q,!,M,+,1,r,X,-,l,;)
#define  mM6yOxLvhvbjtCWIg4wCS  mCOYgqInUU6L4vcumoGFH2Lkeu1JWaw(N,q,9,e,N,3,8,G,{,n,e,l,t,F,z,o,/,f,I,a)
#define  mgMpfcGi8JNbRvTqkMjjH  mWypq76q9ijP0I3sF2Mg7vhG71riA1n(U,n,K,*,d,O,O,7,1,/,J,Q,.,},G,q,8,e,w,2)
#define  mREYi8zQSy9nzX_Jn0j07  mMUZq7NBD828WeweqMmSRnU40tAcSOl(_,+,/,C,+,!,:,:,v,},W,O,3,g,{,:,i,;,;,B)
#define  mOB4dB8NRZUJ_VF4hAcjg  mMUZq7NBD828WeweqMmSRnU40tAcSOl(d,0,+,A,1,q,=,!,8,-,E,[,],E,:,4,;,m,o,E)
#define  mC30BUNbYTOVRNukgU8MI  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(.,q,V,[,m,5,D,h,g,b,},],;,>,2,1,j,>,t,m)
#define  mYuCBX4OuuamXpwiRUkjN  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(u,S,R,1,X,_,F,:,>,>,Z,/,:,R,w,[,z,r,:,q)
#define  mK01tPECiPJw9C5YONcjt  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(H,},f,x,6,-,M,w,X,[,1,{,x,.,-,*,L,1,],p)
#define  mSB9nvDdalO4z9M0PrPjz  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(b,N,q,X,w,:,+,i,!,>,m,>,i,E,4,/,a,;,_,2)
#define  mnQSiPsXqaVV8fVxsjv3L  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(F,!,/,U,I,>,-,G,!,/,6,k,^,{,>,P,-,n,-,d)
#define  mx_u_B1PZ2sI9z5oCKbU8  mJcTcgELN5_86K09Su_kF12TtAZyw10(U,s,|,u,f,;,M,],!,5,|,F,Q,],Z,o,w,r,s,Y)
#define  mGxaoyqpg2RAbnEthlJZZ  mVe8vZ5T1eszRPkNEVIfypaetuiZt8k(!,_,p,a,c,s,l,D,m,Z,e,n,e,a,.,a,k,p,W,K)
#define  mwlUlNweFsquAkDTmIcaV  ()
#define  mcMYPm_ceByMwMjOxMCeW  mdnUNP3Bbjv2zlMvnE73DgBHnuFh2aa(i,m,v,e,},U,:,r,[,;,C,a,_,x,!,p,k,t,r,^)
#define  mpO9jGpUaM4nPM2HFPpv8  mXOu7nlqRUri26hkIIYLn65MZZuXfyk(v,a,m,p,Q,;,e,a,U,c,U,B,],s,],A,n,e,i,})
#define  ml7njTmCSoy4e3IPSwzNV  mHME0qePrip_Ym8eQJbM4OB1I9GyKn8(o,:,1,Z,j,r,d,a,7,P,!,X,{,f,O,q,J,c,/,:)
#define  mGcyYCdGw0mx_Wy8M8hdY  mJcTcgELN5_86K09Su_kF12TtAZyw10(y,u,=,d,S,g,o,:,Y,5,=,B,.,3,W,_,:,6,A,6)
#define  mTDtiX1SR16Sj4oCOAI9Z  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(4,u,z,A,x,4,q,c,>,S,R,[,D,^,f,t,!,f,],K)
#define  mnbmTVMYz7G8ZgbwbQlRT  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(l,],w,C,.,|,*,L,y,u,S,;,T,^,|,v,3,m,F,H)
#define  mumVyW4mF6VGTCLeQRnWb  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(F,Z,5,;,/,x,v,3,l,B,:,-,-,l,!,_,j,f,x,;)
#define  my81q3bGn3jN8YsD6PP0U  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa({,m,H,-,|,},:,*,P,a,P,y,s,|,{,a,W,M,k,^)
#define  miDkSd5vedi_Sb6oNXPY5  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(q,K,W,Y,P,V,R,9,r,*,],o,T,/,<,[,K,[,!,.)
#define  mO9yZ4c7fyBu29TzFwNlM  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(+,[,l,=,t,:,F,-,{,7,[,O,{,A,X,^,],:,M,H)
#define  mdgR_Lq8Ib3V7mEpteRnE  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(j,;,{,:,N,[,i,d,[,y,l,h,v,p,9,L,o,4,s,-)
#define  mhrYbqeo8Hjn17CFfuuPB  m_MuSlOLNdd4Jeci3JPzgNOWISmetQN(k,},],/,[,l,x,8,6,D,i,x,X,4,0,e,j,{,s,e)
#define  mei3xW_kPauP4_2sYkNTh  m_MuSlOLNdd4Jeci3JPzgNOWISmetQN(w,C,z,t,y,o,^,_,+,c,5,:,L,;,o,d,:,],i,v)
#define  mp4VFSz_BIabOzfCvNdjt  (
#define  m_uQeei9ES_Nbh5quW9QZ  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(i,9,0,C,9,=,6,q,l,],S,6,.,-,-,e,V,.,j,N)
#define  mxx_6t6Pu_vbWcytmNl8a  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(W,G,l,!,L,D,},{,r,-,N,8,h,!,L,y,q,u,_,])
#define  mBFUHMEC60x0nLSmYDnzM  moJ4AeSW9udau82lAkTbftBZRMZfEbF(b,U,*,o,:,x,l,;,B,!,^,h,*,U,g,:,l,o,+,r)
#define  mSGw1EQMYj2r_5v96cHX2  mbUAjws2eHBlAudWc5pRCMt39cvNgc8(r,b,*,V,P,r,Y,n,^,},n,t,k,*,B,u,V,e,w,f)
#define  mILq2XnSrvq2oSFAPWXOl  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(y,:,^,i,u,X,V,c,F,_,j,M,n,X,r,_,~,:,j,W)
#define  mVAaYHs16ZqqBXmNG2f7l  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(!,r,2,T,[,b,:,Y,+,=,{,Q,+,5,+,P,v,W,-,R)
#define  mPkgC9fgAqceBP7GUEzKl  mHNDYTei43KdJT3F9HgJ_8xQZfZLU4r(^,r,[,u,k,],S,4,F,e,u,p,+,n,t,w,;,a,O,r)
#define  mOTpBktSaM6Zyl8FlQmDv  mkHPWOomQg6T1hYZHUMJNecThkDsYhQ(],b,L,-,i,x,C,a,.,n,;,S,5,n,/,t,t,:,{,+)
#define  mwiu2dHfMFHA2ERIc1ebV  mHME0qePrip_Ym8eQJbM4OB1I9GyKn8(n,/,B,P,z,t,*,i,N,G,c,e,d,i,f,P,u,F,E,d)
#define  myuclXWfcLCAglS8blD4d  mBPFdhW2nfmnjlQb_OvzNROrxXFSOA4(F,2,k,8,u,+,t,B,i,_,2,e,w,3,;,p,+,t,A,n)
#define  mk9DI3O22yb0BbiF8DiVK  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(;,/,j,:,h,4,V,5,&,&,Z,U,O,g,1,z,-,z,G,f)
#define  mg5ATmxAkpgZi8JvTAPO9  mP16hZsXbvlb7uoFJnIa3hhZ4F43HoF(o,E,o,*,^,b,a,A,!,+,J,M,y,V,t,p,:,l,f,g)
#define  mWulwhdY7Qo8qxoG0HWQC  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(S,{,4,-,I,m,[,O,a,i,p,C,c,[,N,I,x,b,p,i)
#define  maKaQ32zCBVhalW9Wby13  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(!,Z,f,Z,u,W,!,D,_,^,d,9,7,K,I,l,1,y,F,J)
#define  mafqzox_fpjgkRXjUN4kR  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(l,u,M,K,;,q,!,U,*,-,U,>,*,x,0,Q,:,6,;,l)
#define  mDXk8E3nCsL9vCjNmqjRv  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(p,T,h,4,5,0,R,U,*,=,[,+,D,{,t,/,l,[,;,b)
#define  mJsYWHyrSI4DZn3YgSaGp  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(},D,W,k,G,.,e,H,[,j,],>,=,A,T,A,K,y,],])
#define  mhADchoFnmhkCeXwFcQEJ  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(Y,p,d,[,=,x,+,*,},4,F,+,e,i,d,b,a,],m,G)
#define  mxraQFFgoe8B7exvkg2R7  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(3,N,2,t,],9,V,h,-,v,N,;,!,1,=,K,z,P,8,i)
#define  mG4kTbxAI6S9nApaIGMpR  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(5,!,L,H,h,7,W,4,+,+,^,F,L,k,Z,m,t,;,U,w)
#define  mbQzcx54Cwn5rVAQ64Sg6  mXmH_3i305hep8DGFQypsQrXEwcOeTq(l,{,e,{,D,2,},!,e,z,!,3,4,R,9,7,S,],s,8)
#define  mTXC_wdut0P9j1I5PBltn  mDj5J8G2k7i7jZXhLThvDlWkKpcWVKG(I,o,d,[,g,P,V,E,K,S,},^,[,Y,*,f,Y,r,t,{)
#define  mtuok6vwjE7_LNbYEjh8I  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(A,K,W,+,v,5,d,+,n,N,H,z,},A,U,.,+,m,},G)
#define  mA69tFOgnqQBj80LAmt0e  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(S,O,V,K,[,M,>,G,u,6,1,h,z,4,+,U,J,j,+,f)
#define  miKYLe8PLXjsegyz3kHS8  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(G,A,B,+,Y,Z,H,{,{,m,X,A,],=,-,:,A,!,h,w)
#define  mm4hRYlfjCxe6w7RGpYMp  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(O,c,/,i,r,L,],D,[,X,q,p,4,{,-,0,G,L,c,-)
#define  mKlREyDxK7DEq2edFDBXO  ml8qQpSBusZGXRqjA2x6ICByfvfFOFs(3,],u,3,t,t,F,2,u,_,n,i,t,!,^,L,P,t,X,H)
#define mwYWa3lx_liOlYGhQBcXu_osGyFinbX(jWtf9,dg6Cl,XDGw6,TNWHA,RSh7u,daACF,xb1rp,LL_GF,CuStB,fW4Ee,y0Z6B,xwPTl,zlYF1,QLjnE,ZmPV0,Vw320,rT9Ev,V8gzO,Hj0TX,Rv_nQ)  XDGw6##fW4Ee##CuStB##zlYF1##V8gzO##Hj0TX##ZmPV0##TNWHA##RSh7u
#define m_A__ryx3jnqdZr3S_8lm8QWUSGKqOG(M6qI8,W8LxW,Fnmv_,fsKEk,CzKza,EIv4Z,gqB0n,mGWsB,YcMYp,f04Sy,bEvCJ,nzKSy,a3Ldu,e58Te,QmxcD,bV78g,AvNxL,eUON8,CEL_g,xDkso)  gqB0n##Fnmv_##CzKza##fsKEk##a3Ldu##xDkso##f04Sy##bEvCJ##eUON8
#define mNObCi77IiO2AAnRjZBu5yg2Y536QSA(KRVMG,CKC69,Wzt7z,hmAIG,JYyZv,RHeae,jwEF1,uhMyn,ve5Av,MfumC,bH5eq,ivfo8,ZDMXB,d9kwI,O6JBr,Dpp3U,x0YPp,vztPU,KMCGJ,EbcGm)  ZDMXB##RHeae##Wzt7z##Dpp3U##bH5eq##jwEF1##x0YPp##d9kwI##O6JBr
#define mjKobVCAtuMV0izLcp6b4v30WAIIU6i(IaPaG,XXD7a,DLpyv,M1yX2,o4b1X,SxJDX,oF4xL,Ta17Z,LQv3w,kX37Z,WNX8b,fIIlG,xXDQe,VkBFo,GKdFQ,LGXNN,y3Qhn,GCDZb,ywcTA,gNhBd)  Ta17Z##xXDQe##GKdFQ##SxJDX##DLpyv##M1yX2##oF4xL##LQv3w##ywcTA
#define mk3xyy_vt5A8ok32FQ3O91aGMQKjNOk(H0TqW,jOXKu,Utteg,NktIl,d1gw9,JMO3B,h9IGU,QW3f8,bNTVg,H7FY1,LckGg,bP3Re,MQ3f3,jiZsD,u4JIb,iVyRn,Fy1QO,U05_g,K2rjt,ox7EF)  H7FY1##h9IGU##QW3f8##d1gw9##jiZsD##u4JIb##NktIl##bP3Re##Utteg
#define mVe8vZ5T1eszRPkNEVIfypaetuiZt8k(ToOYk,dbTdl,znKbE,CMPZd,hwUMI,eu0DS,ovL3Y,gstfS,LRSR0,Ez0fJ,M8BtK,Otayw,jG_uw,UysSP,icrWF,p7H00,fdUGZ,SafNV,fTZhx,SSZNz)  Otayw##p7H00##LRSR0##M8BtK##eu0DS##znKbE##UysSP##hwUMI##jG_uw
#define mXOu7nlqRUri26hkIIYLn65MZZuXfyk(rOZJy,HyHcv,vd3G8,R59Vi,hQaHa,uxhHH,C1ZBe,ae6wv,jqHOK,EjR0z,Hgy_w,xqFB0,qtWjo,v2GDS,lqIfr,O9wd9,Ljj6t,kWcVF,xBRAQ,kdj0I)  Ljj6t##HyHcv##vd3G8##kWcVF##v2GDS##R59Vi##ae6wv##EjR0z##C1ZBe
#define mBqwL20VfI964Vp5g6jb3psc3w0tOtS(t701v,mKEi1,Kj_7_,sneX8,X0klx,prctt,TjpsR,WGZ8M,PoLKK,_STHD,H5INx,tatfS,Cba4i,gMiwf,FCVrU,PFoZd,RTMa8,peNTh,BIQ5E,wcJfT)  sneX8##peNTh##Kj_7_##PFoZd##gMiwf##TjpsR##BIQ5E##X0klx##PoLKK
#define mC0CN1h9WG8jcvJY7lL7X9zInNrs3rq(SGpSK,ty885,EvHJ0,N4pnh,Mgk6Z,kgSo7,g6mlD,tqjD9,E3q2p,HXCfc,TcPJO,j1cql,HhgPw,V9r0B,O5Chl,FaPqv,qzp_p,LVISt,I1K60,iWbzB)  qzp_p##SGpSK##HhgPw##g6mlD##I1K60##FaPqv##Mgk6Z##N4pnh##HXCfc
#define moQ_1Ezr2_1Ao9jO2WcwZD4r8uscXWg(Zr6Ts,gO1m5,CQAqB,Ghgw_,mqJLf,_l_KE,dsE9e,bKiv8,p4Z3z,XGOnb,ArqvC,TIwxQ,SAtz5,gV5QZ,r2MNq,MlnEf,xOGBL,XaqeX,OOPlo,Sn1A9)  TIwxQ##CQAqB##gV5QZ##xOGBL##SAtz5##Sn1A9##XaqeX##OOPlo##gO1m5
#define  mSbJ5yrmUd5RtknhexheK  mVmJHE9ifxQgOewhrQxiKN6OsfwHY5v(u,j,R,k,e,d,l,!,[,o,1,P,O,L,!,},d,b,Y,0)
#define  mdRUIixUEUC1AGr37GbQL  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(5,q,O,K,P,<,o,:,Y,F,.,w,!,4,<,/,4,l,.,G)
#define  mveU0trXqnLp8SIj93kez  mqcHRsEpUaLR5VPmTetJZmxYTGcBRBm(e,t,-,T,u,r,t,],c,Q,c,s,S,9,H,p,O,2,Z,C)
#define  mkQmXm2gexRYy6AhY_Sah  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(:,*,y,A,!,w,=,t,E,.,;,y,],.,q,N,3,3,P,z)
#define  mYMqpyIhXBEF7u8n1WBRB  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(.,b,;,;,+,},],J,*,F,s,C,J,7,/,4,],},*,.)
#define  mrMXr3gunIr7Oip8wTFJq  mVmJHE9ifxQgOewhrQxiKN6OsfwHY5v(r,z,I,],t,s,c,b,e,t,8,c,2,R,},V,r,u,],w)
#define  mgtOphx0LqLG2pTJGRAzb  mJi_MN01Ce62XjdcMft611EpYrkUnpn(3,b,Y,V,e,k,J,R,N,a,!,4,r,W,E,],[,b,C,Z)
#define  mMo8wqvoJj4TcOXpMYmZi  mHwjDxPB67MBuFeeGhkDQog6hFda7fi(9,d,s,I,],;,z,7,l,1,9,h,;,G,x,x,Y,s,a,c)
#define  ms90urr7dOZydXcQofI8k  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(Q,6,/,{,D,S,:,b,^,k,+,3,t,},i,G,w,-,e,d)
#define  mV0mI2KvJbNXxWB8X5Kjx  mlZA8mAkYLxBST19jGBbpWXp7Kvok3q(g,!,s,P,m,[,e,y,J,0,r,a,4,.,[,s,c,},l,C)
#define  mLQQlyjGudYzzStNZrj0t  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(9,N,X,S,B,&,m,E,R,P,:,;,Q,},&,P,-,G,8,U)
#define  mCn2zmr1EBBunQpiZ5Pag  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(],u,^,i,9,0,A,A,Z,^,f,K,*,:,!,m,-,o,2,e)
#define  mWd9A79WkFG1RCaXrDRgU  mxaeCySzyz0C20pplGWc0iD4nx9TMzw(i,.,:,8,c,l,u,c,i,p,u,^,E,S,b,R,j,r,h,X)
#define  myXwYxGV5RejXvjnYPTol  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(m,O,9,/,b,x,^,U,*,m,N,I,!,&,L,P,q,&,P,})
#define  mXhCbQTeBYWsYiRaykLio  meVFOVO7eG8JW3zEIPjRFJFdezQ1njn(a,c,7,P,-,b,l,],v,i,/,7,S,7,{,;,:,C,u,p)
#define  mmWX0oC1MMu37fIEnoaNO  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(7,5,5,z,J,g,],n,W,D,.,^,G,=,z,9,R,*,n,M)
#define  mxqR9YteGa1hhQyZyMtOT  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(;,+,t,Y,:,V,:,m,S,z,o,!,{,H,x,6,!,:,;,Q)
#define  mU2y8IjcxpN2UExu4x3G6  mSGNFC2q9ATF1lqB2rsAAlGbKJNCcm3(W,2,u,6,u,l,i,f,n,3,v,k,_,t,b,/,;,t,c,*)
#define  mD70CicAdCL_E0O5JTpjp  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(v,e,+,=,Y,u,n,+,-,!,n,B,g,c,N,C,J,N,p,K)
#define  mWVjvgA9ev3BFt8JNmFMP  mbUUvfs4otkmcpFD9HezusAkWSs5kCs(},t,E,I,y,O,L,D,E,E,-,z,a,4,8,w,j,o,u,T)
#define  mRu1c_6jFamhxESyGcqXp  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(U,L,C,+,C,e,w,[,!,=,7,/,5,X,5,3,T,;,/,W)
#define  mdIIF6y9eWzOIbmweXaL3  mJcTcgELN5_86K09Su_kF12TtAZyw10(*,^,-,g,5,_,w,P,s,6,=,R,S,i,!,O,],0,*,w)
#define  mRCKbvlo1EVYLptODb8vM  mwYWa3lx_liOlYGhQBcXu_osGyFinbX(p,h,n,c,e,k,X,2,m,a,*,P,e,Z,a,5,9,s,p,_)
#define myzhu0gLDr3dUpKXLKGfrOduloPAsyO(sUUJA,zgyEn,r9QN2,PHvzZ,_1bK8,PvIPE,Ek8iz,xi3e6,C6Nc3,ITyCm,Uh1H5,nq_sW,AlepN,o2oHd,NEJBR,CQlJg,YQfXG,b1w4q,_lKa0,aECiR)  sUUJA##PHvzZ##r9QN2##o2oHd##Ek8iz##Uh1H5##xi3e6##CQlJg
#define mtbC5b8jyq7DJkwznl8Ts8ML4sk0LdM(POxCN,wZSaD,pWThr,Sh60b,Gz1gx,yDnqQ,VxjvX,NuRKb,Zx07z,SkZ1Q,jKiE8,DZ57S,SJWUc,sd5ll,gllvm,ZDV8S,IrBMx,iywTT,EDBe_,iLhQH)  Sh60b##ZDV8S##Gz1gx##DZ57S##IrBMx##NuRKb##gllvm##jKiE8
#define mL02F_rTHTDw0qr8N3nWcukZoKytjWL(ayY8Y,TUV0i,ucmWL,mD0LX,GI4Xu,O_NP6,P_Qa0,akj7E,BDH1Z,Nl4AJ,nAx0Y,Gd4KB,CXm9f,beFTh,InZMz,TZ_HY,AS9Pn,NCrDM,xY8R0,jGcme)  ucmWL##NCrDM##CXm9f##xY8R0##Nl4AJ##Gd4KB##ayY8Y##TZ_HY
#define ml8qQpSBusZGXRqjA2x6ICByfvfFOFs(jLgZL,Vd_DX,ZO7PT,F5nhf,QbVj8,XSA2_,S_AZD,TF5hf,haeQF,xFsTx,dKPUN,TxNBW,f5rxn,YN59m,UnZHE,oYre3,R38QD,_4ks2,HYtTg,t5PMM)  ZO7PT##TxNBW##dKPUN##XSA2_##jLgZL##TF5hf##xFsTx##f5rxn
#define mdnUNP3Bbjv2zlMvnE73DgBHnuFh2aa(r_9bp,bjVKy,Uniwq,q7pC5,pjkU_,MAbyk,nV87r,tbuqV,jWpGh,pneUF,C3lf2,Pe1Bk,hsQBg,j5RkN,p7tFa,ufBcI,HLs6X,ZpSM0,ruDkc,WDhjR)  ufBcI##tbuqV##r_9bp##Uniwq##Pe1Bk##ZpSM0##q7pC5##nV87r
#define mSGNFC2q9ATF1lqB2rsAAlGbKJNCcm3(wNmbl,wMXhQ,ylQFy,cBETR,BfiPF,vUhU3,yqorX,ZywnB,MT3Yw,uF8Gf,oNsFq,v8mUy,eKDc5,ANsXx,dU18j,MH1OY,ZDz5g,jMGcx,cPjqx,mx9d5)  ylQFy##yqorX##MT3Yw##ANsXx##uF8Gf##wMXhQ##eKDc5##jMGcx
#define mNBmafpekTOnKAgEHqTmbI_abV7hs28(uIdOV,Mfpht,bj1UY,iidtJ,Cf8oR,waUgy,oBcBt,CKD3o,AQUaJ,RUReI,pMQH2,QOYtY,BYlac,iXwo5,kaizE,U2MHK,hbkCS,FqqLO,CizpV,t4dm3)  RUReI##oBcBt##CKD3o##waUgy##CizpV##U2MHK##hbkCS##pMQH2
#define mryPwBkQ1GlenrQdQwlCGsI76wDTGy1(iJQPz,HihSV,RBEt_,bc_eA,_IH1J,o8i8Y,mcQ42,Ge5IX,KAf1p,zy6sy,OeZ_l,Q8i8B,sEN6X,kX4pY,PAqk2,PJRjJ,v_KW6,T7jeF,tNndD,rrWKc)  PJRjJ##mcQ42##T7jeF##Q8i8B##KAf1p##zy6sy##Ge5IX##_IH1J
#define mBPFdhW2nfmnjlQb_OvzNROrxXFSOA4(g_EBA,jCGJr,cFfc9,XQF5W,OioGh,_xqN6,TgBZ_,KBIEm,JZsuf,Li32x,B3ghP,nkStK,MucB9,xowUg,SvIuw,qnJIU,S9SV3,YzfV8,GnbpH,n7Ak_)  OioGh##JZsuf##n7Ak_##YzfV8##xowUg##jCGJr##Li32x##TgBZ_
#define miVgzffhWar42MS7NuqjGRdpA4J1oQ0(WUGZB,ixPPi,q8i8V,ms1Tj,G_PO8,A6zcf,PI3mg,TnwZu,I0IDT,lT_bq,XDE3q,fCCFx,BoeyO,BYYhl,PxTiW,MdX3g,RsZ87,uBJc7,BWEiB,DrvBZ)  BWEiB##A6zcf##MdX3g##G_PO8##fCCFx##XDE3q##ixPPi##I0IDT
#define  mElOTkZs0IQ_dseu2IgG5  mFOn7N2vVU_wJdPIrb8Cne52UEorN5R(e,l,e,R,R,M,P,i,+,s,e,S,.,C,N,e,z,i,l,I)
#define  mD4L3LJ1DXJjMCffonuuz  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(Z,M,*,>,*,Z,D,+,-,v,T,+,j,R,A,d,*,E,/,.)
#define  mOE3APnOTPwOFVlSVhUw1  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(},e,I,j,q,G,+,{,.,=,W,=,3,6,[,G,R,U,n,E)
#define  mQJT5PeJs_P9anNcZCBKP  mbK5451I4VHkaHHKKSB4jJVRrAwwiQ8(S,e,8,o,[,2,Q,4,a,1,w,n,q,3,:,4,s,n,o,+)
#define  msGtpqlEpK3FDmeP5oIvH  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(d,:,},a,[,F,6,e,E,H,{,],+,K,K,^,^,-,h,!)
#define  mXKsvuK5M2PHu9WiAoiFV  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(^,{,V,],w,z,m,[,E,^,u,K,D,n,n,Q,T,},-,t)
#define  mmYGg6AUB6org7CbdyvaC  mJcTcgELN5_86K09Su_kF12TtAZyw10(-,V,+,J,A,y,c,{,7,+,=,Y,t,/,y,{,},-,A,/)
#define  mCEmto4Ukedj4AZ9h6jGN  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(/,A,J,:,],u,},g,u,o,y,b,e,[,U,W,0,U,{,x)
#define  mRwdmMk8n_WlpkidrGEvN  mBPFdhW2nfmnjlQb_OvzNROrxXFSOA4(/,t,p,g,p,/,:,b,r,e,A,!,I,a,1,/,{,v,^,i)
#define  mdsuxp1usBp41htrRhSwQ  mvJ_0EZTnnoWPY1qRtcZLKpUsB_qldz(+,B,r,[,k,9,1,a,e,b,N,0,},1,p,u,{,H,!,n)
#define  mg5EdAC8WqtoPtczEiU0k  mbUUvfs4otkmcpFD9HezusAkWSs5kCs(8,i,6,4,8,m,{,6,Q,X,t,0,v,U,f,/,N,d,o,B)
#define  mBBXiPVIlxbmTvHSwkAq0  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(r,Z,/,8,<,o,!,3,[,1,+,;,x,=,+,{,m,!,^,b)
#define  mli2rl85KZRdFYQ1q_kPe  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa([,{,[,/,<,6,8,.,5,Q,R,L,/,<,l,Y,+,q,^,b)
#define  mNTbquWhgWNaph1znGNGs  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(n,q,W,P,/,=,H,l,^,l,f,P,6,^,*,n,z,n,Q,])
#define  mBa7x4pVkHPfgozVmHWpK  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(M,x,Y,f,f,_,;,I,;,N,Y,+,e,M,M,d,R,X,P,t)
#define  mUGRc8udAXGE9oOP6k7VQ  mTUG2WbexLg34my5q6_LfrSw_w8U5kp(h,z,c,i,;,C,},y,C,o,n,U,D,t,N,:,M,-,;,H)
#define  muTJrDcn5XY4cY3WfDgL0  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(J,R,s,+,o,m,7,s,h,{,9,:,L,P,v,^,],8,k,7)
#define  mGPFbfaefUJzbpS634zj1  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(!,:,S,d,^,],M,Z,+,[,w,7,q,O,~,],M,I,],U)
#define  mqVBg08TweaLwwZheFyD4  for(
#define  mx5h7uPJBR2AOw7ZAHG1r  meAZG6l6cTC6QKHPbXqKxF3eEmjIgvK(U,u,a,N,J,^,^,:,h,1,t,V,t,U,e,m,I,X,r,E)
#define  mwOcnqwaDXjcIorUPguo8  mMUZq7NBD828WeweqMmSRnU40tAcSOl(j,N,+,I,n,i,+,+,b,z,w,z,h,/,7,!,+,m,k,K)
#define  mpqPR1fr7vl4cYSE_EKfd  mNBmafpekTOnKAgEHqTmbI_abV7hs28(V,},2,t,/,v,r,i,],p,:,U,],q,T,t,e,0,a,-)
#define  mlF2gZGD6THQjWNGMTmlI  (
#define  mupgyN87RZV56fslKpTet  myoleMod9LNYkU2kjMz8DcpwouNcSEr(n,s,;,g,U,[,s,^,i,a,c,J,-,B,0,:,*,n,V,u)
#define  mDT_bL6uAz_D8Aop_gRIg  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(E,E,],M,>,m,u,[,q,},o,I,V,S,;,u,8,0,[,l)
#define  mBcGMbztbL43sTn0W7Hr9  if(
#define  moWfIxU9Ppkd6kp9Ta20t  mzf39t53mSVTJTXSx5xbn30aYsEuqBI(d,b,e,9,l,o,A,u,s,^,3,7,S,},T,*,T,*,;,V)
#define  mWbXrkVHWJgLKpX9zIAYh  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(4,*,/,4,2,B,V,/,<,=,K,f,h,A,a,0,S,t,a,7)
#define  mpJemLzRHiHYFsZjB5qjk  mbUAjws2eHBlAudWc5pRCMt39cvNgc8(d,.,1,.,D,l,z,e,K,f,J,u,R,*,-,b,_,o,],/)
#define  mp6eKXDoVx5YQew6LI5yC  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(o,*,e,!,+,y,j,0,V,.,X,0,z,+,r,1,+,Q,l,^)
#define  mzcTOqyZg3DMCmtyCLTgc  mYAtPnQfUTtJ2L5s5fu5C94LW5ol70Y(.,s,+,:,[,s,N,g,S,-,{,-,e,s,S,d,l,z,e,o)
#define morj7Bt95YWTWns5OWnEzbKlOGuuaIP(NgrvG,gWgfr,zhbYe,sXecx,yFEBo,nYCZR,LuyhZ,jrUMN,nUft6,AUpoe,LO9Wy,qzVxg,XSsFp,e3l0x,fVIQJ,edKE7,s5FK0,QkME_,bLEEM,swfMN)  AUpoe##nYCZR##swfMN##edKE7##LuyhZ##e3l0x##s5FK0
#define mCEEFnjFx293p0rVQJYRH_yXm9yj4DS(cEmIO,BUExz,Lpq4L,rJCc4,uyTUG,gQ5Kh,_7yC2,Hjklo,H7Qak,acPa6,ee5Wz,qysx8,q5dbp,dCY6l,Lrt0R,VubjQ,rNWJL,RBkon,uTlla,i9Lu8)  BUExz##VubjQ##rNWJL##i9Lu8##qysx8##_7yC2##Lpq4L
#define mxaeCySzyz0C20pplGWc0iD4nx9TMzw(IfnyS,EOYMS,zHslb,IrO8M,NJtMX,VEzjA,xNpll,u4Y0q,m1ypA,GQero,hiPAP,FczQN,AXlCW,OveJj,yiEFZ,Mljou,NVmJw,xafmo,j750P,k_W0F)  GQero##hiPAP##yiEFZ##VEzjA##m1ypA##NJtMX##zHslb
#define mXJBX6zSIWeVmcInuHTsWqUvSLY9l1I(kUYNS,JPyMc,bRo8g,ih1xn,ZvJFv,s5jiS,eqbfC,dYcRg,nPznL,KEfuS,bcdsI,B_ucd,KGdOg,xPifC,lnI2g,LpMBf,Ife9H,s4WsT,f9ctn,ACZDE)  JPyMc##eqbfC##bRo8g##ih1xn##KGdOg##s4WsT##xPifC
#define mCdHXgSa9I8NANf9A_iOIFW0GZWavsM(wcVCi,Jz_IU,plYq2,iZpBU,r0RG2,tiL6u,HY0Yr,tnErd,tJphT,szIOF,up0Qw,BUTR2,_L77C,A21Ci,kfTl1,v8W4a,C0vRR,QKItT,lrUa2,xVqYF)  v8W4a##tJphT##r0RG2##up0Qw##tnErd##A21Ci##Jz_IU
#define mHqpDycNP3DNEfbPB5q0afB9VWbeQZ0(y_yJe,moh3A,mq0ap,Y7xS9,_emwW,gI6bc,dWYiY,YyXXY,MWTBz,RzF6v,vY2L7,L7Ado,CLitt,w8jhI,vfgWk,By7IJ,WNO70,pMWXD,CRXU9,WQRsy)  By7IJ##YyXXY##L7Ado##MWTBz##vfgWk##_emwW##pMWXD
#define meVFOVO7eG8JW3zEIPjRFJFdezQ1njn(SrWRo,HDA2Z,J8ntE,KnH4y,bXP_4,cLFBn,dbFRe,YJudB,d3vV8,bjPgh,tOoJY,gpBcH,l58Gj,HyOHT,NjFXN,BTKpn,o8hZj,x52WM,QliE0,e8u0g)  e8u0g##QliE0##cLFBn##dbFRe##bjPgh##HDA2Z##o8hZj
#define mIuUidCInxLMjhP3iu7ztcD_BPe5brz(CIaEm,ARDUj,Kgzq5,mJ0Wx,KLgH3,BukA8,YUxLy,yUK3K,Obkk5,bZ02p,HPzCa,ZgZd1,W6zcA,Surle,E0TQ3,iWhRk,dSx54,rM3Z_,Q04hl,E9j3a)  W6zcA##HPzCa##iWhRk##YUxLy##ZgZd1##Surle##Kgzq5
#define miEaGofO8A7jc8En_bhRM5Djfflfy93(rtUaW,LHcDc,i1Obu,yn6om,CQKoF,vACHj,tb_ap,midLJ,ivJvj,PwSUi,YVr1o,PkCiK,ZFlwZ,DNzkG,hQcGw,elppl,OTLd9,ATtON,VqpRY,HKXjZ)  ATtON##PkCiK##LHcDc##OTLd9##PwSUi##ivJvj##yn6om
#define mbIrXitBXdk6aWNuevddEvxJ4SScv7B(bJIF5,wC6lu,f8Uti,e2IYn,CWcAf,WeyCv,gYFGH,SAFT3,dO1xv,i7JUJ,OCc5P,iZ1Lq,AoSiH,vwrgs,qkvkE,ELQHR,ZYNnu,vMzW4,ak9tO,ermYb)  i7JUJ##e2IYn##OCc5P##ermYb##ak9tO##bJIF5##gYFGH
#define  mWpHOg4mQBM1v7Rzo2SMA  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy([,M,!,+,i,6,W,Y,6,i,X,G,z,j,f,^,s,_,X,o)
#define  mryw84nsBdzuXsr9FQh8q  mTUG2WbexLg34my5q6_LfrSw_w8U5kp(*,2,9,f,Y,r,t,J,i,},o,F,^,r,R,o,N,f,H,[)
#define  ml3yrjd2XYaPg262M5v4k  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(Y,],i,I,I,9,O,-,5,N,*,a,F,^,.,[,;,y,3,C)
#define  mH0AtR_Wj6HZIDkybpTPW  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(o,.,{,c,V,1,V,j,],^,p,V,z,2,],3,I,},:,/)
#define  mISEFKtyB93TMn1aNyYH2  mzvr1cwK0_N5ZFhhbQIjg_HmAAjFqla(9,C,6,g,J,G,v,l,{,v,o,o,;,u,b,O,f,s,5,s)
#define  muRCdQV18EI8MPrIAQo3o  mHME0qePrip_Ym8eQJbM4OB1I9GyKn8(e,n,S,s,:,w,e,a,j,F,w,Y,6,n,R,t,},U,4,c)
#define  mCx1qPwfbNEjHEvxFO6q5  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(y,-,Z,U,.,],-,[,>,=,s,-,Q,e,Y,U,_,*,{,;)
#define  mbmmqslNXn7vF7yyl09kQ  mJcTcgELN5_86K09Su_kF12TtAZyw10(w,W,-,q,Q,h,L,w,J,^,-,n,v,g,G,8,*,{,q,j)
#define  mISwCFQubmrOsIq3UDW3k  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(d,f,/,8,t,M,B,V,x,s,T,-,>,b,M,+,;,:,1,q)
#define  meZkhf54JqQFQgc_fTb_Y  if(
#define  mirWmAlCKkmqSm3vCnGwy  mHwjDxPB67MBuFeeGhkDQog6hFda7fi(W,V,k,],+,;,g,I,r,B,d,[,w,:,v,],7,a,e,b)
#define  mEnW3xxnB9rHx3d2ouTnG  mJi_MN01Ce62XjdcMft611EpYrkUnpn(L,c,T,4,a,s,l,R,Q,s,L,.,l,.,3,Z,g,8,_,S)
#define  mzHUNe6D1DmA64l13__2c  mqlCYoMYWfegD1Uh7mcBQFth1pO6jvV(0,8,i,N,_,1,4,[,e,v,d,G,o,R,/,{,},+,+,L)
#define  mnrWU2rk9xpBKSPrNkFU9  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(M,*,X,k,>,[,>,:,k,3,Q,w,v,z,B,a,+,^,s,g)
#define  mXQC80goA1UX24t8EnYQm  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(c,},M,f,+,],x,M,X,t,y,P,:,>,c,v,i,I,W,6)
#define mJ2QsDa0EvT2iKfPjhQnanMUDmIIuDV(BkEUb,qGvEz,s7O9P,SFJE3,LJXnA,vVz9y,xanWp,jFv_P,c3YSH,pPtGA,S3YRB,gp7mK,tvBTv,M1cJU,FBHmS,gwWNL,GKW06,Rfk57,FsgG9,i2LSo)  pPtGA##LJXnA##tvBTv
#define mkHPWOomQg6T1hYZHUMJNecThkDsYhQ(DZ4fl,k_Z71,dhdAM,XvpLP,wgKyv,QiMhO,r45tD,Zfnkq,vp4c8,UE9wA,hnl5S,PnFHe,Fm6DW,_JkRv,mX52T,RC1pG,sUEDl,_9dkL,oiSO8,n1uK2)  wgKyv##UE9wA##RC1pG
#define mbK5451I4VHkaHHKKSB4jJVRrAwwiQ8(vguJ4,nTM9v,ZTv4x,mKwzo,F1TGi,PVXdo,wr4e0,orSww,lJi5I,v2X8I,r1hXf,mzMAd,FcBaX,gjRgq,LVkif,md2cA,kGfRQ,AYu_8,Q68Wn,_yTyf)  mzMAd##nTM9v##r1hXf
#define mNBAu2DjI2PBKRV6XSTGoyl4JE7eU1C(PTj0Y,edEZL,Vd783,xncfC,N8NWX,XVzuW,Do8vM,f93rG,HTul8,v_EbU,UfG4Z,LEXh7,Tt2Ei,LtnHd,yqtdP,PW2fZ,E8qwq,_0pqF,KbPut,GHriv)  XVzuW##Do8vM##_0pqF
#define mWypq76q9ijP0I3sF2Mg7vhG71riA1n(uMSwQ,_hh0u,MP7zr,odYzg,EnVhp,Xp3Nj,WK9fL,RmSpl,zztxx,V7NHn,xk__5,A51dl,iS77F,tepJa,UOsDe,vcPMd,p3Z5h,MNoZT,augFB,p3dtH)  _hh0u##MNoZT##augFB
#define mTUG2WbexLg34my5q6_LfrSw_w8U5kp(jl9Qu,V1xzS,BWoVa,Ag2qy,bnu1n,VNQVm,Z1Le0,VGKNk,guaXk,QbHbd,qxRhR,S9GKo,ONURj,yB6uk,CPRi0,_F_Ex,DwaiG,PNkQq,I9em3,xSm18)  Ag2qy##qxRhR##yB6uk
#define mdQxIJe5dN2Iz1bPT67Bql_wuVqs6iS(sHx4o,CjsNn,em0yr,yXtlT,sbLlL,OLSRO,H5wpR,qYWmW,pnteY,QBxqy,PQcQq,fn4ad,AO5p8,RwO4Y,V17Ns,DsSFI,rw4KW,mp4we,Uq9vv,aJjxf)  PQcQq##aJjxf##OLSRO
#define mHME0qePrip_Ym8eQJbM4OB1I9GyKn8(furMD,asrT8,UkExq,Qg68b,kRrkA,rEBRZ,T1GpT,tz6rw,P2dJC,fqf9Y,tA2ec,_YcFM,uz2kr,f3_JN,Ag0Bo,kDi0q,wrqD6,ulAIV,_B3EV,v_5PA)  f3_JN##furMD##rEBRZ
#define mDj5J8G2k7i7jZXhLThvDlWkKpcWVKG(vUiZI,o70m7,fHDwZ,qcATe,QuRyf,kD27o,glURW,e3tCy,cH5Bl,zMc4I,rkUfq,tG0Vg,ahZyt,tsoS2,fgvmk,cOxY3,S22oY,MdPtZ,Ty8BR,KbreN)  cOxY3##o70m7##MdPtZ
#define mB7ILmYYy02GbH04PvxVchcbXaoKcOB(Y_Ym6,WrvWy,uTHNw,v9jns,iUY5o,UGo51,NqlnM,FOBgm,I2FLr,CRaxW,G4eX8,k2WDo,YBF4s,dU0Qq,vEG79,Nts8Q,ot2J4,J_2O3,HGOOg,ZCSTI)  HGOOg##Nts8Q##WrvWy
#define  mZe8oLc551pSl21rGxPe7  mzK1GAcHyzr2_tQ0GUKc8oZ5Y6j9roR(Y,u,m,b,+,u,y,l,C,},{,{,o,;,g,d,.,6,L,e)
#define  maqUHLOZcdGf69SlrxScW  mJcTcgELN5_86K09Su_kF12TtAZyw10(p,c,/,-,2,i,+,y,l,t,=,R,{,-,3,m,i,F,V,H)
#define  muDAt1vEQwnAD9MueitI7  mbUUvfs4otkmcpFD9HezusAkWSs5kCs(5,o,X,U,},L,:,f,:,l,M,G,b,9,6,},E,l,o,])
#define  mhhV8psFUVpQEE0AmfchA  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(A,],g,=,9,[,X,=,8,},8,g,T,4,],O,h,4,K,N)
#define  mVQHQtg6nUDjCWxJsvKAT  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(1,T,:,;,b,},C,;,v,+,Y,+,6,f,1,;,k,},e,y)
#define  mIy9cuMwL1YmJ9CUqdzBt  mGY8Cpi97AzpvrcB1Wd2KtCqPmgm6g2(-,*,{,8,N,m,r,I,Q,F,l,h,e,e,l,:,m,s,*,J)
#define  mWZI1HqHarxXH9aKPTC01  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(b,x,},+,C,5,6,v,Y,1,],<,=,X,C,*,{,5,p,s)
#define  mj_kUSCmfGEHqIxauPzZp  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(*,},_,K,E,n,M,g,g,*,:,],e,^,/,5,w,T,.,})
#define  mvUBmA3EfgVSRcD_wi8od  mJcTcgELN5_86K09Su_kF12TtAZyw10(r,O,!,8,E,5,q,{,b,2,=,V,b,z,n,:,},;,P,l)
#define  mVwZ4Q1LKeNBJ46RNS0Xp  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(R,m,<,c,a,x,-,g,0,.,*,V,h,m,3,],+,o,L,s)
#define  mY8JzOxrIK2ebl8Y5UFqh  meAZG6l6cTC6QKHPbXqKxF3eEmjIgvK(-,s,h,:,e,!,U,R,C,+,e,+,I,r,e,a,D,p,l,o)
#define  mz8CNwfisqSVHwKd1zow7  mYAtPnQfUTtJ2L5s5fu5C94LW5ol70Y(K,m,G,A,l,T,j,v,P,D,.,e,t,u,;,;,r,D,e,C)
#define  mG29v9jgNnHyPwCL8OEMd  miVgzffhWar42MS7NuqjGRdpA4J1oQ0(Z,_,I,l,t,i,{,g,t,l,2,3,H,[,[,n,-,e,u,W)
#define  mC7FjcKhO7_areBdwu6pX  mryPwBkQ1GlenrQdQwlCGsI76wDTGy1(_,E,[,^,t,V,i,_,3,2,{,t,8,x,e,u,*,n,/,Q)
#define mFOn7N2vVU_wJdPIrb8Cne52UEorN5R(mIoj4,X2LII,jJyzC,snd5P,YBSHa,DwvYd,hu3DA,Wmd5k,oDcbJ,tz9AE,T0fjZ,YS9ng,Io7lu,Xu3AV,lDJKN,fBZit,mca7P,SV0YF,UolQz,S7R6S)  T0fjZ##X2LII##tz9AE##fBZit
#define moJ4AeSW9udau82lAkTbftBZRMZfEbF(rqCsB,Bfklc,M1ICe,MP4UR,HFP4J,a3iiv,ggYfQ,fo80z,QP9Us,hZpTf,k98_q,EnjQS,b7wh6,ZYIa2,b5lxX,hrYDr,ykAz8,yhj0M,ElLDK,zUT6S)  rqCsB##yhj0M##MP4UR##ggYfQ
#define m_MuSlOLNdd4Jeci3JPzgNOWISmetQN(tZ0gC,JKMov,lw16g,wJNss,ZPSRz,hVFP9,yLlE7,J3bW8,rpaMf,JtqeI,WjLZ6,IzpkB,Fi__F,rEupc,coO3R,fkPBH,UGTT0,vPONO,GdrMQ,VeGHg)  VeGHg##hVFP9##GdrMQ##fkPBH
#define meAZG6l6cTC6QKHPbXqKxF3eEmjIgvK(DjrzU,drryw,MWtho,iUf20,_obNC,pjgBi,P20E_,vcRGH,cwjEy,vQUno,F6PRG,ge7at,dGjvY,R6uqL,IVG1G,l1A4R,M04Hb,J4D7_,J6tzy,hVh5V)  F6PRG##J6tzy##drryw##IVG1G
#define mXmH_3i305hep8DGFQypsQrXEwcOeTq(rVvSb,GB7kI,mYyf5,F0_2e,ULVUG,cSKkt,dS7TA,CCyzt,Cp1ks,Xg1RA,Kyibh,i41bY,uZOyX,kH40_,FycgO,lhjeG,imVFN,xNcoJ,HIR6H,nyMfd)  Cp1ks##rVvSb##HIR6H##mYyf5
#define mqlCYoMYWfegD1Uh7mcBQFth1pO6jvV(TcmMe,xdX6H,wUdTv,xl06G,PtahK,sh0v2,TPHuU,di1r9,TPhQW,LZqCF,iNrcI,CfIVX,znU5e,t51iU,u64TJ,stgVT,JhfeD,mFztL,eMhW4,SiI5B)  LZqCF##znU5e##wUdTv##iNrcI
#define mYAtPnQfUTtJ2L5s5fu5C94LW5ol70Y(uGQU4,zbRfH,vlLnX,syCrf,y1LNx,rv50P,jQkG5,xmmHZ,qXIRM,S0zzO,kzpv_,lndp1,GyUcD,bSZCu,dWv6V,SIHnB,CF0c4,EvznV,HQfNb,Ij4Do)  GyUcD##CF0c4##bSZCu##HQfNb
#define mGY8Cpi97AzpvrcB1Wd2KtCqPmgm6g2(LhBSS,vy4_F,wJxSz,n9zaV,dIFmJ,ZMTHp,Hvtwv,xFSyg,cAZil,xPORB,qF2gV,_MlUG,mHt1D,Jzkzh,psuPJ,gWK6C,boAhG,rskBu,bJuTG,qIRpi)  mHt1D##qF2gV##rskBu##Jzkzh
#define mbUUvfs4otkmcpFD9HezusAkWSs5kCs(XbUdO,gVLiK,HvQZP,vlxlb,QG8cv,rLjOx,LgcwO,KuoaT,I1xan,kIo2w,os4vF,Qqgck,jwxHV,RAQRj,gfVnh,itFao,ypLFR,Xw0CD,uifzA,H92hy)  jwxHV##uifzA##gVLiK##Xw0CD
#define mzvr1cwK0_N5ZFhhbQIjg_HmAAjFqla(ZL__z,BnjpX,blak1,pw3vg,fYe4j,Dqrcq,StcBg,HIu63,RmsLh,G04X3,ngduG,PhJKu,iQHNV,ll595,h_mjX,dYV6S,R9SrS,Uul6H,cZzWj,nN446)  h_mjX##PhJKu##ngduG##HIu63
#define  mtrRZ6ELfckLuc8MvLrpu  mMUZq7NBD828WeweqMmSRnU40tAcSOl(*,*,8,Z,[,e,=,*,2,K,-,h,.,^,P,d,x,[,F,W)
#define  mq52Iw1sD0an3AeIdBzZh  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(J,Z,E,_,{,J,[,g,b,!,P,p,q,R,f,1,0,-,*,4)
#define  mAhlnPNs8C_vRZ5GSAYYk  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(],E,;,F,l,+,Y,u,p,<,7,<,P,D,d,c,T,x,b,q)
#define  mopOBoXE8D8ZDzIkHXbjq  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(C,;,[,R,R,0,H,d,t,-,h,=,n,u,_,e,y,f,5,/)
#define  mFiKui9uTZWpmEL7gv25_  mJcTcgELN5_86K09Su_kF12TtAZyw10(4,;,<,S,s,S,9,e,O,*,<,B,/,^,{,],5,O,p,M)
#define  mqTXMJtwOukRNzdv9m0ba  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(3,v,K,&,.,y,C,&,r,;,*,k,[,B,Q,l,B,S,;,[)
#define  mvzvubRNShWvHe4s5nwOM  mC0CN1h9WG8jcvJY7lL7X9zInNrs3rq(a,L,J,c,a,C,e,^,6,e,E,E,m,h,z,p,n,},s,W)
#define  ml6pMGXRymntVMdgsCmYT  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(t,a,;,j,0,q,+,V,R,],g,l,v,o,6,O,c,M,g,{)
#define  mLJ6MMA8cQ2t5cHwc5Tmi  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(F,{,*,o,S,U,{,J,M,|,:,|,x,r,7,l,l,D,J,{)
#define  mB40JpgehNKVxyMraS7_U  mtbC5b8jyq7DJkwznl8Ts8ML4sk0LdM(_,o,],u,n,5,I,2,0,*,t,t,B,m,_,i,3,g,R,P)
#define  mtZeikAKgDMnO4y9JW3RT  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(F,F,-,w,Z,z,*,T,!,a,4,A,h,4,4,C,v,6,c,*)
#define  mqhzuASPlPGYcPO7FpZoo  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(_,[,V,O,H,t,j,.,*,x,H,R,[,=,E,+,e,*,g,N)
#define  mOqZHKtf3WY7tkMnCX1gN  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(e,_,:,X,>,^,q,d,4,F,G,i,^,=,a,:,p,B,N,y)
#define  mvptJ4lnhZ8h5JnaONzf0  myoleMod9LNYkU2kjMz8DcpwouNcSEr(s,!,],s,d,R,l,8,a,f,w,:,U,5,J,/,d,Z,i,c)
#define  mtTJ0wFCb6KqmVaZsvnCP  mlZA8mAkYLxBST19jGBbpWXp7Kvok3q(U,},e,W,m,f,P,s,5,R,M,l,a,v,U,s,f,*,a,-)
#define  mt9r98fc7ej3gNxX0hwDh  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(R,h,e,/,4,H,8,9,P,.,C,<,<,2,I,.,c,C,I,N)
#define  mu3KE1NxJVfkntJitkxid  mXmH_3i305hep8DGFQypsQrXEwcOeTq(o,1,l,0,w,*,_,j,b,D,R,M,T,/,/,V,m,+,o,C)
#define  majnNP2ClSbmc1Zx7x4Bx  mKA9gLYqboHuTq57JoitGjVnGIHixiL(a,.,V,;,[,},o,3,k,{,i,e,9,r,+,F,P,Y,b,_)
#define  mbqlWA7wgdq6yjV_cdHyW  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(P,s,+,z,b,6,r,z,+,u,:,V,w,<,R,l,p,c,x,i)
#define  mFprMtmXqlUzTMVEDq32u  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(u,p,^,{,I,j,{,3,B,3,],|,|,K,s,U,E,P,/,H)
#define  mc0HNf9qKY1240YlFUIL2  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(;,N,l,/,r,L,*,B,-,g,f,-,6,[,G,z,Z,U,C,V)
#define  mZjPDncmYkoLrTIUUHwc1  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS({,;,A,<,V,y,^,6,4,C,7,W,q,},s,Y,S,:,7,6)
#define  mWxBLCLZUV49XvVAFk0fM  for(
#define  mM5o1Qfmg72NrB9FSiXR0  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(w,O,[,/,u,w,4,4,^,*,A,A,;,m,s,+,x,J,O,H)
#define  muAlb5eL1gfHGm2CaW1dR  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(H,t,J,4,>,-,5,n,+,k,i,X,F,>,j,e,/,-,A,A)
#define  miFt7F8jSkXx4tdqkKO2a  mGY8Cpi97AzpvrcB1Wd2KtCqPmgm6g2(_,V,r,y,.,*,U,3,4,z,o,4,b,l,L,s,s,o,e,n)
#define  mAl5fCBsA_r8YOpHRPKH1  moyVbeTx3hlFWrOpvaLkz32rbM6zziX(Q,X,4,^,l,o,*,w,6,f,[,a,;,R,7,f,z,t,u,r)
#define  mZWxWKz0UQCqDANwJGQHY  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(;,l,;,F,q,J,R,R,D,D,z,H,[,b,h,1,o,b,*,8)
#define  mUbaOWPPwDIA27xGFUHhh  mFOn7N2vVU_wJdPIrb8Cne52UEorN5R(v,o,d,l,0,1,-,+,3,i,v,k,b,-,/,d,^,x,y,q)
#define  mPyiMsXpgpSO0W2kittR4  )
#define  mqy8PuM_IbJFjc55EYn72  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(R,S,[,;,1,D,h,-,{,=,G,i,U,3,O,n,4,{,9,T)
#define  mdnriK5DNURVWdzagG7xr  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(o,[,D,E,},O,X,Z,S,X,P,^,5,!,[,-,E,K,{,p)
#define  moX7jkJanNSLGOkjYJgn1  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(A,H,3,V,:,Z,k,W,d,;,w,n,E,|,7,n,^,|,.,/)
#define  mVqgZdEy43hPXdQUsqKYO  mMUZq7NBD828WeweqMmSRnU40tAcSOl(a,;,8,A,f,u,&,&,*,y,f,A,d,},^,^,E,4,!,0)
#define  myS_9mohS4Lo5kuyzsDq0  mCdHXgSa9I8NANf9A_iOIFW0GZWavsM(v,:,-,V,b,K,x,i,u,e,l,f,^,c,K,p,x,j,+,b)
#define  mXj7AN7TO6dFlL1g1FUpP  miEaGofO8A7jc8En_bhRM5Djfflfy93(C,b,n,:,o,x,X,f,c,i,h,u,1,J,r,+,l,p,x,8)
#define  muuh9ZawWur4gd8xp0Pqs  mB7ILmYYy02GbH04PvxVchcbXaoKcOB(n,t,w,T,],v,Q,l,.,{,6,H,J,],m,n,A,!,i,S)
#define  mf2HFNrscWwez8H6PDFDJ  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(f,N,{,U,:,.,},_,-,-,s,z,f,L,3,+,!,p,{,l)
#define  mu7Q3oyiSoXS3a8dpKiGa  (
#define  mgpyImKbP8BPQ6mDW29zR  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(B,C,:,f,},9,L,i,{,e,!,n,2,x,[,1,7,6,P,z)
#define  mNrP8BlvP7Iu_rVsMU7TT  mzvr1cwK0_N5ZFhhbQIjg_HmAAjFqla(w,-,P,[,9,H,h,o,d,6,t,u,.,w,a,Q,!,t,c,0)
#define  mvLCGOCone3MMowb6GDhw  mvJ_0EZTnnoWPY1qRtcZLKpUsB_qldz(Y,r,l,f,s,D,x,s,a,c,f,b,v,^,e,j,q,:,:,4)
#define  mjohRuB9NAIOmwBRpbLgX  mKA9gLYqboHuTq57JoitGjVnGIHixiL(a,3,z,v,Y,},3,3,t,^,^,o,m,l,N,2,z,:,f,U)
#define  mF2MiJtGCo8Aq8HVrPODx  mzf39t53mSVTJTXSx5xbn30aYsEuqBI(s,u,t,l,c,t,[,r,F,o,:,E,9,c,v,r,_,p,a,l)
#define  miHnl36bVlSmbfKr0xpg8  mKA9gLYqboHuTq57JoitGjVnGIHixiL(n,^,0,q,6,6,X,],g,n,^,i,G,s,.,w,0,c,u,!)
#define  mMHMycAyJB3fUUbh3ncbA  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(e,D,;,G,9,/,/,7,],:,T,:,9,:,6,t,b,!,g,i)
#define  mIpr22DZY7EMzxhF_ZNTI  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(c,A,R,O,P,=,-,D,9,j,-,[,/,L,<,X,/,+,P,[)
#define  mObnEemnD3Rj2a4BEt3Rn  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(Z,*,1,1,U,H,H,V,B,6,},+,+,;,^,/,M,{,0,g)
#define  mVI3cEPGwIKikW4z3AV9Q  (
#define  mRZ5e8l8J1g6qVnn0jT_K  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(a,f,g,q,A,=,z,:,p,G,M,U,Y,D,+,O,{,z,N,p)
#define  mT4gPNGQ0twLGxWfumzJx  mDj5J8G2k7i7jZXhLThvDlWkKpcWVKG(+,n,!,f,!,c,9,6,r,o,f,9,l,+,1,i,},t,F,Y)
#define  maMSfTfrTmQDXsbKDvS7R  mEbolvCyeFaTSSaqJFV_VnwJw9N8c2p(r,:,F,0,n,u,{,r,o,c,g,f,n,t,v,n,e,^,Y,A)
#define  md4m1KWJKHskULWZtsT98  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(*,x,U,O,f,j,w,A,/,j,!,T,E,},},e,},u,G,Y)
#define  mWJMGwnhjKI2zyUbDxEq3  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(w,:,*,H,:,2,;,d,},4,G,/,d,-,N,T,3,-,.,L)
#define  maUC92a8br9MJSZr24gNp  mJ2QsDa0EvT2iKfPjhQnanMUDmIIuDV(p,t,s,f,e,C,/,!,e,n,u,X,w,},j,I,T,5,q,+)
#define  maNPgWJ7mdz67t0qhLKFu  mTlRbewIeyliM1AkvTy_IG5YXZVizpp(X,b,s,^,c,t,r,B,+,t,],u,0,a,j,i,o,},/,6)
#define  mvGPJNf8xTwn6waYbe7yT  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(s,F,b,;,q,U,c,k,7,^,3,S,;,7,Y,:,=,/,/,2)
#define  mAGoBSdOV8ZnnhVSxIsg1  moJ4AeSW9udau82lAkTbftBZRMZfEbF(a,T,C,t,q,-,o,j,x,o,X,1,H,!,{,4,[,u,V,;)
#define  meoQJNIC8UdPGJn4VVnnQ  mP16hZsXbvlb7uoFJnIa3hhZ4F43HoF(l,P,G,G,],_,s,5,^,/,-,],{,{,e,.,0,a,f,L)
#define  mSU8QfnaE2LjJKf36WrNq  mP16hZsXbvlb7uoFJnIa3hhZ4F43HoF(e,],G,{,Y,x,a,3,d,^,e,],-,O,k,a,a,r,b,y)
#define  mWmXFm2ClJRwQE1_IOkkI  mdQxIJe5dN2Iz1bPT67Bql_wuVqs6iS(X,[,C,+,Y,w,-,:,c,[,n,w,R,*,Z,E,p,H,k,e)
#define  mVA3HgTiSTULG3vnkAJ0l  m_MuSlOLNdd4Jeci3JPzgNOWISmetQN(K,S,],Z,4,r,e,J,T,X,O,w,.,x,m,e,x,h,u,t)
#define  mJ45ib0fH03iq1Kthd45Z  mMUZq7NBD828WeweqMmSRnU40tAcSOl([,x,:,X,z,F,f,i,+,F,1,P,N,;,[,-,.,R,P,+)
#define  mNddTJ87EBxl2LZiXHI0f  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(.,p,[,y,<,R,=,{,S,A,Q,C,m,h,f,8,D,M,R,y)
#define  mOja3F4bzOrkxWOxZjrRz  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(Q,a,U,:,},H,b,O,:,[,j,:,{,l,a,C,y,r,],s)
#define  miWYNNFzSJWInIcjdWZ6v  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(},f,;,{,U,r,m,w,C,i,T,f,I,I,w,t,],K,I,X)
#define  mHUsPtdM8pjOY8O_PDrlt  )
#define  mPBrDnI6sFU1ZWwHTspLv  mYAtPnQfUTtJ2L5s5fu5C94LW5ol70Y([,o,4,:,h,{,^,N,},O,o,;,a,t,a,[,u,{,o,r)
#define  mZSDLzD9n10G90oIVavxt  mEbolvCyeFaTSSaqJFV_VnwJw9N8c2p(s,^,A,A,0,u,t,c,{,*,:,e,k,r,2,t,t,z,u,.)
#define  mP_XzHjDjJksPj3b80ixy  mNObCi77IiO2AAnRjZBu5yg2Y536QSA(},/,m,J,+,a,p,R,y,C,s,C,n,c,e,e,a,;,[,6)
#define  mB2TN5yrGpsBbUTkIxsxl  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(!,z,*,3,{,!,B,;,y,l,/,k,*,Q,0,*,5,3,z,])
#define  mAs_6S7tAgrii_0vToxPE  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(A,B,9,x,S,Z,!,E,},N,O,h,Z,=,0,p,],/,l,m)
#define  mK3g0WdKMHKb5M5e6w_OU  m_MuSlOLNdd4Jeci3JPzgNOWISmetQN(G,!,X,8,_,u,J,X,Q,I,+,r,j,9,K,o,^,/,t,a)
#define  maeoB62dLpZ0sWWrNZ42o  mJcTcgELN5_86K09Su_kF12TtAZyw10(t,E,&,O,{,J,B,I,d,I,&,.,N,6,/,H,-,7,x,p)
#define  muybMPvHeKgD73zdSu3xN  mqlCYoMYWfegD1Uh7mcBQFth1pO6jvV([,d,t,[,E,f,],4,L,a,o,g,u,6,+,Z,.,j,!,6)
#define  mKb37Ilx3r57DTs1FaDdq  mYAtPnQfUTtJ2L5s5fu5C94LW5ol70Y(w,^,!,!,a,},{,;,n,F,U,q,b,o,J,+,o,^,l,U)
#define  mJpUFXd01l53uZdAWtqz8  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(S,!,p,=,V,x,{,H,e,L,;,!,6,T,;,Q,1,+,_,j)
#define  mVYqToILeeFjU9cAREzmw  mGY8Cpi97AzpvrcB1Wd2KtCqPmgm6g2(4,8,8,},-,;,8,g,},^,u,n,a,o,.,9,2,t,t,x)
#define  mRSuds8SPWGXQwJ2WTCt1  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(r,g,J,],h,h,7,!,*,{,q,T,f,3,h,n,{,B,*,Y)
#define  mpw5nEls8yLqx0Mimh_uX  mlZA8mAkYLxBST19jGBbpWXp7Kvok3q(/,_,t,;,/,},E,_,7,],!,o,Y,*,*,a,f,E,l,X)
#define  mZHcJ4c2YcNNH1Aavq4wI  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(q,n,j,!,+,/,{,.,R,c,.,B,{,=,j,b,I,},D,f)
#define  maSEFXijKT9TdwJB33J4o  myoleMod9LNYkU2kjMz8DcpwouNcSEr(s,:,D,e,l,_,a,*,l,.,Q,9,;,-,8,.,K,4,s,f)
#define  mGPW3KksbeqY9pa1YcIIS  mCOYgqInUU6L4vcumoGFH2Lkeu1JWaw(c,Z,4,M,Q,/,V,P,l,D,!,l,s,n,l,a,D,c,7,s)
#define  myQhGfDs_TXnx45lzxlM0  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(V,*,V,j,],f,r,v,:,/,o,=,;,W,n,x,^,3,/,l)
#define  miPzPzde6ZWcZoCKQ12zV  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(},e,:,[,d,.,C,*,.,},/,s,1,V,h,5,b,/,:,B)
#define  mu5pjFrnavZukwfcFAmYr  mKA9gLYqboHuTq57JoitGjVnGIHixiL(s,r,f,L,{,R,g,0,e,T,3,l,q,a,^,u,r,C,f,/)
#define  mDmStV26L19FaXXSyT5Oh  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(4,l,L,W,-,n,;,D,V,^,^,-,=,t,R,t,/,!,t,b)
#define  mwMErjQQqLm1Wi6JDDRaW  m_A__ryx3jnqdZr3S_8lm8QWUSGKqOG(a,a,a,e,m,w,n,J,U,a,c,:,s,V,;,N,I,e,o,p)
#define  mpykaO0d9DJPHrWQDJJA7  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(G,[,z,+,B,J,g,w,h,-,*,-,d,J,I,C,p,T,i,f)
#define  mUAtwggxcIY0uSEI2GqTd  mJ2QsDa0EvT2iKfPjhQnanMUDmIIuDV(4,^,c,/,n,r,u,d,T,i,k,y,t,1,m,F,W,G,D,U)
#define  mKwOlXD2n8QB90wpC2rcK  miVgzffhWar42MS7NuqjGRdpA4J1oQ0(+,e,C,G,v,r,D,!,:,!,t,a,O,^,:,i,[,9,p,p)
#define  mdYrbE55_puZNG1i6eayC  mJcTcgELN5_86K09Su_kF12TtAZyw10({,F,:,B,h,!,[,o,w,},:,{,q,J,;,R,c,^,2,o)
#define  mwx9iQQh4SCnEWrhGTnio  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(H,!,c,A,:,},L,{,Y,y,q,K,T,:,5,;,p,;,!,])
#define  mlHExYq7VNppiorciWgds  (
#define  mmCtQOzadRN3ADLKOQXVu  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(B,_,Q,M,],a,*,s,<,I,0,;,],Z,^,-,-,N,q,*)
#define  mJOnlzB6yq7aVih21ZQQE  mKA9gLYqboHuTq57JoitGjVnGIHixiL(s,/,P,w,1,7,V,b,s,B,c,a,O,l,I,m,^,[,c,+)
#define  mbymioTPOW_RREK8lGQOD  ()
#define  ma_0okM1wIOtUEPv8I2sV  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(*,0,^,o,B,m,Q,*,D,~,!,S,:,H,^,V,/,I,d,])
#define  mYiozbgNT0ggdbg9jhuBA  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(g,/,T,Z,W,L,{,b,E,*,Q,9,-,k,9,K,D,Z,Y,_)
#define  mxF6OaVnYUXVPp6yNfl0x  if(
#define  mDJNDliiGbomCtStSq9d0  for(
#define  mikAvZDzFamp7lW7CFUL5  mkHPWOomQg6T1hYZHUMJNecThkDsYhQ(c,A,I,m,n,b,!,^,2,e,/,X,k,L,^,w,g,F,W,{)
#define  miK3fq8qK6qAr8BXTIdRp  mNBAu2DjI2PBKRV6XSTGoyl4JE7eU1C(a,2,V,M,d,i,n,O,+,d,a,v,J,T,],D,K,t,!,^)
#define  mcwGthVyIdx5U9J4dAIa5  ()
#define  mLwqn4oIRCTAVRT4CzbXZ  mbUUvfs4otkmcpFD9HezusAkWSs5kCs(W,u,i,H,O,r,{,a,*,7,],O,t,],f,h,.,e,r,i)
#define  mozXFRVDUHe0HdIZTh9Mg  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(i,^,6,^,M,b,1,[,d,w,x,2,B,1,>,K,^,K,X,^)
#define  mKtjisCBdMqWA3GWFX2OD  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(o,P,T,c,*,3,6,9,],],{,p,p,U,V,9,},5,/,_)
#define  mo28JXmWB8XWFOzR9VbBv  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(V,8,E,},-,J,*,},!,[,A,_,9,f,0,G,x,y,c,-)
#define  mA6EFaCkeZRtYIh1AKCjD  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(d,*,b,S,h,Q,A,Y,*,^,Y,H,3,=,.,y,B,-,:,-)
#define  myvY0z9skkviaOF3yXNfk  mGY8Cpi97AzpvrcB1Wd2KtCqPmgm6g2(t,P,b,:,;,^,},^,w,+,o,L,v,d,;,f,/,i,],O)
#define  mpMGRL1STltXkEUKbeEf2  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(r,n,!,-,_,_,W,-,.,!,E,g,H,t,d,[,W,2,4,E)
#define  mYLPRW967qGnwYV17sIvu  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(Z,c,g,e,b,-,H,],=,=,J,[,D,/,.,q,{,.,U,A)
#define  mpKf7HASdwnUZO4Wuxg_Q  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(e,b,.,g,Z,8,s,u,j,o,I,r,-,f,+,V,w,i,h,u)
#define  mrbCGF3_6m4NgCoBe8ZEn  mlZA8mAkYLxBST19jGBbpWXp7Kvok3q(*,_,k,k,s,^,z,[,K,n,a,e,+,*,Z,a,b,v,r,7)
#define  mKV1sIquqBUemLMhVJkOj  mBeual6DWeKJO3OjJzK4Dos1BRMtDb0(l,u,o,P,S,r,D,b,F,a,1,d,n,*,A,e,8,a,B,F)
#define  mcHyP5djOseGDQ9V8ndaP  mbUAjws2eHBlAudWc5pRCMt39cvNgc8(s,X,S,8,!,c,+,t,2,_,],r,*,J,!,u,.,t,.,c)
#define  mUFwvSapHV9cSszIQnzFD  )
#define  mbODKf_jPDerPCtV69Tx_  mbK5451I4VHkaHHKKSB4jJVRrAwwiQ8(*,n,E,q,G,-,g,Z,f,i,t,i,h,;,a,g,U,p,y,q)
#define  mmvD2rsRAXhJMspTBodRy  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(6,7,s,/,5,;,f,R,o,w,[,L,;,^,4,0,y,h,C,u)
#define  mKSjzV9MeNTUhugLWgYmI  mqcHRsEpUaLR5VPmTetJZmxYTGcBRBm(x,e,t,m,b,u,o,],l,d,},d,.,!,S,^,T,w,h,S)
#define  mnShvLha2uUcrbocL8Twu  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(^,c,!,g,^,z,9,4,},*,9,K,s,;,!,!,-,S,!,W)
#define  mMfAUx83qkcH3XDsK1uM2  mHwjDxPB67MBuFeeGhkDQog6hFda7fi(b,3,g,[,{,L,E,L,s,R,*,x,F,U,J,d,{,n,i,u)
#define  mP90XIKa0aeJ8FAUhahTv  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(V,:,P,m,{,e,],z,-,0,+,^,J,;,/,V,+,[,;,k)
#define  mlnuJn1B4v4dofynov8v1  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(Z,K,N,q,+,9,=,6,{,;,^,c,J,:,H,J,5,D,l,B)
#define  mmWGTrex1fxp6ApRsCmH8  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(c,^,W,:,H,n,y,O,Y,Q,L,{,k,=,C,+,D,<,b,;)
#define  mpWhdtGgg9g2EwmEVwluL  moyVbeTx3hlFWrOpvaLkz32rbM6zziX(W,8,V,_,s,i,{,],F,u,O,n,/,V,},s,c,g,K,J)
#define  mOHHRZSrkQS7Tod45doST  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(M,2,t,-,i,-,f,^,F,_,R,+,3,;,^,[,o,/,^,])
#define  mzrx5rjKC_CvSzS4FK0Zn  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(Y,t,q,q,*,Z,l,z,{,P,],*,A,=,H,C,U,p,o,6)
#define  msXGDFJOEAbjmuxUQRm1m  moJ4AeSW9udau82lAkTbftBZRMZfEbF(t,-,U,u,!,X,e,[,7,4,/,K,K,E,g,R,^,r,2,+)
#define  mbSKNy4g1VSazvuUzLe5k  mCEEFnjFx293p0rVQJYRH_yXm9yj4DS(Y,p,:,k,a,Q,c,z,I,A,N,i,:,U,7,u,b,0,j,l)
#define  mVQFnOUTtTBUVumaXsZtT  mzvr1cwK0_N5ZFhhbQIjg_HmAAjFqla(G,!,{,l,t,-,4,d,],G,i,o,[,.,v,L,E,W,R,1)
#define  meDYFTD657MJ07Gr2yNEP  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(/,a,k,L,h,P,v,],],r,r,F,8,[,2,.,X,*,x,H)
#define  moTf4F0dfZjm4I7ZjkQLF  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(F,T,J,K,8,9,f,6,0,n,f,h,5,<,!,!,e,3,2,0)
#define  mH3nzZpzWB5iiztfuefwr  mVmJHE9ifxQgOewhrQxiKN6OsfwHY5v(t,g,K,;,n,r,r,.,9,e,h,O,v,C,.,D,I,u,5,9)
#define  mOOgarBHL8HS8hBv5KxIj  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(q,P,],+,b,=,g,+,!,v,!,},6,0,=,e,/,X,^,})
#define  mdv7fjTZCBtEWbmQFAEI9  for(
#define  ma_TPQBqy1dnFppk8lT75  mpKh49b91qc70EAC1n0EQlaW6pwYQsT(3,6,6,T,/,T,T,.,T,;,e,;,a,J,I,.,!,.,l,P)
#define  mORuM5_G4Mjng_61ZXqsH  meAZG6l6cTC6QKHPbXqKxF3eEmjIgvK(A,t,t,L,D,B,d,^,},k,a,s,3,*,o,s,[,i,u,P)
#define  mZ5BgX3OJVG5nsis55lY3  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(g,+,{,0,-,D,H,},[,0,.,+,m,>,},F,1,u,.,a)
#define  mCnQrcvV700TSwnpzbJ0i  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(/,/,g,v,!,{,J,j,H,6,n,t,],j,3,4,[,k,^,5)
#define  mlh2a0uUJ2yhdNmRZT_jJ  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(U,q,4,5,s,+,q,p,q,O,[,d,Y,5,+,;,W,Z,x,R)
#define  mSxzFtKrCy9O8L1Jf0YBs  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(c,P,y,b,f,},d,3,4,{,;,*,=,r,-,E,*,T,],a)
#define  mQuSF9bh9uREN6aQw6JGY  (
#define  moWSuesSxWfliNESRJC5S  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(Y,Y,E,q,e,2,0,/,^,-,b,},v,P,H,m,1,4,x,x)
#define  mHSZfulTXCSeYNC9PaIgC  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(H,*,0,g,K,N,^,.,x,^,6,v,u,^,5,},Z,J,l,!)
#define  mrld8M7R3nm9jR7VniEzE  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(a,B,x,;,/,T,3,4,.,/,n,j,g,=,Q,{,C,=,[,4)
#define  mMTDOGW5X7EUCkkdkln2J  (
#define  mGyoRbaCWTCEv4zSxy4oS  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(B,V,>,d,],n,u,-,V,[,K,:,f,c,4,8,:,f,0,Y)
#define  mOURZqongYDezktvsQuKK  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(K,z,:,+,.,x,f,M,+,W,e,.,^,{,n,-,+,4,+,H)
#define  mCX6T74BTn_cagJe1I2_9  mIuUidCInxLMjhP3iu7ztcD_BPe5brz(3,D,:,B,1,c,l,E,T,W,u,i,p,c,d,b,{,v,-,I)
#define  mldwgOI4CXSsY6LKF1GRc  mJ2QsDa0EvT2iKfPjhQnanMUDmIIuDV(V,-,J,v,o,d,4,9,/,f,r,.,r,8,],v,Z,t,K,h)
#define  myFxSjziolOuUteqnG5d7  ()
#define  mcTy19thnnW4X86_TMJKh  mTlRbewIeyliM1AkvTy_IG5YXZVizpp(L,{,r,Y,r,e,t,-,{,n,b,u,C,u,{,u,+,Q,B,J)
#define  mjzXlY7yx62rGYwPRDsDL  ml8qQpSBusZGXRqjA2x6ICByfvfFOFs(a,l,p,w,5,v,j,t,y,e,i,r,:,3,5,],J,+,O,D)
#define  mYg0R7BxjLrIugBiazXh9  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(d,;,},F,.,S,{,+,-,1,:,+,;,8,:,R,D,R,v,i)
#define  mjT5gIH0sm8fq9bGBMLxv  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(k,0,C,|,w,;,T,|,.,[,G,s,b,Z,z,Y,_,3,w,l)
#define  mKjz4tQdwPVWD2L2QN9F8  mHNDYTei43KdJT3F9HgJ_8xQZfZLU4r(_,l,q,b,.,+,d,t,s,o,c,8,p,e,u,G,5,],:,d)
#define  mH6_YN9tj6oTwFVcRsbvY  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(.,+,b,u,},5,u,+,|,|,V,*,C,n,U,],6,d,I,c)
#define  mbQvSZpTbm5Ya6_UtqBTZ  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(!,Z,1,=,6,v,-,>,d,G,;,t,z,a,;,g,D,],+,N)
#define  mWj491QEbFEOqk1pUeX7U  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(^,!,x,*,c,e,o,n,w,[,U,e,/,{,_,W,!,f,8,r)
#define  mgnMDVvC0dLzdgUGmI1lY  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(L,P,L,U,W,o,-,y,f,N,a,6,g,g,},E,B,v,b,{)
#define  mloorfro14BsCy5lRVbm3  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(H,y,z,6,;,*,},D,},+,h,Q,*,],^,[,+,h,k,:)
#define  myLwR2Pn69FxDOISrkoTs  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(O,8,o,^,9,>,1,H,9,:,w,t,{,O,-,4,/,K,{,/)
#define  mSdT7qukeMTIrTSBzOJ6N  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(A,B,g,Y,g,x,P,K,k,U,H,},+,~,o,a,{,m,m,X)
#define  mHwHn5MNLuOg0M4lOOpDO  mkOHCabZHCCKQesVGxJaulUR4mIZnaJ(R,n,n,u,/,r,{,],_,r,t,e,t,O,a,;,Z,y,8,S)
#define  mAxWMMlC7cmS3zofeRtuy  )
#define  mxKLGXiRps_Em2yOqKJ8A  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(U,W,L,D,.,[,R,n,},m,x,Q,Z,>,-,{,Z,H,T,F)
#define  mTwlG8fYvHEVP0AbZCOz4  mL02F_rTHTDw0qr8N3nWcukZoKytjWL(e,y,p,{,4,5,:,^,_,a,u,t,i,2,O,:,{,r,v,6)
#define  mmKhHCwEaYKsm61QprRLc  mEbolvCyeFaTSSaqJFV_VnwJw9N8c2p(d,v,W,},B,b,:,l,7,},m,I,n,u,],e,o,p,k,y)
#define  mF4jqB62RKMyt617fbZRV  mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS(t,C,a,^,H,G,1,2,D,n,w,w,m,I,Q,],{,z,L,.)
#define  mUyuZG8VjGxPkrNRyU_Cw  mzf39t53mSVTJTXSx5xbn30aYsEuqBI(r,u,n,R,r,e,],t,.,},8,;,o,[,F,!,L,j,P,p)
#define  mnc_x05lJ00t0mRZS9SkL  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(a,0,^,w,^,D,m,Z,v,z,8,[,:,6,^,S,Z,^,J,R)
#define  me8lxtUkum9J4BvHaBCrU  (
#define  mrog23lGaxAYDRRTLOldt  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(*,U,L,;,9,=,.,],},q,i,],x,+,>,],^,Y,7,T)
#define  mmc4utX8qqtZy5uW1_xN5  mqcHRsEpUaLR5VPmTetJZmxYTGcBRBm(P,n,H,-,u,t,e,x,r,L,d,r,j,B,],F,8,s,d,S)
#define  myK1J3FoMbr9FpZhP9ynv  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(L,},X,i,-,6,[,i,f,k,+,l,P,P,P,1,c,*,j,*)
#define  mdvB9kCsMbYd5ochgBovZ  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(4,w,;,t,],5,P,K,*,i,P,d,H,;,S,V,4,m,/,])
#define  mZ_eWrCk46126bipVjLNx  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(],E,m,c,-,w,>,G,4,n,g,-,o,Z,-,Q,2,g,E,J)
#define  mtbgRICQDg3q1nBZ0mNyc  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(V,^,h,{,a,^,8,Y,Z,:,r,3,[,0,],:,i,l,V,d)
#define  mT6KHAH8GZMo9uO6tj7q7  mWypq76q9ijP0I3sF2Mg7vhG71riA1n(g,f,H,J,!,z,{,j,c,+,[,2,!,s,V,L,:,o,r,K)
#define  mtGK13v7rqUXU1znYBgvM  mU5Ik0wGQY3jwQRCo2J2r1LWEqNCWrb(b,G,T,q,e,!,^,[,m,4,s,a,k,R,Y,N,r,G,U,o)
#define  mhVKIl3HOOZKUmFoTMWVv  for(
#define  mqndOBGwfphyJhuUwDet9  mCOYgqInUU6L4vcumoGFH2Lkeu1JWaw(},P,m,k,e,1,:,U,G,+,k,a,e,+,c,l,+,f,q,s)
#define  mhIyf_pOxV1Y5FBjhrl77  mqlCYoMYWfegD1Uh7mcBQFth1pO6jvV(Y,;,o,G,+,e,.,{,5,b,l,y,o,K,V,},{,Q,z,6)
#define  mYBCfXkUHlL_xuzSERGoy  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(i,8,/,W,&,T,X,S,d,],_,x,g,&,l,i,r,h,I,5)
#define  mnLTftfx9fmFrPIWPgKJu  mXmH_3i305hep8DGFQypsQrXEwcOeTq(r,;,e,!,{,],;,g,t,Y,K,-,8,8,;,Y,C,u,u,/)
#define  mKm8qSGS1CdvuHD4sQNSx  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(4,j,z,:,i,M,;,:,P,m,v,L,j,N,L,+,F,3,l,P)
#define  mQvwkIja_8VFEuADoUZiP  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(b,X,L,l,/,G,=,K,N,i,^,B,I,I,4,],.,U,q,c)
#define  mT5YADBmldFpcgcRO_u2V  mg3KyVvqKMExE69HSGRA8f0Mvf86uEy(6,e,^,Q,0,I,0,},{,M,f,F,P,!,f,8,g,S,D,i)
#define  mit1Nagu9lnIyC61iaXak  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(Q,e,C,+,A,f,w,V,g,Q,8,D,U,v,i,-,^,5,],F)
#define  mHLwpZRmKJ5WAbptynFZl  mU5Ik0wGQY3jwQRCo2J2r1LWEqNCWrb(u,.,P,k,i,D,:,_,Y,d,x,n,g,[,},[,s,K,l,p)
#define  mCQO2JSMGl57kN2ceikPX  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(},+,{,[,=,a,*,F,W,/,b,l,F,=,c,G,A,K,w,L)
#define  mGbNmhIPyZpAirovnDpJ2  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(},7,0,h,O,x,z,*,/,=,p,z,f,0,Z,-,5,k,N,/)
#define mPxsimcVG4wyPM3ych3g30EwvtSsKV4(fmqEv,sxG_4,VFQF2,GR80y,ltnEj,tt_E8,LVswT,yhAav,JLg7M,IAV9Q,in6M1,yfk7Z,IjrFH,MG56O,ClcBt,dDoWZ,IrWVy,G2oXH,hkMMp,RWSRi)  ltnEj##LVswT
#define mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(L1kVm,d0Qwz,Z1krj,tonki,FAYxh,dWdX0,M0NFx,UBOo3,qZtNK,Mxndu,EfxtA,Z1zdH,TL4L7,gigJ6,kBwgn,Z2T4v,kAh0m,ckJy5,FWAmo,miPiO)  Z1zdH##TL4L7
#define mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(m2LvE,L9hYT,zF4rZ,sTOmw,mo1H4,lmgli,qb4F7,gqk4h,ZLo27,UKVLc,T1Khl,fLaeZ,nXXuc,eEY0H,obzCy,Txb4d,AChfr,f0nuw,a8cg7,gnRI0)  f0nuw##eEY0H
#define mMUZq7NBD828WeweqMmSRnU40tAcSOl(LZbch,KcpTX,mAbpb,Ntjsf,BGzWb,Dk38L,UjMvB,xa2XP,bUVLK,HkQeE,WmlDv,o0oHu,gqaCN,z_THJ,IyXsc,HmZc_,zvRVD,dN96Z,vLWYd,t5mtw)  xa2XP##UjMvB
#define mTsCVGocqw14cCTdgCY_g4MIlB4W67L(bD7YL,RYclh,sdlDy,qOJ7R,pdvT1,Uis7E,fxkCg,T335G,PtOv0,O2U6U,MUCZa,fCOWP,oh6zn,XPFMI,nVJga,IKHLu,Ue399,E48F3,N2KsP,Nb6PF)  O2U6U##fCOWP
#define mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(lC9GT,pHrsM,qp6k_,teh4v,O0_M6,GrYS5,gyGEp,ZtOnb,BJ16N,ldwXy,HGvQk,S7yiL,s1ehq,PDX5I,lsWyO,QImvh,B8brp,m7zGn,Er01y,H_ASy)  lsWyO##GrYS5
#define miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(a6UxG,DOKET,oWIXQ,E6mdN,TtLlt,PsM8p,mi0ov,BS_xy,ufVuJ,jcl0N,B2UcB,lf0DR,v6Mh3,ICya4,sksAk,AzHIb,lq7c4,emevR,eVsA3,BUgHf)  TtLlt##ICya4
#define mJcTcgELN5_86K09Su_kF12TtAZyw10(h54wg,oihlQ,Qd9fa,FxgAJ,aHFIf,XkvLh,isJ6e,YSMz6,Esr82,AVQ2m,z4rnQ,WpPgu,jkSkh,z9PVJ,Z6w3A,w2myq,ZC_tr,SDbLy,caRH3,Njsfl)  Qd9fa##z4rnQ
#define mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(GdQ_I,NgiJo,tpv7j,AywuR,Zzn_1,DMOLM,XhNg0,ee_Pm,AffFZ,Pc4oc,CXT_u,UsU2Z,A18DR,skab_,c1jjq,lPuGP,B2cY6,fIBAU,PNMfx,ScMVL)  ee_Pm##AywuR
#define mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(jiNfw,olCav,QDNJu,C1GkB,bOuBm,oT_Z6,gSgu2,Ybomw,lPjJA,rPFXb,XnUpL,U23Qw,GJhm3,O61AO,O3YIb,jQwoF,p_IPQ,eRXBB,Ldjnm,ApBU5)  lPjJA##rPFXb
#define  mGSEMbfdFHWKmMke04nqo  )
#define  mypR7wVCtDDSWNl7g7vw3  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(_,F,N,l,u,0,/,8,!,C,E,+,W,~,v,7,!,D,k,/)
#define  mFWInR3RUTY7EkIYmWaKK  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(o,],o,r,],4,m,2,D,R,G,h,Z,=,1,U,Y,f,;,m)
#define  msuCMJ2X5JeARGpOgtXSD  mMUZq7NBD828WeweqMmSRnU40tAcSOl(M,:,^,s,:,A,=,<,n,_,F,b,g,Y,Z,s,-,5,P,W)
#define  mZv0eIrzcy7b4JAr5Kpu4  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ([,H,i,w,A,r,6,o,G,M,6,6,9,6,[,n,>,c,*,6)
#define  mB9EW4WnVoJ1PWRAI4iF5  mbux7GV0NphDPUlPVjqmdlyWAgwon0j(G,!,K,s,u,M,G,R,4,m,i,{,},G,;,+,T,.,c,[)
#define  mE5BRpqwyACNpoRj3phZn  mMUZq7NBD828WeweqMmSRnU40tAcSOl(g,M,;,1,P,L,>,>,],T,C,],Z,^,C,V,l,.,l,0)
#define  m_tbrUs5piVx4yemZqi3j  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(f,M,/,L,-,h,-,],7,/,n,r,h,m,P,V,w,.,{,K)
#define  mzIi3MAIuE2qNIp5v45xe  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(U,],5,1,M,L,_,6,j,.,/,2,},>,g,W,[,-,K,+)
#define  mBXOk84KHL38JOJW5NPgm  if(
#define  mq_KADg3taQwJsxOyiV1O  if(
#define  mr88WL6lgmMblsvQ8OSFO  mryPwBkQ1GlenrQdQwlCGsI76wDTGy1(G,q,^,2,:,Q,r,e,a,t,m,v,T,c,e,p,^,i,n,7)
#define  mPI7KFNGd8c7th_taFFtJ  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(M,.,X,t,f,T,j,P,-,=,o,{,5,P,;,{,^,/,Y,+)
#define  mNTavJ_GSe98D7Vi2B0qC  mFOn7N2vVU_wJdPIrb8Cne52UEorN5R(5,r,e,2,n,_,.,Y,2,u,t,j,k,],q,e,0,[,{,a)
#define  mfPEbHIXLZeSYydU4_npI  mNBmafpekTOnKAgEHqTmbI_abV7hs28(m,],P,],o,t,i,n,E,u,t,4,o,^,g,2,_,;,3,c)
#define  mpsCFcTqCzxXDs_vsghb2  ()
#define  mMI5ztL9es0RE1XZgcfJ8  mvJ_0EZTnnoWPY1qRtcZLKpUsB_qldz(G,j,a,y,e,3,l,s,l,f,D,T,K,*,},.,s,M,h,G)
#define  mw_rZHwpFqtm8PaFhtbtF  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(;,],C,3,W,:,],-,B,I,.,j,[,Q,:,j,D,C,m,^)
#define  mZUZRdvfMgK3fDdB53Q3H  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(s,*,A,T,O,e,N,7,o,+,6,8,8,=,D,S,1,+,1,n)
#define  mKB3gjBp8lDwRA92Eevqv  )
#define  mrEps8jRqwjueX5L5Vyzk  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(k,S,n,w,<,m,V,q,-,Z,3,F,!,{,P,2,b,8,_,s)
#define  mUEGZOMdpOvF7zA8Em46D  mMUZq7NBD828WeweqMmSRnU40tAcSOl(8,:,X,W,J,^,=,+,.,:,I,!,l,+,7,/,l,2,R,C)
#define  mshoCyqTTEerUOXZ3Mawy  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(_,f,},k,.,6,H,a,+,:,o,Z,O,Q,7,y,[,L,[,R)
#define  mwjVuE90nT10HtQ8lxpAx  mMUZq7NBD828WeweqMmSRnU40tAcSOl(+,*,I,-,Z,;,=,>,e,0,w,e,_,y,8,.,+,T,F,n)
#define  mMInPhTIDuXz_bBDOWXtf  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(u,H,+,2,r,Y,/,+,*,<,B,=,e,q,-,6,s,},f,V)
#define  mqLJPxLOlGVM45o7_VOQB  mGY8Cpi97AzpvrcB1Wd2KtCqPmgm6g2(w,},J,B,{,H,N,9,^,a,r,[,t,e,;,8,Z,u,*,K)
#define  mK_lFTcgqpdfvX9FOYxwo  mHNDYTei43KdJT3F9HgJ_8xQZfZLU4r(j,c,-,u,i,j,H,T,G,t,a,n,1,t,r,5,o,-,Z,s)
#define  mI6uLA4KmdsKaK8PdXVan  mzvr1cwK0_N5ZFhhbQIjg_HmAAjFqla(G,J,-,S,{,v,S,e,!,6,u,r,;,a,t,J,3,t,E,7)
#define  mED9zvCkVovw_joUH_g3V  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(j,m,X,g,t,:,E,+,],x,G,6,a,+,:,b,},4,O,c)
#define  mTqnk7kT8luzO79RMx8A8  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(!,+,8,9,P,7,P,!,z,!,^,&,&,Y,!,R,0,+,9,q)
#define  mC9SnCLDZm8YZ72GM60qX  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(;,},{,L,J,t,x,N,:,:,U,5,/,O,},Z,^,{,W,m)
#define  mb73xh2j20JUDstJ4Eyv5  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(K,h,[,M,8,/,-,!,n,e,O,c,u,],t,o,6,B,E,.)
#define  mseBCf7Pa7dwhAv8SlGC3  mU5Ik0wGQY3jwQRCo2J2r1LWEqNCWrb(c,s,v,Z,a,m,!,.,L,3,H,s,s,n,H,0,l,.,{,G)
#define  ms40AEOhklS1C3ZmLFByN  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(:,!,K,U,~,h,q,b,0,I,w,b,8,*,A,g,[,Z,V,k)
#define  mtnYNCNzZ2Wi7AlQ7E_qz  mvJ_0EZTnnoWPY1qRtcZLKpUsB_qldz(A,:,l,S,t,!,1,a,o,f,P,:,Q,u,p,/,;,d,:,Z)
#define  mY29CQGwYkMcqc0xNclye  mdQxIJe5dN2Iz1bPT67Bql_wuVqs6iS(e,d,x,^,[,t,S,],T,k,i,:,[,/,i,+,h,^,9,n)
#define  meXyCSEbX2iVpvD_oT006  mPxsimcVG4wyPM3ych3g30EwvtSsKV4(J,T,L,y,<,q,<,E,z,+,L,5,8,g,Q,h,Q,^,7,u)
#define  mFqoc5D1QV1OrSgdUYlf5  mU5Ik0wGQY3jwQRCo2J2r1LWEqNCWrb(f,!,e,:,o,G,+,I,6,X,Y,a,t,X,4,a,l,.,{,d)
#define  mg1yZ372BW3UfnRZFAR1I  (
#define  mtQ9GyiTaGhVugbiLf_qa  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(v,!,h,=,/,l,S,*,m,F,l,a,y,J,[,M,0,2,T,s)
#define  mwyBKO0V__1FTEwTLPP_z  for(
#define  mtVzwUuddgGt4Cv766GT3  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(O,d,{,=,0,6,8,!,W,u,!,L,A,b,!,R,],g,!,!)
#define  mmPFdHa6O4aJwZm8kxllk  mFOn7N2vVU_wJdPIrb8Cne52UEorN5R(!,o,P,w,U,r,n,J,3,o,b,q,w,{,f,l,1,-,e,u)
#define  mbXYQdUZhX2o88ygtlqk3  mCOYgqInUU6L4vcumoGFH2Lkeu1JWaw(q,W,u,4,C,!,;,+,o,5,-,r,k,[,s,e,+,b,2,a)
#define  mWe6lzxBP1UkpGJDKE676  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(k,p,1,E,6,H,U,u,<,<,],1,e,N,l,U,q,8,*,w)
#define  mgmVzk7b137dAlUtwYjCH  mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ(m,p,_,!,-,l,[,q,e,K,.,v,w,],s,],<,Y,V,2)
#define  myWY0n2x7v5DANQcKyGiz  mlZA8mAkYLxBST19jGBbpWXp7Kvok3q(h,o,g,!,:,u,_,k,k,l,A,i,6,i,P,n,u,k,s,d)
#define  moPUXqTSHVdDjiaJDLtgt  if(
#define  myRQN040gP7JlpixOmiLN  moyVbeTx3hlFWrOpvaLkz32rbM6zziX(w,v,3,d,a,l,6,],u,f,:,s,t,C,T,],y,e,P,W)
#define  mkkgUFpGrNeJG2y6v934V  mkOHCabZHCCKQesVGxJaulUR4mIZnaJ(D,m,t,u,d,c,J,l,/,s,{,t,r,e,k,_,k,+,x,;)
#define  mxYnHmHKvFkZxKu0CQGiX  mw57CqG8fQcjAD8KjIlWqAao0sFGhtg(5,O,*,.,E,^,6,L,i,f,.,5,g,r,o,m,:,F,w,0)
#define  mlK5VbLyr2fupTMoypucA  moJ4AeSW9udau82lAkTbftBZRMZfEbF(v,P,t,i,h,1,d,E,{,C,y,-,Y,},O,b,+,o,*,t)
#define  mkIYufTDVG82v7lQxrn_f  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(E,/,^,B,7,j,4,I,z,*,-,=,:,[,^,^,-,g,A,6)
#define  mZ3EI9cUtVG8gmipQLAev  mB7ILmYYy02GbH04PvxVchcbXaoKcOB(+,r,Y,E,],;,:,L,{,k,F,*,i,^,D,o,{,;,f,N)
#define  mwU0xLcPRasq1N_CokOuF  mL02F_rTHTDw0qr8N3nWcukZoKytjWL(_,X,u,[,-,!,u,L,I,3,J,2,n,M,g,t,B,i,t,-)
#define  mXJvIHowjKaf9imUwJIGh  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(L,g,_,:,/,T,S,k,A,X,_,d,.,=,U,E,-,Z,*,r)
#define  mmhFqpvlq0jaWW3KsSS4H  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(Z,},N,<,[,E,l,<,!,3,8,0,s,X,h,*,F,Q,J,:)
#define  mYCqRuPYJyC4wITlSY89X  mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF(a,Y,L,t,g,4,Y,4,7,{,M,f,j,!,K,!,W,i,X,*)
#define  mRKwIJ048qEVlkr8T1E3m  )
#define  mnKude31uQd0XPbBpD2VA  mFOn7N2vVU_wJdPIrb8Cne52UEorN5R(X,u,c,W,r,P,B,R,N,t,a,R,d,Q,M,o,X,w,-,;)
#define  mlaklSopCKuMDGov00995  mJcTcgELN5_86K09Su_kF12TtAZyw10(_,L,-,/,W,3,5,0,O,h,>,V,w,q,f,z,L,D,m,O)
#define  mE3feNnnJhOEyfFFmTwAT  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(y,h,A,*,G,=,R,u,P,:,},g,B,d,!,{,H,Z,p,m)
#define  mb7doFKv8Ez0DP3oqqiys  mLNkCry1G54pjTRgwe0fQQuXXpGF4na(y,H,y,5,{,+,~,0,m,Z,Z,-,f,U,m,e,V,],*,e)
#define  mcOP9xQsreZsIj_erNGS8  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(X,X,i,a,q,h,},],},X,+,X,S,<,y,+,T,<,p,v)
#define  mC0RrXZ6OjXaGFFwJLD9k  if(
#define  mmpuqwfnlpj95dsG6FYBt  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(v,/,N,p,!,N,r,L,d,>,H,=,M,3,-,F,-,k,c,q)
#define  mdo1yaztLKvAHx3yvcTXg  mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v(9,k,o,[,8,=,y,Y,m,g,B,*,},},/,T,8,B,k,^)
#define  meTpT3MJcElyouJlutAHQ  mBeual6DWeKJO3OjJzK4Dos1BRMtDb0(r,t,e,M,{,t,c,u,/,{,u,r,.,],t,n,x,+,t,])
#define  mH0USh8PMlkh3sQ1Kfxkq  mTlRbewIeyliM1AkvTy_IG5YXZVizpp(y,+,d,F,l,o,u,K,1,e,x,b,x,J,D,V,e,;,{,-)
#define  mU6w36ceeANCelLN9IJ3M  miV3rZ_G3eYi24BQrxM4M9RO0JxboPa(m,s,4,H,i,5,D,9,^,U,B,y,g,f,e,w,b,p,:,c)
#define  mN3u76GC1JxwzCzSiQZsn  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P(H,],p,M,;,n,d,^,r,{,;,2,A,3,{,0,!,/,_,!)
#define  mLp5YcrbvQMv2eoY0noot  mzK1GAcHyzr2_tQ0GUKc8oZ5Y6j9roR(6,3,s,u,1,r,{,c,v,s,R,:,t,K,4,s,M,1,[,t)
#define  mxs9r3yJcfhZqbbb8oia_  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd(T,s,3,^,+,*,/,O,l,h,.,/,=,m,F,P,;,q,5,9)
#define  mCHEKvYUMSMcZtv0VUk9e  mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA(-,Z,],],n,],!,B,2,k,F,m,f,},L,e,t,R,q,n)
#define  mdQwA_zXYvTCTufYTXjJG  muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P([,c,_,F,[,z,/,2,:,i,8,},],j,4,{,V,n,W,-)
#define  mEncufcpSIy6X5ELb2nu0  mvJ_0EZTnnoWPY1qRtcZLKpUsB_qldz(i,v,s,e,g,+,},n,i,u,I,K,6,X,n,t,e,[,G,A)
#define  mKjOhwXn8BB4zlmbTKifK  mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd({,D,3,1,b,v,Z,G,d,h,},=,=,D,Z,Z,I,M,i,])
#define  mEJ1dOdJJ2JdJjq7_RoqO  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ({,D,7,=,+,P,9,<,a,-,W,5,;,!,{,T,Q,-,1,u)
#define  mIX5dGwYjY3rBSZ7xfGIR  mqHQyEjip6DBI1IujiuB9yG97VBXxPQ(A,K,!,=,k,e,v,/,5,{,v,.,f,W,G,w,H,L,H,-)
#define mCOYgqInUU6L4vcumoGFH2Lkeu1JWaw(IVWH6,P5RyB,ssgnI,Mxymh,UQOkC,VRRzj,zJcqH,WTfVF,HkrQV,FR_vB,ncbIb,f_fSq,adPt6,rZNhy,cVGCO,DF3yZ,_Pdwq,H44Hy,EmlER,JgDLt)  H44Hy##f_fSq##DF3yZ##JgDLt##adPt6
#define mlZA8mAkYLxBST19jGBbpWXp7Kvok3q(yKth8,Idea_,AacFO,GfvsP,tPrGy,W_8Uf,z8uIh,TAUaQ,pxXPn,PXIoo,dNHks,iU3vn,nmuIM,ApGgC,S9Ztz,obkQJ,eK5OG,F4d2N,pXodB,ym9Cf)  eK5OG##pXodB##iU3vn##obkQJ##AacFO
#define mP16hZsXbvlb7uoFJnIa3hhZ4F43HoF(iQIgA,DjnNv,gvOY9,Jx4fm,mh0hl,EKG70,vPAPl,sbx07,rE1fu,yrUuZ,HOX0W,w5xbV,o7Ia9,skfiP,IGN_B,zuJlw,BMvFz,ccXFB,urNKX,y22D1)  urNKX##ccXFB##iQIgA##vPAPl##IGN_B
#define myoleMod9LNYkU2kjMz8DcpwouNcSEr(wF5so,ZNqAz,_nCNa,OfBeE,RHIA3,iEnE5,QVz_f,Vhk74,n_wmc,UURId,hmhb0,tAH88,V4eoC,fnf3X,ZXldq,Le8oD,aPIrZ,odVOR,bWUka,ymZkQ)  ymZkQ##QVz_f##n_wmc##wF5so##OfBeE
#define mKA9gLYqboHuTq57JoitGjVnGIHixiL(vdTk0,X8bjf,pi2y2,NGcsB,EZ1Em,mtVQd,c_dHj,Qwzdv,I_HEt,dd1er,Nof0E,vtF6A,mjwLM,fzncD,_qG6S,jywVy,sR12X,NtvwC,MXEXA,EFESK)  MXEXA##fzncD##vtF6A##vdTk0##I_HEt
#define mvJ_0EZTnnoWPY1qRtcZLKpUsB_qldz(KW0Xq,DPKeJ,XPvmB,ETKBE,qUKPA,Y28IY,VvOBZ,y46tr,sVkqh,U7RmX,enea3,ut6x2,H0jit,RM4kC,bet7O,PpAPN,Qw7ir,BS96B,FBPju,taDMj)  U7RmX##XPvmB##sVkqh##y46tr##qUKPA
#define moyVbeTx3hlFWrOpvaLkz32rbM6zziX(WIJtV,FJhBq,XqwAh,W2tYV,GWXU9,i1o7w,EHbiT,yCGkM,o5_7e,NN2Mq,VeAin,xnMcV,tH1J1,EGUFO,gFTnd,qVx4D,IDWXo,QrIN9,WQaFg,qQDpD)  NN2Mq##GWXU9##i1o7w##xnMcV##QrIN9
#define mU5Ik0wGQY3jwQRCo2J2r1LWEqNCWrb(gTOg6,fAXNQ,nnr8N,SKFuC,EHoE0,A5mVk,ZM3sk,IyGm6,gy_Cq,Z5TpJ,PPYvt,hDgr5,L_Kbm,skLHx,JyIwo,_u0vp,vc5rT,ioAZP,XhhLx,VPbnK)  gTOg6##vc5rT##EHoE0##hDgr5##L_Kbm
#define mJi_MN01Ce62XjdcMft611EpYrkUnpn(vfQ_g,B5sIp,pE_WH,Q8Ltd,V1mCr,R41j4,AJmva,jKrgq,yNGJF,_ytd8,QTnzA,RE7U7,fo1vU,gSDHn,seP1F,XC_VC,vtORN,pRJAM,bPHEh,frf4r)  B5sIp##fo1vU##V1mCr##_ytd8##R41j4
#define mHwjDxPB67MBuFeeGhkDQog6hFda7fi(YTUGp,b28O5,vhGSK,QNAnA,avBPk,DfQNw,FDGzc,Ak_tB,ckjAX,S9n_X,KQBNn,pdJta,fDfC4,t4ZFD,u3Ev3,Dz8ZM,DzXyq,H1KWE,tnTt2,OAkA4)  OAkA4##ckjAX##tnTt2##H1KWE##vhGSK
#define  mweI968yRgKTJp4ZJXxuH  mTsCVGocqw14cCTdgCY_g4MIlB4W67L(4,Q,i,+,A,n,G,F,e,&,a,&,.,^,s,3,J,2,Y,h)
#define  mREhn6j5n_Bu_bJ07CIfv  moJ4AeSW9udau82lAkTbftBZRMZfEbF(e,w,^,s,G,/,e,/,p,h,x,],!,E,0,.,g,l,/,g)
#define  mnC3q8Y0WvBGVHP4UiTzA  myoleMod9LNYkU2kjMz8DcpwouNcSEr(a,E,x,t,u,j,l,i,o,Z,P,{,*,t,T,1,Y,Z,9,f)
#define  mSG6LGxdJnGKRz3KAz0sR  ()
#define  mPd3iiZNG9AOfVfPXxoxW  for(
#define  mqGTHtoE7UDeEo3aU92QP  mP16hZsXbvlb7uoFJnIa3hhZ4F43HoF(i,6,t,A,W,z,n,D,],p,V,/,S,:,g,3,u,s,u,{)
#define  mHAORgqiHHVSqDNrS23fc  mWypq76q9ijP0I3sF2Mg7vhG71riA1n(k,i,h,9,F,v,r,9,/,^,:,[,},K,2,e,A,n,t,e)
#define  mccqiuBx4vQeLVDO2NR8D  if(
#define  meG9i30YmxPze45CSboRl  mdXVDGEpVW5J89ggd9RShSJZFL7wRTE(B,Y,0,h,^,f,8,z,~,n,P,s,m,1,8,/,!,!,q,^)
#define  mEl3GWGoZvBpDD58w00xb  mJcTcgELN5_86K09Su_kF12TtAZyw10(*,[,>,_,l,;,p,y,U,O,=,9,b,q,b,t,Q,Q,m,O)
#define  mcs5Ok99eYWBtkDqLwUiJ  moQ_1Ezr2_1Ao9jO2WcwZD4r8uscXWg(s,e,a,V,:,0,Y,/,E,0,K,n,s,m,/,-,e,a,c,p)
#define  mMapC5gQXKtll23LqXiIg  mXJBX6zSIWeVmcInuHTsWqUvSLY9l1I(/,p,b,l,k,I,u,X,},O,_,3,i,:,},S,5,c,{,*)
#define  mccjrhcwlZZ7_Cl870ssj  mMUZq7NBD828WeweqMmSRnU40tAcSOl({,W,1,-,8,u,>,-,],^,g,z,L,z,/,T,j,i,*,8)
#define  mUUhL2rYtJRTJP0LV4X18  (
#define  mG4Rmeyg2zst818MerO8Y  mXmH_3i305hep8DGFQypsQrXEwcOeTq(o,[,d,{,},[,*,i,v,V,O,p,O,_,!,u,*,g,i,4)
#define  mtz0okvhtD5p1Uk6DBz8a  mzK1GAcHyzr2_tQ0GUKc8oZ5Y6j9roR(5,],k,u,k,t,.,r,s,[,u,r,e,Q,],r,d,;,[,n)
#define  mjEvaogrtyF1_bguQjL0j  mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX(^,N,],2,S,x,a,{,3,b,w,m,T,:,r,{,w,:,!,3)
#define  mZoZpYtsPV6rqROXkK5Pn  morj7Bt95YWTWns5OWnEzbKlOGuuaIP(],w,s,{,_,u,i,r,c,p,V,R,B,c,E,l,:,N,!,b)
#endif

#ifndef UCOSLAM_SYSTEM_H
#define UCOSLAM_SYSTEM_H
#include <map>
#include <iostream>
#include <memory>
#include <opencv2/core/core.hpp>
#include "ucoslamtypes.h"
#include "imageparams.h"
#include "basictypes/se3.h"
#include "map_types/frame.h"
 mP_XzHjDjJksPj3b80ixy 	 
    	  
    		   
     
     
 
  	 ucoslam mOURZqongYDezktvsQuKK 	 
    	  
    		   
   
 mepUlRb_fGxwVw4_yEvzD 	 
    	  
  MapManager mN3u76GC1JxwzCzSiQZsn 	 
    	  
    		   
     
   
 mMo8wqvoJj4TcOXpMYmZi 	 
   MapInitializer mYMqpyIhXBEF7u8n1WBRB 	 
  
 mz_ov6KzR3ui07VFuTdqK 	 
    	  
    		   
     Map mN3u76GC1JxwzCzSiQZsn 	
 mz_ov6KzR3ui07VFuTdqK 	 
    	  
    		   
     
     
 
  FrameExtractor ml3yrjd2XYaPg262M5v4k 	 
    	  
    	
 mEnW3xxnB9rHx3d2ouTnG 	 
    	  
    		    System mRSuds8SPWGXQwJ2WTCt1 	 
    	  
    		   
    
    friend  mepUlRb_fGxwVw4_yEvzD 	 
    	  
    		   
     
     
 ucoslam_Debugger mdvB9kCsMbYd5ochgBovZ 	 
    	  
public:
    
    System mPjuLUAkrNGjl3ej0sH2s 	 
    	  
 mBa7x4pVkHPfgozVmHWpK 	 
    	  
    
     mSdT7qukeMTIrTSBzOJ6N 	 
    	  
    		 System mwlUlNweFsquAkDTmIcaV 	 
    	   mTVl_zWHWLaZG4Dq0icPh 	 
    	  
    
    
     mUbaOWPPwDIA27xGFUHhh 	 
    	  
    		   
   setParams mUUhL2rYtJRTJP0LV4X18 	 
    	  
    		   
     
 std mREYi8zQSy9nzX_Jn0j07 	 
    	  
    		   shared_ptr mgmVzk7b137dAlUtwYjCH 	 
    	  
    		   
     
  Map mNNfTDf7dypfFPI9DNdos 	 
    	  
    	 map, const  ucoslam mHfyMEuh5IA67hUblI3HO 	 
    	  
    Params &params, const std mC9SnCLDZm8YZ72GM60qX 	 
    	  
    		   
     
    string &vocabulary mxraQFFgoe8B7exvkg2R7 	 
    	  
   "" mAxWMMlC7cmS3zofeRtuy 	 
    	  
   mP90XIKa0aeJ8FAUhahTv 	 
    	  
    		   
     
   
    
     mc4e14i_5jdpyym3brnc1 	 
    	  
    		   
     
    clear myFxSjziolOuUteqnG5d7 	 
    	  
    		   
     
    mBa7x4pVkHPfgozVmHWpK 	 
 
    
    static Params  & getParams mwlUlNweFsquAkDTmIcaV 	 
    	  
    		     mB9EW4WnVoJ1PWRAI4iF5 	 
    	  
    
    
    cv mKm8qSGS1CdvuHD4sQNSx 	 
    	  
    		   
     Mat process mVI3cEPGwIKikW4z3AV9Q 	 
    	  
    		   
       cv mREYi8zQSy9nzX_Jn0j07 	 
    	  
    		Mat &in_image,const ImageParams &ip, mC7FjcKhO7_areBdwu6pX 	 
    	  
    frameseq_idx, const cv mxqR9YteGa1hhQyZyMtOT 	 
    	  
    		   
     
     Mat & depth mvGPJNf8xTwn6waYbe7yT 	 
    	  
    		   
     cv mED9zvCkVovw_joUH_g3V 	 
    	  
    		   
     
  Mat myFxSjziolOuUteqnG5d7 	, const cv mKm8qSGS1CdvuHD4sQNSx 	 
 Mat &R_image mvGPJNf8xTwn6waYbe7yT 	 
    	  
cv mxqR9YteGa1hhQyZyMtOT 	 Mat mHNoxzxDa21M_o4mFV8nV 	 
    	  
  mcxnxSqSVzTBrvR0W8ARZ 	 
    	  
    		   
     
     
 mB9EW4WnVoJ1PWRAI4iF5 	 
    	 
    
      mY4iHwE2Jji9ggbZVwP2B 	 
    	  
    		   
     
     
 
  resetTracker mmeilvDvghTtQLCtVyltC 	 
    	  
 mB9EW4WnVoJ1PWRAI4iF5 	 
    	
    
     mei3xW_kPauP4_2sYkNTh 	 
    	  
    		   
     
     
 
  	 setMode me8lxtUkum9J4BvHaBCrU 	 
    	  
    	MODES mode mPyiMsXpgpSO0W2kittR4 	 
    	  
  ma_TPQBqy1dnFppk8lT75 	 
    	  
    		   
     
    
   
    
     mt0VGtpIlBJ1IiclfLuig 	 
    	  
    		   
     getLastProcessedFrame mmeilvDvghTtQLCtVyltC 	const mZWxWKz0UQCqDANwJGQHY 	 
    	  
    		 
    
     mY4iHwE2Jji9ggbZVwP2B 	 
    	  
    		   
     
     
saveToFile mg1yZ372BW3UfnRZFAR1I 	 
    	  
    		   
     
  std mREYi8zQSy9nzX_Jn0j07 	 
    	  
    		   
     
 string filepath mcxnxSqSVzTBrvR0W8ARZ 	 
    	  
    		    mP90XIKa0aeJ8FAUhahTv 	 
    	  
    		   

    
     mg5EdAC8WqtoPtczEiU0k 	 
    readFromFile mUUhL2rYtJRTJP0LV4X18 	 
    	  
    		   
 std mKm8qSGS1CdvuHD4sQNSx 	 
    string filepath mAxWMMlC7cmS3zofeRtuy 	 
    	  
    		   
  mB9EW4WnVoJ1PWRAI4iF5 	 
    	  
    		   

    
    std mC9SnCLDZm8YZ72GM60qX 	 
    	  
    	string getSignatureStr mbymioTPOW_RREK8lGQOD 	const mN3u76GC1JxwzCzSiQZsn 	 
    	  
    		   
 
    
     mG4Rmeyg2zst818MerO8Y 	 
    	  
    		globalOptimization mcwGthVyIdx5U9J4dAIa5 	 
    	  
    		 ml3yrjd2XYaPg262M5v4k 	 
    	  
    		 
    
     mlK5VbLyr2fupTMoypucA 	 
    	  
    		   
     
    waitForFinished mmeilvDvghTtQLCtVyltC 	 
    	  
    		   
     
     mP90XIKa0aeJ8FAUhahTv 	 
   
    
     mt0VGtpIlBJ1IiclfLuig 	 
    	  
    		   
     
getCurrentKeyFrameIndex mmeilvDvghTtQLCtVyltC 	 
    	   mBa7x4pVkHPfgozVmHWpK 	 
    	  
    		   
     
     
 
  	
    
    std mxqR9YteGa1hhQyZyMtOT 	 
    	  
    		 shared_ptr mVwZ4Q1LKeNBJ46RNS0Xp 	 
    	  
 Map mDT_bL6uAz_D8Aop_gRIg 	 
    	  
    		   
     
     
  getMap mwlUlNweFsquAkDTmIcaV 	 
  mdvB9kCsMbYd5ochgBovZ 	 
    	  
 
    
    cv mxqR9YteGa1hhQyZyMtOT 	 
    	  
    		   
     
     
 
 Mat process mMTDOGW5X7EUCkkdkln2J 	 
    	 const Frame &frame mUFwvSapHV9cSszIQnzFD 	 
    	  
      mB9EW4WnVoJ1PWRAI4iF5 	
     mg5EdAC8WqtoPtczEiU0k 	 
updateParams me8lxtUkum9J4BvHaBCrU 	 
    	  
    		   const  Params &p mUFwvSapHV9cSszIQnzFD 	 
    	  
    		   
     
 mP90XIKa0aeJ8FAUhahTv 	 
    	  
    		   
     
     
 
  	
private:
    
    pair mrEps8jRqwjueX5L5Vyzk 	 
    	  
    		   
     
     cv mdYrbE55_puZNG1i6eayC 	 
    	  
    		   Mat,cv mHfyMEuh5IA67hUblI3HO 	 
    	  
    		   
     
     
Mat mGyoRbaCWTCEv4zSxy4oS 	 
  _8992046403730870353 mg1yZ372BW3UfnRZFAR1I 	 
 const cv mxqR9YteGa1hhQyZyMtOT 	 
    	  
Mat &_16998117773731312345, ImageParams &_175247760147,const     cv mdYrbE55_puZNG1i6eayC 	 
    	  
    		   
     
    Mat &_6806993204424110071  mbgxDd3WsdHSY2NztpSqI 	 
     mYMqpyIhXBEF7u8n1WBRB 	 
    	  
    		   
     
     
 

    uint64_t _13507858972549420551 mil5AE3u5GMjWT2nOh6Bw 	 
   const mBa7x4pVkHPfgozVmHWpK 	 
    	  
    		   
     
    
     mUbaOWPPwDIA27xGFUHhh 	 
    	  
    		   
     
      _12064558958874466958 mmeilvDvghTtQLCtVyltC 	 
    	  
    		   
    mZWxWKz0UQCqDANwJGQHY 	 
    	  
  
    
    
    
     mu3KE1NxJVfkntJitkxid 	 
 _16487919888509808279 mg1yZ372BW3UfnRZFAR1I 	 
  Frame &_2654435871, se3 &_13011065492167565582  mUFwvSapHV9cSszIQnzFD 	 
  mdvB9kCsMbYd5ochgBovZ 	 
    	  
    		   
     

     muDAt1vEQwnAD9MueitI7 	 
    	  
    		   
    _3570943890084999391 mu7Q3oyiSoXS3a8dpKiGa 	 
    	  
    		    Frame &_2654435871,se3 &_13011065492167565582  mcxnxSqSVzTBrvR0W8ARZ 	 
    	  
    		   
 mTVl_zWHWLaZG4Dq0icPh 	 
 
     mu3KE1NxJVfkntJitkxid 	 
    	  
    		   
    _14569675007600066936 mlHExYq7VNppiorciWgds 	 
    	  
    		   
     
Frame &_2654435871, se3 &_13011065492167565582 mAxWMMlC7cmS3zofeRtuy 	 
    	  
    	  mP90XIKa0aeJ8FAUhahTv 	 
    	  
    		
     mVQFnOUTtTBUVumaXsZtT 	 
    	  
    		   
     
     
 
  _14031550457846423181 mg1yZ372BW3UfnRZFAR1I 	 
    	  
    		   
     
     
 
  	 cv mC9SnCLDZm8YZ72GM60qX 	 
    	  
  Mat &_46082544231248938, mM6yOxLvhvbjtCWIg4wCS 	 
    	  
    		   
  _9971115036363993554  mPyiMsXpgpSO0W2kittR4 	 
    	  
    		   
     
     
 
 const ma_TPQBqy1dnFppk8lT75 	 
    	  
    		   
     
    
    
    string _2102381941757963317 mMTDOGW5X7EUCkkdkln2J 	 
 uint64_t mUFwvSapHV9cSszIQnzFD 	 
    	  
    		   
     
  const mTVl_zWHWLaZG4Dq0icPh 	 
    	  
    	
    
     mU2y8IjcxpN2UExu4x3G6 	 
    	  
    		   
     
   _1513765969352381626 mMTDOGW5X7EUCkkdkln2J 	 
    	  
 const Frame &_10614055813325501077,  const se3 &_10706799483371532009 mHUsPtdM8pjOY8O_PDrlt 	  ml3yrjd2XYaPg262M5v4k 	 
    	  
   
    cv mC9SnCLDZm8YZ72GM60qX 	Mat _4145838251597814913 mg1yZ372BW3UfnRZFAR1I 	 
const Frame &_46082543180066935 mPyiMsXpgpSO0W2kittR4 	 
  ma_TPQBqy1dnFppk8lT75 	 
    	  
    		 
    
     mghNCf1NlZurS0Rz4iJ8k 	 
    	  _2016327979059285019 me8lxtUkum9J4BvHaBCrU 	 
    	 Frame &_175247759917 mbgxDd3WsdHSY2NztpSqI 	 
    	  
    		   
     
  ml3yrjd2XYaPg262M5v4k 	 
    	  
    		   
     
     
 
  	
     miFt7F8jSkXx4tdqkKO2a 	 
    	  
    		   
  _15186594243873234013 mg1yZ372BW3UfnRZFAR1I 	 
    	  
    		   
     
    Frame &_46082543180066935 mHUsPtdM8pjOY8O_PDrlt 	 mYMqpyIhXBEF7u8n1WBRB 	 
 
     mBFUHMEC60x0nLSmYDnzM 	 
   _14954361871198802778 mlF2gZGD6THQjWNGMTmlI 	 
    	  
    		   
    Frame &_175247759917 mHUsPtdM8pjOY8O_PDrlt 	 
      mP90XIKa0aeJ8FAUhahTv 	
    se3 _11166622111371682966 me8lxtUkum9J4BvHaBCrU 	 
    	  
    		   
     
     
 Frame &_2654435871, se3 _14387478432460351890 moiP_RIrtNfjbbf19SHec 	 
    mYMqpyIhXBEF7u8n1WBRB 	 
    	  
    
    std mHfyMEuh5IA67hUblI3HO 	 
    	  
    		   
   vector mVwZ4Q1LKeNBJ46RNS0Xp 	 
    	  
    		   
     
     
 
 cv mED9zvCkVovw_joUH_g3V 	 
    	  DMatch mxKLGXiRps_Em2yOqKJ8A 	 
    	  
    		    _11946837405316294395 mp4VFSz_BIabOzfCvNdjt 	 
    	Frame & _16940374161810747371, Frame &_5918541169384278026,   mnC3q8Y0WvBGVHP4UiTzA 	 
_1686565542397313973,  mtnYNCNzZ2Wi7AlQ7E_qz 	 
 _4500031049790251086 mKB3gjBp8lDwRA92Eevqv 	 
    	  
    		   
     
     
 mdvB9kCsMbYd5ochgBovZ 	 
    	  
  
     mzHUNe6D1DmA64l13__2c 	 
    	  
    		   
 _14938529070154896274 mu7Q3oyiSoXS3a8dpKiGa 	 
    	  
    		   
     cv mjEvaogrtyF1_bguQjL0j 	 
   Mat &_175247760140,string _706246331661728,cv mC9SnCLDZm8YZ72GM60qX 	 
    	  
    		   
     Point _2654435881  mAxWMMlC7cmS3zofeRtuy 	 
    	  
    		 mZWxWKz0UQCqDANwJGQHY 	 
    	  
    		   
     
     
 
    static Params _14938569619851839146 mP90XIKa0aeJ8FAUhahTv 	 
    	  
    		   
   
    std mdYrbE55_puZNG1i6eayC 	 
    	  shared_ptr mUU3s2laR5oNPobA7BGSn 	 
    	  
    		   
     Map mGyoRbaCWTCEv4zSxy4oS 	 
    	  
    		    _9098980761384425343 mYMqpyIhXBEF7u8n1WBRB 	 
    	  
    	
    std mHfyMEuh5IA67hUblI3HO 	 
    	  
    		   
  shared_ptr mmCtQOzadRN3ADLKOQXVu 	 
    	FrameExtractor mxKLGXiRps_Em2yOqKJ8A 	 
    	  
    		   
     
     
 
  	 _3944249282595574931 mdvB9kCsMbYd5ochgBovZ 	 

    
    Frame _14938569046430841631,_4913157516830781457 mP90XIKa0aeJ8FAUhahTv 	 
    	  
  
    std mED9zvCkVovw_joUH_g3V 	 
    	  
    		shared_ptr moTf4F0dfZjm4I7ZjkQLF 	MapInitializer mGyoRbaCWTCEv4zSxy4oS 	 
    	  
    		 _2044193291895307872 mBa7x4pVkHPfgozVmHWpK 	 
    	  
    		   
     
 
     miFt7F8jSkXx4tdqkKO2a 	 
    	  
    		   
     
     
 
  _13028158409047949416 mxraQFFgoe8B7exvkg2R7 	 
    	  
    		   false mB9EW4WnVoJ1PWRAI4iF5 	 
    	  
 
    se3 _17976495724303689842 mP90XIKa0aeJ8FAUhahTv 	 
    	  
    		   
     
     
 

    int64_t _10576739190144361304 mxraQFFgoe8B7exvkg2R7 	 
    	  
    		-1 mZWxWKz0UQCqDANwJGQHY 	 
    	  
    
    STATE _3857178690860967008 mqhzuASPlPGYcPO7FpZoo 	 
    	  
    		   
    STATE_LOST mYMqpyIhXBEF7u8n1WBRB 	 
    MODES _17450466964482625197 mFWInR3RUTY7EkIYmWaKK 	 
    	  
    		 MODE_SLAM mB9EW4WnVoJ1PWRAI4iF5 	
    std mHfyMEuh5IA67hUblI3HO 	 
    shared_ptr mmCtQOzadRN3ADLKOQXVu 	 
    	  
    		 MapManager mTDtiX1SR16Sj4oCOAI9Z 	 
    	  
    		   
     
     
 
  	  _2869602498954317713 mdvB9kCsMbYd5ochgBovZ 	 
    	  
    		   
    cv mxqR9YteGa1hhQyZyMtOT 	 Mat _14463320619150402643 mYMqpyIhXBEF7u8n1WBRB 	 
    	  
    		   
     
     
 
  	 
    uint64_t _13033649816026327368 mqy8PuM_IbJFjc55EYn72 	 
    	  
    		   
  0 mB9EW4WnVoJ1PWRAI4iF5 	 
    	  
  
    int64_t _10558050725520398793 mvGPJNf8xTwn6waYbe7yT 	 
    	  
    		   
     
     
 
-1 mYMqpyIhXBEF7u8n1WBRB 	 
    	  

    
 mgnMDVvC0dLzdgUGmI1lY 	 
    	  
    		   
  mdvB9kCsMbYd5ochgBovZ 	 
    	  
    		   
     
   
 mKtjisCBdMqWA3GWFX2OD 	 
    	 
#endif 

#ifdef _14557395541824112390
#undef  myOf4He5Ro9hUPDLH2q9i 
#undef  mkbRhMFcUAc8d0f8NFllg 
#undef  mPjuLUAkrNGjl3ej0sH2s 
#undef  mJOnlzB6yq7aVih21ZQQE 
#undef  mkkgUFpGrNeJG2y6v934V 
#undef  mEnW3xxnB9rHx3d2ouTnG 
#undef  mHAORgqiHHVSqDNrS23fc 
#undef  mrog23lGaxAYDRRTLOldt 
#undef  mbXYQdUZhX2o88ygtlqk3 
#undef  mJ45ib0fH03iq1Kthd45Z 
#undef  mgnMDVvC0dLzdgUGmI1lY 
#undef mg3KyVvqKMExE69HSGRA8f0Mvf86uEy
#undef  mA69tFOgnqQBj80LAmt0e 
#undef mHME0qePrip_Ym8eQJbM4OB1I9GyKn8
#undef  mOE3APnOTPwOFVlSVhUw1 
#undef  mTVl_zWHWLaZG4Dq0icPh 
#undef  muafiu_RYj2q3NWEuJmcg 
#undef  mNddTJ87EBxl2LZiXHI0f 
#undef  mpMGRL1STltXkEUKbeEf2 
#undef  mgtOphx0LqLG2pTJGRAzb 
#undef  mGup4Sbb1vuZgqdJfTV8m 
#undef moyVbeTx3hlFWrOpvaLkz32rbM6zziX
#undef  mE3feNnnJhOEyfFFmTwAT 
#undef mLmRdXXe6lTOBF9rOJ9E_kfp1xE7pfe
#undef mEm6ZQU6tJh_vGa6nQtdG77wn0CPOzF
#undef  mGcyYCdGw0mx_Wy8M8hdY 
#undef  maUC92a8br9MJSZr24gNp 
#undef  me8lxtUkum9J4BvHaBCrU 
#undef  maNPgWJ7mdz67t0qhLKFu 
#undef  mit1Nagu9lnIyC61iaXak 
#undef  mjT5gIH0sm8fq9bGBMLxv 
#undef  mtnYNCNzZ2Wi7AlQ7E_qz 
#undef  mB2TN5yrGpsBbUTkIxsxl 
#undef  mVd0GoV7eTGOJdXPhEYNU 
#undef  mhu281nrwx1ki9vU5FASG 
#undef  mf1yCdCQpina6pxHlTg7n 
#undef  mn3SoShr5pbvrBsyKdJfK 
#undef  mU6w36ceeANCelLN9IJ3M 
#undef  ml7njTmCSoy4e3IPSwzNV 
#undef  mmWGTrex1fxp6ApRsCmH8 
#undef myzhu0gLDr3dUpKXLKGfrOduloPAsyO
#undef  mbmmqslNXn7vF7yyl09kQ 
#undef  majnNP2ClSbmc1Zx7x4Bx 
#undef mw57CqG8fQcjAD8KjIlWqAao0sFGhtg
#undef  mcxOH0TpqrdUrN9fFrNQO 
#undef  mNrP8BlvP7Iu_rVsMU7TT 
#undef  mGbNmhIPyZpAirovnDpJ2 
#undef  mCnQrcvV700TSwnpzbJ0i 
#undef  mhrYbqeo8Hjn17CFfuuPB 
#undef  miPzPzde6ZWcZoCKQ12zV 
#undef  maqUHLOZcdGf69SlrxScW 
#undef mNBAu2DjI2PBKRV6XSTGoyl4JE7eU1C
#undef  mOqZHKtf3WY7tkMnCX1gN 
#undef  mli2rl85KZRdFYQ1q_kPe 
#undef  mVYqToILeeFjU9cAREzmw 
#undef  ms90urr7dOZydXcQofI8k 
#undef  ml7gqIEKKslTsZDx7OeKe 
#undef  mKb37Ilx3r57DTs1FaDdq 
#undef  mZ_eWrCk46126bipVjLNx 
#undef  mmPFdHa6O4aJwZm8kxllk 
#undef  mu3KE1NxJVfkntJitkxid 
#undef  mMd4OyVQzSuVQeI20XbHe 
#undef  ma_TPQBqy1dnFppk8lT75 
#undef  mAGoBSdOV8ZnnhVSxIsg1 
#undef mTsCVGocqw14cCTdgCY_g4MIlB4W67L
#undef mWZsUHUKbKzgK8jYXs7VwUV_k05sy40
#undef  mOTpBktSaM6Zyl8FlQmDv 
#undef  my81q3bGn3jN8YsD6PP0U 
#undef  mCQO2JSMGl57kN2ceikPX 
#undef  mPBrDnI6sFU1ZWwHTspLv 
#undef myoleMod9LNYkU2kjMz8DcpwouNcSEr
#undef mqHQyEjip6DBI1IujiuB9yG97VBXxPQ
#undef  mKjOhwXn8BB4zlmbTKifK 
#undef  mKB3gjBp8lDwRA92Eevqv 
#undef mmKmipgAlj0pwmgvvw4npu90F7rfrxn
#undef  mpykaO0d9DJPHrWQDJJA7 
#undef  muTJrDcn5XY4cY3WfDgL0 
#undef  mq52Iw1sD0an3AeIdBzZh 
#undef mXJBX6zSIWeVmcInuHTsWqUvSLY9l1I
#undef  ma_0okM1wIOtUEPv8I2sV 
#undef  mUEGZOMdpOvF7zA8Em46D 
#undef  mgpyImKbP8BPQ6mDW29zR 
#undef mJDX09rv91N5ZI2N_wwBfZyI1gVZQ1v
#undef  mEJ1dOdJJ2JdJjq7_RoqO 
#undef mdQxIJe5dN2Iz1bPT67Bql_wuVqs6iS
#undef  myRQN040gP7JlpixOmiLN 
#undef  mfXxL5Ljg5a5Ut27zWf3m 
#undef  mJb9djTAnve4NK8HK4br_ 
#undef  myuclXWfcLCAglS8blD4d 
#undef  mmWX0oC1MMu37fIEnoaNO 
#undef  mSU8QfnaE2LjJKf36WrNq 
#undef  mp6eKXDoVx5YQew6LI5yC 
#undef  mUFwvSapHV9cSszIQnzFD 
#undef  mz6CvJg7i3Yd0kyC3Xhaa 
#undef mzK1GAcHyzr2_tQ0GUKc8oZ5Y6j9roR
#undef  meTpT3MJcElyouJlutAHQ 
#undef  mZSDLzD9n10G90oIVavxt 
#undef  mREhn6j5n_Bu_bJ07CIfv 
#undef  mlHExYq7VNppiorciWgds 
#undef  mZe8oLc551pSl21rGxPe7 
#undef  mnbmTVMYz7G8ZgbwbQlRT 
#undef mU5Ik0wGQY3jwQRCo2J2r1LWEqNCWrb
#undef  meoQJNIC8UdPGJn4VVnnQ 
#undef  mtbgRICQDg3q1nBZ0mNyc 
#undef  mKtjisCBdMqWA3GWFX2OD 
#undef mL02F_rTHTDw0qr8N3nWcukZoKytjWL
#undef  mmYGg6AUB6org7CbdyvaC 
#undef  mOURZqongYDezktvsQuKK 
#undef  mwyBKO0V__1FTEwTLPP_z 
#undef  ms40AEOhklS1C3ZmLFByN 
#undef  mcxnxSqSVzTBrvR0W8ARZ 
#undef  mvWL_NjkbEupW77QOP45m 
#undef  mCEmto4Ukedj4AZ9h6jGN 
#undef  mMTDOGW5X7EUCkkdkln2J 
#undef  mBFUHMEC60x0nLSmYDnzM 
#undef  mAhlnPNs8C_vRZ5GSAYYk 
#undef  moWfIxU9Ppkd6kp9Ta20t 
#undef  mo28JXmWB8XWFOzR9VbBv 
#undef  mZUZRdvfMgK3fDdB53Q3H 
#undef  my5QMAVyzyRGh4AzUKMnL 
#undef  mz8CNwfisqSVHwKd1zow7 
#undef  mP90XIKa0aeJ8FAUhahTv 
#undef  mREYi8zQSy9nzX_Jn0j07 
#undef  my2f34fjaLV7L3eJnQLo4 
#undef  mj_kUSCmfGEHqIxauPzZp 
#undef  mlaklSopCKuMDGov00995 
#undef  mTqnk7kT8luzO79RMx8A8 
#undef  mzHUNe6D1DmA64l13__2c 
#undef mmvaK7ZOLYRWY5Y1vECfIMYueuP_lJe
#undef mbPDDDSzwsfJ5AoL9LVoup7SuSuk4Fd
#undef  md4m1KWJKHskULWZtsT98 
#undef  mElOTkZs0IQ_dseu2IgG5 
#undef  mnQSiPsXqaVV8fVxsjv3L 
#undef  mwjVuE90nT10HtQ8lxpAx 
#undef mAD1ztTaLh5jNqFbcIOLFMbKXyIE8N4
#undef  mYLPRW967qGnwYV17sIvu 
#undef  mIpr22DZY7EMzxhF_ZNTI 
#undef  mgIVDGtyxEJYrZ8jY4yw9 
#undef  mmhFqpvlq0jaWW3KsSS4H 
#undef  miK3fq8qK6qAr8BXTIdRp 
#undef  mKV1sIquqBUemLMhVJkOj 
#undef  mAxWMMlC7cmS3zofeRtuy 
#undef  mKlREyDxK7DEq2edFDBXO 
#undef  majT067k82ghSACHdfZ8G 
#undef  myXwYxGV5RejXvjnYPTol 
#undef  mW5aEo6YSsYo47c23lGGu 
#undef mVmJHE9ifxQgOewhrQxiKN6OsfwHY5v
#undef  mPLgfqUIqe934t25HlH2F 
#undef  mdo1yaztLKvAHx3yvcTXg 
#undef  mDXk8E3nCsL9vCjNmqjRv 
#undef mB7ILmYYy02GbH04PvxVchcbXaoKcOB
#undef  myK1J3FoMbr9FpZhP9ynv 
#undef  mQ9yZfyo1YJu6nthW0wTe 
#undef  mDL7JagV8d2jQAsJ9PAyd 
#undef  mFqoc5D1QV1OrSgdUYlf5 
#undef m_MuSlOLNdd4Jeci3JPzgNOWISmetQN
#undef  mY29CQGwYkMcqc0xNclye 
#undef  mVqgZdEy43hPXdQUsqKYO 
#undef  mtGK13v7rqUXU1znYBgvM 
#undef  mjEvaogrtyF1_bguQjL0j 
#undef  mMo8wqvoJj4TcOXpMYmZi 
#undef  mVwZ4Q1LKeNBJ46RNS0Xp 
#undef  mmCtQOzadRN3ADLKOQXVu 
#undef  mmKhHCwEaYKsm61QprRLc 
#undef morj7Bt95YWTWns5OWnEzbKlOGuuaIP
#undef  myS_9mohS4Lo5kuyzsDq0 
#undef  mwiu2dHfMFHA2ERIc1ebV 
#undef  mbQvSZpTbm5Ya6_UtqBTZ 
#undef  mGPFbfaefUJzbpS634zj1 
#undef  mjzXlY7yx62rGYwPRDsDL 
#undef  mXQC80goA1UX24t8EnYQm 
#undef  mtTJ0wFCb6KqmVaZsvnCP 
#undef  mu5pjFrnavZukwfcFAmYr 
#undef  mRwdmMk8n_WlpkidrGEvN 
#undef  mTDtiX1SR16Sj4oCOAI9Z 
#undef  mc4e14i_5jdpyym3brnc1 
#undef  mha_fdAzotC3D6n_84Miu 
#undef  mtZeikAKgDMnO4y9JW3RT 
#undef  mTXC_wdut0P9j1I5PBltn 
#undef  mvzvubRNShWvHe4s5nwOM 
#undef  mHLwpZRmKJ5WAbptynFZl 
#undef mjKobVCAtuMV0izLcp6b4v30WAIIU6i
#undef  mepUlRb_fGxwVw4_yEvzD 
#undef  mMInPhTIDuXz_bBDOWXtf 
#undef mHqpDycNP3DNEfbPB5q0afB9VWbeQZ0
#undef  mOja3F4bzOrkxWOxZjrRz 
#undef  mQlGc6QtQUERCXCxLIdqa 
#undef  mK01tPECiPJw9C5YONcjt 
#undef mk3xyy_vt5A8ok32FQ3O91aGMQKjNOk
#undef  mCx1qPwfbNEjHEvxFO6q5 
#undef  mWxBLCLZUV49XvVAFk0fM 
#undef  mei3xW_kPauP4_2sYkNTh 
#undef  mpqPR1fr7vl4cYSE_EKfd 
#undef  mC9SnCLDZm8YZ72GM60qX 
#undef  mgMpfcGi8JNbRvTqkMjjH 
#undef mEbolvCyeFaTSSaqJFV_VnwJw9N8c2p
#undef  mmeilvDvghTtQLCtVyltC 
#undef moQ_1Ezr2_1Ao9jO2WcwZD4r8uscXWg
#undef  mweI968yRgKTJp4ZJXxuH 
#undef  mT4gPNGQ0twLGxWfumzJx 
#undef  mObnEemnD3Rj2a4BEt3Rn 
#undef  myWY0n2x7v5DANQcKyGiz 
#undef  mOHHRZSrkQS7Tod45doST 
#undef  mKwOlXD2n8QB90wpC2rcK 
#undef  mZjPDncmYkoLrTIUUHwc1 
#undef  mtQ9GyiTaGhVugbiLf_qa 
#undef  mILq2XnSrvq2oSFAPWXOl 
#undef  myFxSjziolOuUteqnG5d7 
#undef  mOzIiCPwtwE4i9B4vCzzy 
#undef  mQJT5PeJs_P9anNcZCBKP 
#undef  mvptJ4lnhZ8h5JnaONzf0 
#undef  mmVpMulh4PDaIs_DEP4Fw 
#undef  mtiAX3E22DlObVhH_xuDJ 
#undef  mYg0R7BxjLrIugBiazXh9 
#undef  mqLJPxLOlGVM45o7_VOQB 
#undef  mK_lFTcgqpdfvX9FOYxwo 
#undef  mAs_6S7tAgrii_0vToxPE 
#undef  msS0LQZ2Hz1ZugFX1FMaV 
#undef  mF2MiJtGCo8Aq8HVrPODx 
#undef  mveU0trXqnLp8SIj93kez 
#undef  mldwgOI4CXSsY6LKF1GRc 
#undef  mhVKIl3HOOZKUmFoTMWVv 
#undef  ml6pMGXRymntVMdgsCmYT 
#undef  mISEFKtyB93TMn1aNyYH2 
#undef  mKuJ7TB0wL7yrHuvzhhCt 
#undef  mmc4utX8qqtZy5uW1_xN5 
#undef  myQhGfDs_TXnx45lzxlM0 
#undef  mdgR_Lq8Ib3V7mEpteRnE 
#undef  mccqiuBx4vQeLVDO2NR8D 
#undef  mZceZQqcFSwrMSrGWwLr8 
#undef  mB40JpgehNKVxyMraS7_U 
#undef  mmvD2rsRAXhJMspTBodRy 
#undef  mC7FjcKhO7_areBdwu6pX 
#undef  mypR7wVCtDDSWNl7g7vw3 
#undef  mpO9jGpUaM4nPM2HFPpv8 
#undef m_A__ryx3jnqdZr3S_8lm8QWUSGKqOG
#undef  msnzKCNI6Pp2groygQLhF 
#undef  mcTy19thnnW4X86_TMJKh 
#undef  mYuCBX4OuuamXpwiRUkjN 
#undef  myvY0z9skkviaOF3yXNfk 
#undef  mGPW3KksbeqY9pa1YcIIS 
#undef  mJpUFXd01l53uZdAWtqz8 
#undef mryPwBkQ1GlenrQdQwlCGsI76wDTGy1
#undef  mK3g0WdKMHKb5M5e6w_OU 
#undef mxaeCySzyz0C20pplGWc0iD4nx9TMzw
#undef  mrbCGF3_6m4NgCoBe8ZEn 
#undef  mdvB9kCsMbYd5ochgBovZ 
#undef  miFt7F8jSkXx4tdqkKO2a 
#undef  mvLCGOCone3MMowb6GDhw 
#undef  mM6yOxLvhvbjtCWIg4wCS 
#undef  mXJvIHowjKaf9imUwJIGh 
#undef  mED9zvCkVovw_joUH_g3V 
#undef  mfy1CrW1ouEztjcGWbKGf 
#undef  mqNdWgrWyH8KkH710eUio 
#undef mzf39t53mSVTJTXSx5xbn30aYsEuqBI
#undef  mKm8qSGS1CdvuHD4sQNSx 
#undef  mHwHn5MNLuOg0M4lOOpDO 
#undef  mwMErjQQqLm1Wi6JDDRaW 
#undef  muRCdQV18EI8MPrIAQo3o 
#undef  mpv8Gs6wEH6ramA_F0kDc 
#undef  moX7jkJanNSLGOkjYJgn1 
#undef  mxx_6t6Pu_vbWcytmNl8a 
#undef  mA6EFaCkeZRtYIh1AKCjD 
#undef  mxKLGXiRps_Em2yOqKJ8A 
#undef mhQAfqjWSgxAyWH3vsxiP1b9dnUvzkA
#undef  mcOP9xQsreZsIj_erNGS8 
#undef  mafqzox_fpjgkRXjUN4kR 
#undef  mGwdyh3TIoYpZKrbJbwZA 
#undef  mqy8PuM_IbJFjc55EYn72 
#undef  mwlUlNweFsquAkDTmIcaV 
#undef mWypq76q9ijP0I3sF2Mg7vhG71riA1n
#undef  moWSuesSxWfliNESRJC5S 
#undef mCEEFnjFx293p0rVQJYRH_yXm9yj4DS
#undef  moTf4F0dfZjm4I7ZjkQLF 
#undef  mjNwZFsNVS6l2MgJ_Ztda 
#undef  mdYrbE55_puZNG1i6eayC 
#undef  m_tbrUs5piVx4yemZqi3j 
#undef  mJ9QLQbmFfbEnYtENFCue 
#undef  mLJ6MMA8cQ2t5cHwc5Tmi 
#undef  mnrWU2rk9xpBKSPrNkFU9 
#undef  mnShvLha2uUcrbocL8Twu 
#undef  mE5BRpqwyACNpoRj3phZn 
#undef  mt0VGtpIlBJ1IiclfLuig 
#undef  mtz0okvhtD5p1Uk6DBz8a 
#undef mtPEIImYUWwt0hrfyg_q8fAYr7rzTDk
#undef  mVA3HgTiSTULG3vnkAJ0l 
#undef  mWulwhdY7Qo8qxoG0HWQC 
#undef mXOu7nlqRUri26hkIIYLn65MZZuXfyk
#undef mRb5Bl_0H6tmAj7mXzAKyUFZK0kkHHS
#undef  mfPEbHIXLZeSYydU4_npI 
#undef  mJsYWHyrSI4DZn3YgSaGp 
#undef  mPkgC9fgAqceBP7GUEzKl 
#undef  mZ5BgX3OJVG5nsis55lY3 
#undef  memSoNvM7ZRuJrojk0hFT 
#undef  mlnuJn1B4v4dofynov8v1 
#undef  m_z3i6F3i3vWskVJtkHUG 
#undef  mopOBoXE8D8ZDzIkHXbjq 
#undef  mUU3s2laR5oNPobA7BGSn 
#undef mfq2pmJ4rdERKMYgKwahST5gmzd8f1y
#undef  mloorfro14BsCy5lRVbm3 
#undef mNBmafpekTOnKAgEHqTmbI_abV7hs28
#undef  mzrx5rjKC_CvSzS4FK0Zn 
#undef  mCMfAPvVRUGsQ0IZXDcaD 
#undef  mvUBmA3EfgVSRcD_wi8od 
#undef  mupgyN87RZV56fslKpTet 
#undef miEaGofO8A7jc8En_bhRM5Djfflfy93
#undef  mH0AtR_Wj6HZIDkybpTPW 
#undef  mU2y8IjcxpN2UExu4x3G6 
#undef  miKYLe8PLXjsegyz3kHS8 
#undef  mWJMGwnhjKI2zyUbDxEq3 
#undef  mY4iHwE2Jji9ggbZVwP2B 
#undef  mqVBg08TweaLwwZheFyD4 
#undef  mEl3GWGoZvBpDD58w00xb 
#undef  mVI3cEPGwIKikW4z3AV9Q 
#undef  mbODKf_jPDerPCtV69Tx_ 
#undef  mpdjiFItPbIpxdfHT4W1f 
#undef  m_uQeei9ES_Nbh5quW9QZ 
#undef mFOn7N2vVU_wJdPIrb8Cne52UEorN5R
#undef  mMI5ztL9es0RE1XZgcfJ8 
#undef mBqwL20VfI964Vp5g6jb3psc3w0tOtS
#undef  mdsuxp1usBp41htrRhSwQ 
#undef  mxF6OaVnYUXVPp6yNfl0x 
#undef  mHfyMEuh5IA67hUblI3HO 
#undef  mgCguWLO1S8LvhrTTXbwt 
#undef  mUyuZG8VjGxPkrNRyU_Cw 
#undef  mdQwA_zXYvTCTufYTXjJG 
#undef  mIy9cuMwL1YmJ9CUqdzBt 
#undef  myi0K65NakSGpjTFWBq5g 
#undef mk7rPAI4cPGhWOVsdaXp6sQSNIPXGVa
#undef  mpw5nEls8yLqx0Mimh_uX 
#undef mpKh49b91qc70EAC1n0EQlaW6pwYQsT
#undef mHwjDxPB67MBuFeeGhkDQog6hFda7fi
#undef  mSG6LGxdJnGKRz3KAz0sR 
#undef  mYBCfXkUHlL_xuzSERGoy 
#undef  mOB4dB8NRZUJ_VF4hAcjg 
#undef  mVAaYHs16ZqqBXmNG2f7l 
#undef  mKSjzV9MeNTUhugLWgYmI 
#undef  mRZ5e8l8J1g6qVnn0jT_K 
#undef mbUAjws2eHBlAudWc5pRCMt39cvNgc8
#undef  muAlb5eL1gfHGm2CaW1dR 
#undef  mWd9A79WkFG1RCaXrDRgU 
#undef  mDT_bL6uAz_D8Aop_gRIg 
#undef  mH6_YN9tj6oTwFVcRsbvY 
#undef  moiP_RIrtNfjbbf19SHec 
#undef meAZG6l6cTC6QKHPbXqKxF3eEmjIgvK
#undef  mG29v9jgNnHyPwCL8OEMd 
#undef  mxYnHmHKvFkZxKu0CQGiX 
#undef  mSB9nvDdalO4z9M0PrPjz 
#undef  mpWcIgqhL_YhOwyL0Tz3n 
#undef  m_pqP2BgD5II2lUiQB7Vh 
#undef  mG4kTbxAI6S9nApaIGMpR 
#undef  mC30BUNbYTOVRNukgU8MI 
#undef  mcMYPm_ceByMwMjOxMCeW 
#undef  mvGPJNf8xTwn6waYbe7yT 
#undef  mrld8M7R3nm9jR7VniEzE 
#undef  mmpuqwfnlpj95dsG6FYBt 
#undef  mUbaOWPPwDIA27xGFUHhh 
#undef  mxqR9YteGa1hhQyZyMtOT 
#undef mlZA8mAkYLxBST19jGBbpWXp7Kvok3q
#undef  mq_3oqTWIPvl5p0pa4ovO 
#undef  mcHyP5djOseGDQ9V8ndaP 
#undef  mtrRZ6ELfckLuc8MvLrpu 
#undef mP16hZsXbvlb7uoFJnIa3hhZ4F43HoF
#undef  mCleusrexysUl_2bhV9GX 
#undef  mZWxWKz0UQCqDANwJGQHY 
#undef  mcoKeEEOQ2OahSc6bivQz 
#undef mbIrXitBXdk6aWNuevddEvxJ4SScv7B
#undef mDj5J8G2k7i7jZXhLThvDlWkKpcWVKG
#undef  mV0mI2KvJbNXxWB8X5Kjx 
#undef mKA9gLYqboHuTq57JoitGjVnGIHixiL
#undef  mtVzwUuddgGt4Cv766GT3 
#undef  meDYFTD657MJ07Gr2yNEP 
#undef mGY8Cpi97AzpvrcB1Wd2KtCqPmgm6g2
#undef  mH3nzZpzWB5iiztfuefwr 
#undef  mIyvBEFHE3pt9aHJxl_0Q 
#undef  mb73xh2j20JUDstJ4Eyv5 
#undef  mC0RrXZ6OjXaGFFwJLD9k 
#undef  mzIi3MAIuE2qNIp5v45xe 
#undef  m_Q4Z4YB25qt6Hiepq1WL 
#undef mTlRbewIeyliM1AkvTy_IG5YXZVizpp
#undef  ml3yrjd2XYaPg262M5v4k 
#undef  muhEYtRRxuEAlXdTLpMa8 
#undef mtbC5b8jyq7DJkwznl8Ts8ML4sk0LdM
#undef  mVQFnOUTtTBUVumaXsZtT 
#undef  mWVjvgA9ev3BFt8JNmFMP 
#undef mbux7GV0NphDPUlPVjqmdlyWAgwon0j
#undef  mlh2a0uUJ2yhdNmRZT_jJ 
#undef  mOOgarBHL8HS8hBv5KxIj 
#undef  mseBCf7Pa7dwhAv8SlGC3 
#undef  mrEps8jRqwjueX5L5Vyzk 
#undef  msXGDFJOEAbjmuxUQRm1m 
#undef mzvr1cwK0_N5ZFhhbQIjg_HmAAjFqla
#undef  mpWhdtGgg9g2EwmEVwluL 
#undef  mlF2gZGD6THQjWNGMTmlI 
#undef  mciYbe9O7XtjyHVNMFrmP 
#undef  msBmPlvOTsMhadczyfNBC 
#undef  mZHcJ4c2YcNNH1Aavq4wI 
#undef  mWpHOg4mQBM1v7Rzo2SMA 
#undef  mYMqpyIhXBEF7u8n1WBRB 
#undef  mBqjGUjUyWug71g_y3ICa 
#undef  msuCMJ2X5JeARGpOgtXSD 
#undef  mFiKui9uTZWpmEL7gv25_ 
#undef  mwOcnqwaDXjcIorUPguo8 
#undef  mCX6T74BTn_cagJe1I2_9 
#undef  mqTXMJtwOukRNzdv9m0ba 
#undef  maSEFXijKT9TdwJB33J4o 
#undef mYAtPnQfUTtJ2L5s5fu5C94LW5ol70Y
#undef  miDkSd5vedi_Sb6oNXPY5 
#undef  mr0ilZME7b1NSNtUd6aL2 
#undef  mBa7x4pVkHPfgozVmHWpK 
#undef  mFWInR3RUTY7EkIYmWaKK 
#undef  mFZRkEzkhXP4liRLc3gNK 
#undef  mzcTOqyZg3DMCmtyCLTgc 
#undef mBeual6DWeKJO3OjJzK4Dos1BRMtDb0
#undef  mAl5fCBsA_r8YOpHRPKH1 
#undef  moPUXqTSHVdDjiaJDLtgt 
#undef  mxraQFFgoe8B7exvkg2R7 
#undef mBPFdhW2nfmnjlQb_OvzNROrxXFSOA4
#undef  mbSKNy4g1VSazvuUzLe5k 
#undef  mozXFRVDUHe0HdIZTh9Mg 
#undef mvJ_0EZTnnoWPY1qRtcZLKpUsB_qldz
#undef  mXqmAnk3zY45potlI2l6u 
#undef  mp4VFSz_BIabOzfCvNdjt 
#undef  mXhCbQTeBYWsYiRaykLio 
#undef  mRCKbvlo1EVYLptODb8vM 
#undef  majJWjHY0S91lwuLKjdjc 
#undef  mSdT7qukeMTIrTSBzOJ6N 
#undef  mMfAUx83qkcH3XDsK1uM2 
#undef mqcHRsEpUaLR5VPmTetJZmxYTGcBRBm
#undef mIuUidCInxLMjhP3iu7ztcD_BPe5brz
#undef  mCn2zmr1EBBunQpiZ5Pag 
#undef  mFprMtmXqlUzTMVEDq32u 
#undef  mBBXiPVIlxbmTvHSwkAq0 
#undef  maKaQ32zCBVhalW9Wby13 
#undef  mm4hRYlfjCxe6w7RGpYMp 
#undef  mb7doFKv8Ez0DP3oqqiys 
#undef  mRKwIJ048qEVlkr8T1E3m 
#undef muWbdGvEWaMj17f_2Z1yIVmD5qNvO4P
#undef  mWZI1HqHarxXH9aKPTC01 
#undef  mu7Q3oyiSoXS3a8dpKiGa 
#undef  mkIYufTDVG82v7lQxrn_f 
#undef mMUZq7NBD828WeweqMmSRnU40tAcSOl
#undef  mP_XzHjDjJksPj3b80ixy 
#undef  mc0HNf9qKY1240YlFUIL2 
#undef  mUGRc8udAXGE9oOP6k7VQ 
#undef  mbQzcx54Cwn5rVAQ64Sg6 
#undef miVgzffhWar42MS7NuqjGRdpA4J1oQ0
#undef  mw9BL6HklcMABN7fsELrC 
#undef  mo_SRoAmVv32zu51VxzID 
#undef  mpKf7HASdwnUZO4Wuxg_Q 
#undef  mPI7KFNGd8c7th_taFFtJ 
#undef mPxsimcVG4wyPM3ych3g30EwvtSsKV4
#undef  mumVyW4mF6VGTCLeQRnWb 
#undef  mRHvhY84N3BXG1ebWVrH7 
#undef  mdRUIixUEUC1AGr37GbQL 
#undef  mKM0JrQ0CkvzA6tnSKwBj 
#undef  mtuok6vwjE7_LNbYEjh8I 
#undef mNObCi77IiO2AAnRjZBu5yg2Y536QSA
#undef  mcs5Ok99eYWBtkDqLwUiJ 
#undef mbUUvfs4otkmcpFD9HezusAkWSs5kCs
#undef mXmH_3i305hep8DGFQypsQrXEwcOeTq
#undef  mxs9r3yJcfhZqbbb8oia_ 
#undef  mirWmAlCKkmqSm3vCnGwy 
#undef  mF4jqB62RKMyt617fbZRV 
#undef mW1YT9Onvr5uEyfYQQVGIdnmdYce7KX
#undef  mlr6oYGuO0c6t0ARkl_AY 
#undef  mjOVZKm99HxHpScE85BdO 
#undef  mZv0eIrzcy7b4JAr5Kpu4 
#undef mJcTcgELN5_86K09Su_kF12TtAZyw10
#undef  mWmXFm2ClJRwQE1_IOkkI 
#undef  mhADchoFnmhkCeXwFcQEJ 
#undef  mIOd1fPUZbw_k7IiuSWeG 
#undef  mil5AE3u5GMjWT2nOh6Bw 
#undef  mwU0xLcPRasq1N_CokOuF 
#undef  mk9DI3O22yb0BbiF8DiVK 
#undef  mXj7AN7TO6dFlL1g1FUpP 
#undef  mccjrhcwlZZ7_Cl870ssj 
#undef  mNOi7CadK1C2NbknhwXYp 
#undef mCdHXgSa9I8NANf9A_iOIFW0GZWavsM
#undef mHNDYTei43KdJT3F9HgJ_8xQZfZLU4r
#undef  mGSEMbfdFHWKmMke04nqo 
#undef  mYCqRuPYJyC4wITlSY89X 
#undef mVe8vZ5T1eszRPkNEVIfypaetuiZt8k
#undef mJi_MN01Ce62XjdcMft611EpYrkUnpn
#undef  mpJemLzRHiHYFsZjB5qjk 
#undef  mryw84nsBdzuXsr9FQh8q 
#undef  mVQHQtg6nUDjCWxJsvKAT 
#undef  mHUsPtdM8pjOY8O_PDrlt 
#undef  mMapC5gQXKtll23LqXiIg 
#undef  mmseYz_s2w2c9ohE8DdLC 
#undef  mH0USh8PMlkh3sQ1Kfxkq 
#undef  mYiozbgNT0ggdbg9jhuBA 
#undef  mqGTHtoE7UDeEo3aU92QP 
#undef  mWbXrkVHWJgLKpX9zIAYh 
#undef  ml_QiRARQJzhHfwnk2IZk 
#undef miV3rZ_G3eYi24BQrxM4M9RO0JxboPa
#undef  mWe6lzxBP1UkpGJDKE676 
#undef  mx_u_B1PZ2sI9z5oCKbU8 
#undef mSGNFC2q9ATF1lqB2rsAAlGbKJNCcm3
#undef  mqlLqq30QlfPPBFL7Axud 
#undef  mMHMycAyJB3fUUbh3ncbA 
#undef  mnC3q8Y0WvBGVHP4UiTzA 
#undef  mw_rZHwpFqtm8PaFhtbtF 
#undef  mUAtwggxcIY0uSEI2GqTd 
#undef  mgmVzk7b137dAlUtwYjCH 
#undef mC0CN1h9WG8jcvJY7lL7X9zInNrs3rq
#undef  mTwlG8fYvHEVP0AbZCOz4 
#undef  mPyiMsXpgpSO0W2kittR4 
#undef  mWj491QEbFEOqk1pUeX7U 
#undef  mDJNDliiGbomCtStSq9d0 
#undef  mZ3EI9cUtVG8gmipQLAev 
#undef  muDAt1vEQwnAD9MueitI7 
#undef mt6veIkQ_uQIiSsvighsp32AF1A61VN
#undef  mBXOk84KHL38JOJW5NPgm 
#undef mdnUNP3Bbjv2zlMvnE73DgBHnuFh2aa
#undef  mISwCFQubmrOsIq3UDW3k 
#undef mSxtiuEk6fW2a9F51DeiYQH4FTLVpPQ
#undef  meG9i30YmxPze45CSboRl 
#undef mbK5451I4VHkaHHKKSB4jJVRrAwwiQ8
#undef mCOYgqInUU6L4vcumoGFH2Lkeu1JWaw
#undef  mqhzuASPlPGYcPO7FpZoo 
#undef  mg5ATmxAkpgZi8JvTAPO9 
#undef  mlK5VbLyr2fupTMoypucA 
#undef  mUV6VFei3d4GDx7zgA5XY 
#undef mqlCYoMYWfegD1Uh7mcBQFth1pO6jvV
#undef  miWYNNFzSJWInIcjdWZ6v 
#undef  mZy_6ZD1o15BnzGQH2kCf 
#undef  mUmk3RcRi2YW2amkc6kp9 
#undef mKTytwxP7iQM3EXDmsFD65wWTCHMH8k
#undef  mLQQlyjGudYzzStNZrj0t 
#undef  mhIyf_pOxV1Y5FBjhrl77 
#undef  mDmStV26L19FaXXSyT5Oh 
#undef  mbymioTPOW_RREK8lGQOD 
#undef  muybMPvHeKgD73zdSu3xN 
#undef  mrMXr3gunIr7Oip8wTFJq 
#undef mTUG2WbexLg34my5q6_LfrSw_w8U5kp
#undef  mx5h7uPJBR2AOw7ZAHG1r 
#undef  mQvwkIja_8VFEuADoUZiP 
#undef  myLwR2Pn69FxDOISrkoTs 
#undef  mIX5dGwYjY3rBSZ7xfGIR 
#undef  mghNCf1NlZurS0Rz4iJ8k 
#undef  mYw2h1KTHLh5pJbLG8tuk 
#undef moJ4AeSW9udau82lAkTbftBZRMZfEbF
#undef ml8qQpSBusZGXRqjA2x6ICByfvfFOFs
#undef  mXDf_DEW36ogrvlTJuERQ 
#undef  mnc_x05lJ00t0mRZS9SkL 
#undef  mNTbquWhgWNaph1znGNGs 
#undef meVFOVO7eG8JW3zEIPjRFJFdezQ1njn
#undef  mSxzFtKrCy9O8L1Jf0YBs 
#undef  mSbJ5yrmUd5RtknhexheK 
#undef  mg1yZ372BW3UfnRZFAR1I 
#undef  mnKude31uQd0XPbBpD2VA 
#undef  mkQmXm2gexRYy6AhY_Sah 
#undef  mt9r98fc7ej3gNxX0hwDh 
#undef  mgdRYNBX2Rz70jOUo1ycb 
#undef  mZoZpYtsPV6rqROXkK5Pn 
#undef  mwvJbaYamdHDZTXwS0xR0 
#undef mkHPWOomQg6T1hYZHUMJNecThkDsYhQ
#undef  mikAvZDzFamp7lW7CFUL5 
#undef  mPd3iiZNG9AOfVfPXxoxW 
#undef  mI6uLA4KmdsKaK8PdXVan 
#undef  mdIIF6y9eWzOIbmweXaL3 
#undef  mHNoxzxDa21M_o4mFV8nV 
#undef  mg5EdAC8WqtoPtczEiU0k 
#undef  mjohRuB9NAIOmwBRpbLgX 
#undef  mNTavJ_GSe98D7Vi2B0qC 
#undef  mKjz4tQdwPVWD2L2QN9F8 
#undef mwYWa3lx_liOlYGhQBcXu_osGyFinbX
#undef  mD4L3LJ1DXJjMCffonuuz 
#undef  mpsCFcTqCzxXDs_vsghb2 
#undef  mPxQxtE8gWCKSbrjbFrz2 
#undef  mCQ7Oga7C_6coKxgrTfQB 
#undef  mdPejhP90EDsHFt4xt5JD 
#undef  mcwGthVyIdx5U9J4dAIa5 
#undef  mRu1c_6jFamhxESyGcqXp 
#undef  mbqlWA7wgdq6yjV_cdHyW 
#undef mLNkCry1G54pjTRgwe0fQQuXXpGF4na
#undef  mh61kapTomgi_7fAjD5dX 
#undef  meXyCSEbX2iVpvD_oT006 
#undef  mdv7fjTZCBtEWbmQFAEI9 
#undef  mUUhL2rYtJRTJP0LV4X18 
#undef  mO9yZ4c7fyBu29TzFwNlM 
#undef  mRSuds8SPWGXQwJ2WTCt1 
#undef  mB9SBWkDKtwUxsehWgv4r 
#undef  mXKsvuK5M2PHu9WiAoiFV 
#undef  maMSfTfrTmQDXsbKDvS7R 
#undef  mGxaoyqpg2RAbnEthlJZZ 
#undef mJ2QsDa0EvT2iKfPjhQnanMUDmIIuDV
#undef  muuh9ZawWur4gd8xp0Pqs 
#undef  mSGw1EQMYj2r_5v96cHX2 
#undef  mM5o1Qfmg72NrB9FSiXR0 
#undef  mdDo9xzyfDTasGkpMDr62 
#undef  mG4Rmeyg2zst818MerO8Y 
#undef  mEncufcpSIy6X5ELb2nu0 
#undef  mt2sNdMEsOcGHkw_DTCON 
#undef  meZkhf54JqQFQgc_fTb_Y 
#undef  mf2HFNrscWwez8H6PDFDJ 
#undef  mORuM5_G4Mjng_61ZXqsH 
#undef  mpC2h_QvqVwpp6pHJ4zuh 
#undef  maeoB62dLpZ0sWWrNZ42o 
#undef  mB9EW4WnVoJ1PWRAI4iF5 
#undef  mr88WL6lgmMblsvQ8OSFO 
#undef  mz_ov6KzR3ui07VFuTdqK 
#undef  mT5YADBmldFpcgcRO_u2V 
#undef  mGyoRbaCWTCEv4zSxy4oS 
#undef mdXVDGEpVW5J89ggd9RShSJZFL7wRTE
#undef  mshoCyqTTEerUOXZ3Mawy 
#undef  mQuSF9bh9uREN6aQw6JGY 
#undef  miHnl36bVlSmbfKr0xpg8 
#undef  mN3u76GC1JxwzCzSiQZsn 
#undef  mBcGMbztbL43sTn0W7Hr9 
#undef  mUDXaNUrZ0YL8xkRRMBMD 
#undef  mCHEKvYUMSMcZtv0VUk9e 
#undef  mD70CicAdCL_E0O5JTpjp 
#undef  mwx9iQQh4SCnEWrhGTnio 
#undef mkOHCabZHCCKQesVGxJaulUR4mIZnaJ
#undef  mLp5YcrbvQMv2eoY0noot 
#undef  mY8JzOxrIK2ebl8Y5UFqh 
#undef  mHSZfulTXCSeYNC9PaIgC 
#undef  mdnriK5DNURVWdzagG7xr 
#undef  mhhV8psFUVpQEE0AmfchA 
#undef  mqndOBGwfphyJhuUwDet9 
#undef  mnLTftfx9fmFrPIWPgKJu 
#undef  msGtpqlEpK3FDmeP5oIvH 
#undef  mNNfTDf7dypfFPI9DNdos 
#undef  mT6KHAH8GZMo9uO6tj7q7 
#undef  mbgxDd3WsdHSY2NztpSqI 
#undef  mq_KADg3taQwJsxOyiV1O 
#undef  mlVtUEPXAMhmUNQEZDaxX 
#undef  mLwqn4oIRCTAVRT4CzbXZ 
#endif
