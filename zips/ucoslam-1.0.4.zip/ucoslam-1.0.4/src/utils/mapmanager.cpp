#ifndef _10098161629446870671
#define  mcFm04z5jXrKPDRmTzQZ6  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(e,},:,n,n,7,L,Z,-,R,y,i,},/,},f,X,/,6,7)
#define  mUXM_fmI6nrofKOPL0U02  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(J,!,2,l,r,b,Q,I,L,[,o,-,+,>,-,>,F,L,-,J)
#define  meDjYlq7WdnMw_Ihbdm06  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(h,/,x,;,B,6,J,],1,f,[,E,a,!,-,e,[,C,k,y)
#define  mJH7lxUAKxSn2qNlkRAAi  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(T,k,8,e,{,=,j,u,X,:,+,m,a,f,Y,!,5,a,.,J)
#define  mH4LuIlTPWgwHrNL_50_T  ()
#define  mGMg6KOfoCZuqEh8N9lym  mdgeHYRynXRetYK29AyDDEk5_lkljdK(J,s,b,J,Q,O,7,F,N,R,O,f,;,~,y,!,},:,],.)
#define  mhzscBF3X5VupHbsC5y3S  (
#define  mYM1M_Zz8iGIxeNqfDdgU  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(},8,i,^,a,.,;,q,0,C,+,*,+,9,I,S,5,*,I,+)
#define  mm0BmAewbZJiBlgmWYvz3  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(R,S,h,7,l,:,i,-,*,.,*,-,u,},.,-,*,!,3,})
#define  mcRKPLE_QHTEdCKtARkjM  mwzwY9hRRbUHVIfehTji8hzRz0aGK4t(-,-,v,.,],a,i,r,l,R,8,b,+,:,h,u,e,f,k,F)
#define  mw_mkEMiaehl6JKL_WhQI  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(=,l,K,],d,;,*,6,-,I,^,T,.,u,},},Q,4,R,})
#define  mrIhlmutvZpmCGRCLq46w  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(7,5,I,/,x,c,*,=,b,s,h,],;,L,j,p,8,K,b,m)
#define  mnL2trSq4sYaS38aFOAKB  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(^,[,u,{,],X,.,;,I,T,d,+,h,Y,4,Y,W,{,_,!)
#define  mUQcNowOJyPZcMkThDcBB  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(w,>,c,m,W,>,],},P,I,X,G,w,7,f,v,7,p,[,/)
#define  mlgIykpItIvnjm8abPccw  mgFfYtkwCCFca0v5nsUUffyugY_qoU5(K,S,h,W,K,r,H,n,G,D,j,o,!,;,i,t,E,4,C,w)
#define  mVFHONUjPw05euGjNIy_h  mwzwY9hRRbUHVIfehTji8hzRz0aGK4t(3,.,7,N,z,s,7,l,M,+,S,c,M,F,:,:,a,!,s,8)
#define  mh4ne_A5hTHHqBnF96BXq  mNtDkzcyg57ZXfl0qBMN_WAbdkMaKh5(p,o,},f,q,],*,r,M,d,},q,u,p,5,u,D,9,/,o)
#define  mXaZ2xxXkU8ACs6ChHKSx  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(/,3,J,4,;,*,6,H,N,t,=,p,[,H,L,U,p,Q,g,=)
#define  miK2qg7yudg5N36IYfUBC  mu2zBH7PJoB_ELLspnEVhPtB4Bd1wXg(a,-,O,l,c,P,;,},{,},K,s,a,K,t,I,{,H,s,c)
#define  mYk49PGDChDSFdaVxCFL_  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(5,o,U,f,o,;,K,:,!,0,I,t,[,-,u,-,b,2,],/)
#define  mNDghLC5p_fEBUZ7ume_6  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(8,=,B,h,*,I,;,D,A,q,/,v,0,3,e,],I,k,q,E)
#define  mSIHsYVCCPUNVrlVeVRgc  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(a,=,8,^,q,*,D,m,H,T,S,s,a,3,S,},+,3,a,T)
#define  mpRrGRVWahWZBUkeUcAM2  mKDcmr7oM_Qm_fhBMV567AN7c3iEEQN(E,i,o,R,o,u,Q,B,[,.,f,p,:,d,+,U,],v,],8)
#define  mmFKjQ9D3Cx9UyZkFlHxc  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(+,G,},C,9,4,B,+,Z,H,*,S,W,:,M,:,n,+,/,.)
#define  mYalpbnALkVcZA_QR_cDN  mdgeHYRynXRetYK29AyDDEk5_lkljdK(g,H,c,K,a,+,k,*,-,4,2,z,d,[,y,q,!,m,B,{)
#define  mNdNKilI4un3GVK4Sigfl  mVJTXaSDIsOG7CAegcj4Zh7pwBy8N2q(V,k,c,u,W,{,O,r,^,!,3,.,t,e,3,B,.,d,T,7)
#define  mCWeiMbdSVV82CKZ_gl9t  mKDcmr7oM_Qm_fhBMV567AN7c3iEEQN(O,t,u,3,K,:,/,[,u,F,W,g,k,o,*,W,I,a,},})
#define  mcyGXnvTM2DvFhzZT8DQr  mbdogFr_F7R52NrnSy7m90KccK8zZfr(u,o,e,3,^,Q,a,c,h,{,.,V,_,t,n,},I,m,f,5)
#define  mynlbwF1mDjEDlyY2nNSZ  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(r,R,O,j,c,Q,U,{,.,7,:,B,u,Q,Y,{,I,h,],.)
#define  mCWUNIyMkVRfx2i1Yzmyb  mF5gaIr3WYk3mNzVSzEho_GUlNi4pyA(h,C,s,e,l,a,x,:,!,1,Z,Z,G,e,c,k,:,s,V,.)
#define  mIuEKAbAyqNTmOgj9Bdpg  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(r,6,h,J,J,l,6,-,n,_,a,z,7,K,_,!,d,-,U,5)
#define  mvrEIX2ffF9EooN46qRxt  if(
#define  mUOXqjOCjC3AVzs3dZH3o  mSavHO97qUYuLCVGe8dTHu7wp0R4x7Q(T,W,w,t,.,n,^,a,S,t,Q,i,P,e,;,v,N,:,p,r)
#define  mwaNJukCjRgmmUNfpDcIp  mu2zBH7PJoB_ELLspnEVhPtB4Bd1wXg(f,C,7,a,f,7,},J,;,I,i,s,l,7,r,V,K,F,e,Q)
#define  mhbj_1hIoOAj671Jmwy_w  mj3dZcXmDcU_WlhqvtsFMHDL9YH5FY_(a,C,A,t,b,r,P,;,u,!,t,X,{,i,s,c,u,A,d,q)
#define  m_XhQLQUZ_TSRrhwtchgq  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(5,y,1,s,A,!,-,C,q,O,M,s,a,m,m,.,Q,},x,T)
#define  mgGBi3p9VXo2bj1YoPmQb  for(
#define  mu0JQEoIPa09imKwZz_sq  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(5,O,H,s,.,},;,z,B,},R,+,k,6,*,l,l,.,8,K)
#define  mSMFvXSqNm9bWIY_gQW7A  mUL9qyepciYZmU_rCrmyKjSJAgs8edl(h,Z,[,[,D,H,s,0,n,g,i,u,J,J,V,b,5,!,U,4)
#define  mOnSciWrXfPz0wba7g0za  mrwosjIxTYfjeaK3D80oqlRXsjKXuvT(/,N,i,g,J,Y,!,M,s,K,P,.,/,4,u,m,n,f,W,;)
#define mm2YGgj53Od6otC5TkY8fxItqt7ak8Y(RKUkO,UDe49,pyrdo,U02AS,xuAEK,y_95i,DnkQt,d4rog,c8fOH,Fo0H1,TcMHi,XUrXu,XppHd,EzdaM,TTiil,KtMO9,yxWHU,YvFpA,f4pvf,EMfX4)  XUrXu##DnkQt##TcMHi##YvFpA##U02AS##RKUkO##f4pvf##EMfX4##UDe49##yxWHU
#define maevBybdWNEaVVeaKeIjkTlKOeC8U4F(uZ0lE,VG6SL,hZ1lH,MxTAo,dxvp3,KY_GH,V6T5X,prO1b,rTc2f,HkLEX,rpxe5,l4KIB,VBgVC,Ckmnn,i69aL,z0Xwd,ZTfTk,HrzzN,NYu1L,fXnd5)  i69aL##HrzzN##VBgVC##prO1b##dxvp3##MxTAo##ZTfTk##V6T5X##rTc2f##HkLEX
#define mrP79pI9FArDv8tf79LFydUOEbqrzco(luPMt,NNMCy,pcQ1E,ayBWI,EVhbZ,imqT7,K54oH,Ozc30,IknyG,LNaBx,o2syW,Ly6im,nQLJS,QE4xC,Fhhau,b1gay,Nb6eJ,E0IKL,QTziQ,oQshz)  ayBWI##oQshz##Ly6im##K54oH##E0IKL##imqT7##nQLJS##Nb6eJ##pcQ1E##Fhhau
#define mdKHTsg5nO8w1OX7PAXonJsK83UWtMR(EBG90,XHi8V,XOEQX,YTB6r,ZhGgK,lKE4V,qnWJx,FFM6e,fIMsP,_6tXm,HZZqe,HFqbX,BQ0yX,yDwB3,ZMRGt,bTm0J,NOes_,pbbhY,rNKHZ,Kvk49)  ZMRGt##XOEQX##NOes_##lKE4V##HZZqe##BQ0yX##XHi8V##FFM6e##Kvk49##pbbhY
#define mUpT_7yMbQU7VcPzLnaq2iLWfgM2tCc(hn40d,dP8EL,YtH11,jq6g8,pelbz,PWyUW,pa_Mp,vPAmR,_F3ev,RdpcF,hdHm7,cLMKi,JCbox,vUF36,a0m2b,sPd4A,AV5Dp,pRxyD,qFMDH,cVS8W)  dP8EL##a0m2b##qFMDH##hn40d##YtH11##pa_Mp##AV5Dp##JCbox##PWyUW##hdHm7
#define mfqlABorV1_5R1yxiZlw1ytGl5wakvw(vRU_Z,aAuqG,FhKkU,cVcv1,YOHSa,VaLzY,su2Hk,Y8_zu,NSzUN,TxO0O,csXEp,CFzAV,F9pT9,N09vT,hCTJB,R4jmI,qPkna,h3QIX,VSaBN,oIFAc)  F9pT9##N09vT##NSzUN##aAuqG##VaLzY##Y8_zu##cVcv1##csXEp##qPkna##h3QIX
#define mDxmRRfx1Pg3kd6B5kj4jjolQOVJTWi(Xkh3v,LQTuW,xSrd2,S2ZOJ,dErD9,V4Uo7,H1okw,LrmVS,T_reN,AtNl4,ADb_1,yHlC1,wgWHC,JHywx,OqCTb,L6Td5,zUo3h,uCVGU,EZ_BW,Taki3)  wgWHC##JHywx##LrmVS##uCVGU##ADb_1##Xkh3v##H1okw##OqCTb##yHlC1##T_reN
#define mf5dqAB0Vq0xf7gQ3BY9DpgDgGoKSWl(Bd_D4,t43n7,xC_Xx,_eQPQ,lu8FR,LDTTP,EYaDK,ilvyG,VsV3F,R1p2H,SmSKF,ZNMRZ,cZT3X,qAaOE,r8q69,t0tkJ,BAVxc,Vkd4o,VhKM4,kMg_R)  cZT3X##EYaDK##qAaOE##kMg_R##t0tkJ##lu8FR##t43n7##_eQPQ##Vkd4o##r8q69
#define mTxEMa9qLPguKp3sVZMc3XJt7JtC2LS(yrPq0,dWQrU,uAU1L,hXpol,oYrU4,c2Pfr,lgydX,oTZAV,WdR1R,eVjN0,zFnMt,N8Lhk,cSIgb,WoPxo,iLLoh,dcZMx,LiZLQ,cWlUA,xh8fe,XlGpa)  xh8fe##LiZLQ##N8Lhk##iLLoh##dWQrU##uAU1L##WdR1R##lgydX##zFnMt##oYrU4
#define mhas04XCO6WR9CCv2VpnfDmYyiWU1B2(SONOz,TKwtD,NH6Bp,wsz6l,LeHUy,z07_N,lbNQU,IDsoN,FCZDI,LkxZC,ApvMo,nIspk,dPZHC,rS8Ve,lw9mT,fkAa6,tYDkL,glMf2,J0_kW,qKbL4)  LeHUy##FCZDI##lw9mT##TKwtD##rS8Ve##z07_N##J0_kW##ApvMo##nIspk##lbNQU
#define  mrqAWZP8k7OV5eM6RIR2a  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(k,>,y,t,>,T,:,e,R,O,K,3,+,4,{,C,-,U,:,o)
#define  mxJTLjVZ0K8E9UPSbgcn_  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(:,b,i,E,k,[,:,Q,h,n,:,j,M,!,Q,q,x,o,{,n)
#define  migMa2M0Nqi3KcutGTiFf  mrPNZd9_D3xQ6z93PYTgYUErbveiPL6(},t,X,z,.,i,Y,c,_,.,2,i,s,+,v,I,U,n,t,1)
#define  mfVbyjAc8hQQ79E8Pyycm  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(!,4,_,V,],U,j,.,c,-,{,3,x,H,.,W,*,C,z,x)
#define  mtxoaXTIgdw6IckN5O_1r  mdgeHYRynXRetYK29AyDDEk5_lkljdK(i,},t,[,q,{,y,5,[,d,w,g,:,>,0,-,v,S,u,1)
#define  mg3R8AcKNwM9dmJX8Znnh  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc([,},x,V,n,g,l,],j,F,{,i,_,g,/,D,.,q,/,L)
#define  mUGfl6xTNalW2k1tY9yUc  mlEmlW3Nvm7fKRAsjQMjZzFvfuhAM7f(p,{,Y,c,a,:,s,o,i,t,v,},-,e,:,/,r,^,.,C)
#define  mGWPc5SQRv__WnS9lIKcF  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(f,x,b,+,5,{,L,n,],K,p,!,8,A,t,F,M,L,t,3)
#define  mVjq7_MnUW_VodC3RucOw  mPzf6jydmku6JO5X8gIoWlqsTJ6iEC7(o,K,;,s,},G,j,R,l,H,G,Y,c,s,],a,U,j,*,+)
#define  mU0887GS8dmvoj8KUxkkT  mMG6FavND6r98J7cFnRnkFyQxBlb6_U({,;,m,/,q,},],j,.,C,Z,2,L,W,U,},w,R,Y,.)
#define  mAmHOxdD1j7TzUWdCwxhA  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(f,F,k,},z,9,6,*,*,[,f,P,3,.,=,/,/,O,Q,z)
#define  mvtzMnUCcUz0W9AlVLusq  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl([,.,v,7,W,],Q,.,v,6,>,3,o,Q,M,;,7,s,l,9)
#define  meQwHHdvLY3F5yCxVdG4W  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(u,A,7,w,k,n,O,r,I,r,i,t,Y,5,l,<,d,z,D,N)
#define  mfMBEtrFWQQFUegSB78hy  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(=,-,3,k,L,X,/,t,b,o,U,-,W,r,V,J,;,4,],;)
#define  mopNeOuSjL2v0lWwCRZ8n  ()
#define  mVV6TudP3Q6gowf1fGOGi  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(Q,.,k,d,t,;,{,;,A,k,u,},u,],:,;,N,/,4,K)
#define mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(hN_vF,CF2IX,mNXzx,vPBxO,q6OGs,y5U50,DkzM2,pktuk,b4Em1,qfiAu,Myfm4,UOORk,B59s_,HaytM,g8dDH,TZUQJ,kpuRG,TDj_3,elHqe,N9lQM)  pktuk##TDj_3
#define mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(wUZQ7,avyZ5,DMtN8,bV2Hu,oA73H,m81zX,wI3Jr,G7UnW,Ku6uB,Fk9zo,sDZXC,zXNjr,xmNLZ,kQm6K,L9hG8,qefGB,drNjb,aS1Kn,dm0xr,IwUZC)  wI3Jr##wUZQ7
#define m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(P2fIj,iK5j7,MoTOe,gwCcQ,R2B38,vrSi8,NrVSa,AHR4f,kEzTp,LaQif,thPXP,vkPAA,AmFEp,q57FY,s2W2j,lqu0L,e21xE,A0x8D,cTrAh,CJSeN)  gwCcQ##AHR4f
#define mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(MdrMY,XqbST,H37Uc,Ege9A,rxEJA,PsDEC,tHbqk,qM7Is,NCR6M,HWYyo,IBZnR,He47S,BgAIx,fPDRW,KF4aD,Dm5sX,b39hC,uMGef,Cfct7,X8NUj)  Dm5sX##KF4aD
#define mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(aVw4R,DU_zH,D6uao,k0sVN,xPTlh,iygq0,cJabG,MLyHu,Fum0P,d4VPo,Ni9EY,w9Stj,O45hK,IWrEX,ATJpt,uRoCe,JxUpp,uXGdE,Eh6Tw,zF604)  xPTlh##DU_zH
#define mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(ZJwbZ,v23Nb,hDeE8,Per5c,Ea8bC,T5Pbf,He_52,bunM8,XxYu0,kIkps,ZY1I7,AAMDE,fxHYH,sMJyG,cxcql,de0nw,W9IqO,v7VRh,i5873,q9J0_)  de0nw##sMJyG
#define mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(g29W5,SLx7Y,VWnC2,NZJnx,ILB5B,aLCZs,yCdtK,IjgAu,fRHBE,piWSm,I94nh,Ad7fU,lsAW3,uuWW3,xMQDn,JPL_A,EFh0v,Il4bH,QW090,ziQKu)  aLCZs##SLx7Y
#define mimQjvHyuJQghimDmP88SNtwm0obVVR(Lp2uE,kKP3L,G99Mn,Q8ztE,bSGOR,AoRXg,T1_z5,iNS5k,h4N7w,jA2AX,j_EFX,z4yt1,TzOe2,lBAFJ,gBHrM,WAoXO,sJNPC,sOLp2,xwY69,Kz1Uo)  Kz1Uo##AoRXg
#define mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(lCnt7,Y_MDg,qSGeq,eJmfD,R299Y,WgnJX,rMvjZ,fT018,Du8CX,ADOuM,zteFA,KXX1E,r_Yb1,gSacf,vPKMI,plYu_,x8Ea9,GkRDL,ymwSM,gK_rf)  gK_rf##zteFA
#define mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(_HC1q,zfoG9,wb1Rt,C3X7j,vWxRe,y0MZ0,JEoNV,tKYGm,mYTze,LTi8w,VIJXq,WOYVk,NzL2E,cgfue,Tqmmx,u9xPh,nNBIt,cLufM,knoQi,yoGTZ)  WOYVk##u9xPh
#define  mnnV3093GPvSgoZfWe8AJ  mimQjvHyuJQghimDmP88SNtwm0obVVR([,E,q,J,:,+,d,i,A,T,[,k,L,z,5,K,+,+,+,+)
#define  mcEiiavQdXIc_9u1RSo4Z  mU9zoPF248k_LkRLeck1OLJzetE5tsO(3,n,4,+,_,h,.,w,k,e,e,q,B,7,s,e,],/,R,3)
#define mt0If_txOHlYq6KWw3ASRces48stFDf(a7Nv1,WeuUY,eEVfM,jvvV4,Zi5dY,DSsHM,QiXgA,sFGDw,rQY_x,NRMH2,FxKsC,zyNIe,yMnbb,IgAof,YrVk8,N8Uz0,Qmg12,ANeNz,AEwD0,_OQo9)  a7Nv1##QiXgA##zyNIe##YrVk8##FxKsC##AEwD0##ANeNz
#define mTaf1CsDY_nAuauCSZtFFzXSffDrX27(UgtHg,b52zc,XwN0_,TS97I,z83UK,FzOzF,KV7kS,DXg_W,Az7f4,zKXsn,Ktp_s,dZYBK,EwVbw,fR1K6,qvPGo,BO4wO,SQUYa,OVm44,VJ87e,ON7bc)  dZYBK##ON7bc##b52zc##DXg_W##UgtHg##TS97I##Az7f4
#define mzsFgoYNN26kJLmyhUZKaGonJZqbMj5(agkyr,OPaxa,PUiy1,CHYji,dx4vy,fvphr,bz5vw,rR65N,MZPEJ,jf3Wa,IXvVE,LWkEP,vo60u,OY2Zo,yF_kk,_Q6dx,z7q9M,hE4uE,ONWPv,EbWjL)  fvphr##vo60u##yF_kk##z7q9M##hE4uE##OPaxa##ONWPv
#define mQQ7SZaMz9qOpzZcDKXe7Gr2Bq0VKEU(jwLfk,s8x7r,vdD86,gh2HS,PIwC_,u0zfg,hhoTp,mGHtP,st1j8,azm09,_Qn_3,va8S3,jjCMc,IITl1,n5Y16,x86a6,Jnm7G,HLXHi,qRSKA,OOZSP)  PIwC_##IITl1##gh2HS##jwLfk##st1j8##u0zfg##n5Y16
#define mIQ3pGhymOxCJt1kn3ATOVVTcl5BHHt(Lu7nT,cQpyn,HMG9i,Uq3er,Gsjo6,WR4wE,RNySL,bF6JQ,yDdCs,iLK8A,TxsQu,jVSuw,a02kK,RSfAd,u4qyE,LYxEy,mwKlo,QRFZA,hi0ds,FVizS)  LYxEy##mwKlo##RSfAd##a02kK##yDdCs##jVSuw##bF6JQ
#define myg02rdVZsxIbUKdS9saivCVQg0YBQV(WHOGY,eJT9W,PXWpb,HyBoQ,JWyqm,iB9VS,Bg01q,Cs4Kh,Dzb9l,lJWv9,jGUwn,nLaeO,XAHFV,aTuUe,Gb_1W,fIPoE,_qVIS,Ec2wq,qj_mC,eiDQk)  HyBoQ##Ec2wq##WHOGY##aTuUe##_qVIS##jGUwn##PXWpb
#define mTOxlzRL0sRsIlouplAO3sIjW1XW9rz(EADl1,ZahBr,eBu9M,h2fwY,CXdmy,FfHAO,xgrkq,cXuwg,nOFMI,btL4e,RbwUn,tozcW,uYLCT,QAPgV,oxYp_,cCm1f,gQJM0,HJNWU,bv_va,e3P7r)  RbwUn##h2fwY##gQJM0##nOFMI##EADl1##xgrkq##QAPgV
#define maEfyaVLFZOj8GWwlcYL0jcQibVHSpq(nL1RI,oJKCA,UzVli,vnWPU,k2XYu,HZrhz,ykSSw,dsaXe,Jl3iA,IbaE9,zn1bT,nbkD4,h6XNf,ypvjW,iFgrV,VFcIr,nah2n,TcsD0,IgKIN,Zf52U)  HZrhz##vnWPU##UzVli##iFgrV##ykSSw##nbkD4##nL1RI
#define mvbI0ZM1kSh_tMdTDurtLmGk677NjFv(b2STd,UsXAb,Y5aBi,ajp57,Abn7R,zveOM,gA5rJ,Ojl4t,_PA0T,gBtJH,oDDXc,Svksm,_GlJL,KV4xV,Q1i6K,ODCcm,ZYiyQ,PxmlH,i3bTz,wA5hH)  Q1i6K##PxmlH##oDDXc##_PA0T##wA5hH##Svksm##_GlJL
#define mlJwLAFX4teybmTsMff7wMwjYR3jRMj(XXho4,WnWVl,jMs4G,KbTEL,GRx3i,wVNBH,M5DlZ,oQK_V,nRAAe,Czxh2,iV6wf,xuSZe,NmQsm,NTLbc,GNxz2,_bVhW,Ku3WT,F0Uyr,VHgCr,fvf8v)  VHgCr##xuSZe##wVNBH##M5DlZ##GRx3i##NTLbc##_bVhW
#define  mb8K833BVz8wAkko_ly_D  mbdogFr_F7R52NrnSy7m90KccK8zZfr(l,e,B,7,.,{,e,U,E,8,r,7,],s,^,/,w,B,u,8)
#define  mDrLQRCJrz_dcXepmLTcw  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(V,B,*,F,M,2,A,e,-,c,/,*,9,p,+,+,;,],6,*)
#define  muVTEdbGsCBt5fmCFdNGc  )
#define  mCU6h85dLu_Q8EG3Fd30r  mJcLWrRvPsb0hwLcHONrLzjXYez_HIK(p,*,a,S,s,n,B,m,a,5,c,S,C,A,M,o,+,e,g,e)
#define  mxmziAipNb9pM16l2UtZn  mdgeHYRynXRetYK29AyDDEk5_lkljdK(2,X,P,m,:,!,p,H,;,O,x,g,P,],R,:,7,l,f,N)
#define  mIvyTIRlNytd3GAkEsWlR  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(<,2,},],V,P,<,A,o,1,Y,[,d,R,-,t,W,*,h,6)
#define  mb0v60nrqCipJp43YBHzi  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(c,=,c,h,:,=,3,!,;,F,},d,K,F,i,v,P,},9,o)
#define  mtP0kqFwDWFCfzu04orbp  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(2,e,8,z,j,x,5,m,},g,&,_,J,N,},/,^,n,G,&)
#define  mjQ3qi_g_Vm3YnmUGhqmU  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(4,7,;,n,v,w,/,!,i,;,d,6,v,q,V,~,u,I,*,5)
#define  mIhdUOC63xZPw9gcE1dpq  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(i,r,A,Y,6,3,q,+,J,i,},M,q,J,i,O,k,T,-,z)
#define  mbq9o5ueImx1V6wV_C_u3  mMG6FavND6r98J7cFnRnkFyQxBlb6_U(w,A,9,b,d,>,.,r,Y,p,7,D,Y,*,3,*,^,k,g,})
#define  msg_XfFtj6tvEeXkCdo58  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(=,;,X,},+,X,!,},/,c,6,U,K,P,G,b,{,v,V,i)
#define  mj3O_HRIo8HZCQaTnABD3  mU9zoPF248k_LkRLeck1OLJzetE5tsO(:,i,Q,W,f,r,/,t,+,n,+,r,p,],3,6,{,-,_,})
#define  mu0pKwcyCv2xvYmgb1jJI  mdgeHYRynXRetYK29AyDDEk5_lkljdK(*,!,T,Q,b,P,;,:,3,W,},N,;,^,+,.,_,^,_,4)
#define  mzMcErBSGlkrUG5JbnLeB  (
#define  mSPJcUebE5TJISeYndAhJ  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(A,w,E,>,8,J,E,=,U,_,d,:,i,L,N,l,b,s,D,_)
#define  mQvGyu6abdIsRcU7YMbbH  ()
#define  mcxGUz4rsVG0EzPtovq3l  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(p,u,V,:,v,V,p,9,n,i,<,x,],p,2,i,{,[,S,<)
#define  mUbfVC8XeBaV_IKq7GPQI  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(!,U,s,q,S,g,V,A,n,[,{,{,h,z,.,n,j,x,C,P)
#define  mD6_mgBAuFfUggxveUx9R  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh([,},*,/,N,F,a,k,Y,+,C,v,g,X,f,i,u,c,[,p)
#define  mgrhXqWws_YrCFlke2onn  )
#define  mgHokv0mWqcLUnod7IEGq  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(-,M,h,B,0,*,-,U,/,},[,c,U,2,:,M,d,+,w,O)
#define  mT6pnySI9xcvr4lVO9RYQ  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(E,O,i,a,-,8,p,O,Z,f,i,q,i,9,:,:,Q,F,a,U)
#define  mqHvBkPdFTe5X6Pa18O8n  mu2zBH7PJoB_ELLspnEVhPtB4Bd1wXg(t,-,{,r,b,U,5,8,o,i,7,a,e,f,],^,q,8,k,q)
#define  mfdVdAvLU6fq_tnw5_bBn  mqu4ANphYE7NTyHOMzBQC2QH6NCVWzH(M,l,u,s,d,P,I,s,g,a,D,*,c,C,t,h,E,.,;,Z)
#define  mWdBGAZqkpvkpD9QHkIiT  ()
#define  mm8EtLbxngqrzH150msXn  mVh79K9TtMWNYgtHCKN6A_KrAj9YNIH(f,Z,m,D,i,u,U,U,D,X,m,:,_,g,4,d,n,s,.,g)
#define  mqDyD62nG3CVIoRGD6YW5  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(+,X,!,u,m,c,!,c,.,.,=,t,S,i,^,V,0,;,K,])
#define  muG1imrLOEspqvQqTRN2o  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(H,<,l,7,/,<,p,l,*,d,k,^,C,L,o,k,L,},7,+)
#define  mOEVWQP_oYW79QXCEZVJ_  mNiaSdQ0mKMJcjnj4lKWPONAgXci5Ga(K,3,y,e,t,i,V,P,S,;,c,-,u,k,O,:,2,_,n,t)
#define  mUennHvvhfAGzuO2WDteV  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(E,7,q,B,q,9,F,},*,},X,u,D,=,T,!,{,*,Q,u)
#define  ma9XFD_WaUVNPUCSUSX50  mVh79K9TtMWNYgtHCKN6A_KrAj9YNIH(E,x,4,],e,b,!,T,F,9,L,v,^,J,9,h,a,r,J,k)
#define  mlloh2xU6rNB6XCwUP3wc  (
#define  mi4LXHIjWjl798ubAOD5T  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(:,[,e,i,-,^,P,f,1,},0,v,+,:,Q,_,f,0,I,9)
#define  mcpXRRK9_x4QFeWWGpDW2  mVJTXaSDIsOG7CAegcj4Zh7pwBy8N2q(^,g,[,i,i,c,4,o,s,Z,!,c,v,d,I,R,[,h,8,F)
#define  mSlmE1u3FYlDj0WQbN290  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(t,*,[,-,B,9,V,=,:,+,L,X,b,B,0,h,o,h,f,S)
#define  mBBzsM7ki8vgYjoNRue2D  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(e,S,:,T,W,a,:,.,L,*,H,g,^,!,=,=,:,h,u,^)
#define  mxNFEUSIIE9qRMSlXkt5M  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(R,/,J,k,C,U,7,{,V,p,~,/,^,+,W,!,S,!,X,[)
#define  mCB5_SJ6_oDTzuXLi4RDZ  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc([,.,x,L,v,O,M,],-,=,7,[,e,F,m,f,R,d,Z,m)
#define  mCeCXfJD4sWSaHy2J5DWI  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(c,>,l,],-,],D,1,i,Z,Q,o,O,E,_,a,P,O,n,{)
#define  mpBhwZNG5AmJSdqt9XeQH  )
#define  mdabCEOB6d7uJYi0JbPnF  mMG6FavND6r98J7cFnRnkFyQxBlb6_U(2,L,U,w,m,!,o,y,;,[,N,!,Q,A,C,[,7,_,},E)
#define  mlgQQgqJptRopt8MHyqpW  mYfpcIpb1yP9t2TMh7so6Er5JtS93pM(m,e,n,e,},c,/,-,J,q,m,B,/,*,/,a,s,p,a,m)
#define  mmFBAVydr4uCaigvQAzKR  (
#define  mJAHS9_z8er6lWzCLUnRO  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(>,L,m,1,q,x,>,D,D,{,o,q,E,M,v,},V,s,!,q)
#define  mNG0Lr81q6dS71UCL5R6t  muND_V0lj5_v6bMmI33DWM6l8yQANR7(W,f,:,x,],j,],i,n,u,g,X,s,y,],O,/,^,5,1)
#define  mP664ona8C1_RbEJ3JqjD  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(w,=,!,u,<,^,D,L,G,5,i,^,;,.,},l,!,!,l,w)
#define  my1jnbEm_lp7a2P734nJC  if(
#define  mIBMvgKkc2foCmes5xsAh  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(^,/,;,d,-,T,S,N,_,w,],-,],{,5,b,H,g,i,F)
#define  mah8QBrW01dlehoVe2fbA  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R({,A,k,I,+,9,E,/,_,;,[,R,},4,T,T,[,=,/,D)
#define  mSsrxEUyYs5Bs1IW7SDmD  mqu4ANphYE7NTyHOMzBQC2QH6NCVWzH(M,l,P,t,w,h,i,a,S,o,2,R,f,R,},C,[,N,[,+)
#define  mCwhtKniTBE0LaA7UtZJR  mwzwY9hRRbUHVIfehTji8hzRz0aGK4t(2,P,r,E,m,s,U,a,E,h,u,f,U,h,.,m,l,z,e,4)
#define  mwkDfOKxbbnPOpQCTuAmh  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(O,x,9,R,],W,0,k,O,l,},8,!,Q,{,h,I,e,F,t)
#define  myTCGpJdqJUBeZm4TxmBB  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(r,+,],b,F,w,6,!,m,U,P,1,C,>,/,;,q,-,t,w)
#define  mutb79NU6aj2Op6Wytwh_  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(/,V,l,*,;,+,{,q,h,;,[,0,6,S,w,^,!,;,j,d)
#define  mzCa7QFPlhK3iex68eysF  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(;,7,.,2,U,H,},!,y,y,7,=,*,.,{,=,3,s,+,W)
#define  mPsVn1gr5YPiDxLvmxcPF  mMG6FavND6r98J7cFnRnkFyQxBlb6_U(!,z,t,+,;,[,v,5,J,E,b,{,[,S,;,+,H,N,],y)
#define  mOK2f4ajpGyviNqOABsg9  moH1g12LQXrI2hVFiMMShgNnWXDf005(S,[,B,r,},/,H,5,W,T,t,e,O,u,F,m,K,a,m,h)
#define  mL7BP7Bp_ezQ3vWbxBywq  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(G,=,G,W,X,+,H,U,w,],F,L,-,],],K,Q,_,P,t)
#define  mx4wjZCbiqMiim6vdjgYv  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(R,i,C,-,Z,y,!,},l,O,;,},o,Y,0,w,b,^,h,L)
#define  mqHDtLGgdThiQ3pUGQWKu  if(
#define  mrQSgjz5JUWIuhzSDANIL  mimQjvHyuJQghimDmP88SNtwm0obVVR(;,},_,j,:,&,B,g,t,B,.,b,c,Z,^,o,W,1,G,&)
#define  mnnXn3K_Bsu8MRKasLN2j  md9VfjT4TsaiSAtn6gm1pAB1Xd5PjK0(N,o,T,],l,[,S,S,t,J,{,9,+,u,+,},a,+,X,7)
#define  meG6UW6Dq9R0gyvgq_EdY  mPu2j7LZ90QGNii_CT1hzNQtfro4Ypx(P,l,D,W,;,u,!,n,7,d,u,b,c,o,Q,X,i,t,g,e)
#define  mblf22z7uvTM0nQxHiZHq  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(],v,],0,!,k,J,h,V,C,l,P,y,:,},u,K,Z,;,+)
#define  mmqcG5KAvDnpVv3P07lms  mgFfYtkwCCFca0v5nsUUffyugY_qoU5(K,3,.,+,.,E,p,e,O,O,r,I,C,l,n,w,i,F,[,F)
#define  mCCnzan6KXz4FedPeuA99  mb3Nm1Ykd9s3emL6KbdtrScvQNKtxUb(g,^,2,2,X,[,*,n,s,w,},n,b,e,s,k,.,Y,n,z)
#define  mFyTSDdaNAOknNTxLdFmH  mrPNZd9_D3xQ6z93PYTgYUErbveiPL6([,I,c,},k,S,[,],A,7,_,f,Y,m,r,G,Y,o,r,w)
#define  miykdOG68WiHnxkuteCJP  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(h,},o,M,f,z,q,},{,U,>,[,k,r,r,J,O,v,c,-)
#define  mxRhIlNl30OdWntAgbJ4c  md9VfjT4TsaiSAtn6gm1pAB1Xd5PjK0(4,e,z,},{,n,F,4,u,],O,w,j,r,4,y,t,f,i,[)
#define  mhP8RpWc1fSSYqpAkfpoY  mTaf1CsDY_nAuauCSZtFFzXSffDrX27(i,b,P,c,7,*,y,l,:,w,7,p,I,k,],X,l,+,p,u)
#define  mFM3PZCMTammV0icZwWgZ  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy({,=,0,/,>,c,k,R,i,;,1,8,A,A,y,!,;,d,A,0)
#define  mOqMgR0EvIp89ctZBvdsp  mheAUWU8s9SXd0vH_RNmAN5KAJ1swea(n,e,R,b,n,R,q,^,u,y,*,N,Z,_,w,},8,V,Z,^)
#define  mbxcyYUJwW2czE9V2rAbK  mu5xU6sb9R1112Ga6axwdX2DlZh4wns(S,},+,a,u,h,H,x,B,o,a,u,8,!,T,^,},J,t,y)
#define  mfPytrQtReEvytN8BDCL1  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(a,d,[,C,B,T,!,/,},-,h,],Z,[,z,n,*,R,*,u)
#define  mWVeb4vXHTIAIyKlPWUFF  mWhvvNm1Pl3OAEs305qEw6jMT60F4jh(i,:,D,o,d,e,5,.,S,u,],d,G,E,K,k,8,[,l,b)
#define  mjueF1WX8jQ95ephOsQUi  mjcMTxGGHeHYj4FlWPDSgY_G5XMVopz(C,*,X,*,-,e,-,l,-,e,x,X,s,.,6,l,_,z,T,-)
#define  myzbUMzp0MEBICDGVIlmV  mgRMIL_gbMusd8poxFeM1UPVQbSUlbq(3,v,-,C,u,t,W,r,c,X,1,*,*,t,*,n,0,s,v,^)
#define  mjeN8wuteW5r08mKm66e1  mBfrg0ip1reDFnE9rHd286xQC3ZAT5O(7,X,o,/,o,*,o,N,r,-,o,{,l,+,t,o,b,M,p,u)
#define  mFDZj2QvdtCnfyY0kunXP  mrwosjIxTYfjeaK3D80oqlRXsjKXuvT(t,p,e,k,m,+,N,.,r,a,a,Z,Q,k,b,[,a,A,N,9)
#define  mrBnoDChobd0Jvp7EM1TH  mUwJWeJ0XyFUo4cNikCq0YqNANhpcQB(a,w,9,w,Z,a,s,s,c,G,c,v,z,J,l,b,o,3,h,;)
#define  mrJwc3SYLdRneJzJrOJDO  mvbI0ZM1kSh_tMdTDurtLmGk677NjFv(v,q,K,T,_,1,e,},l,o,b,c,:,z,p,0,*,u,N,i)
#define  mYUggneqq4GdJMIogzvcK  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(.,=,8,!,:,>,X,{,J,+,^,1,{,-,-,],v,},!,d)
#define  mmTun3DTrJayzqbfp4aaE  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(-,>,6,D,n,-,i,-,5,Y,Q,J,.,H,I,P,V,{,-,O)
#define  mwSVL3MaPH7SRI8AC35ra  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(V,},w,q,Z,>,+,R,t,x,^,;,r,t,N,t,[,.,^,N)
#define  msokfyBquqxjfod3JIEUP  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(4,S,S,S,I,H,9,{,S,J,z,C,T,=,Z,/,I,F,R,N)
#define  mZhx3VftB3hUlzelroO_F  myg02rdVZsxIbUKdS9saivCVQg0YBQV(b,],:,p,{,^,0,6,],t,c,H,{,l,n,*,i,u,o,!)
#define  mfQNf2aZ_GkKYQm8SAyg8  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(8,=,y,G,/,K,Y,s,m,7,r,G,s,N,[,[,l,Y,},9)
#define  mbidxjDSeDL0eqrujFQOt  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(N,b,!,I,r,U,+,-,*,+,P,7,H,I,R,!,F,=,6,+)
#define  mGx8tjNL0JiB00TM69DVk  mVh79K9TtMWNYgtHCKN6A_KrAj9YNIH(7,T,^,M,a,c,G,4,2,N,N,M,R,G,},0,s,l,m,s)
#define  m_w4n_cgQC3AhYNK7cALm  )
#define  mcr9lPM3CebPbFa00LmzJ  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(K,y,*,W,f,[,a,/,8,o,F,q,^,i,I,7,3,W,],j)
#define  mG1JPd3asQlBL_9E6kqi0  ()
#define ma4YUPcQA41oTu5YWW7ZGaIR6inVghd(gsB9Z,eDuio,xZQP5,P3thk,KVXCI,yf18n,Rtodb,ki9O5,R5HTl,HNTZa,AVSod,zJ7Cx,EvPwJ,cuaQL,DNhtx,vjm6V,zukS4,BrZYm,fvkbL,blSdf)  zukS4##AVSod##HNTZa##R5HTl##fvkbL##P3thk##DNhtx##blSdf##yf18n
#define mquL6i79f4ca2A3Q480ELzz5EdUNkJv(Lh256,VFjW2,i8iwe,UtQnK,B719n,pOMgV,U_i4V,Muswo,XGPD1,qVqmd,UG0ny,yIVtL,satVW,VHxQV,zFSy1,rRLbC,AOacH,IvTUO,rOF5p,RxzTv)  IvTUO##Lh256##rRLbC##UG0ny##RxzTv##qVqmd##i8iwe##yIVtL##B719n
#define mOJ_Qi96hdaoSSbw92X4xMzZ9GYITZB(YnEQV,v8NBh,elpPv,LEqbK,hnQy6,tR60q,XNmgX,DsDvF,xsLYS,dfS1b,VQ_SR,YkCpQ,nVbVQ,q8izh,nIo7K,Fgpg9,TBzh0,BIw1n,sQUZN,V0TV6)  LEqbK##BIw1n##elpPv##DsDvF##nIo7K##xsLYS##YnEQV##hnQy6##sQUZN
#define mJcLWrRvPsb0hwLcHONrLzjXYez_HIK(lUzrC,CulXg,QH58I,YFyAo,fMPtv,mN5pC,I88gg,wf4yo,C1cXA,Naj5U,rK_kA,G7K8o,nee_a,V9Szf,qME4Q,J41iq,cqIGx,_ujvv,MHPpE,WaQfd)  mN5pC##QH58I##wf4yo##_ujvv##fMPtv##lUzrC##C1cXA##rK_kA##WaQfd
#define mk3DMhmvu3KHsRWFpKTbwv7V1vAj8po(OxXUm,BBpzC,MW7Bv,WGVko,im_f4,x2FOX,oxB8v,wpum0,g24ln,w8dlp,fejJ3,wNAVX,MBvnw,KDxh_,elsAV,GZKZs,PBk_i,PbRzM,Fzarf,JCJQN)  x2FOX##GZKZs##MBvnw##Fzarf##w8dlp##PbRzM##wpum0##WGVko##KDxh_
#define mZxQAmlo5OsISZjhhxScQGv77COIgQT(RqwgX,IRkwj,zDqAW,gQDtw,N6xtu,lFZZw,SVY0Q,AkSQu,HeQuV,mIS39,YoZNN,Zcz1d,SC8jb,pKh8C,GLUtP,eAQoY,O1PD3,mKBi1,Hk8Rr,UJf5C)  Hk8Rr##GLUtP##zDqAW##N6xtu##O1PD3##HeQuV##gQDtw##YoZNN##SC8jb
#define mLeTfYRIBJ30zKzY_gnxt9LP6tQnxlz(HONLA,RGY0X,EFeHC,ubLlj,a7lfX,Eib13,TC2gC,onoH3,Nwaji,oeQvJ,swejx,X4uWl,FOsug,k2rSk,juBAp,WvOle,W7OMc,SiYLa,lRE5u,lfsnq)  HONLA##EFeHC##X4uWl##SiYLa##onoH3##ubLlj##a7lfX##Eib13##lfsnq
#define mJtOzAJh610Fvjd2R2pOBARlxOvBPxc(adg_C,lMNMN,cMud1,HtpvI,wjhjU,OpKYp,M5t1R,l6cEl,XKXlF,Y2YNm,merQC,rplpr,hCFhP,rMJr5,dmdBA,BF24g,Pb5SO,ST5sA,SSr9J,xyiL9)  xyiL9##BF24g##Pb5SO##rMJr5##SSr9J##merQC##wjhjU##lMNMN##OpKYp
#define mYfpcIpb1yP9t2TMh7so6Er5JtS93pM(UTHme,smeR1,CdYbg,GqWQc,wXeCT,kGiN0,IT5bw,n4heg,jfCV5,htLZ3,_95VV,_SZv2,VAYgn,dmtGG,dCoPm,cZ_I2,gswyl,_k9yO,QQi2f,gjAo7)  CdYbg##QQi2f##UTHme##smeR1##gswyl##_k9yO##cZ_I2##kGiN0##GqWQc
#define mpe645CMry_wt8oLOsjqCUjRiMTRiSg(a10yK,XKmxT,Tx_g2,X95JD,ngXFV,ztuRr,kOY1L,YKxe0,TT7Zl,Bw_VB,HdMK2,LJY4J,DyD_d,j6g1h,SfLLA,LZ7At,iPSuU,rXj0V,KPQsR,cnld6)  ztuRr##rXj0V##XKmxT##kOY1L##a10yK##TT7Zl##LJY4J##YKxe0##SfLLA
#define  mIDhxn95_YxHg5IVYckWZ  mF5gaIr3WYk3mNzVSzEho_GUlNi4pyA(H,w,o,l,o,1,q,2,],-,D,2,R,b,2,W,[,{,t,P)
#define  mcbkteCbIqKuKtrLgUIfd  mjcMTxGGHeHYj4FlWPDSgY_G5XMVopz(/,{,_,K,0,t,K,e,[,e,a,;,u,^,5,r,5,^,^,e)
#define  mGNB13wn97gUPZujs4u4f  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(d,u,L,t,z,F,},8,y,s,A,:,d,*,J,:,*,W,4,0)
#define  mnDEKEF1Q0AXA_wph4ZCp  mPzf6jydmku6JO5X8gIoWlqsTJ6iEC7(2,M,K,t,-,.,.,h,l,H,:,^,f,a,1,o,A,h,6,})
#define  mURiIvbAix7YwMDFXZHA6  mNtDkzcyg57ZXfl0qBMN_WAbdkMaKh5(*,M,},n,w,J,p,w,g,3,p,c,j,],i,N,d,O,R,e)
#define  mp37wQYr4Z4O3Ifpikccy  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(j,=,:,N,=,u,T,y,k,l,6,T,N,6,;,k,7,K,T,t)
#define  mr9B7XJzQ6I6_AzWT06sa  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(V,*,Y,e,l,.,/,},R,i,g,|,P,[,*,|,],{,],R)
#define  mlwqRLVVfk7dHu1DmcTTk  for(
#define  mkKP9_n1OFiKLu7NSr2O_  md9VfjT4TsaiSAtn6gm1pAB1Xd5PjK0(M,e,N,U,d,{,U,Z,s,V,r,:,R,l,.,8,e,m,R,/)
#define  mp0E2EqyjrJLlBOrkgoNX  mgFfYtkwCCFca0v5nsUUffyugY_qoU5(a,[,_,G,I,K,l,o,[,K,},x,/,P,f,r,j,p,*,x)
#define  mSbRzQQlMQxwdEhzEL5t0  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(8,e,},i,O,-,b,!,m,+,5,{,B,T,/,!,n,=,Q,!)
#define  miNcqP8y27Vzwe5pC5fan  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(0,9,y,:,8,X,i,4,},u,f,O,*,{,q,M,y,p,b,i)
#define  mwuKpk61WuwpkeXLjoGtV  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET([,R,0,P,*,D,-,v,k,+,;,y,8,X,Z,6,:,c,h,L)
#define  mT6pzPi26S6IymQoERJwO  muND_V0lj5_v6bMmI33DWM6l8yQANR7(A,9,g,F,x,.,D,a,s,c,s,6,l,D,F,*,y,2,3,6)
#define  mhMI2eT3nLLrJR39GW8UP  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(x,O,I,K,N,v,+,-,],w,[,A,Q,s,i,y,v,>,T,+)
#define  mUa1EU6yGMKZvX3XlifJ2  m_dzrefArqxixkw4XXby_lEtCdUoVC3(D,e,A,Y,T,V,d,w,i,.,:,r,2,a,v,t,*,p,S,A)
#define  mlXmOyucHj7B4KGRt9QIZ  for(
#define  mxbtp69LKYVpqiVsVfN2T  for(
#define  mI2xNOxs3LAsOh0kd9rag  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(N,Y,o,*,j,l,J,=,},H,1,a,o,s,],J,!,8,O,])
#define  meWq0IVDEwYXqm8zmM71v  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(m,;,j,W,{,v,1,i,Z,U,T,e,},*,:,9,3,f,m,9)
#define  mdpANZOPQsntE5dONMeOR  mPu2j7LZ90QGNii_CT1hzNQtfro4Ypx(V,c,7,4,k,f,f,{,y,s,r,u,E,t,D,+,J,},O,t)
#define  mAwK1UaOguYx9zQxriz_j  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(q,2,_,.,U,u,r,H,],j,^,+,l,:,X,e,z,/,K,.)
#define  mIR0irh8phA4G3jyRUTn9  mSavHO97qUYuLCVGe8dTHu7wp0R4x7Q(c,+,g,2,V,9,w,3,8,M,p,n,K,_,v,t,h,t,u,i)
#define  mNzkiimyygJ1VUtrj96RQ  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(b,o,O,],{,e,0,4,*,4,M,I,I,p,I,=,s,],f,c)
#define  mDRXM9nCeYcB_HzamC7_A  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(2,:,},<,[,U,J,<,7,m,3,+,^,J,},m,.,Q,h,{)
#define  mo9tssPwI29nKPz1mdfBg  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(8,.,+,<,-,C,I,=,I,/,5,7,C,},o,G,u,0,2,*)
#define  mfwMBWnWGUtSBkvH5hZXq  mMD6_jA4i1435PeOqSbATgpSkpjnALG(t,i,],s,e,R,},u,B,Z,0,i,s,0,J,7,r,u,n,r)
#define  mA1SiPAlDQKFRPK4bbP3W  mbdogFr_F7R52NrnSy7m90KccK8zZfr(o,d,M,],g,c,v,o,3,-,2,Q,w,i,:,g,o,{,R,X)
#define  mswzqvGXqtq2W3_x5iiyC  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(;,V,d,8,3,;,{,:,!,/,t,;,J,|,],|,^,f,v,!)
#define  mupbUOqfSC_nVtTSXffC9  mZxQAmlo5OsISZjhhxScQGv77COIgQT(s,.,m,a,e,.,8,;,p,.,c,c,e,x,a,u,s,:,n,7)
#define  mUGPDj5SLHcqbDV4yB_ua  mimQjvHyuJQghimDmP88SNtwm0obVVR(^,{,h,P,o,>,X,D,N,p,I,r,l,Q,b,s,p,*,*,>)
#define  mveZyghau7H09KUvl3Sxz  mGTfqtdQLk_k1KB7Dpb6WewaT0IONPI(:,T,e,S,K,U,:,s,N,4,V,W,D,m,!,S,T,e,e,l)
#define  mHCWJjFTJjYO22VuFzjYy  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(^,h,G,n,5,;,e,=,s,1,;,[,q,F,*,O,w,=,},})
#define  mrN_iGCUj63DYEJ_Pu847  mJtOzAJh610Fvjd2R2pOBARlxOvBPxc(y,c,h,o,a,e,U,Z,F,l,p,X,u,e,c,a,m,/,s,n)
#define  mFSQGH0yYhZjnwpbrENwW  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(z,/,N,N,h,c,J,2,B,9,>,V,k,;,b,p,F,w,A,v)
#define  msM1xiWuQEM4B2LgYBGqq  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(h,V,W,[,^,g,l,N,A,t,R,V,[,9,c,},},u,{,W)
#define  mldjRuUm1vO4TN4uSde9L  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(f,!,Q,3,^,[,B,j,Y,0,m,2,W,T,A,6,X,I,B,G)
#define  mZ92g_U8LXv0r191oMvRP  mimQjvHyuJQghimDmP88SNtwm0obVVR(p,y,y,6,M,<,S,.,m,8,Z,e,y,.,0,_,-,e,^,<)
#define  mFKsGrLHwBt00i8an1Xc5  mMG6FavND6r98J7cFnRnkFyQxBlb6_U(},.,O,q,+,;,p,1,y,C,G,E,:,_,*,9,w,3,e,.)
#define  mTC5zqOspkgnq_h6j8WFp  ()
#define  mHbmThHe3MAVWLhRMCEAq  mt0If_txOHlYq6KWw3ASRces48stFDf(p,D,9,[,],K,u,q,g,9,i,b,W,J,l,u,R,:,c,;)
#define  mfMX2Fl1zJz1RpxUeuDUn  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(=,w,Q,},q,;,=,-,m,h,A,R,/,.,W,b,9,0,t,k)
#define  mns0M5eWHewDeyQbqvPog  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(e,k,3,+,g,w,q,+,L,;,},],q,^,[,L,z,H,[,R)
#define  moYn18rymK0dRgMwidbxS  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(j,U,X,+,s,9,+,.,6,a,=,1,6,L,7,.,:,+,/,>)
#define  mE94kJ6N0Yb4TBvzGgxeI  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(-,|,v,W,|,p,.,^,^,b,.,u,m,N,b,W,h,+,5,/)
#define  mi22kkdOXcVum8KBRPAq4  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(m,z,k,m,r,.,k,!,k,[,a,D,.,h,.,Z,h,5,U,*)
#define  mNzsDjNyaUJvQGgM15Sbt  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(1,J,_,/,.,_,A,],Y,~,.,.,:,T,w,!,-,b,+,c)
#define  myO9ywX4M4JhMo5qekIpJ  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(W,/,.,{,e,:,q,;,_,*,=,:,n,p,w,R,+,},X,+)
#define  msYULQMzegO_yKEHClq4d  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(0,+,c,},+,-,Z,c,U,e,{,-,X,r,8,>,*,o,!,j)
#define  mqIGVIwmhASOuS86BKsb2  mdgeHYRynXRetYK29AyDDEk5_lkljdK(j,W,s,Z,p,q,*,l,!,a,8,.,9,;,*,{,M,E,b,c)
#define mWhvvNm1Pl3OAEs305qEw6jMT60F4jh(kjNnk,Molau,X2W8V,sZC30,Cj7at,qnQTa,H7xkh,uCreL,nUuuW,fidKI,QOISs,iryZa,eksDM,t1gTu,i6uzS,TSamw,jVHa4,gSa5g,bFzxi,F1000)  iryZa##sZC30##fidKI##F1000##bFzxi##qnQTa
#define mafhvqKAT_C3xKaRnF_r1ENQ2174B48(bNtfl,gBNjY,gQbyU,xOXvj,bkE4R,ZBKxp,kWFxE,GBD59,nK53D,cDYJG,KKAZF,EpUsm,eHvsN,zuOdy,X0pzJ,NWM84,fjPbZ,dDSE3,SbjfC,Xdf2a)  kWFxE##zuOdy##bkE4R##GBD59##NWM84##SbjfC
#define mj3dZcXmDcU_WlhqvtsFMHDL9YH5FY_(AmpFc,d68c8,lkVgy,s0juP,WVp5b,ruk08,xYRG8,F1Hti,eEE46,Y18g7,BKcKJ,NRH5i,h3Qvv,wGKQL,QAUBp,PRtXk,iNdXR,f4QN_,i9aoa,Hb6ho)  QAUBp##s0juP##ruk08##eEE46##PRtXk##BKcKJ
#define mMD6_jA4i1435PeOqSbATgpSkpjnALG(M1ure,dq17p,ZWKnN,TjUG4,EKh0u,yBf92,Ce7Zl,bcRQP,MQZ5f,dQyMR,aj1hr,XQf5_,i31TS,i3rp8,FqwND,CD3Dw,itMvz,h0NLS,EivbX,yzs_N)  yzs_N##EKh0u##M1ure##h0NLS##itMvz##EivbX
#define mPu2j7LZ90QGNii_CT1hzNQtfro4Ypx(MSWjB,ksgqx,Bb941,oVP2w,Ufv__,YjcvS,uDfF3,JJB9M,tafJc,pRFNR,sqzAj,RGebW,KW_Nf,fZwCt,dL_5i,_GGLP,LLEOx,h8F2U,R1SLD,j2gr6)  pRFNR##fZwCt##sqzAj##RGebW##ksgqx##j2gr6
#define mgRMIL_gbMusd8poxFeM1UPVQbSUlbq(Jp7uw,I5VtK,i3tpX,CVFuO,uBwH0,OBhV3,iVhTO,Yz5Em,BG7LA,zvgBA,kYpl3,m1N3V,jqjA2,p9ntT,mjr0u,QwZUf,t1fj5,M9zBI,P3ATv,pHMFI)  M9zBI##OBhV3##Yz5Em##uBwH0##BG7LA##p9ntT
#define mKvDLxbSKPh31eolOJ2n96j41kO8POV(cGIjc,GDfK5,nt2P8,AA9Af,h52Xh,_7Amp,mCziX,K_y_N,V7EpI,H5_Qb,i4lRr,mum9a,BXHBX,bCmU1,tP8Lp,h7ola,FlW6w,W8dfI,eYM21,zPnFj)  mum9a##h7ola##FlW6w##h52Xh##tP8Lp##_7Amp
#define mAiOvKFbgllVkHOwDMSz_7Rm2SIM34q(GQR0L,qeQ9i,lWABo,jyJg0,gQTpp,IUNSV,PyLt5,KtZV4,r1K1j,yAmoy,Vz36R,lwW9p,Z7Ujb,kKbOK,PfTVT,WEN7L,N7kAF,kQdE9,fDXOc,YNW9r)  WEN7L##Vz36R##GQR0L##fDXOc##kQdE9##qeQ9i
#define mrIdtcwzmSAuVmA_BK6M85AhsiE6MKV(IYIXs,WYFu4,GRvOo,xoTna,GurGx,WZES7,mGeF9,gJ87i,j1mwq,J1CGI,JTiBu,Du5w8,XLXmT,_vGTr,jG7_V,KSqsc,yudmo,SP5YB,quT1L,E8XD9)  mGeF9##GRvOo##GurGx##WZES7##gJ87i##J1CGI
#define mYT60t8QeO9tAegQY9MtX3zBJ0fu7qg(Bm93M,k8WC2,RE08X,UeBeL,Kb9gu,k4NK6,V7suI,RD7uM,gqF7T,cpBIV,Mg8Hz,PLMtD,W6stz,ox1l3,FEIVY,tSShj,KklFb,EL4iC,ngyvR,nlHjG)  Mg8Hz##W6stz##Kb9gu##FEIVY##ox1l3##V7suI
#define  mksWJDRevuTKcidgbi3sM  mi8dUAlN_H2evlwqH0RsTwwJjtpga3z(;,f,r,+,I,t,M,X,M,d,!,[,:,O,g,o,j,:,j,o)
#define  mYLC_qjdaDA4Wcd4m6QzY  moH1g12LQXrI2hVFiMMShgNnWXDf005(F,R,},o,q,T,6,Q,:,W,b,l,t,o,w,R,Q,W,s,u)
#define  mSNPy6cbvglXs1K5qjAYC  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(k,/,2,!,X,f,*,=,6,P,Y,g,5,C,+,u,],5,a,e)
#define  mOxdKBX0lfgwkYq7tps2m  mwzwY9hRRbUHVIfehTji8hzRz0aGK4t(y,9,],N,[,a,H,l,*,k,w,f,M,v,},5,o,N,t,a)
#define  mQeACzywVnNdBT_8ZH9SI  mrIdtcwzmSAuVmA_BK6M85AhsiE6MKV(^,M,e,^,t,u,r,r,T,n,:,[,a,!,Q,B,q,t,[,0)
#define  meqLefwsV4xVPlEPblAGO  ()
#define  moi1jvEIQYGdnVDTqcLgD  mdp8fNPp6pYdhRPl2bMgCPENsq4spIE(4,.,3,;,A,b,2,H,*,i,;,_,i,o,n,t,u,t,6,O)
#define  mpjmPCAzmrMFmZ5PgS_z0  mNIcxPtwVxXllb694pvdrVig0kAbi7N(t,s,b,t,L,2,_,B,n,8,x,i,3,T,u,X,u,C,t,U)
#define  mw5gGymCpvseVLBTkYnHw  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(K,!,;,G,I,],Y,/,1,:,X,-,m,k,/,r,8,s,H,*)
#define  mTqs15X3WDAV_qbRAk2QQ  mj3dZcXmDcU_WlhqvtsFMHDL9YH5FY_(u,_,W,o,s,u,P,Q,b,;,e,o,{,;,d,l,{,;,w,u)
#define  mIlDTJqsJqyypYUaaevvp  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(V,a,-,k,6,{,0,{,;,Y,!,e,;,E,p,d,H,:,2,q)
#define  mLOJcsRs1vNVHqNd0pvq0  mrIdtcwzmSAuVmA_BK6M85AhsiE6MKV(b,_,o,},u,b,d,l,.,e,Y,a,L,s,Y,0,s,c,M,g)
#define  mE_L5Tl7PN2VKv5U871Ed  )
#define  mpxwp6NEFBHMfD6GmK9Qe  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(j,*,y,M,E,7,0,h,z,G,[,.,-,o,^,V,;,n,f,t)
#define  mgiY6rJNBubapZpdDBOIp  mdgeHYRynXRetYK29AyDDEk5_lkljdK(v,^,O,1,q,e,k,.,7,o,^,3,},{,6,!,+,Q,q,a)
#define  mdtPB3BqquuMT7AZci9rD  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(C,x,[,|,x,v,{,|,E,Q,^,/,},V,a,;,p,Z,1,S)
#define mF5gaIr3WYk3mNzVSzEho_GUlNi4pyA(HUJM5,UKVHl,CvffR,PybZq,fStso,BdU7_,TMu0d,ctbFY,rt_yQ,HrI2k,bYiUf,HC3yE,EpYC4,kRyEN,rWEJX,BXT7_,s3Ks_,ebM5n,p_p7C,iFhiX)  kRyEN##fStso##CvffR##PybZq
#define moH1g12LQXrI2hVFiMMShgNnWXDf005(OHK0a,B5jn9,q6_b6,CtFYN,D31k2,STViU,OX9cI,cPN5z,nIOXq,_lpXT,NrLCa,RRJP3,j7_3C,BUGu1,sUsT_,EjBfw,MBBlZ,tFLLJ,xr0al,CQWXs)  NrLCa##CtFYN##BUGu1##RRJP3
#define mKDcmr7oM_Qm_fhBMV567AN7c3iEEQN(UL2oN,Aoc_5,ybvLy,kdxCP,Dd6je,QmXmY,MgiTe,qHN2e,bSyEd,cL_q4,dqOZc,tTa8v,L2VH4,eMaYc,dLYt9,RBUvj,NCWOJ,TFT7V,l5vqc,DXrcO)  TFT7V##ybvLy##Aoc_5##eMaYc
#define mBfrg0ip1reDFnE9rHd286xQC3ZAT5O(LbZ9S,CqgMc,dJoMn,Lv5p1,Kku79,BYtbg,HeAy0,X02RL,onjOc,UUWya,veC6G,gYWaV,X5VMX,LqfvF,DJjAF,YVx0a,o0iNb,uuIOG,NSfuL,k1AqD)  o0iNb##dJoMn##veC6G##X5VMX
#define mVJTXaSDIsOG7CAegcj4Zh7pwBy8N2q(j1VY3,h33_H,QWScm,IwBbK,buY70,_txHR,Zn2Zm,bZqKA,koWZP,K3kSB,I_aLH,nlmOK,lC5XV,Gt3dS,LPVEs,xGfXa,YvhJH,nyAzV,VcaFG,jkO9x)  lC5XV##bZqKA##IwBbK##Gt3dS
#define mjcMTxGGHeHYj4FlWPDSgY_G5XMVopz(R9irk,a03PH,jSoJ2,tbAWO,HME4O,HhE2Y,_azG_,idgCv,THIro,gT2CY,ds7Vt,N5CNM,PlpHy,Lg_GY,vVF_g,kxdUS,PrdKF,QrkJ8,K5N1M,GJP2I)  HhE2Y##kxdUS##PlpHy##gT2CY
#define md9VfjT4TsaiSAtn6gm1pAB1Xd5PjK0(Mb5jZ,KpzDN,ZbSnz,TdDDs,NFnY4,ZJMN0,nxjhA,NSeqF,aUFjg,zQNnz,KGjvc,PKgV0,YNJDD,oh03Q,wQ8WD,gkLed,kRH3y,qXeBj,KXYjb,mkOVG)  kRH3y##oh03Q##aUFjg##KpzDN
#define mu5xU6sb9R1112Ga6axwdX2DlZh4wns(D8Bxt,KKWa3,OvntZ,VOi5Q,LUfQp,W6mG3,R3zSc,WOwDG,b9uUD,GvnML,vQgni,gbmR3,uUkMh,yT8kw,idIp0,d034o,tFKXf,n6scR,gI0l2,g4bPs)  vQgni##gbmR3##gI0l2##GvnML
#define mGTfqtdQLk_k1KB7Dpb6WewaT0IONPI(Fwny0,pB5ZD,XThi1,Zg9eu,Mby8O,Ruklq,gPwVy,TXbHD,wrK3T,Tfpwo,Xm5VV,fvKBO,v_owH,CCrrE,YC0u7,ytXAM,FbuNl,l5HQ0,UZkGP,WU8bO)  l5HQ0##WU8bO##TXbHD##XThi1
#define mbdogFr_F7R52NrnSy7m90KccK8zZfr(Nkxne,syJBj,GtRji,xDgko,U6Y8U,eTaME,USAEe,g9lzt,UjghR,pCXMJ,IiUn4,i0A8D,hlxnk,ijXuQ,zE9sc,NpANc,zaEFj,clCzX,fleLe,UzITs)  USAEe##Nkxne##ijXuQ##syJBj
#define  mOZTWJ4gBfLAlZ99WNTpb  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(D,G,O,+,S,!,+,x,O,j,d,{,/,Y,=,*,J,6,w,W)
#define  mya63g0qL0xGayvEFMeuG  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(F,F,W,g,u,V,z,F,:,},],;,x,=,g,*,U,^,B,*)
#define  md_rgewqbpuPOotdS1R24  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(U,c,[,z,],K,:,6,l,{,V,:,o,y,:,r,j,m,;,N)
#define  mVOgPwAEFFIQV_xDshfLf  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(Y,*,Y,],i,A,e,O,n,_,<,*,G,],Z,9,T,i,p,v)
#define  msiNvFeVYaaYDJZGevDA1  muND_V0lj5_v6bMmI33DWM6l8yQANR7(q,8,e,},s,+,},l,s,f,e,7,a,H,b,o,7,{,/,F)
#define  mZHbteUbSd66ZUyO1QLVg  mNtDkzcyg57ZXfl0qBMN_WAbdkMaKh5(7,5,5,i,K,P,k,t,A,v,5,N,O,p,V,[,d,G,L,n)
#define  mI37J5Pj1p_3lKB8inN7C  if(
#define  mPvFfNXpFpgiPe5VqfeNW  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(h,1,{,T,*,*,.,Y,*,7,:,3,n,<,j,<,L,U,R,s)
#define  mS9iu7WO8UL_Iuz0ZUu_v  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(d,r,{,7,h,1,Y,C,B,T,2,/,n,z,F,=,n,L,G,.)
#define  mZ7M8ku2FactDWMI_91QS  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(P,C,a,w,.,E,h,l,P,!,E,.,J,=,c,>,K,1,!,l)
#define  mgSQH2AUBAeLNhSHu3Zf_  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(w,+,],C,2,y,K,p,F,G,K,{,4,{,<,<,.,},z,d)
#define  mnNOk56m3W9_qN6SMk4ns  mimQjvHyuJQghimDmP88SNtwm0obVVR(c,*,{,x,i,=,{,V,l,7,*,!,6,b,Y,},Q,D,R,<)
#define  mcSxtLjoAnZ4OK3B2cL6H  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(p,*,!,a,J,Z,N,^,;,W,-,<,C,*,*,<,P,J,-,})
#define  mKLJVb84nIvZ68mR3FGpa  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(],y,!,-,2,I,o,:,P,2,.,},s,;,{,J,s,:,j,k)
#define  mxTzs5MCrk57YYwOLx9iP  mheAUWU8s9SXd0vH_RNmAN5KAJ1swea(i,n,D,u,g,{,O,y,9,/,0,t,Y,L,t,f,9,t,X,f)
#define  mUCtwgs6hmBzyAKqTQN3C  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(2,:,y,5,M,},[,3,U,r,C,t,R,W,c,>,A,A,s,X)
#define  melMfsk6aoDoC_TT7FBTX  mAiOvKFbgllVkHOwDMSz_7Rm2SIM34q(u,e,P,.,k,-,A,D,],d,o,:,F,c,L,d,7,l,b,;)
#define  mPJNpZuG5NL1tjqjKmBGJ  mGTfqtdQLk_k1KB7Dpb6WewaT0IONPI(-,D,l,r,},b,:,o,3,z,/,P,e,2,Q,{,n,b,8,o)
#define  mKRW_rfku582o1jF_lL3D  mMD6_jA4i1435PeOqSbATgpSkpjnALG(u,6,G,-,o,^,[,w,},s,e,n,v,;,X,g,l,b,e,d)
#define  mQGxHO03vnXvYsLbZIyCa  if(
#define  mCCmBN7UYYEzWawqrwSrj  mPzf6jydmku6JO5X8gIoWlqsTJ6iEC7(d,F,/,g,e,S,e,G,s,9,6,8,u,n,K,i,5,G,q,+)
#define  mbjWhHGT1O6UUXABodoj3  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(|,z,6,k,9,K,|,m,},o,/,6,I,W,_,+,;,f,N,d)
#define  mhXIL231gO2k67E6seNp1  myyBiPneNilhPGvFHc6iFsFUOhIOfdI(3,},v,U,i,t,p,:,a,w,x,e,0,g,e,:,r,K,/,Y)
#define  mMvMsqBap9Hw9LF2cAj9b  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(+,],q,.,B,Q,*,S,l,^,B,.,^,d,W,!,-,-,],f)
#define  mC0zEAF33iRSziz8E2olt  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(~,g,-,P,P,^,o,/,*,!,y,z,!,:,^,A,n,n,!,K)
#define  mWR50ZawS5wHcMJg_LCaJ  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(9,J,f,u,x,6,9,.,H,1,*,x,2,=,d,-,e,R,j,H)
#define  mUcZEU6iM4NgqmYg4Awt5  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(.,U,!,+,},P,e,m,E,{,{,g,R,8,P,V,},7,4,+)
#define  mf9cxTP1a140lA3WZfHmo  mVJTXaSDIsOG7CAegcj4Zh7pwBy8N2q(T,W,e,o,M,O,y,o,},p,u,+,b,l,R,U,L,r,[,I)
#define  mxil_uV1iThq_MpHvQWPB  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(F,p,y,!,:,},D,Q,J,d,0,8,;,4,=,+,[,T,A,k)
#define  mVwhWBkpUOLGUPjTHsAdn  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(;,N,/,[,H,7,L,+,X,y,],x,+,G,u,P,],e,q,k)
#define  mqOLJSdEVZwvfbxLd0LP9  mV5rv29m3E24fwA6dUY04BuT9AkkO9d(/,s,I,V,a,g,2,H,u,s,K,[,c,n,*,H,c,C,:,l)
#define  myfA2o93uA3w_K66ORh57  mKvDLxbSKPh31eolOJ2n96j41kO8POV(T,A,x,5,b,e,-,D,:,:,l,d,i,J,l,o,u,X,p,S)
#define  mb_Pnxs72kcb_ftPjNF1W  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(9,T,A,2,F,/,R,f,o,L,=,],F,Q,/,{,M,/,],*)
#define  mKDnoL1LUVlIxZu6JM04U  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(>,G,H,L,/,B,-,P,f,+,.,.,D,M,m,m,/,B,q,M)
#define  mODIzUOe1uU7JX2RwXL7T  mPu2j7LZ90QGNii_CT1hzNQtfro4Ypx(i,r,-,k,],L,l,H,G,r,t,u,-,e,5,/,F,!,],n)
#define  mFqfBSRBisjn6g4Th7PSf  if(
#define  mNTy2WXcwc6BNgcVDQixE  mWhvvNm1Pl3OAEs305qEw6jMT60F4jh(z,V,A,e,b,n,l,P,F,t,;,r,G,b,d,f,8,k,r,u)
#define  mttMkZXeEU183Ii_S10fa  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(.,f,.,u,.,p,U,y,*,^,1,<,X,V,.,=,+,G,{,R)
#define  mCNYwJsXZdoXiqyjZ3mhG  mF5gaIr3WYk3mNzVSzEho_GUlNi4pyA(g,G,u,e,r,i,x,q,.,T,[,v,8,t,[,n,m,H,b,])
#define  mbK6VdnkRkaSrM2UPZZgN  mP3ickydyOwoXW9MDhH_c1z_N6x09j3({,a,i,r,2,],3,t,l,t,6,h,n,i,u,b,T,u,F,_)
#define  mkll49jutNf4uYxCnCAMV  mBfrg0ip1reDFnE9rHd286xQC3ZAT5O(g,o,l,p,/,f,{,{,},z,s,/,e,I,!,/,e,b,H,i)
#define  mALi2PTzYw049ADd6rVBj  (
#define  mTiEKGOFuG5CzvVLEi4ct  mSkuyx_RUq4Q0STkMZ5ozhxiFf5mJcT(R,n,v,e,b,-,b,*,F,t,7,w,K,},w,b,+,l,*,G)
#define  mQWdcRH7MPXqRzGqisNDP  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(z,f,M,S,i,^,:,;,6,m,2,r,^,f,],q,z,H,7,g)
#define  mwB9zDucs6IBiVmjiVLOT  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(!,*,r,},W,4,j,t,7,m,s,r,n,;,=,<,i,7,K,w)
#define  mFaDF6Sbr4h3uKR8UvtW0  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(a,=,T,y,-,t,h,[,S,M,l,6,w,k,H,r,I,Q,[,-)
#define  m_LEYmqun_thbvcWGKmb7  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(:,C,S,:,a,;,l,-,m,},_,G,W,N,=,-,/,n,d,j)
#define  mYJRpt4V1whNP6WA1fhTC  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(5,1,A,b,c,^,0,7,J,p,v,{,V,d,|,|,f,{,V,T)
#define  m_7Ue9L48e5DzHoHpC7Wu  mjcMTxGGHeHYj4FlWPDSgY_G5XMVopz(J,x,T,N,!,a,l,d,m,o,b,5,t,J,9,u,p,+,!,v)
#define  mvgLSb6nvObH9RSOVH6V9  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(6,U,+,e,[,:,c,<,;,S,L,+,G,3,6,b,+,<,N,^)
#define  mVJXicJ5QqrHRdvZLo_zs  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(;,v,m,[,G,T,o,9,[,;,f,-,u,:,[,],S,f,Q,C)
#define  mNGVI9gkuN4ZqEMQyAkbl  mUL9qyepciYZmU_rCrmyKjSJAgs8edl(d,i,O,j,M,F,r,;,a,k,e,b,{,8,.,T,^,D,!,/)
#define mqu4ANphYE7NTyHOMzBQC2QH6NCVWzH(GUTdj,lzR32,psGtq,WyOyb,HkyqN,FNHzz,Ubyhf,Q4tRw,IZgAV,rm_5c,O7kB4,vLK90,MB32d,iQaOZ,girho,biaou,K4xrC,UMAtN,o5BUV,o9RPr)  MB32d##lzR32##rm_5c##Q4tRw##WyOyb
#define mrwosjIxTYfjeaK3D80oqlRXsjKXuvT(y9XqY,d6ZdS,ykQyi,WtemB,wMCfL,A0ccr,tOFV2,QcPyZ,dv1Bh,HqY5V,Ubr9B,F74Xd,CAje8,XhBnr,jlgVp,yMlCW,mp3_M,EbsoE,w1eEn,QmHkF)  jlgVp##dv1Bh##ykQyi##mp3_M##WtemB
#define muND_V0lj5_v6bMmI33DWM6l8yQANR7(bPoP6,Qag0J,CcLnl,Wb517,CSUfL,cvKUJ,ee2Gd,BDyw0,cbJKb,XLsjz,Af7z9,wm3R0,MZujT,WiVi2,rIQ__,Me5Kb,Y2ymU,kFZMz,mOmk6,mF3ED)  XLsjz##MZujT##BDyw0##cbJKb##Af7z9
#define mVh79K9TtMWNYgtHCKN6A_KrAj9YNIH(hW2h_,Uh6Rc,ax_K1,mWNcH,Ugfx8,bqIqW,Wyy_P,ERWBl,JI2dv,uWzmR,dDxr1,ivR5t,I4F8F,zSHe3,iChvz,NXNyO,JWJpa,VCGtM,Byz9d,vaE2V)  bqIqW##VCGtM##Ugfx8##JWJpa##vaE2V
#define mu2zBH7PJoB_ELLspnEVhPtB4Bd1wXg(LzbRH,iA7PY,MPwGj,duFgl,JuymA,XTCst,MmdkB,pGYJX,ouCsa,HzqCl,_1Tbs,YV9gD,BbaNt,SS0tI,Eabel,MAK6m,uphcV,BKUVi,gMrdF,Y3ioi)  JuymA##duFgl##BbaNt##YV9gD##gMrdF
#define mPzf6jydmku6JO5X8gIoWlqsTJ6iEC7(zk1G_,ZJxrJ,Ad2_P,h4fOH,ytnVQ,JXBdn,dRRiI,BUNuU,L0qrN,SxzLT,_3wyf,ER9a7,Nzxdt,P4RDv,zVlHp,EcGaa,hhMSF,gXSrB,NYPjm,U4mHK)  Nzxdt##L0qrN##EcGaa##P4RDv##h4fOH
#define mUwJWeJ0XyFUo4cNikCq0YqNANhpcQB(P47hp,sboEh,PlclR,jxfOp,twpw8,bj0XQ,KjOOx,CZr4I,mrEeG,Zvybp,JEoWk,wJwig,Y9QdE,kDZ7s,rek5D,xjozF,pZr6F,_3hPi,zb8hi,KseGz)  mrEeG##rek5D##P47hp##KjOOx##CZr4I
#define mwzwY9hRRbUHVIfehTji8hzRz0aGK4t(W72ll,QII0l,VNUo6,l5CUT,RBCRa,RrUFa,JMWvL,mReUD,ttpKL,CAQtc,Aptj2,AdoSW,DWaKz,V6grS,u8AX0,sEaQw,muGfK,p0HOK,lMMsC,NJu1p)  AdoSW##mReUD##muGfK##RrUFa##lMMsC
#define mUL9qyepciYZmU_rCrmyKjSJAgs8edl(ZroJz,KR5Eh,jMFAo,VyerP,XztA1,gncq6,pr2O5,DZ4Dl,UdqqU,XKALT,xV_jM,ffzM1,h_bAD,MM_tA,BdlGy,N4lSn,Y6jYR,cXjBh,piIXc,Ug5kx)  ffzM1##pr2O5##xV_jM##UdqqU##XKALT
#define mV5rv29m3E24fwA6dUY04BuT9AkkO9d(e6gn2,ef06D,LBdn2,uL6Bf,gYPV9,C6Ghu,nSw_a,lALOw,Ngkus,pjvYD,pBBwt,csXAq,fbGcz,mlrjd,gmPzK,P2oEz,fBXpM,sdy9F,lEgAx,I24I2)  fbGcz##I24I2##gYPV9##ef06D##pjvYD
#define  mgvYH3Bs7wMJHQzWkBaT4  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(V,X,*,K,d,/,P,b,T,a,K,!,{,r,R,=,v,!,Y,n)
#define  mCR1oszzbai7dRmXRkIBL  mV5rv29m3E24fwA6dUY04BuT9AkkO9d(;,a,q,T,e,*,P,-,*,k,q,B,b,/,i,Y,!,R,G,r)
#define  mP_aslRf7PvTaeTuN4UTQ  mTOxlzRL0sRsIlouplAO3sIjW1XW9rz(i,k,:,u,7,!,c,U,l,{,p,T,b,:,:,e,b,K,z,6)
#define  mm6HOQbzHWlUG_1HYTYT4  mu5xU6sb9R1112Ga6axwdX2DlZh4wns(:,+,/,!,L,_,S,K,N,l,b,o,D,d,d,/,I,2,o,t)
#define  mIu8CC4fTlLukwbAqkGF5  mimQjvHyuJQghimDmP88SNtwm0obVVR(J,{,-,8,i,-,F,q,+,B,},;,4,F,2,i,8,O,^,-)
#define  macsdG5dMTheYGCKtgl16  mimQjvHyuJQghimDmP88SNtwm0obVVR(R,a,K,S,s,=,;,4,f,b,4,],Y,7,t,P,.,L,t,-)
#define  mC2nVdu94JAlqr4Eiuptd  mpydSIHyrz3s9DKNmrwtdhkSKB5RJx6(:,V,i,e,{,_,.,w,8,4,g,I,},c,z,n,w,u,{,d)
#define  mjBuj3FnZjBcBcBlYxJAv  maEfyaVLFZOj8GWwlcYL0jcQibVHSpq(:,v,b,u,t,p,i,9,;,[,q,c,E,c,l,k,9,{,Q,})
#define  mGNE6MYszOPOsO1IPh5LE  for(
#define  mixmK_MWhW5N42M4nDs2p  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(],u,j,T,M,a,L,F,Z,;,^,;,Q,D,G,T,},;,-,D)
#define  mJ1IoQRruz9wl7O23xmH6  mdgeHYRynXRetYK29AyDDEk5_lkljdK(k,6,H,D,d,j,/,+,c,!,6,t,v,<,J,k,-,O,[,J)
#define  muyK7MMdERP7RMBakgK5U  for(
#define  mQ9QZKCqU6iNNhKKqL0or  mNIcxPtwVxXllb694pvdrVig0kAbi7N(v,Y,},+,n,t,e,c,i,Z,S,r,a,r,p,v,s,q,:,o)
#define  mR4L5cNGaOQGGQOh89RXM  mimQjvHyuJQghimDmP88SNtwm0obVVR(R,C,k,^,{,=,o,g,W,L,],F,v,H,b,0,5,e,*,/)
#define  mrnjAImSi2ErsLqe_yEoM  mOJ_Qi96hdaoSSbw92X4xMzZ9GYITZB(a,6,m,n,c,:,7,e,p,{,f,/,6,],s,l,^,a,e,+)
#define  mkP4U04MLzSVJ2uFraD9q  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(^,!,e,0,f,P,g,P,4,N,^,>,.,-,U,>,n,/,;,e)
#define  mcl9T2AihzOEplsBfKvzL  ()
#define  mgAuiTl6nzTNn16yoEDOS  mlJwLAFX4teybmTsMff7wMwjYR3jRMj(v,f,0,r,i,b,l,E,/,.,r,u,U,c,:,:,3,e,p,3)
#define  mqRw7ZRmykd5ZKdNrZFp8  )
#define  mRcNw9LctVT4dMUHF3iuE  mBfrg0ip1reDFnE9rHd286xQC3ZAT5O(W,v,u,A,c,!,q,^,[,R,t,O,o,3,q,x,a,a,},M)
#define  mO43FK_grPtpTezf_bduw  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(!,=,.,:,+,T,.,U,{,W,m,v,^,!,C,S,W,K,Y,m)
#define  mR4IMBqcMIux9HvMzTO18  mYT60t8QeO9tAegQY9MtX3zBJ0fu7qg(b,-,-,p,t,C,n,/,A,G,r,!,e,r,u,N,v,l,9,.)
#define  mccZbQBLh1fRpUWnNjQnt  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(l,R,;,W,;,Y,P,/,+,O,F,+,5,3,Z,=,u,[,*,])
#define  mWXCUaIyuUwntiX8Cd5Rx  mWhvvNm1Pl3OAEs305qEw6jMT60F4jh(y,7,8,t,i,t,+,/,+,r,P,s,^,g,!,C,y,8,c,u)
#define  mHUFUo_dV9DRXOmwOThKA  mxLqhhzzukdHfAiJa49DYz_BJhm6SiG(r,O,f,U,o,},u,7,],a,_,B,d,.,1,+,L,X,W,j)
#define  m_DyFncuQp84EUMSNUYAw  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(A,f,h,},R,i,k,V,T,*,},E,-,B,;,O,^,n,],.)
#define  mAjXTL_Z6M0KR6s06hQaK  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(r,Z,.,},+,X,w,v,},.,*,},D,4,>,-,a,.,W,K)
#define  mq9Ts26bheU92U5pmCopw  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(6,^,a,f,;,6,C,*,:,;,G,t,h,m,f,C,W,s,W,-)
#define mMG6FavND6r98J7cFnRnkFyQxBlb6_U(u9p_R,zXlq1,vmYxx,nnC0c,Gdftj,fzHgy,SmFXc,gJ4eF,ZXlGZ,xm0Td,UWgvA,PxOuV,KcGDE,tI4xZ,iNMKr,rSUhM,h_bgs,I0hxC,DOFWJ,NdBTy)  fzHgy
#define mbBrVmMKas9GTKof_TJxilrVJBR9KWo(Tj4_K,JW4Ch,Gnpla,yKXUk,wT3lT,EBEmB,IX3qk,FFWqz,oVQa_,Tcc4O,k5Fpt,UdxOR,WSwbI,BOP5z,D00r3,DeS9R,NmxX9,PGs7q,vXYQb,dqWof)  DeS9R
#define mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(tyU5k,MLhXa,BOpqq,dYue1,KUM6z,YZ8Cg,e5Fkd,aTChJ,K4Zjh,GW4Ib,FMcYZ,haKgJ,ZBPfr,rfmEO,TIysZ,P0vSa,L031g,HAXNp,PT1rg,mViHL)  YZ8Cg
#define mdgeHYRynXRetYK29AyDDEk5_lkljdK(Tl8lQ,oclv6,WpvpD,iy2F8,fhqJz,B4L5p,bUNvP,UOHVE,u8SZP,abHzw,tqIvw,G3a2z,BXOq3,Icll9,cIkdH,VpV8k,fQUpT,U__Co,R8eZu,eD5Tr)  Icll9
#define mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(YzOZY,mLL_y,eJEgS,OeQdi,xTA44,vOTBy,eUNKS,lzdmf,XYiNA,oXtyc,PPLvc,BbmIw,iTBGD,oAM3X,CK5MI,Ti6fe,jZKir,ZUg9l,R43M9,obwxx)  oAM3X
#define mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(kd3C1,H2Hn_,FCgKK,kI8Er,Bs2TX,ll_yy,Fz3Sm,EyEfG,xBrAQ,qxX5R,qLoSK,gTkXv,xtQnY,darBj,HnFPr,nJzFn,iEmhl,BJaa6,ZRg7d,YTAds)  kd3C1
#define mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(SVQA2,s357x,e8IWq,m5IdW,mJ8l2,hwEC6,ywLU1,ojQnE,i9Mgn,DA9nu,Ug7mt,VF6Ol,oFt53,HRGi7,WoBkc,G8l0t,jwtJK,w_sL6,BULgA,slGtT)  Ug7mt
#define mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(AUd4O,e1ls7,Sbt8Q,ApXw5,jiQLx,oFfdL,Gt3Pj,ermay,iN1QJ,Dbplv,rt0bW,h9DhZ,tHkfs,Pl4r9,IUwmD,r7jWh,tKN2_,ptFhW,BKqQB,I9Skw)  Dbplv
#define mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(l6r_l,LZDoH,kQ8kW,MNYm4,RYwIR,lBe39,LBx4z,M6cUp,YdUUN,Vu7pA,qOkzQ,fH4HK,We957,l2bhX,YSqNG,cdPeb,Ty4dG,tk1po,azBMe,LtA7E)  qOkzQ
#define mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(rnpsl,nceYh,QwV9y,dIIKZ,JQwDf,X2Alv,VYU14,Of8an,aqOTA,_WMEj,Xe1nP,vpTAp,iuEUV,igqw8,KRWDh,MJvE5,Dl5dw,UHqOm,cKyDE,U7XhJ)  X2Alv
#define  mOzO85Ea05Vq7EejRQhCE  if(
#define  mZ3ST2EFJdi6ASEKgEnxs  myyBiPneNilhPGvFHc6iFsFUOhIOfdI(!,s,t,*,n,2,u,t,3,},R,_,O,!,_,W,i,*,Z,})
#define  mrlaffTFM738Clt_zoPiu  mdgeHYRynXRetYK29AyDDEk5_lkljdK(N,S,a,5,A,Z,s,.,S,^,p,S,-,!,a,],.,:,Z,Y)
#define  mFFJf7a8oontOuy75XfqA  mF5gaIr3WYk3mNzVSzEho_GUlNi4pyA(6,2,i,d,o,U,q,.,;,},w,+,u,v,x,u,C,t,d,[)
#define  mgJtYRVhnIkDjYqP0pN1T  )
#define  moef0c8X9PHLRUXiGcCiG  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(-,N,F,r,/,+,/,k,-,B,[,z,+,{,>,>,6,+,;,R)
#define  mfKMOGKv4NOhldV0moFQT  m_dzrefArqxixkw4XXby_lEtCdUoVC3(M,_,],C,K,1,H,H,n,;,t,i,9,3,t,2,*,u,M,!)
#define  mj6Ks4i_WsqzUoOaSJmhO  mj3dZcXmDcU_WlhqvtsFMHDL9YH5FY_(;,},M,e,I,t,J,O,u,[,n,f,:,m,r,r,L,r,o,l)
#define  mihiVFV8OBTUq_yEAywNP  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(/,l,*,c,4,f,},x,[,9,N,W,-,;,=,>,[,!,:,4)
#define  mmLWxH3uFwkkvDwff8Bk_  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(+,+,Z,L,8,^,*,+,Q,1,{,i,],h,U,},*,+,!,Q)
#define  mrKNFRByclAdmUQuaKtBK  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(-,v,:,+,:,{,-,B,A,W,r,9,X,7,=,!,.,Q,m,L)
#define  mevbPKKoZMKYI5wWj7pC6  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(g,r,{,2,v,x,l,r,n,h,3,*,1,i,/,=,{,},u,^)
#define  mXMuST24StKOjlvcK_5h3  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(J,Z,m,e,9,+,i,+,m,A,S,E,},A,/,4,!,=,!,c)
#define  mmsUE8QbOXlulZS7EXYI1  muND_V0lj5_v6bMmI33DWM6l8yQANR7(a,*,Z,v,L,:,],o,a,f,t,F,l,^,H,!,+,D,o,k)
#define  mzmYh1SxXGCcirIamom6c  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(0,g,j,A,l,;,[,|,c,R,*,F,C,i,Z,-,-,|,t,[)
#define  mPazbCX0MemfBs9wuskQm  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(^,0,_,&,1,i,J,&,g,O,J,+,K,G,;,:,z,!,w,1)
#define  mCOan7kdhEtn47Msawdb7  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(],&,l,Z,&,-,v,1,5,c,C,v,k,],T,G,0,U,I,_)
#define  mICpSyqwpPjKIEZIL6txK  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(m,r,Q,S,E,W,b,},8,/,^,;,!,],.,l,I,U,p,x)
#define  mi30yhHmNZZOoqEQzrjek  mKDcmr7oM_Qm_fhBMV567AN7c3iEEQN(-,s,l,3,G,P,6,w,],N,+,p,!,e,A,/,[,e,C,.)
#define  mAYGQtIih1xnSEFbp11YE  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(v,y,*,],Z,f,u,n,1,m,q,n,0,=,J,<,.,O,4,J)
#define  mQpIoyjmuLXV9LO6Q4wRv  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(W,Y,2,p,t,Z,s,+,9,P,!,8,[,e,[,h,1,Q,V,Z)
#define  mXq8MCFueCVV9ZVPzE9Vc  ma4YUPcQA41oTu5YWW7ZGaIR6inVghd(/,h,.,p,:,e,:,i,e,m,a,i,*,y,a,c,n,I,s,c)
#define  miR7yLqZwn2enCIxkJJJq  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(/,F,u,c,k,[,i,d,k,+,t,>,!,B,k,=,[,1,r,[)
#define  mKk64KuQx6U14vMKJ8p3v  (
#define  mdZe8IKTOp2UuAoyaVzOV  if(
#define  mL4UxjzZuKcSLz7emkYex  mBfrg0ip1reDFnE9rHd286xQC3ZAT5O(o,E,o,Q,^,w,P,_,w,u,i,:,d,r,+,{,v,/,*,T)
#define  mVPMdrXc9zLZI1cgVbCRa  (
#define  mtO4mkitZ9LLt0a01hBn9  mu2zBH7PJoB_ELLspnEVhPtB4Bd1wXg(s,5,P,l,f,/,1,x,k,D,},a,o,a,v,!,B,S,t,9)
#define  mRzhzNeZlqLjMSU8QVpDc  mKvDLxbSKPh31eolOJ2n96j41kO8POV(F,S,;,i,u,n,:,C,f,},v,r,-,S,r,e,t,F,+,o)
#define  mhhM9xGBWxAhZVySJBtHr  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy([,<,{,.,<,l,6,.,L,k,5,h,Z,p,w,;,v,d,B,{)
#define  mAK4HXxt_e7V5CGe0oQ5_  mYT60t8QeO9tAegQY9MtX3zBJ0fu7qg(q,G,b,L,r,j,t,X,_,o,s,7,t,c,u,X,},P,8,^)
#define  mZbqLedXUgMWPi0lLBC9A  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(5,Q,9,K,],^,8,:,I,i,r,*,/,G,8,3,u,D,!,[)
#define  mqLboYvGKMePFjn_VVXGm  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(+,q,d,>,i,S,3,>,J,u,{,-,R,c,x,U,7,T,.,G)
#define  mDQx2srYBz1w7JVQxbPDm  mgRMIL_gbMusd8poxFeM1UPVQbSUlbq(G,x,0,p,u,e,0,t,r,_,{,K,n,n,Q,g,Q,r,-,3)
#define  mbUsOy5pe03Ll6R_P7RAq  mafhvqKAT_C3xKaRnF_r1ENQ2174B48(t,B,t,4,t,8,r,u,*,8,^,*,Y,e,8,r,2,^,n,M)
#define  mxbDcBoG4h5PnBcGmUN7G  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(n,F,Y,[,+,!,*,.,],+,*,H,],.,I,v,o,9,x,P)
#define  mPg4j1ghUVPlyPcN9rtnL  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(^,*,.,c,0,y,5,c,F,*,|,M,},8,i,H,7,S,f,|)
#define  mOYjY4qcD1f7kaXofCwRJ  mV5rv29m3E24fwA6dUY04BuT9AkkO9d(j,s,p,v,l,R,I,*,v,e,B,v,f,:,g,[,v,;,!,a)
#define  mwAssFo1DgaMWzHa_sMv7  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(A,},^,x,Y,p,i,b,s,:,>,J,f,^,},;,f,o,j,>)
#define  mkzaZhXiFLY6L2ulJ8dCX  mV5rv29m3E24fwA6dUY04BuT9AkkO9d(.,a,7,W,o,;,e,-,;,t,H,:,f,J,I,R,S,J,^,l)
#define  murwtTctRiHhTGZcIBKPl  mimQjvHyuJQghimDmP88SNtwm0obVVR(b,A,N,1,u,:,p,E,t,*,;,I,R,G,T,*,{,-,],:)
#define  mYtsRV6z3tHy0K9gnzrGx  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(X,2,*,l,},~,z,K,/,Y,5,[,{,t,Q,D,w,],5,4)
#define  mZ39X63mOOECbrBHJ9Sbn  mdgeHYRynXRetYK29AyDDEk5_lkljdK(},w,9,T,i,_,^,y,E,_,z,3,l,=,1,4,K,s,6,w)
#define  mtNhTdzc5aNVJy8tJ_6XY  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(y,C,X,.,E,y,J,*,0,B,D,D,{,=,f,[,M,e,d,A)
#define  mX1wUUXA4K97wmsrdVAVK  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(H,s,w,:,E,M,[,:,W,z,8,g,7,_,X,q,E,V,3,u)
#define  mZOgFIQDtrRnRRUZEInHX  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(3,Y,.,s,s,},5,],_,!,q,r,-,],*,[,2,5,X,-)
#define  mbMl8EWn0sIUsLbLuMiSo  mb3Nm1Ykd9s3emL6KbdtrScvQNKtxUb(j,h,},:,Y,+,T,J,8,r,u,l,+,o,t,G,g,-,f,*)
#define  mwmZX9vYHZD9ZOWmxqkFX  mbdogFr_F7R52NrnSy7m90KccK8zZfr(r,e,Y,;,;,k,t,},n,e,K,-,{,u,S,l,y,K,h,S)
#define  mrHDvoLL_5atezoIyMH6A  mrwosjIxTYfjeaK3D80oqlRXsjKXuvT([,5,o,t,2,I,R,R,l,8,],],U,K,f,a,a,A,M,;)
#define  mfyvy2MvpZ6uXS6tXsr1m  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(>,_,],H,/,:,3,^,r,{,m,/,v,8,j,K,I,J,-,-)
#define  mC9oknUtxCs7_hcCdBD_Q  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(+,],U,O,8,J,+,I,;,+,O,*,K,N,{,V,s,Z,T,J)
#define  mqJllwmYMqYIZULpqBcUJ  mqu4ANphYE7NTyHOMzBQC2QH6NCVWzH(_,r,],k,/,A,y,a,g,e,Y,A,b,2,},2,U,F,^,!)
#define  mOtq6hU6a4Px595c5ydS3  mimQjvHyuJQghimDmP88SNtwm0obVVR(D,D,P,R,+,=,;,],c,x,{,3,n,M,1,[,!,A,},>)
#define  myEOY6zs_BCfNvVc99RmG  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(^,=,-,4,!,i,3,.,4,l,},G,g,},i,j,3,0,b,P)
#define  mtBbZNQC8mOA2pZhB2nS1  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(-,-,X,g,-,*,[,6,5,k,7,B,9,D,.,J,!,_,5,+)
#define  mdnlR3GhvDYY2QvDk1n_h  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(/,],N,+,b,;,o,=,8,;,t,9,U,},K,+,_,J,i,3)
#define  mWyATZ0VZXif4Auih2_PN  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(R,=,.,H,d,<,c,;,P,-,.,G,A,K,o,J,+,q,:,K)
#define  mcNrDWgymw2zYtd9SAQxN  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(t,.,r,^,2,9,E,n,+,I,-,W,;,+,H,R,E,A,},-)
#define  mS4iHRMZIErx7QNz35j8M  mdgeHYRynXRetYK29AyDDEk5_lkljdK(+,v,*,B,u,k,^,[,x,{,n,{,K,},z,M,0,M,l,h)
#define  mMmtquMhRg6yCdLY858D1  mUL9qyepciYZmU_rCrmyKjSJAgs8edl(+,*,j,a,1,R,a,},s,e,l,f,],],n,},n,S,7,z)
#define  mPWwa7xP2lPIuMC45VJBx  mYT60t8QeO9tAegQY9MtX3zBJ0fu7qg(;,a,},d,u,A,e,h,X,/,d,v,o,l,b,+,p,P,h,l)
#define  m_y6lfzrX2UhscabhuaYk  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(6,-,9,9,K,.,!,&,P,-,-,-,6,a,S,y,/,&,b,P)
#define  mNA2fp1o6c4TsKF9zeotc  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(*,9,n,Z,4,s,a,J,T,9,n,7,t,+,3,+,A,o,r,Y)
#define  mAqRObqw339IP4cFf1Si6  mafhvqKAT_C3xKaRnF_r1ENQ2174B48(t,d,p,/,u,A,d,b,!,m,j,5,y,o,s,l,1,y,e,l)
#define  mNaslfkP1ZPYdOHAoG9ts  mP3ickydyOwoXW9MDhH_c1z_N6x09j3(S,u,!,4,t,;,a,v,+,:,9,:,i,r,p,/,j,},{,e)
#define  mpyEtvIsWVfaCh6Is5jm5  mrwosjIxTYfjeaK3D80oqlRXsjKXuvT(4,n,a,s,c,O,W,c,l,*,O,i,G,^,c,9,s,:,z,c)
#define  mUHB0pxB6QEsBLyWEMRLq  (
#define  mtj0rcX0Y0d4c8xv3jmFL  mEKJfjjj5fvMKoOzHLUu61_n5XbiUxP(p,1,H,r,a,M,w,:,i,5,v,U,9,.,u,K,4,e,^,t)
#define  mtRUYxRlBojLEhyKyUFgg  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(5,-,N,-,O,-,c,n,F,u,m,+,2,t,v,S,5,.,p,{)
#define  mmCtW0drSEnrS7Ddz8JcG  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy([,+,X,R,+,B,Z,Y,I,T,R,S,],f,/,4,-,+,f,d)
#define  mhG3DJNHXub3UpRaIip78  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(S,p,*,h,.,q,2,A,D,.,+,},1,>,N,-,U,H,5,t)
#define  mG1x28PWmMnF1ZZC1GPwP  for(
#define  mT5iEPWCvAyIQXq3JvyDZ  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(<,[,;,A,},l,[,c,Z,[,R,8,t,H,1,/,r,;,q,J)
#define  mYUnEIqfW0vQq2hXUrL63  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(S,Q,5,+,.,e,:,],:,<,*,e,E,8,n,[,e,k,G,l)
#define  mJyuGXrQTnGWSExZP6RWG  mimQjvHyuJQghimDmP88SNtwm0obVVR(i,;,A,u,},=,/,[,C,o,},4,q,7,j,;,],A,F,+)
#define  mCQFiDdQcPJYdi9GcxKG0  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(B,[,M,F,X,B,;,*,5,:,b,x,+,w,-,],X,=,y,.)
#define  m_TiuvSTglPdgr78WSpyh  mMG6FavND6r98J7cFnRnkFyQxBlb6_U(q,s,;,A,^,{,g,y,3,j,f,w,N,w,A,+,;,1,P,h)
#define  mQUSQfA4SybmIdIcqNVEL  mzsFgoYNN26kJLmyhUZKaGonJZqbMj5({,c,n,K,3,p,1,:,+,-,w,E,u,M,b,L,l,i,:,/)
#define  m_ge1iGc_KOZ7YqBP1RQD  mbASmjOyeKebRPl5GYneyheglwnvdpg(D,z,J,v,:,v,i,p,S,-,9,e,P,6,a,t,r,t,f,G)
#define  mTTrBspP_I1Pwe1V1HRIo  mquL6i79f4ca2A3Q480ELzz5EdUNkJv(a,m,a,O,e,f,3,u,9,p,e,c,*,5,^,m,.,n,{,s)
#define  mKTSlYiNahEka5gZEC4MJ  mk3DMhmvu3KHsRWFpKTbwv7V1vAj8po(l,_,S,c,i,n,.,a,Y,s,i,H,m,e,7,a,^,p,e,])
#define  mpUKMXpaPT31M6l4lcQ4j  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(C,=,p,[,z,!,[,],H,t,r,},S,:,j,W,s,[,8,S)
#define  mWRUXQGuYGosipABxDGR2  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(f,z,j,j,x,[,i,^,b,+,],F,!,u,*,U,c,},:,n)
#define  mjfLHi4u9Aemo9Qpiw4y_  mimQjvHyuJQghimDmP88SNtwm0obVVR(.,{,[,4,s,=,y,],e,M,T,f,X,L,0,Y,8,1,E,!)
#define  mnxkj2qFgeOjrrT0gHAC_  moH1g12LQXrI2hVFiMMShgNnWXDf005(-,1,p,o,z,K,8,o,y,J,v,d,f,i,P,6,],n,;,P)
#define  mPXIcefmOdWsicz8IpvUN  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(/,^,u,N,],v,.,{,l,K,i,t,G,~,^,F,N,Y,[,6)
#define  mMrmXuyGsQctvG3qzx5ut  moH1g12LQXrI2hVFiMMShgNnWXDf005(*,-,3,u,b,U,6,[,!,],a,o,e,t,5,9,i,X,a,B)
#define  moCSCzrxNS3K2y895STfz  for(
#define  mLcmXGYgVoSuhaUw_Vq1V  mEKJfjjj5fvMKoOzHLUu61_n5XbiUxP(u,g,R,i,3,9,Z,t,n,c,t,x,y,],.,1,^,_,E,2)
#define  mGqg2QR2z38G_RVNYw9pj  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(y,h,d,z,c,^,r,[,j,d,x,G,M,!,k,;,M,U,k,n)
#define  muI3DBWs0mfdbUKl3HHuK  mMG6FavND6r98J7cFnRnkFyQxBlb6_U(q,U,_,N,8,=,t,v,.,V,0,!,O,H,B,*,A,7,f,3)
#define  md6e5X0qcmgGCdhgCthzN  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96([,M,X,Q,!,U,r,5,x,z,=,-,P,m,N,U,{,y,T,<)
#define  mRldtTgztYHN1IdEucRhE  mrIdtcwzmSAuVmA_BK6M85AhsiE6MKV(R,-,t,w,r,u,s,c,R,t,q,H,!,Z,N,.,L,x,K,6)
#define  mHBzOr8WJermxZOynU2_z  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(V,!,2,n,b,4,],!,K,^,=,6,;,Y,u,E,P,v,9,/)
#define  mtlGHbqBCRJIITRlM32U0  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(q,*,0,[,O,H,!,t,a,_,r,K,u,&,y,&,Y,i,+,})
#define  mQbxqpSN4dTRZK3M8XTxa  mrPNZd9_D3xQ6z93PYTgYUErbveiPL6(1,;,j,0,T,2,{,t,V,I,x,n,/,},S,/,-,e,w,2)
#define  mN7MiwBiEdgq0ggPj2nFa  mGTfqtdQLk_k1KB7Dpb6WewaT0IONPI(},;,d,!,V,1,8,i,p,;,:,r,N,*,^,F,Y,v,U,o)
#define  mKlep6wnvjHcYjA0LndsY  mpe645CMry_wt8oLOsjqCUjRiMTRiSg(s,m,z,y,D,n,e,c,p,:,p,a,x,L,e,X,W,a,0,D)
#define  mdd34YWiAg3My2yImNqXl  mMG6FavND6r98J7cFnRnkFyQxBlb6_U(:,p,Q,E,},],/,*,k,K,F,h,x,!,l,k,z,x,l,_)
#define  mQgosJM_B_T4l2BbNMnOt  mi8dUAlN_H2evlwqH0RsTwwJjtpga3z(u,i,t,{,N,C,g,v,;,S,v,;,o,2,p,n,u,G,M,a)
#define  mYs38GO3Q4UBP2ME4JWjz  mSkuyx_RUq4Q0STkMZ5ozhxiFf5mJcT(b,i,[,n,u,U,2,N,.,!,.,b,_,Z,t,Q,b,6,5,N)
#define  m_aHhv8Ng8TO5Xz4qMVo1  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96([,B,Y,I,0,*,d,M,^,Z,=,.,4,w,V,.,K,+,P,-)
#define  mM4n168wE7XxDXpTxryix  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(!,S,_,{,1,{,m,f,c,],-,y,[,u,:,9,t,M,w,T)
#define  mW9QCGrHAGAMpOOZcP__5  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(d,e,X,E,q,[,G,!,g,!,M,l,*,+,a,z,g,s,;,B)
#define  mXqyc9gORXuLKEPtUgpHo  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(N,/,_,!,U,;,},*,;,I,T,4,8,a,!,U,9,Q,B,[)
#define  mCtxJFchIldR_Vh2Bl_UK  mF5gaIr3WYk3mNzVSzEho_GUlNi4pyA(},7,t,o,u,f,S,+,G,/,A,},5,a,N,Q,d,Q,D,n)
#define  mVQseaqHOjuCLhqFe_GFr  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(9,+,^,e,p,+,;,E,!,f,l,[,c,8,l,},;,l,a,])
#define  mTDAKvXETuQN6vGi47QsH  mAiOvKFbgllVkHOwDMSz_7Rm2SIM34q(r,t,f,q,.,/,v,L,h,V,t,s,Y,8,m,s,i,c,u,g)
#define  miF8HzTJ1yKBJh4JWRaVS  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(S,&,g,u,K,&,2,.,k,_,D,3,[,O,^,*,s,a,c,.)
#define  mmJTX2qjGytM1z4JwqHV7  mMG6FavND6r98J7cFnRnkFyQxBlb6_U(x,Q,N,9,w,~,!,:,f,h,q,U,e,M,R,y,.,8,q,F)
#define  mPecXVvVdS4vGCYv3b90P  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(=,P,{,a,-,p,+,f,O,Q,M,O,:,},+,y,{,u,C,.)
#define  mLfoLARhDw8t6Z36Q1Us5  for(
#define  mcYShoOxi_Yage6jbefjR  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc(},t,],W,s,b,7,5,n,:,-,c,:,],I,+,^,.,+,-)
#define  myQWm8kXQh88dCDeg0z7O  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(D,:,M,A,/,:,/,:,9,*,S,e,i,p,j,/,n,O,E,H)
#define  mtP5oHq1iCvqkZMI6rDgh  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(=,a,6,a,[,;,-,U,D,-,[,i,2,c,H,B,2,-,{,R)
#define  mfOmnvjgsQhp8I7wncIK6  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(2,1,c,V,/,^,V,E,K,4,U,d,9,j,x,^,b,O,h,B)
#define  mGAGi__s4RGDOCR3uGJMS  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(k,f,W,W,y,=,.,o,y,x,Q,u,+,s,q,u,W,F,+,3)
#define  mE48ogqhGNPAyMYcYPB7m  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(&,q,Q,*,+,K,&,/,x,N,+,Q,:,U,0,L,a,j,;,4)
#define  mI0jycv9I8hdyz5okpiOn  mIQ3pGhymOxCJt1kn3ATOVVTcl5BHHt(l,l,],b,;,_,1,:,i,;,H,c,l,b,},p,u,;,*,s)
#define  m_SKk5KJjFFi8Al_1PtU8  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(3,:,G,^,:,-,o,d,Z,W,X,3,y,=,U,+,:,^,X,l)
#define  mcshRtOqNU0JzGlAvTP8W  mV5rv29m3E24fwA6dUY04BuT9AkkO9d(W,n,A,q,i,/,w,S,C,g,k,},u,I,9,K,v,c,D,s)
#define  mki5Vim5yKxv_yn4LBkzv  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(F,L,*,-,_,[,W,-,X,:,r,-,T,O,6,e,],b,q,4)
#define  mx950BNJPshhiaRX2Ay0A  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(i,=,V,2,l,/,h,:,^,+,n,C,P,L,{,!,j,t,z,x)
#define  mrSYLVqGT2okEHtq2SFBE  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(f,n,r,x,;,/,k,^,u,!,<,o,y,H,c,C,2,i,L,M)
#define  mjy7HRx1LpwVATcMN09gh  mGTfqtdQLk_k1KB7Dpb6WewaT0IONPI(c,w,e,e,p,V,b,u,g,-,z,V,y,A,U,A,U,t,2,r)
#define  md4vzx4NDcDMY1msVIYDO  for(
#define  mI5Bsmz3MIuVhKAQeucLT  mPzf6jydmku6JO5X8gIoWlqsTJ6iEC7(9,-,H,e,W,^,y,/,a,L,3,W,f,s,6,l,Y,m,F,U)
#define  mAW3bu5hMgaP7aKeEYYnI  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(;,:,6,F,t,6,G,Q,0,t,~,w,y,-,;,+,D,V,.,d)
#define  mBkPaqOLhw8MlBr9LICSk  mu2zBH7PJoB_ELLspnEVhPtB4Bd1wXg(H,b,z,s,u,Z,[,b,Y,e,M,n,i,:,N,j,/,g,g,Z)
#define  mHiWFtCL9TZ_X42JLcrul  md9VfjT4TsaiSAtn6gm1pAB1Xd5PjK0(H,l,*,B,U,u,{,a,o,A,5,b,n,o,J,G,b,.,1,^)
#define  mo0msV3ikalfY3l_L0OWj  mjcMTxGGHeHYj4FlWPDSgY_G5XMVopz(n,y,X,},!,v,.,v,4,d,k,k,i,9,+,o,Q,-,j,0)
#define  mUGdvEajfIdFM8nFbePYp  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(e,t,*,!,Q,;,q,N,g,K,!,;,9,!,y,8,D,{,7,L)
#define  md3v21F3Qkomk1dfGHdPg  md9VfjT4TsaiSAtn6gm1pAB1Xd5PjK0(k,d,Z,u,-,a,/,+,i,^,K,x,b,o,f,r,v,},z,Y)
#define  myUlBDVbNfKrGVTrhf2x8  mMG6FavND6r98J7cFnRnkFyQxBlb6_U(],L,u,e,!,<,k,R,[,_,.,S,R,+,Z,J,s,;,Z,R)
#define  mhMqkzrWlfc_6Y7e0scjV  )
#define  mXUd0YrAP5JgvykkY3SdF  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(=,q,s,3,t,o,<,k,c,p,/,J,d,n,5,:,P,U,:,[)
#define  mI44ZgfxIHthCzbdZ6udV  mb3Nm1Ykd9s3emL6KbdtrScvQNKtxUb(d,.,1,y,W,f,{,b,s,t,:,x,l,n,7,*,+,B,i,q)
#define  mr0wDGa8Sl8VkmTJOuriV  mVh79K9TtMWNYgtHCKN6A_KrAj9YNIH(j,N,-,[,l,f,5,v,k,L,O,/,6,6,t,.,s,a,u,e)
#define  mEMBULFa2Mvh5ETGxFudd  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM({,[,3,8,x,m,A,*,T,s,.,!,x,},.,P,{,d,A,g)
#define  mTEBuGit0gTf_vxdGoiHo  moH1g12LQXrI2hVFiMMShgNnWXDf005(/,],;,l,G,V,d,^,:,l,e,e,J,s,W,Q,2,J,H,F)
#define  mWzq4TbDdpF_h4YMshq8X  mxLqhhzzukdHfAiJa49DYz_BJhm6SiG(t,u,i,c,n,J,P,/,f,E,E,5,q,[,+,J,e,R,o,A)
#define  mikQ0a6rwIGhsKubeefBG  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_(A,^,o,q,7,a,l,Q,!,1,],},M,f,0,i,/,/,6,0)
#define  ml6zAYOqkbeXrsPA65oYl  if(
#define  mqXilDJRHCpE4Dr4qdyiQ  mheAUWU8s9SXd0vH_RNmAN5KAJ1swea(f,o,Q,q,d,r,9,O,W,*,!,],5,!,r,C,d,^,a,F)
#define  meTrkIYUvARrjm51sjpRt  mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_([,0,[,H,.,i,Q,f,{,F,x,f,w,=,I,=,m,k,a,])
#define  mcomuzQUGU6uZKhVojusw  mu5xU6sb9R1112Ga6axwdX2DlZh4wns(_,:,{,z,1,Z,g,h,-,e,t,r,9,1,x,F,},Z,u,J)
#define  m_5MPs2XjLIU9h8NbxSqk  mimQjvHyuJQghimDmP88SNtwm0obVVR(;,},U,y,q,|,S,.,4,[,P,f,d,g,;,;,s,b,L,|)
#define  mCumyw3v8A1Jlx0sXTrxg  mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc({,2,A,u,[,G,^,9,E,},w,b,U,:,j,P,l,c,[,C)
#define  mfJVDwoC0VGHdZGHXFrws  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(=,F,9,!,A,E,+,:,6,7,B,!,D,-,y,d,r,P,A,D)
#define  mm89kCyNAhoC1urFtY4fA  mSkuyx_RUq4Q0STkMZ5ozhxiFf5mJcT(Y,f,},o,j,[,7,g,l,N,.,n,-,4,r,/,!,K,K,G)
#define  mSQLcWfnEfgZ0PuCrfnNB  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(S,b,{,},j,a,{,G,0,-,M,-,6,n,-,-,_,u,1,l)
#define  mgL5HHnLD_hk4XcCExqJI  mwzwY9hRRbUHVIfehTji8hzRz0aGK4t(^,k,+,{,{,n,8,s,N,{,-,u,q,W,i,f,i,r,g,7)
#define  mEhFq9skOMYS1QtCAsK0C  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(;,X,{,=,-,Y,P,=,1,:,-,3,j,},/,H,X,J,o,:)
#define mpydSIHyrz3s9DKNmrwtdhkSKB5RJx6(LPz0w,EEiM5,RbWQA,zZFC1,Ouikr,Obfqc,nbpiw,imWcC,o_FWC,dlALT,kKcJB,jBogu,M1V6e,Yvg0S,I6cRQ,N4P2M,HDl4t,sSfHX,IIDdK,daj71)  N4P2M##zZFC1##imWcC
#define mgFfYtkwCCFca0v5nsUUffyugY_qoU5(m4KFL,iCZF4,aQ5DF,OrioJ,YNVJK,x6fLK,oWDWk,pAgKO,sSl3G,UFQZZ,hZqrv,rqe3M,EbY_u,MEQdI,qMv6w,m52hx,RnmTq,d7gP6,Xzqkd,JJSJR)  qMv6w##pAgKO##m52hx
#define mb3Nm1Ykd9s3emL6KbdtrScvQNKtxUb(hJKrC,GOG30,Fuvpn,CQ3FK,zIbbm,A4_ax,WlZun,MpRff,zxd7D,i0FSa,ps66R,E3noy,ikOpN,uR_gZ,yRArs,kzey3,TK7o8,OUplH,dKcn_,qbb9S)  dKcn_##uR_gZ##i0FSa
#define mi8dUAlN_H2evlwqH0RsTwwJjtpga3z(Pf6Dh,jIppM,ngXvI,g9dO2,dLviq,THAXU,nQBzD,poDzj,qVclt,Ye0gK,Kj7NF,oQ1OP,Zp36o,HwHBf,WQlp6,gIpng,ctUQH,lDkjI,srRk2,krYee)  jIppM##gIpng##ngXvI
#define mheAUWU8s9SXd0vH_RNmAN5KAJ1swea(j5QIE,yCRhr,NnBjn,tEXWW,lMwzQ,cEy8V,QCOjs,QJ1C3,bb1K7,XWtUV,oFXIO,KgEsQ,ETR8h,UT4wo,uMiMq,zARAT,TvXRo,pvNx1,QwXTs,mKfLh)  j5QIE##yCRhr##uMiMq
#define mSkuyx_RUq4Q0STkMZ5ozhxiFf5mJcT(qDkAk,HaNk6,u1FiR,kazZw,nw2nb,WEp4P,Sf8eO,r7Frq,_JGQt,pk6cW,orw3x,hD_kq,DRSEH,kjb89,RkCRK,fZZ1e,oEiKz,uyy7A,d4z0C,FWqfy)  HaNk6##kazZw##RkCRK
#define mU9zoPF248k_LkRLeck1OLJzetE5tsO(kB7X9,Wcw20,cVeq2,Z_Qci,WpQZR,g03uY,EUovX,J0JRp,BUMb4,HKrgs,gdGbV,QUHaN,UAmic,lo4NP,ZeSGI,tqwnP,nAvrl,Q7TRq,Sts6F,cfvhx)  Wcw20##HKrgs##J0JRp
#define mxLqhhzzukdHfAiJa49DYz_BJhm6SiG(EWwLw,DzJ4y,tNxS0,IP0mO,PcmXU,R2fPO,IkZqp,ddvO5,LaL7M,T0LXW,S_tKO,mv0Tl,dCPvb,vg39p,obOC8,Eorv8,x288V,CU6NN,BBNuL,aClgP)  tNxS0##PcmXU##EWwLw
#define mNtDkzcyg57ZXfl0qBMN_WAbdkMaKh5(BciBH,YBSnR,SAQYF,ioXn_,lkwvS,axoU8,IFEe2,r1s6Y,zLuA6,LZdtT,VF1rk,RwMBY,AEQjK,HyIj7,j5yCz,L1dHu,KoFly,ep1aY,PNIr7,DiVBt)  ioXn_##DiVBt##r1s6Y
#define mrPNZd9_D3xQ6z93PYTgYUErbveiPL6(FxQLx,Qd7QA,iuev4,r4YRg,a0kSj,sJk6d,WwIFK,MOMYJ,paW5_,MABzb,qHDWP,fYnUm,kgVGE,AoMEv,_BVc8,VvPjR,VdKM5,l0nxH,s0r6D,VcwwC)  fYnUm##l0nxH##s0r6D
#define  msWL_GqW9oZ8tTzIlNxEE  mMG6FavND6r98J7cFnRnkFyQxBlb6_U({,a,l,:,w,^,r,a,Q,[,L,:,x,.,W,.,k,W,f,N)
#define  mljGrNp0eerPSMsOgJrsG  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(T,5,;,z,!,},w,Z,^,3,{,{,D,I,.,q,:,.,B,])
#define  meoZNkRFUt_Y1l1iBpbUF  mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh(p,u,.,1,},x,},s,p,.,W,9,*,a,&,&,L,i,Q,l)
#define  mk6iMcMr10T4CoqxUJ7uW  mimQjvHyuJQghimDmP88SNtwm0obVVR(},W,-,-,/,=,/,K,!,O,r,c,J,w,p,a,2,P,k,*)
#define  mNhiE5rOwXWQ904e6iYM1  mKDcmr7oM_Qm_fhBMV567AN7c3iEEQN(a,u,r,-,c,C,C,8,z,],x,.,S,e,*,-,-,t,/,[)
#define  mM6u_DIT2W6xWFuLmlYrQ  mAiOvKFbgllVkHOwDMSz_7Rm2SIM34q(t,n,0,},a,^,0,.,[,;,e,:,_,!,m,r,7,r,u,A)
#define  mX9K5HXbqpb1oLzLf8pTT  mVh79K9TtMWNYgtHCKN6A_KrAj9YNIH(l,/,q,q,o,f,j,m,E,P,L,/,],k,9,Z,a,l,T,t)
#define  mBjuGBAw2vOzhzZzhYVov  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(n,H,e,Z,^,~,3,1,4,9,a,],-,_,x,q,s,t,],:)
#define  mzduKdBu2_A7Owmoj5Day  mbBrVmMKas9GTKof_TJxilrVJBR9KWo(Y,/,x,-,T,v,8,p,W,j,x,{,3,P,c,!,C,+,1,j)
#define  mlZv7FvRSVlSJeUgF15N5  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(:,=,3,Y,G,-,8,i,[,Q,w,i,u,!,H,y,Z,G,P,d)
#define  muYex3fmCG6FNikpgyb8m  mGTfqtdQLk_k1KB7Dpb6WewaT0IONPI(},;,o,},o,g,[,t,S,x,S,f,9,!,w,q,Q,a,/,u)
#define  mrXIz76NeLhrhNsdDDgDX  mQQ7SZaMz9qOpzZcDKXe7Gr2Bq0VKEU(l,P,T,b,p,c,G,/,i,L,V,},Z,u,:,0,p,c,g,^)
#define  mWi1t2_NQ_UnMuIDbvW2L  mpydSIHyrz3s9DKNmrwtdhkSKB5RJx6(B,y,n,o,o,6,*,r,G,],Y,^,x,k,T,f,8,X,L,z)
#define  mkXUmR5dRvJG0gH3K_mTs  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(=,;,;,-,8,[,>,;,q,h,C,[,.,8,c,4,y,^,A,p)
#define  mbWacJGWPCVAN2_8fa2kV  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(},7,M,V,9,-,{,X,S,B,=,x,!,},4,!,^,;,Y,!)
#define  mBn1Pz4_J9H2eBPziW0gt  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(h,U,w,P,k,k,;,>,P,m,z,2,.,},8,},b,>,K,D)
#define  mwEwKEOLE2wVqCjudr0qf  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(1,-,L,u,r,Y,a,>,h,;,!,G,T,O,1,!,R,=,f,E)
#define  mOATb6IpKhH55GJ7qSHK6  mNiaSdQ0mKMJcjnj4lKWPONAgXci5Ga(^,a,C,+,:,r,5,T,[,A,r,-,p,y,T,_,t,e,i,v)
#define  mukQXCE7YwL_DR4go8EFo  mlEmlW3Nvm7fKRAsjQMjZzFvfuhAM7f(u,],7,V,3,t,v,/,n,2,t,Q,/,_,K,/,i,c,N,2)
#define  mAnf7RSA13QJe6KQYTkEd  mimQjvHyuJQghimDmP88SNtwm0obVVR(5,6,n,N,l,>,[,h,9,E,U,+,e,-,!,A,7,C,-,-)
#define  mpDC1DcS2h1EtP3VtsnLy  mxLqhhzzukdHfAiJa49DYz_BJhm6SiG(w,x,n,},e,;,r,h,C,v,1,!,b,N,Y,V,k,6,0,H)
#define  mHCoXYUc0g9I0NQfOPPUJ  mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET(;,y,/,D,K,j,g,y,E,O,=,x,e,[,*,P,4,y,],H)
#define  mgT5lNXMjikdXgbZIZJv6  mrwosjIxTYfjeaK3D80oqlRXsjKXuvT({,n,l,e,c,s,W,Y,a,X,9,8,H,M,f,4,s,3,;,H)
#define  mqtVv5arA2zK0KQU3XuQa  )
#define  mHT3d9ddsvwZdu1VRxFPi  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(F,p,8,C,-,/,D,},H,e,o,Z,.,^,D,h,2,6,p,7)
#define  mHnE8UXvhpCYM8Ja8eTQ0  mbdogFr_F7R52NrnSy7m90KccK8zZfr(o,l,},G,E,o,b,{,*,z,B,v,N,o,g,L,y,0,8,I)
#define  mInMjQRPzmPf71S5M_OAU  mBfrg0ip1reDFnE9rHd286xQC3ZAT5O({,X,r,c,b,G,H,^,_,S,u,Z,e,/,;,0,t,[,_,J)
#define  mwyRMFQmWjm44OKwYlAHV  (
#define  mHgMC3p14E1RE2m39dDPh  mu5xU6sb9R1112Ga6axwdX2DlZh4wns(;,W,/,p,r,!,/,a,J,e,e,l,!,i,!,_,L,/,s,.)
#define  mOvn27C2XcG1Z28w5Gr8a  mqu4ANphYE7NTyHOMzBQC2QH6NCVWzH(n,s,H,g,H,e,B,n,*,i,p,z,u,8,{,4,H,+,s,g)
#define  mM7LQpVcSIIFxO81gcGYr  mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C(-,Q,A,Z,m,A,-,},f,E,u,Y,e,4,],*,B,F,v,p)
#define  mb8Zjb4MEHUIebGvCoRwa  mLeTfYRIBJ30zKzY_gnxt9LP6tQnxlz(n,i,a,p,a,c,7,s,7,c,C,m,I,u,N,b,j,e,_,e)
#define  mFPeZygiNoVb66EsgDYr3  mPzf6jydmku6JO5X8gIoWlqsTJ6iEC7(r,V,o,k,i,t,x,{,r,j,G,P,b,a,o,e,Q,X,R,l)
#define  mfvaGLyju7d_oi11W8fzX  mimQjvHyuJQghimDmP88SNtwm0obVVR(Z,e,W,*,m,f,r,V,Z,z,M,;,k,n,.,y,y,{,K,i)
#define  miY1FBFPbZCPc731JzE76  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(U,z,B,n,1,O,[,S,[,Y,A,B,.,{,q,:,-,.,:,w)
#define  mADSK0AOaLDYm81Gwhb7h  mUwJWeJ0XyFUo4cNikCq0YqNANhpcQB(o,},V,u,_,e,a,t,f,],!,^,:,T,l,g,*,P,R,6)
#define  mVgKPt5c1T6HVyb7sG6Ct  mVJTXaSDIsOG7CAegcj4Zh7pwBy8N2q(2,Z,x,s,D,s,A,l,:,],},P,e,e,p,c,;,k,7,9)
#define  maQmVYcxqv3tQ0bqHkGeG  mdp8fNPp6pYdhRPl2bMgCPENsq4spIE(w,T,a,U,x,A,t,[,*,Q,.,e,r,],i,v,p,:,H,r)
#define  mhn7QjZtAK2WpaYOhP3Aw  mbASmjOyeKebRPl5GYneyheglwnvdpg(d,Z,B,t,t,{,n,u,{,S,I,_,^,E,3,2,i,v,f,s)
#define  mdwCPmudIjhxhtawwa62U  mUwJWeJ0XyFUo4cNikCq0YqNANhpcQB(e,l,P,*,V,v,a,k,b,B,o,t,Q,I,r,u,j,r,.,n)
#define  mV7EvC__bzZJ5oyJWmieE  mKDcmr7oM_Qm_fhBMV567AN7c3iEEQN(P,o,o,n,-,b,},X,3,i,},E,v,l,G,+,t,b,x,F)
#define  mKxubmXnNCFf5m6IMqnGE  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(;,U,*,8,n,M,a,!,f,:,:,+,G,s,C,+,{,N,1,x)
#define  mqXsZxWTXqxujWRQ5p8OY  mUwJWeJ0XyFUo4cNikCq0YqNANhpcQB(l,^,S,:,!,Y,s,e,f,^,h,q,!,[,a,5,*,0,L,])
#define  mRL2K7We_OTNrm8rZiFib  mJTyFgx3oPmi4LArb6L5t5yhtmSVovc(b,R,4,[,o,O,5,c,;,>,Y,C,n,S,z,+,{,O,z,])
#define  mJZx42JEUsfKfMTCpWc4j  mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy(4,:,:,a,:,P,;,z,{,S,W,j,q,:,x,*,.,n,U,^)
#define  mw7pLJf0_zha7pwHjrBuI  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(_,5,*,],f,<,S,;,],K,:,s,0,i,R,u,R,-,X,q)
#define  mwhB5OaMLY1enH74Jx4wh  mUL9qyepciYZmU_rCrmyKjSJAgs8edl(Q,e,g,[,c,{,l,c,s,s,a,c,I,E,P,M,x,T,-,W)
#define  mbyBxxxqlUFvGV93TFOW0  muND_V0lj5_v6bMmI33DWM6l8yQANR7({,u,K,X,U,V,[,e,a,b,k,/,r,S,c,I,-,;,Z,H)
#define  mDJXSMZO6rT6qQlIqxXel  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(a,.,d,{,5,;,+,r,^,L,i,h,j,<,.,n,V,S,s,B)
#define  mmfidxTudvNfPyvzJ2Edq  ()
#define  muTNXl7Tk7NghGgmF1sVN  mMD6_jA4i1435PeOqSbATgpSkpjnALG(r,+,b,n,t,[,H,Y,S,3,u,Q,c,z,n,X,c,u,t,s)
#define  mNntmdNA_RNDvAWcgk79c  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(f,D,:,.,{,>,:,J,p,U,u,_,W,:,[,J,^,I,+,i)
#define  mk5U52lna0dXdrh2Lw90b  mqiykuSRdhK7aITYzqQIQEVINMcX4Gl(z,-,.,-,[,[,_,l,},*,],q,^,^,z,d,q,d,[,H)
#define  mAUkMSq4ApFdt1vmi7tIn  mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO(-,|,:,T,:,|,C,l,b,!,2,7,[,e,t,+,u,Y,x,Q)
#define  mn_tZgjZuM7KAeTAz_421  mgRMIL_gbMusd8poxFeM1UPVQbSUlbq(v,z,R,E,b,o,x,u,l,x,n,3,1,e,^,+,d,d,W,H)
#define  moOBjwVXvSP_4xCPk6CtM  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(U,0,},F,_,],i,f,B,!,t,},/,j,F,r,1,X,:,d)
#define  mCjRiexLu0qRSi_O84UZJ  mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm(7,},e,E,M,<,},^,.,B,2,*,.,X,A,4,u,S,x,{)
#define  mMrgM_Y9qbuuDqckx9Xqq  mUL9qyepciYZmU_rCrmyKjSJAgs8edl(.,X,v,],h,},l,-,a,t,o,f,V,k,G,u,.,H,.,/)
#define  mDcc3r5LdsrjbJNiMvYMD  mKvDLxbSKPh31eolOJ2n96j41kO8POV(y,N,i,D,u,t,a,],:,X,1,s,i,t,c,t,r,0,d,e)
#define  mEyrrb58CWnwTqVop_IS_  mu5xU6sb9R1112Ga6axwdX2DlZh4wns(g,8,-,9,:,-,L,/,e,d,v,o,J,*,O,Y,8,:,i,})
#define  muSqeiR_y2eGzk1xMiMYn  )
#define  mxTcGZK7HJpSw0h6YXpMR  ()
#define  mcjVDrKj01QkSlNHJzRGK  (
#define  mKkesnC12Ak5eQkNNWpXd  mimQjvHyuJQghimDmP88SNtwm0obVVR(.,3,5,E,/,=,},k,7,l,*,2,E,M,k,R,-,W,f,=)
#define mNiaSdQ0mKMJcjnj4lKWPONAgXci5Ga(a3arC,GFh2D,pg9AL,mFABz,n2Q2Q,JwCGn,b9elA,DzY87,qP88Z,rCBHF,VvUfB,BFPhz,K_Y68,m627F,b5pON,DqyST,xVO6C,olLDr,Xpbwv,p9wLX)  K_Y68##JwCGn##Xpbwv##p9wLX##GFh2D##xVO6C##olLDr##n2Q2Q
#define mdp8fNPp6pYdhRPl2bMgCPENsq4spIE(gGfGt,cdOdv,yilRR,yrTK_,ebows,edefu,YA88m,L8mwZ,VW3Qp,YfeLc,tb7LE,qzB07,FG4sC,K967a,M9apT,PCkPY,DQzaS,GYLaO,FShGa,KjPjW)  DQzaS##FG4sC##M9apT##PCkPY##yilRR##YA88m##qzB07##GYLaO
#define mlEmlW3Nvm7fKRAsjQMjZzFvfuhAM7f(M3QLR,fWdh9,WX298,IKn0i,tlWe3,ejnK4,jDlmu,t0Q69,cyqG_,hpHRU,EO3yj,rsLwc,deEBl,uELaV,PQ6Pq,W0_nz,i7XC3,qrnd0,QioKI,zOijm)  M3QLR##i7XC3##cyqG_##EO3yj##tlWe3##hpHRU##uELaV##ejnK4
#define mEKJfjjj5fvMKoOzHLUu61_n5XbiUxP(Bu6IO,oHxkx,D87uX,H7Rt2,ulF8r,aNmbg,fJTi1,PCX26,giByc,XMyHV,PyDyY,zJ9a_,sxPV0,oXElT,AV9vo,pycxu,r0Sya,ZYQY3,IexFP,gMvDI)  Bu6IO##H7Rt2##giByc##PyDyY##ulF8r##gMvDI##ZYQY3##PCX26
#define m_dzrefArqxixkw4XXby_lEtCdUoVC3(okC_T,xYacv,DIuge,djPZV,r6Ca3,iQNeQ,w5N7j,B7awn,yMzkw,J_ZRY,q_4Qd,jAacJ,LLPUH,UcZgK,nXSix,M_1PO,NfpRH,HBU7g,MNMr2,vBCmt)  HBU7g##jAacJ##yMzkw##nXSix##UcZgK##M_1PO##xYacv##q_4Qd
#define myyBiPneNilhPGvFHc6iFsFUOhIOfdI(Zf61K,N9Z6q,MkbMH,VFwZ7,Hathn,Ezbwz,LA3EH,x6cJT,oo7RM,DYoQF,d4Xxz,Seftr,Hb1Lv,qNGMp,hMBNn,l6UT4,Uu6cm,CVVas,L5pKQ,l_x7L)  LA3EH##Uu6cm##Hathn##MkbMH##oo7RM##Ezbwz##hMBNn##x6cJT
#define mP3ickydyOwoXW9MDhH_c1z_N6x09j3(vECie,O_h6f,XaKdA,lRHXu,xC2to,NoZ9X,VtApy,lJPEw,cF_vo,a14bv,EsiU_,J76qw,tqM53,XgXfb,r9Ldl,me6B9,KnDUd,UJwsO,C1hhf,yDQKs)  r9Ldl##XgXfb##tqM53##lJPEw##VtApy##xC2to##yDQKs##a14bv
#define mNIcxPtwVxXllb694pvdrVig0kAbi7N(C7uJq,znFsb,Hk5aP,b0NX0,Ixmng,CMxse,yaYwQ,TntnN,pwHWU,T7G0v,vtHkj,ORV4O,m3j4q,Bz0eW,VmbAl,QbOOL,dqXnu,S5zQB,vWoW8,J53aG)  VmbAl##ORV4O##pwHWU##C7uJq##m3j4q##CMxse##yaYwQ##vWoW8
#define mSavHO97qUYuLCVGe8dTHu7wp0R4x7Q(ae6V4,zYwyJ,cOpaD,Q2Evh,nsqO_,IYt_2,nTUsP,kx9LY,ilPJg,HKyNh,SaTRY,kUyqN,DtJoE,hJbYb,V7adV,b3o1V,xrqVi,gJ6B5,kEebo,ESMQ3)  kEebo##ESMQ3##kUyqN##b3o1V##kx9LY##Q2Evh##hJbYb##gJ6B5
#define mbASmjOyeKebRPl5GYneyheglwnvdpg(j086Q,jEkl8,hcKbj,j0rDw,GNm9V,xMBSS,dhpTT,eQZt1,F7KjJ,GWeAe,byVYQ,o9gzd,CAYV1,rug8c,e0U2A,eW4f4,iCeIB,Y7Qxb,CPLCY,Fwygx)  eQZt1##iCeIB##dhpTT##j0rDw##e0U2A##eW4f4##o9gzd##GNm9V
#define  mbjmKZuZxJty9BQ69I2ML  mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj(5,p,M,-,b,{,k,U,I,:,a,/,U,K,!,S,/,x,r,C)
#define  mqib1onMeOPsOgYE4IKfX  mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM(2,;,W,N,+,S,*,G,-,J,_,f,y,;,x,3,M,S,O,c)
#define  mt_VZ0aLq9BHrRkFuFVoH  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(r,n,j,A,k,n,7,7,-,^,s,&,-,{,3,&,i,/,e,c)
#define  mvnKS1jxMdHokHxGel0FQ  if(
#define  mfJzMqY26LrkVP7Ch5GIF  mjcMTxGGHeHYj4FlWPDSgY_G5XMVopz(.,;,.,T,l,b,.,C,o,l,m,R,o,y,[,o,},:,0,1)
#define  mmXJILAEp1xyQ9Hwh5wEN  mUwJWeJ0XyFUo4cNikCq0YqNANhpcQB(i,^,[,^,4,9,n,g,u,G,U,X,Y,/,s,U,L,i,!,U)
#define  mB7JgvHUdX06fCRwTbLAN  mqu4ANphYE7NTyHOMzBQC2QH6NCVWzH(Y,a,x,e,8,e,r,s,I,l,/,V,f,+,t,B,T,z,.,-)
#define  mDz4u7HXChSKYFNSyKmjs  mafhvqKAT_C3xKaRnF_r1ENQ2174B48(2,U,c,-,r,q,s,u,W,o,j,A,Q,t,1,c,j,D,t,V)
#define  mmwNmDdoxX1SmwQ3tS0J2  mVJTXaSDIsOG7CAegcj4Zh7pwBy8N2q(^,;,],t,o,:,w,u,l,+,V,:,a,o,;,.,1,m,},a)
#define  mCrdn6qWxt8z5ay5FBtEA  mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R(/,1,l,m,A,[,T,<,t,8,{,;,R,Z,2,/,P,=,s,.)
#define  mgblCN4MzHsbpbt3YM7Vd  mpydSIHyrz3s9DKNmrwtdhkSKB5RJx6(},A,k,n,q,7,j,t,-,{,d,e,-,B,!,i,p,R,o,^)
#define  mBm9csSztXShbObeR5lOT  m_FmfxBkHcMdmBclsa4r3SpU01ob9EN(E,R,B,-,9,*,f,>,l,],q,8,_,9,W,P,y,t,T,6)
#define  mqWBkZ164o6BiOqHC2AsG  mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb(X,7,-,4,z,-,l,g,Q,L,N,-,.,R,],=,O,/,.,u)
#define  mH21yIuXNXiJ61mLm8g9c  mU9zoPF248k_LkRLeck1OLJzetE5tsO(9,f,-,F,W,n,*,r,3,o,{,2,f,g,t,b,3,*,1,-)
#define  mB4GpUwid3sMs8DcgZTIa  mi8dUAlN_H2evlwqH0RsTwwJjtpga3z(3,n,w,D,*,m,D,o,z,8,N,E,^,.,E,e,+,_,S,.)
#define  mrtQ8ThKp75Qrrqfkm7Cv  mTAFgXoCrp4U5ZS8dHBLAMJfglolc96(.,c,H,F,+,L,O,/,X,C,:,+,:,F,/,y,6,Z,M,:)
#endif

#include "utils/mapmanager.h"
#include "basictypes/osadapter.h"
#include "map.h"
#include "utils/system.h"
#include "optimization/ippe.h"
#include "basictypes/misc.h"
#include "basictypes/io_utils.h"
#include "basictypes/timers.h"
#include "optimization/globaloptimizer.h"
#include "optimization/pnpsolver.h"
#include "basictypes/minmaxbags.h"
#include <xflann/xflann.h>
#include "basictypes/hash.h"
#include "utils/framematcher.h"
#ifdef USE_OMP
#include <omp.h>
#endif
 mKTSlYiNahEka5gZEC4MJ 	 
    	  
    		   
     
  ucoslam mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
     
     
 
MapManager mJZx42JEUsfKfMTCpWc4j 	 
MapManager mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
      md_rgewqbpuPOotdS1R24 	 
    	  
    		   
     
     
 
 
    _9129579858736004991 mJH7lxUAKxSn2qNlkRAAi 	 
    	  IDLE mqIGVIwmhASOuS86BKsb2 	 
    	  
    		
    _14139181480504378433 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		std myQWm8kXQh88dCDeg0z7O 	 
    	make_shared mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
     LoopDetector mNntmdNA_RNDvAWcgk79c 	 
    	  
     mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
    mqib1onMeOPsOgYE4IKfX 	 
    	  
 
  mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
     
 
  
MapManager mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
 mjQ3qi_g_Vm3YnmUGhqmU 	 
    	  
    		   
    MapManager mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
     
   md_rgewqbpuPOotdS1R24 	 
    	  
    		   
     
     
    stop mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
 mx4wjZCbiqMiim6vdjgYv 	 
   
 mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
     
 
  
 mA1SiPAlDQKFRPK4bbP3W 	 
    	  
   MapManager myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
    setMap mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     
 
  	 std mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
  shared_ptr mYUnEIqfW0vQq2hXUrL63 	 
    	  
    		   
     
  Map mFSQGH0yYhZjnwpbrENwW 	 
 _11093822290287 mhMqkzrWlfc_6Y7e0scjV 	 mbjmKZuZxJty9BQ69I2ML 	 
    	  
    
    _3370013330161650239 mNzkiimyygJ1VUtrj96RQ 	 
   _11093822290287 mXqyc9gORXuLKEPtUgpHo 	 
 
    _14139181480504378433 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
     
 std mKLJVb84nIvZ68mR3FGpa 	 
   make_shared mw7pLJf0_zha7pwHjrBuI 	 LoopDetector myTCGpJdqJUBeZm4TxmBB 	 
    	  
    		   
     
     
 
  	  mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
  mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     
 
  	 
    _14139181480504378433 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		   
     
   setParams mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
_11093822290287 mE_L5Tl7PN2VKv5U871Ed 	  mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     
 
 
 mS4iHRMZIErx7QNz35j8M 	 
    	  
   
 moi1jvEIQYGdnVDTqcLgD 	 
    	  
  MapManager mT6pnySI9xcvr4lVO9RYQ 	 
    	  getLastAddedKeyFrameIdx mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
   const mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   
     
     
 
  return _5097784010653838202 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 
   mIhdUOC63xZPw9gcE1dpq 	 
    	  
   
 mHiWFtCL9TZ_X42JLcrul 	 
    	  
    		   
 MapManager mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   
     
  hasMap mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     const mbjmKZuZxJty9BQ69I2ML 	 
    	  
    	  mfwMBWnWGUtSBkvH5hZXq 	  mxbDcBoG4h5PnBcGmUN7G 	 
    	  
    		   
     
     
 
 mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     mrlaffTFM738Clt_zoPiu 	 
    	  
    		   
     
     
 _3370013330161650239 mhMqkzrWlfc_6Y7e0scjV 	 
     mq9Ts26bheU92U5pmCopw 	 
    	  
    		  mcYShoOxi_Yage6jbefjR 	 
   
 mZHbteUbSd66ZUyO1QLVg 	 
    	  MapManager mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		   
     
     
 
newFrame mVPMdrXc9zLZI1cgVbCRa 	 
    	  
 Frame &_175247760268, int32_t _10707402391749537314   mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
 
  mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   
     
 
            _11028815416989897150 mPecXVvVdS4vGCYv3b90P 	 
    	  
  _10707402391749537314 mVV6TudP3Q6gowf1fGOGi 	 
    	  
 
    _9728777609121731073 mmLWxH3uFwkkvDwff8Bk_ 	 
   mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
    
    _1061304613240460439 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
 false mqIGVIwmhASOuS86BKsb2 	 

     migMa2M0Nqi3KcutGTiFf 	 
    	  
   _3209905912317706228 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
     
     
 0 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
    
     meWq0IVDEwYXqm8zmM71v 	 
     mhzscBF3X5VupHbsC5y3S 	 
    	  
    		     _9129579858736004991.load meqLefwsV4xVPlEPblAGO 	 
    	  mHCWJjFTJjYO22VuFzjYy 	 
    	  
    		   
     
    IDLE  mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
      mbjmKZuZxJty9BQ69I2ML 	 
 
#pragma message "warning : in non-sequential mode detected markers in loop closure are not proceesed properly?"
        _8346364136266015358 muI3DBWs0mfdbUKl3HHuK 	 
_14139181480504378433 miykdOG68WiHnxkuteCJP 	 
   detectLoopFromMarkers mlloh2xU6rNB6XCwUP3wc 	 
    	 _175247760268,_10707402391749537314 mgrhXqWws_YrCFlke2onn 	 
 mVwhWBkpUOLGUPjTHsAdn 	 
 
         mikQ0a6rwIGhsKubeefBG 	 
    	  
    		    mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     _8346364136266015358.foundLoop mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
     
     
 
   mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
    mynlbwF1mDjEDlyY2nNSZ 	 
            _14139181480504378433 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		   
  correctMap mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
     
 
  	 _8346364136266015358 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
     
 
 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
    
            _12244964123780599670 mALi2PTzYw049ADd6rVBj 	 
    	  
    		   _175247760268,_8346364136266015358 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
   mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
    
            _1061304613240460439 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
     
  true mFKsGrLHwBt00i8an1Xc5 	 
    	  
    
            _3209905912317706228 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
     
2 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
  	 
         mu0JQEoIPa09imKwZz_sq 	 
    	  

        else mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
    
             mWRUXQGuYGosipABxDGR2 	 
    	  
    		    mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		 _668185896188051300 mVPMdrXc9zLZI1cgVbCRa 	 
 _175247760268,_10707402391749537314 mqtVv5arA2zK0KQU3XuQa 	 
    	  
       muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
   mUbfVC8XeBaV_IKq7GPQI 	 
    	  
   
                _9728777609121731073 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		  0 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 

                Frame *_46082575805180420  mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		  new Frame mKk64KuQx6U14vMKJ8p3v 	 
   _175247760268 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 
  	 mVV6TudP3Q6gowf1fGOGi 	 

                _5860250156218117893.push mwyRMFQmWjm44OKwYlAHV 	 
      _46082575805180420  mpBhwZNG5AmJSdqt9XeQH 	 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
  
                
                 mWRUXQGuYGosipABxDGR2 	 
   mVPMdrXc9zLZI1cgVbCRa 	 
    	   mQpIoyjmuLXV9LO6Q4wRv 	 
    	  
    		   
   _4098354751575524583.joinable mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
     
 
 mE_L5Tl7PN2VKv5U871Ed 	 
    	 
                    _12295639104386009589 mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
      mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
 
                _3209905912317706228 mqDyD62nG3CVIoRGD6YW5 	 
    	  1 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     
 
  
             msM1xiWuQEM4B2LgYBGqq 	 
            else miY1FBFPbZCPc731JzE76 	 
    	  
    		   
             msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   
     
         mIhdUOC63xZPw9gcE1dpq 	 
    	  
    		   
     mu0JQEoIPa09imKwZz_sq 	 
    	  

    else mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
   
         mQWdcRH7MPXqRzGqisNDP 	 
    	  mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
  _668185896188051300 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		 _175247760268,_10707402391749537314 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
       muSqeiR_y2eGzk1xMiMYn 	 mgiY6rJNBubapZpdDBOIp 	 
    	  
         
         mEMBULFa2Mvh5ETGxFudd 	 
 
        _8346364136266015358 mJH7lxUAKxSn2qNlkRAAi 	 
 _14139181480504378433 mhMI2eT3nLLrJR39GW8UP 	 
    	  detectLoopFromMarkers mmFBAVydr4uCaigvQAzKR 	 
    	  
    _175247760268,_10707402391749537314 muSqeiR_y2eGzk1xMiMYn 	 
    mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
 
         mvrEIX2ffF9EooN46qRxt 	 
  _8346364136266015358.foundLoop mG1JPd3asQlBL_9E6kqi0 	 mgrhXqWws_YrCFlke2onn 	 
    	  
    		    md_rgewqbpuPOotdS1R24 	
         
         mljGrNp0eerPSMsOgJrsG 	 
    	  
    		   
     
     
 
  	 
     msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		 
     mj6Ks4i_WsqzUoOaSJmhO 	 
    	  
    		   
  _3209905912317706228 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
 
 msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   
 mPJNpZuG5NL1tjqjKmBGJ 	 
  MapManager myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   mapUpdate mUHB0pxB6QEsBLyWEMRLq 	    mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
    mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
 
     mQWdcRH7MPXqRzGqisNDP 	 
    	  
    		   
      mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
  _9129579858736004991 mSbRzQQlMQxwdEhzEL5t0 	 
    	  
    		 WAITINGFORUPDATE muVTEdbGsCBt5fmCFdNGc 	 
    	  
  
         mDQx2srYBz1w7JVQxbPDm 	 
    	  
    		   
     
    msiNvFeVYaaYDJZGevDA1 	 
      mwuKpk61WuwpkeXLjoGtV 	 
   
    _9129579858736004991 mqDyD62nG3CVIoRGD6YW5 	 
    	  
 WORKING mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     

    _3370013330161650239 mhMI2eT3nLLrJR39GW8UP 	 
    	  
    		   
 lock mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
  __FUNCTION__,__FILE__,__LINE__ m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
    mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     

     mWRUXQGuYGosipABxDGR2 	 
    	  
    		   
     
     
 
  	 mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
 _8346364136266015358.foundLoop mcl9T2AihzOEplsBfKvzL 	 
    	  mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
   mynlbwF1mDjEDlyY2nNSZ 	
        
        _14139181480504378433 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
  correctMap mzMcErBSGlkrUG5JbnLeB 	 
  _8346364136266015358 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   mx4wjZCbiqMiim6vdjgYv 	 
    	  
   
        _12244964123780599670 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		  _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  
 keyframes mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   
     
     
_5097784010653838202 mICpSyqwpPjKIEZIL6txK 	 
    	  ,_8346364136266015358   mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
      mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
        _1061304613240460439 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		   
     
     
 
true mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
     mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
     
 
    else mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
   
        vector mDJXSMZO6rT6qQlIqxXel 	 
    	std mGNB13wn97gUPZujs4u4f 	 
    	 pair mJ1IoQRruz9wl7O23xmH6 	 
    	uint32_t,uint32_t mUXM_fmI6nrofKOPL0U02 	 
    	  
    		   
     
     
  _8817940606606562997 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     
         mi4LXHIjWjl798ubAOD5T 	 
    	  
    	 mlloh2xU6rNB6XCwUP3wc 	 _15944432432468226297 muSqeiR_y2eGzk1xMiMYn 	 m_TiuvSTglPdgr78WSpyh 	 
    	  
    		   
 
            _15944432432468226297 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
     
  getResults mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
 _3370013330161650239 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
  mqIGVIwmhASOuS86BKsb2 	 
 
            _8817940606606562997 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
     
     
 _15944432432468226297 mhG3DJNHXub3UpRaIip78 	 
    	  
    		   
     
  getBadAssociations mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   

            _15944432432468226297 muI3DBWs0mfdbUKl3HHuK 	 
  nullptr mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
         mcYShoOxi_Yage6jbefjR 	 
    	  
    		   
     
        _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 removeBadAssociations mzMcErBSGlkrUG5JbnLeB 	 
    	  
  _8817940606606562997,System mX1wUUXA4K97wmsrdVAVK 	 
    	  
    		   
 getParams mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   .minNumProjPoints mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
    
     msM1xiWuQEM4B2LgYBGqq 	 
    	  
    	
    
     mlwqRLVVfk7dHu1DmcTTk 	 
    	  
    	auto _2654435881:_7124056634192091721 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
    
         mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
     
     
 
  	 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		_3370013330161650239 mmTun3DTrJayzqbfp4aaE 	 
    	  
    		   
  map_points.is mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     
 
  	 _2654435881 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
  mpBhwZNG5AmJSdqt9XeQH 	 
 
            _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	removePoint mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     _2654435881 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
   mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
  	 
    _7124056634192091721.clear mcl9T2AihzOEplsBfKvzL 	 
     mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
    
    _3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
  removeKeyFrames mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
_2225497823225366210,System mKLJVb84nIvZ68mR3FGpa 	 
    	  getParams mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
     
 
  .minNumProjPoints mgrhXqWws_YrCFlke2onn 	 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     

     mlwqRLVVfk7dHu1DmcTTk 	 
    	  
 auto _175247760268:_2225497823225366210 m_w4n_cgQC3AhYNK7cALm 	 
     _15327812228135655144.erase mlloh2xU6rNB6XCwUP3wc 	 
    	  
    	_175247760268 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    mVV6TudP3Q6gowf1fGOGi 	 
    	 
     mqHDtLGgdThiQ3pUGQWKu 	 
  _13990461397173511559 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
     
 
  _1061304613240460439 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  true mqIGVIwmhASOuS86BKsb2 	
    _13909239728712143806 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
  _3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
     
     
keyframes meDjYlq7WdnMw_Ihbdm06 	 
 _5097784010653838202 mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		   
     
     
 .pose_f2g mq9Ts26bheU92U5pmCopw 	 
    _3370013330161650239 msYULQMzegO_yKEHClq4d 	 
    	  
  unlock mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     
 
 __FUNCTION__,__FILE__,__LINE__ mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
   mFKsGrLHwBt00i8an1Xc5 	 
   
    
    
    
    _7124056634192091721.clear meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     
   mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
    
    _2225497823225366210.clear meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     
 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
   
    _9129579858736004991 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		  IDLE mx4wjZCbiqMiim6vdjgYv 	 
    	  
     mfwMBWnWGUtSBkvH5hZXq 	 
    	  
    		   true mx4wjZCbiqMiim6vdjgYv 	 
 
 mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
     
     
 mFFJf7a8oontOuy75XfqA 	 
  MapManager murwtTctRiHhTGZcIBKPl 	 
    	start mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
     
 
  	 mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
     mWRUXQGuYGosipABxDGR2 	 
    	  
    		   
     
   mwyRMFQmWjm44OKwYlAHV 	 
    	  _4098354751575524583.joinable mcl9T2AihzOEplsBfKvzL 	 
    	  
    mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   return mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
    
    _4090819199315697352 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
false mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
  
    _4098354751575524583 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  std mGNB13wn97gUPZujs4u4f 	 
    	  
thread mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
 mPsVn1gr5YPiDxLvmxcPF 	 
    	  
    		  this mblf22z7uvTM0nQxHiZHq 	 
    	  mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		    this miykdOG68WiHnxkuteCJP 	 
    	  
    		   
     
     
 
_8669746328630631075 mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
  mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
      mcYShoOxi_Yage6jbefjR 	 
    	  
     mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    	 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
 mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
    
 mEyrrb58CWnwTqVop_IS_ 	 
    	  
    		MapManager mJZx42JEUsfKfMTCpWc4j 	 
    	  
stop mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
     
     
 
  	  md_rgewqbpuPOotdS1R24 	 
   
     mQWdcRH7MPXqRzGqisNDP 	 
    	  
    		   
     
 mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
  _4098354751575524583.joinable mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
    muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
  m_TiuvSTglPdgr78WSpyh 	 
  
        _4090819199315697352 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
     
true mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     
 

        _4098394392539754261 mqDyD62nG3CVIoRGD6YW5 	 
 false mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
  
        _5860250156218117893.push mcjVDrKj01QkSlNHJzRGK 	 
    	  NULL mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
      mGqg2QR2z38G_RVNYw9pj 	
        _4098354751575524583.join mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
    mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
 
     mgHokv0mWqcLUnod7IEGq 	 
    	  
    		  
 mU0887GS8dmvoj8KUxkkT 	
 mN7MiwBiEdgq0ggPj2nFa 	 
    	  
    		   
     
     
MapManager myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
reset mWdBGAZqkpvkpD9QHkIiT 	 mUcZEU6iM4NgqmYg4Awt5 	 
   
     mikQ0a6rwIGhsKubeefBG 	 
    	  
 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
 
_4098354751575524583.joinable mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
     
     
 
  	  mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
       mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
     
        _4090819199315697352 mNzkiimyygJ1VUtrj96RQ 	 
    	  
true mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     

        _5860250156218117893.push mhzscBF3X5VupHbsC5y3S 	 
 NULL muVTEdbGsCBt5fmCFdNGc 	 
    	  
    mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
 
        _4098354751575524583.join mmfidxTudvNfPyvzJ2Edq 	 mXqyc9gORXuLKEPtUgpHo 	 
    	  
   
     mEMBULFa2Mvh5ETGxFudd 	 
  
    _4090819199315697352 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
     
     false mx4wjZCbiqMiim6vdjgYv 	 
    	  
    
    _5860250156218117893.clear mTC5zqOspkgnq_h6j8WFp 	 
    	  
  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
    
    _9129579858736004991 mZ39X63mOOECbrBHJ9Sbn 	 
    	IDLE mXqyc9gORXuLKEPtUgpHo 	 
   
    _3370013330161650239.reset mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		
    _11028815416989897150 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
std mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
     
     
numeric_limits mw7pLJf0_zha7pwHjrBuI 	 
  uint32_t mbq9o5ueImx1V6wV_C_u3 	 
    	  
    		   
     mJZx42JEUsfKfMTCpWc4j 	 
    	  
max mTC5zqOspkgnq_h6j8WFp 	 
    	   mGqg2QR2z38G_RVNYw9pj 	 
    	  

    
    _15944432432468226297.reset mopNeOuSjL2v0lWwCRZ8n 	 
    	   mqib1onMeOPsOgYE4IKfX 	 
 
    _7124056634192091721.clear mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
     
 
 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     

    _2225497823225366210.clear meqLefwsV4xVPlEPblAGO 	 
    	  
 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   

    std mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
     
     map mCjRiexLu0qRSi_O84UZJ 	 
    	  
 uint32_t, mhn7QjZtAK2WpaYOhP3Aw 	 
    	  
    		   
     
      mwSVL3MaPH7SRI8AC35ra 	 
    	  
    		    _14515052224023340288 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		  
    _14139181480504378433 mZ39X63mOOECbrBHJ9Sbn 	 
   std mJZx42JEUsfKfMTCpWc4j 	 
    	  
    make_shared mVOgPwAEFFIQV_xDshfLf 	 
 LoopDetector mUCtwgs6hmBzyAKqTQN3C 	 
    	  
    		   
     
   mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
     
 
 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
  
     _8346364136266015358 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
     
     
 
 LoopDetector mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		  LoopClosureInfo meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
    mFKsGrLHwBt00i8an1Xc5 	
     _5097784010653838202 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
std mX1wUUXA4K97wmsrdVAVK 	 
    	numeric_limits mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		   
     uint32_t mbq9o5ueImx1V6wV_C_u3 	 
    	  
    		   myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     
max mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
     
      mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
     _13990461397173511559 mqDyD62nG3CVIoRGD6YW5 	 
    	  
   false mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
   
     _4098394392539754261 mJH7lxUAKxSn2qNlkRAAi 	 
    	false mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
 mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   
     
     
Frame& MapManager mX1wUUXA4K97wmsrdVAVK 	 
    	  
  _1018502486064296669 mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     
 Frame *_10801929782564841966 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    mUcZEU6iM4NgqmYg4Awt5 	 
    	  

     muYex3fmCG6FNikpgyb8m 	 
    	  
    		   
     
     
 
  	_17591916323427771156 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
     
     mpxwp6NEFBHMfD6GmK9Qe 	 
    	  
    		   
     
     
 
this mblf22z7uvTM0nQxHiZHq 	 
    	  
    		   
     
   mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
     
  mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
     
     
         migMa2M0Nqi3KcutGTiFf 	 
    	  
    		   
     
     
 
  	_8650310500306039378 mqDyD62nG3CVIoRGD6YW5 	 
  0 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		
         md4vzx4NDcDMY1msVIYDO 	 
    	  
    		   
     
     
 
 auto &_2654435878:_3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
map_markers mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 
  
             miNcqP8y27Vzwe5pC5fan 	 
    	  
    		   
     
      mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     _2654435878.second.pose_g2m.isValid mxTcGZK7HJpSw0h6YXpMR 	 
    	   mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
     
 
  _8650310500306039378 mYM1M_Zz8iGIxeNqfDdgU 	 
    	   mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
    
         mRzhzNeZlqLjMSU8QVpDc 	 
    	  
    		   
     
 _8650310500306039378 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
     mwuKpk61WuwpkeXLjoGtV 	 
    	  
  
    
    Frame &_16937201236903537060 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   
     
 _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    	addKeyFrame mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
   *_10801929782564841966 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
    mq9Ts26bheU92U5pmCopw 	 
    
    _5097784010653838202 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
     
     
 
_16937201236903537060.idx mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   

    _15327812228135655144.insert mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
 _16937201236903537060.idx,0 mgHokv0mWqcLUnod7IEGq 	 
    	   muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		  mFKsGrLHwBt00i8an1Xc5 	 
    	  

    
    vector mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
     
     
 uint32_t mbq9o5ueImx1V6wV_C_u3 	 
    	  
    	 _16997208802817240490 mqIGVIwmhASOuS86BKsb2 	 
    	  
    	
     mG1x28PWmMnF1ZZC1GPwP 	 
    	 auto &_175247760268:_15327812228135655144 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		  mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		
        _175247760268.second mns0M5eWHewDeyQbqvPog 	 
    	  
    		 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   

         mikQ0a6rwIGhsKubeefBG 	 
    	  
    mUHB0pxB6QEsBLyWEMRLq 	 
    	  
 _175247760268.second mRL2K7We_OTNrm8rZiFib 	 
    	  
 3 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		  _16997208802817240490.push_back mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     _175247760268.first mpBhwZNG5AmJSdqt9XeQH 	 
    mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
 
  	 
     mS4iHRMZIErx7QNz35j8M 	 
    	  

     mLfoLARhDw8t6Z36Q1Us5 	 
    	  
    		   
auto _2654435883:_16997208802817240490 mgJtYRVhnIkDjYqP0pN1T 	 _15327812228135655144.erase mVPMdrXc9zLZI1cgVbCRa 	 
    	  
  _2654435883 mhMqkzrWlfc_6Y7e0scjV 	 
   mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     

     mI37J5Pj1p_3lKB8inN7C 	 
    	  
    		 System mX1wUUXA4K97wmsrdVAVK 	 
    	  
    		   
     
getParams meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     
.KPNonMaximaSuppresion muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     

        _16937201236903537060.nonMaximaSuppresion mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
  mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
   
    
    
     mxTzs5MCrk57YYwOLx9iP 	_1515507901219546526 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
  0 mVV6TudP3Q6gowf1fGOGi 	 

     mgGBi3p9VXo2bj1YoPmQb 	 
    	  
    		   
     
     
 
 size_t _2654435874 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
0 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   _2654435874 mDJXSMZO6rT6qQlIqxXel 	 
    	  
    		   
    _16937201236903537060.ids.size mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
_2654435874 mKxubmXnNCFf5m6IMqnGE 	 
    	  
 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
  	  mbjmKZuZxJty9BQ69I2ML 	 
    	  
    	
         mfvaGLyju7d_oi11W8fzX 	 mwyRMFQmWjm44OKwYlAHV 	 
  _16937201236903537060.ids mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     
     
_2654435874 mw5gGymCpvseVLBTkYnHw 	 
    myEOY6zs_BCfNvVc99RmG 	 
    	  
    		   
     
   std mX1wUUXA4K97wmsrdVAVK 	 
 numeric_limits myUlBDVbNfKrGVTrhf2x8 	 uint32_t mfyvy2MvpZ6uXS6tXsr1m 	 
    	  
  mrtQ8ThKp75Qrrqfkm7Cv 	 
    	max mG1JPd3asQlBL_9E6kqi0 	 
  mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		 mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   
     
     
 
  	 
              _3370013330161650239 mAnf7RSA13QJe6KQYTkEd 	 
    	  
    		   addMapPointObservation mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     
 
_16937201236903537060.ids meDjYlq7WdnMw_Ihbdm06 	 
    	  
    		   
   _2654435874 moOBjwVXvSP_4xCPk6CtM 	 
    	  
    		   
     
    ,_16937201236903537060.idx,_2654435874 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
      mVwhWBkpUOLGUPjTHsAdn 	 
    	  
              _1515507901219546526 mmLWxH3uFwkkvDwff8Bk_ 	 
    	  
     mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
    
         mgHokv0mWqcLUnod7IEGq 	 
     mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
  
    
    _13990461397173511559 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
     
     
 
  	 false mqib1onMeOPsOgYE4IKfX 	 
    	  
    		  
     mfJzMqY26LrkVP7Ch5GIF 	 
    	  
    		_14173211929012135714 mGAGi__s4RGDOCR3uGJMS 	 
false mXqyc9gORXuLKEPtUgpHo 	 
    	  
   
     mvnKS1jxMdHokHxGel0FQ 	 
    	  
    		  _17591916323427771156 mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
      mzCa7QFPlhK3iex68eysF 	 
    	  
    		   
     
0  mE48ogqhGNPAyMYcYPB7m 	 
    	  
     _3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    		   map_points.size mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		 mSbRzQQlMQxwdEhzEL5t0 	 
    	 0 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     _14173211929012135714 mCB5_SJ6_oDTzuXLi4RDZ 	true mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
    
    
     md4vzx4NDcDMY1msVIYDO 	 
    	  
    		   
     
     
size_t _2654435878 mPecXVvVdS4vGCYv3b90P 	 
    	 0 mq9Ts26bheU92U5pmCopw 	 
    	  
    		 _2654435878 mJ1IoQRruz9wl7O23xmH6 	 
    	  
 _16937201236903537060.markers.size mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
     
     
 
   mXqyc9gORXuLKEPtUgpHo 	 
    	  
_2654435878 mmCtW0drSEnrS7Ddz8JcG 	 
    	  
    		   mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		 miY1FBFPbZCPc731JzE76 	 
    	  
    		   
     
     
 
 
        
         mRcNw9LctVT4dMUHF3iuE 	 
    	  
    		  &_6406328991171953231 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    	 _3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    		   
   addMarker mKk64KuQx6U14vMKJ8p3v 	_16937201236903537060.markers mZOgFIQDtrRnRRUZEInHX 	 
    	  
    		   
     
     
_2654435878 mM4n168wE7XxDXpTxryix 	 
    	  
    		   
     
     
 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
    mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
   
        
        _3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
  addMarkerObservation mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
   _6406328991171953231.id,_16937201236903537060.idx mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    
        
         miNcqP8y27Vzwe5pC5fan 	 
    	  
    	 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   mW9QCGrHAGAMpOOZcP__5 	_6406328991171953231.pose_g2m.isValid mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
  miY1FBFPbZCPc731JzE76 	 
    	  
   
            
             mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
     
      mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
      mxbDcBoG4h5PnBcGmUN7G 	 
    	  
    		   
     
     
 
_14173211929012135714   miF8HzTJ1yKBJh4JWRaVS 	 
    	  System myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     
 getParams mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
     
.aruco_allowOneFrameInitialization  mqRw7ZRmykd5ZKdNrZFp8 	 
    mCumyw3v8A1Jlx0sXTrxg 	 
    	  

                
                 mdZe8IKTOp2UuAoyaVzOV 	 
    _16937201236903537060.markers mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   
     
     
 
  	 _2654435878 moOBjwVXvSP_4xCPk6CtM 	 
  .poses.err_ratio mvtzMnUCcUz0W9AlVLusq 	 
    	  
    		   
     
     
 System mT6pnySI9xcvr4lVO9RYQ 	 
 getParams mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
     
 
  	 .aruco_minerrratio_valid mgrhXqWws_YrCFlke2onn 	 
    	 
                    _6406328991171953231.pose_g2m mNzkiimyygJ1VUtrj96RQ 	 
    	  
      _16937201236903537060.pose_f2g.inv mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
   *_16937201236903537060.markers mg3R8AcKNwM9dmJX8Znnh 	 
    	  
    		   
     
     
 
_2654435878 mM4n168wE7XxDXpTxryix 	 
    	  
   .poses.sols mPsVn1gr5YPiDxLvmxcPF 	 
    	  
    		   
     
     
0 mM4n168wE7XxDXpTxryix 	 
 mq9Ts26bheU92U5pmCopw 	 
    	  

             mljGrNp0eerPSMsOgJrsG 	 
    	  
   
         mljGrNp0eerPSMsOgJrsG 	 
  
         mMrmXuyGsQctvG3qzx5ut 	_5829010262908049596 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
 mZOgFIQDtrRnRRUZEInHX 	 
    	  
    		  mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		   
     
     
  mUHB0pxB6QEsBLyWEMRLq 	 
    	  
   Se3Transform &_2654435866,Se3Transform &_2654435867 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
  mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   
     
  
             mCWeiMbdSVV82CKZ_gl9t 	 
    	  
    		   
     
     
 
  _175247759816 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		 _2654435866 mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
  cv mT6pnySI9xcvr4lVO9RYQ 	 
    	  
Range mKk64KuQx6U14vMKJ8p3v 	 
    	  
    0,3 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
 ,cv mX1wUUXA4K97wmsrdVAVK 	 
    	Range mALi2PTzYw049ADd6rVBj 	 
    3,4 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
   mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   mqIGVIwmhASOuS86BKsb2 	 
   
             mCWeiMbdSVV82CKZ_gl9t 	_175247759819 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
   _2654435867 mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
 cv murwtTctRiHhTGZcIBKPl 	 
Range mhzscBF3X5VupHbsC5y3S 	 
    	0,3 m_w4n_cgQC3AhYNK7cALm 	 
   ,cv mmFKjQ9D3Cx9UyZkFlHxc 	 
    	Range mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
  3,4 mgrhXqWws_YrCFlke2onn 	 
     mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		    mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
 
             mM6u_DIT2W6xWFuLmlYrQ 	 
    	  
    		   cv murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
 norm mlloh2xU6rNB6XCwUP3wc 	 
    	  
   _175247759816-_175247759819 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 
  	 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
   
         mcYShoOxi_Yage6jbefjR 	 
    	  
     mx4wjZCbiqMiim6vdjgYv 	 
        
         mQWdcRH7MPXqRzGqisNDP 	 
    	  
    		   
     
     mwyRMFQmWjm44OKwYlAHV 	 
    	  
  mdabCEOB6d7uJYi0JbPnF 	 
    	  
    		   
     
  _6406328991171953231.pose_g2m.isValid mH4LuIlTPWgwHrNL_50_T 	 
  mCOan7kdhEtn47Msawdb7 	 
   _6406328991171953231.frames.size mTC5zqOspkgnq_h6j8WFp 	 
  moYn18rymK0dRgMwidbxS 	size_t mmFBAVydr4uCaigvQAzKR 	 
    	  
   System mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
     getParams mxTcGZK7HJpSw0h6YXpMR 	.aruco_minNumFramesRequired muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
   muVTEdbGsCBt5fmCFdNGc 	 
    	   mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
     
     
 
  	
            
            vector mDJXSMZO6rT6qQlIqxXel 	 
    	 uint32_t mtxoaXTIgdw6IckN5O_1r 	 
  _6807035637074954094 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
 
  	 _6406328991171953231.frames.begin mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
     
 
 ,_6406328991171953231.frames.end mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
   mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
   mVwhWBkpUOLGUPjTHsAdn 	 
    	  
            std murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
     
 vector mCjRiexLu0qRSi_O84UZJ 	 
    	  
    		   
   bool mtxoaXTIgdw6IckN5O_1r 	 
 _4942080627572011540 mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
   _6807035637074954094.size mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    ,false mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     mwuKpk61WuwpkeXLjoGtV 	 
 
            std mX1wUUXA4K97wmsrdVAVK 	 
    	vector mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		   
     
   uint32_t mRL2K7We_OTNrm8rZiFib 	 
 _347298374087418072 mq9Ts26bheU92U5pmCopw 	 
    	  _347298374087418072.reserve mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
    _6406328991171953231.frames.size mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
     
 
  	  mgrhXqWws_YrCFlke2onn 	 
     mXqyc9gORXuLKEPtUgpHo 	 
 
             mGNE6MYszOPOsO1IPh5LE 	 
  size_t _2654435874 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
0 mq9Ts26bheU92U5pmCopw 	 
    _2654435874 meQwHHdvLY3F5yCxVdG4W 	 
    	  
_6807035637074954094.size meqLefwsV4xVPlEPblAGO 	 
    	   mVV6TudP3Q6gowf1fGOGi 	_2654435874 mKxubmXnNCFf5m6IMqnGE 	 
    	  
    		   
     
 m_w4n_cgQC3AhYNK7cALm 	 
     mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
     
                
                 miNcqP8y27Vzwe5pC5fan 	 
    	  
    		   
     
     
 
  	  mKk64KuQx6U14vMKJ8p3v 	 
    mrlaffTFM738Clt_zoPiu 	 
    	  
    		   
     
    _4942080627572011540 meDjYlq7WdnMw_Ihbdm06 	 
   _2654435874 mxmziAipNb9pM16l2UtZn 	 
    	  
    		   mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 
  	 mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
     
                    pair mw7pLJf0_zha7pwHjrBuI 	 int,float mUCtwgs6hmBzyAKqTQN3C 	 
    	  
    		   
     
   _706246351459982 mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
    -1,std murwtTctRiHhTGZcIBKPl 	 
    	  
    numeric_limits myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
     
     
 
  float mFSQGH0yYhZjnwpbrENwW 	 
    	 myQWm8kXQh88dCDeg0z7O 	lowest mopNeOuSjL2v0lWwCRZ8n 	 
    	 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
   mGqg2QR2z38G_RVNYw9pj 	 
    	  

                     mLfoLARhDw8t6Z36Q1Us5 	 
    	  
    		size_t _2654435875 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
     _2654435874+1 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
  _2654435875 mCjRiexLu0qRSi_O84UZJ 	 
    	  
    		   
   _6807035637074954094.size mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		    mVV6TudP3Q6gowf1fGOGi 	 
    	  
  _2654435875 mC9oknUtxCs7_hcCdBD_Q 	 
    	  
    		   
     
     
 
   muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
      mUbfVC8XeBaV_IKq7GPQI 	
                         mOzO85Ea05Vq7EejRQhCE 	 
    	  
  mrlaffTFM738Clt_zoPiu 	 
    	  
    		   
_4942080627572011540 mZOgFIQDtrRnRRUZEInHX 	 
    	  
    		   
    _2654435875 mICpSyqwpPjKIEZIL6txK 	 
    mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
     
 
 miY1FBFPbZCPc731JzE76 	 
    	  
    		   
 
                             mkzaZhXiFLY6L2ulJ8dCX 	 
    	  
    		   
     
   _2654435869 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   
   _5829010262908049596 mzMcErBSGlkrUG5JbnLeB 	 
    	  
     _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    		 keyframes mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     
     
 
  	 _6807035637074954094 mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   
     _2654435874 mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
     
 
  	  mw5gGymCpvseVLBTkYnHw 	 
    	  
    .pose_f2g,_3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    		   
     
 keyframes mfPytrQtReEvytN8BDCL1 	 
    	  
 _6807035637074954094 mpxwp6NEFBHMfD6GmK9Qe 	 
    	  
    		   
     
   _2654435875 mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		   
     
     
 
  	 mICpSyqwpPjKIEZIL6txK 	 
    	  
    .pose_f2g mgJtYRVhnIkDjYqP0pN1T 	 
    mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
  
                             mcFm04z5jXrKPDRmTzQZ6 	 
    	  
    		   
     
     
 
   mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
    _2654435869 mNntmdNA_RNDvAWcgk79c 	 
    	  
    		   
     
 System myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
 getParams mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
     
     
 
 .minBaseLine  mrQSgjz5JUWIuhzSDANIL 	 
    	  
    		   
 _2654435869 mtxoaXTIgdw6IckN5O_1r 	 
   _706246351459982.first mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
    
                                _706246351459982 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   
     
     mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
 _2654435875,_2654435869 mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
     
     
 
   mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
  
                         mcYShoOxi_Yage6jbefjR 	
                     mcYShoOxi_Yage6jbefjR 	 
    	  
  
                     mQWdcRH7MPXqRzGqisNDP 	 
    	  
    		   
     
     
  mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
    _706246351459982.first myEOY6zs_BCfNvVc99RmG 	 
    	  
    		   
     -1 m_w4n_cgQC3AhYNK7cALm 	 
    	  
   mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
     
    
                        _347298374087418072.push_back mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
     
 
_6807035637074954094 mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
   _2654435874 mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		   
     
     
 
  mgJtYRVhnIkDjYqP0pN1T 	 
   mGqg2QR2z38G_RVNYw9pj 	 
                        _347298374087418072.push_back mKk64KuQx6U14vMKJ8p3v 	 
    	  _6807035637074954094 mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
   _706246351459982.first mM4n168wE7XxDXpTxryix 	 
    	 mqtVv5arA2zK0KQU3XuQa 	 
    	  
   mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
  	
                        _4942080627572011540 mfPytrQtReEvytN8BDCL1 	 
    	  
    		   
     
     _2654435874 mIBMvgKkc2foCmes5xsAh 	 
    	  
    		   
     
     
 mJH7lxUAKxSn2qNlkRAAi 	 
    	true mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
                        _4942080627572011540 mg3R8AcKNwM9dmJX8Znnh 	 
    	  
    		   
     
 _706246351459982.first mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    	 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
     
     
 
  	 true mqIGVIwmhASOuS86BKsb2 	 
  
                     mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   
     
     
 
  	 
                 mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
 
             mS4iHRMZIErx7QNz35j8M 	 
             mD6_mgBAuFfUggxveUx9R 	 mmFBAVydr4uCaigvQAzKR 	 
    	  
_347298374087418072.size mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
  mYUggneqq4GdJMIogzvcK 	 
    	  
    		   
     
     
 
  size_t mUHB0pxB6QEsBLyWEMRLq 	 
System murwtTctRiHhTGZcIBKPl 	 
    	  
    		 getParams mTC5zqOspkgnq_h6j8WFp 	 
  .aruco_minNumFramesRequired muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		    mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
   mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
     
 
                vector mYUnEIqfW0vQq2hXUrL63 	 
    	  
 ucoslam mX1wUUXA4K97wmsrdVAVK 	 MarkerObservation mfyvy2MvpZ6uXS6tXsr1m 	 
     _16750267944260729636 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 
 
                vector myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
     se3 mbq9o5ueImx1V6wV_C_u3 	 
    	  
    		   
     
     
 
  	  _11822840474894279984 mVV6TudP3Q6gowf1fGOGi 	 

                 mGNE6MYszOPOsO1IPh5LE 	 auto _2654435871:_347298374087418072 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
  	  mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
     
     
 
 
                    _16750267944260729636.push_back mcjVDrKj01QkSlNHJzRGK 	 
    	 _3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	  
    	keyframes mg3R8AcKNwM9dmJX8Znnh 	 
    	  
    		   
_2654435871 mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
    .getMarker mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
_6406328991171953231.id mgrhXqWws_YrCFlke2onn 	 
    	   mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
   mVV6TudP3Q6gowf1fGOGi 	 
                    _11822840474894279984.push_back mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
_3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
     
     
 
  	 keyframes mfPytrQtReEvytN8BDCL1 	 
  _2654435871 moOBjwVXvSP_4xCPk6CtM 	 
    	  
    		   
  .pose_f2g mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
      mq9Ts26bheU92U5pmCopw 	 
    	  
    	
                 mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
     
  
                 mRcNw9LctVT4dMUHF3iuE 	 
    	  
    		   
     
     
_706246335742885 mJH7lxUAKxSn2qNlkRAAi 	 
 ARUCO_bestMarkerPose mALi2PTzYw049ADd6rVBj 	 
    	_16750267944260729636,_11822840474894279984,_16937201236903537060.imageParams.undistorted mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
     
   , _6406328991171953231.size mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 
  	 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     
 

                 mcFm04z5jXrKPDRmTzQZ6 	 
    	  
    		   
     
   mwyRMFQmWjm44OKwYlAHV 	 
    	  
    mxbDcBoG4h5PnBcGmUN7G 	 
    	  
    		   
     
_706246335742885.empty mcl9T2AihzOEplsBfKvzL 	 
    	  
    muVTEdbGsCBt5fmCFdNGc 	 
    	  
 md_rgewqbpuPOotdS1R24 	 
                    _6406328991171953231.pose_g2m muI3DBWs0mfdbUKl3HHuK 	 
_706246335742885 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		  
                 mU0887GS8dmvoj8KUxkkT 	 

             mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
     

         mIhdUOC63xZPw9gcE1dpq 	 
    
     mcYShoOxi_Yage6jbefjR 	 
    	  
    		   
  
    
    
    
    
     mfvaGLyju7d_oi11W8fzX 	 
    	  
    		   
      mwyRMFQmWjm44OKwYlAHV 	_14173211929012135714 mE48ogqhGNPAyMYcYPB7m 	 
    	  
    		   
      _17591916323427771156 mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
     
     
 
  myTCGpJdqJUBeZm4TxmBB 	 
    	  
    		   
  0 muVTEdbGsCBt5fmCFdNGc 	 
    	  
  mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
     
     
 
  	 
            
            
            
        
        pair mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		   
     double,double mRL2K7We_OTNrm8rZiFib 	 
    	  
   _6868692417182700890 mALi2PTzYw049ADd6rVBj 	0,0 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		
         mGNE6MYszOPOsO1IPh5LE 	 
    	  
    		   
     
     
 auto &_2654435878:_16937201236903537060.markers mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		  mynlbwF1mDjEDlyY2nNSZ 	 
    	  
    		   
    
             mCWeiMbdSVV82CKZ_gl9t 	 
    	  
    		   
     
     
 
  	&_1522769364481108173 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
_3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		   
     map_markers.at mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		 _2654435878.id mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
      mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		
             mcFm04z5jXrKPDRmTzQZ6 	 
    	  
     mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
  mW9QCGrHAGAMpOOZcP__5 	 
    	  
    		   
  _1522769364481108173.pose_g2m.isValid mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
     
 mhMqkzrWlfc_6Y7e0scjV 	 
  continue mVwhWBkpUOLGUPjTHsAdn 	 
            
            cv mKLJVb84nIvZ68mR3FGpa 	 
  Point2f _3005399638492048904 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
  0,0 mpBhwZNG5AmJSdqt9XeQH 	  mq9Ts26bheU92U5pmCopw 	 
    	  
    		
             muyK7MMdERP7RMBakgK5U 	 
    	  
    		   
  auto _2654435881:_2654435878.und_corners m_w4n_cgQC3AhYNK7cALm 	 
   _3005399638492048904+_2654435881 mXqyc9gORXuLKEPtUgpHo 	 
    
            _3005399638492048904 mSIHsYVCCPUNVrlVeVRgc 	1./4. mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
            
             mWVeb4vXHTIAIyKlPWUFF 	 
   _6807036690967323841 mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
     
     
std mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
     
     
 
 numeric_limits meQwHHdvLY3F5yCxVdG4W 	 
    	  
    		   
     
     double mfyvy2MvpZ6uXS6tXsr1m 	 
    	  
    	 mGNB13wn97gUPZujs4u4f 	 
    	  
    		min mmfidxTudvNfPyvzJ2Edq 	 
 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
  	 
             moCSCzrxNS3K2y895STfz 	 
 auto _2654435881:_2654435878.und_corners mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   _6807036690967323841 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
 std mGNB13wn97gUPZujs4u4f 	 
    	  
    max mmFBAVydr4uCaigvQAzKR 	 
  cv mJZx42JEUsfKfMTCpWc4j 	norm mUHB0pxB6QEsBLyWEMRLq 	 _3005399638492048904-_2654435881 mqRw7ZRmykd5ZKdNrZFp8 	,_6807036690967323841 mgrhXqWws_YrCFlke2onn 	 
     mVwhWBkpUOLGUPjTHsAdn 	
            vector myUlBDVbNfKrGVTrhf2x8 	 
    	  
    	uint32_t mtxoaXTIgdw6IckN5O_1r 	 
    	  
 _46082575776210371 mPecXVvVdS4vGCYv3b90P 	 
    	 _16937201236903537060.getIdOfPointsInRegion mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
 _3005399638492048904,_6807036690967323841 mqtVv5arA2zK0KQU3XuQa 	 
  mVwhWBkpUOLGUPjTHsAdn 	
             mD6_mgBAuFfUggxveUx9R 	 
    	  
    		   
     
     
 
  mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
 _46082575776210371.size mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
 mw7pLJf0_zha7pwHjrBuI 	 
   5 mgrhXqWws_YrCFlke2onn 	 
    continue mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     
 
  	 
            
            
             mWVeb4vXHTIAIyKlPWUFF 	 
    	  
    		   
_6806985421310060113 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   0 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 
  	 
             mlXmOyucHj7B4KGRt9QIZ 	 
    	  
    		   
     
     
 
  	 auto _11093822294347:_46082575776210371 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
 
  	  md_rgewqbpuPOotdS1R24 	
                
                _6806985421310060113 myO9ywX4M4JhMo5qekIpJ 	 
    	  
    		   
     
        cv murwtTctRiHhTGZcIBKPl 	 
    	norm mcjVDrKj01QkSlNHJzRGK 	 
    	   _16937201236903537060.pose_f2g*_3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  
  map_points mi22kkdOXcVum8KBRPAq4 	 
    _11093822294347 mIBMvgKkc2foCmes5xsAh 	 
    	  
    		   
 .getCoordinates mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
     
 
  	  mqtVv5arA2zK0KQU3XuQa 	 
    	  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
   
             mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
     
 
  	
             mn_tZgjZuM7KAeTAz_421 	 
    	  
    		   
     
     
_2899393255657923952 mGAGi__s4RGDOCR3uGJMS 	 
    	  
_6806985421310060113/double mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   _46082575776210371.size meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     
     
 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
    
            
            cv mX1wUUXA4K97wmsrdVAVK 	 
    	  
    		   
     
   Mat _11093822386652 mZ39X63mOOECbrBHJ9Sbn 	 
    	  _16937201236903537060.pose_f2g*_1522769364481108173.pose_g2m mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
             myfA2o93uA3w_K66ORh57 	 
    	  
    		   
     
     
 
 _15593881797400272442 muI3DBWs0mfdbUKl3HHuK 	 
    	  
 cv myQWm8kXQh88dCDeg0z7O 	norm mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 
  _11093822386652.rowRange mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
    0,3 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
 
 .colRange mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
     
 
3,4 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 
 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 

            _6868692417182700890.first m_SKk5KJjFFi8Al_1PtU8 	_15593881797400272442/_2899393255657923952 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 
  	
            _6868692417182700890.second mVQseaqHOjuCLhqFe_GFr 	 
    	  mXqyc9gORXuLKEPtUgpHo 	 
    	  

         msM1xiWuQEM4B2LgYBGqq 	 
 
         miNcqP8y27Vzwe5pC5fan 	 
    	  
    		   mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
 _6868692417182700890.second mHCWJjFTJjYO22VuFzjYy 	 
    	  
    		   
     0 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     
 
  	 mgiY6rJNBubapZpdDBOIp 	 
    	  
    		 
             mlwqRLVVfk7dHu1DmcTTk 	 
    	  
  auto &_2654435878:_3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    map_markers mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     

                _2654435878.second.pose_g2m mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   se3 mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
     
      mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
  
         mS4iHRMZIErx7QNz35j8M 	 
    	  
    		   
     
        else mynlbwF1mDjEDlyY2nNSZ 	 
    	  
    		   
     
    
            
             melMfsk6aoDoC_TT7FBTX 	 _17370277987955713200 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
     
   _6868692417182700890.first/_6868692417182700890.second mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
             mGNE6MYszOPOsO1IPh5LE 	 
    	  
    		   
     
     
 
  	auto &_175247759380:_3370013330161650239 mhMI2eT3nLLrJR39GW8UP 	 
    	  
   map_points mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
    
               _175247759380.scalePoint mcjVDrKj01QkSlNHJzRGK 	 
    	  
    	_17370277987955713200 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
  mq9Ts26bheU92U5pmCopw 	 
    	 
           
             moCSCzrxNS3K2y895STfz 	 
    	 auto &_46082543180066935:_3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  keyframes mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
      mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
     
  
                cv mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    		   
     
     
 
 Mat _2654435885 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
     
     
 _46082543180066935.pose_f2g.rowRange mALi2PTzYw049ADd6rVBj 	 
    	  
  0,3 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
  .colRange mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     
 
  	3,4 mhMqkzrWlfc_6Y7e0scjV 	  mwuKpk61WuwpkeXLjoGtV 	 
    	
                _2654435885 mevbPKKoZMKYI5wWj7pC6 	 
    	  
    		_17370277987955713200 mqIGVIwmhASOuS86BKsb2 	 

             msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   
     
  
            _10758134674558762512 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		  10 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		  mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
            _13990461397173511559 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
     
 true mVwhWBkpUOLGUPjTHsAdn 	 
  
         mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
     
     mS4iHRMZIErx7QNz35j8M 	 
    	  
    	
     mbUsOy5pe03Ll6R_P7RAq 	 
 _16937201236903537060 mwuKpk61WuwpkeXLjoGtV 	 
    	  
  
 mgHokv0mWqcLUnod7IEGq 	 

 mL4UxjzZuKcSLz7emkYex 	 
    	  
    MapManager mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		   
     
     
 
  	_12295639104386009589 mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
     
     mUbfVC8XeBaV_IKq7GPQI 	 
    	 
    _4098394392539754261 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		   
     
    false mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
  
    
    Frame    *_10801929782564841966 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
 
    _5860250156218117893.pop mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
   _10801929782564841966 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
  mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
   
     mvnKS1jxMdHokHxGel0FQ 	 
    	  
    		 _10801929782564841966 mEhFq9skOMYS1QtCAsK0C 	 
    	  
    		   NULL mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
  return mqib1onMeOPsOgYE4IKfX 	 
  
    _9129579858736004991 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
     
 WORKING mFKsGrLHwBt00i8an1Xc5 	 
 
    
    _3370013330161650239 msYULQMzegO_yKEHClq4d 	 
    	  
    		   
     
   lock mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     
 
 __FUNCTION__,__FILE__,__LINE__ mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     mVwhWBkpUOLGUPjTHsAdn 	 
   
    Frame &_16937201236903537060 mqDyD62nG3CVIoRGD6YW5 	 
_1018502486064296669 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
  _10801929782564841966 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		  
    delete _10801929782564841966 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		 
    
    _8346364136266015358 mJH7lxUAKxSn2qNlkRAAi 	 
    	  _14139181480504378433 msYULQMzegO_yKEHClq4d 	 
    	  
  detectLoopFromKeyPoints mzMcErBSGlkrUG5JbnLeB 	 
    	  
    	_16937201236903537060,_11028815416989897150 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
   mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
    _3370013330161650239 mmTun3DTrJayzqbfp4aaE 	 
    	  
   unlock mKk64KuQx6U14vMKJ8p3v 	 
    	  
 __FUNCTION__,__FILE__,__LINE__ muSqeiR_y2eGzk1xMiMYn 	 
    mGqg2QR2z38G_RVNYw9pj 	 
    	  
    	
    
    _7124056634192091721 mqDyD62nG3CVIoRGD6YW5 	 
    	 _8352839093262355382 mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
  mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		  mwuKpk61WuwpkeXLjoGtV 	 
    _3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	  
    		   
 removePoints mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 
  	_7124056634192091721.begin mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		 ,_7124056634192091721.end mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
     
 
  	 ,false muVTEdbGsCBt5fmCFdNGc 	 
    	  mVwhWBkpUOLGUPjTHsAdn 	 
    	 
    _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  
    		   
     
    lock mUHB0pxB6QEsBLyWEMRLq 	 
   __FUNCTION__,__FILE__,__LINE__ mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 
   mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     

    
     mZHbteUbSd66ZUyO1QLVg 	 
    	  
    		   
     
_175247759447 mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		 20 mq9Ts26bheU92U5pmCopw 	 
    	  
    	
    
     mfvaGLyju7d_oi11W8fzX 	 
    	  
    		   
     
     
 mKk64KuQx6U14vMKJ8p3v 	 _16937201236903537060.imageParams.isStereoCamera mmfidxTudvNfPyvzJ2Edq 	 
    mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
  	 md_rgewqbpuPOotdS1R24 	 
 
        _175247759447 mtNhTdzc5aNVJy8tJ_6XY 	 5 mqib1onMeOPsOgYE4IKfX 	 
    	  
 
         mlXmOyucHj7B4KGRt9QIZ 	const  mCtxJFchIldR_Vh2Bl_UK 	 
    	  
    		   
     
    &_11093822286451:_8820655757626307961 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
     
 _16937201236903537060,10 muVTEdbGsCBt5fmCFdNGc 	  mhMqkzrWlfc_6Y7e0scjV 	 
    	  
 miY1FBFPbZCPc731JzE76 	 
    	  
    		 
             mRcNw9LctVT4dMUHF3iuE 	 
   &_3005399799907669332 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
   _3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	  
addNewPoint mKk64KuQx6U14vMKJ8p3v 	 
    _16937201236903537060.fseq_idx muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
      mwuKpk61WuwpkeXLjoGtV 	
            _3005399799907669332.setStereo mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
    true mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
 mXqyc9gORXuLKEPtUgpHo 	 
            _3005399799907669332.setCoordinates mzMcErBSGlkrUG5JbnLeB 	 
    	_11093822286451.pose mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
  mqIGVIwmhASOuS86BKsb2 	 
    	
             mGNE6MYszOPOsO1IPh5LE 	 
    	  
   auto _11093822298882:_11093822286451.frame_kpt mE_L5Tl7PN2VKv5U871Ed 	 
    	  

                _3370013330161650239 msYULQMzegO_yKEHClq4d 	 
    	  
    	addMapPointObservation mVPMdrXc9zLZI1cgVbCRa 	 
    	  _3005399799907669332.id,_11093822298882.first,_11093822298882.second mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
  mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     
 
 
         mIhdUOC63xZPw9gcE1dpq 	 
    	  
   
     mIhdUOC63xZPw9gcE1dpq 	 
    	  
 
    
         mCtxJFchIldR_Vh2Bl_UK 	 
    	  
    		   
     _1516014567936766152 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
     
  _13988982604287804007 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
   _16937201236903537060,_175247759447,System mT6pnySI9xcvr4lVO9RYQ 	getParams mG1JPd3asQlBL_9E6kqi0 	 
   .maxNewPoints mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
 mVV6TudP3Q6gowf1fGOGi 	
         mLfoLARhDw8t6Z36Q1Us5 	 
    	 const  mbxcyYUJwW2czE9V2rAbK 	 
    	  
    		   
     
     
 
&_11093822286451:_1516014567936766152 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    	 mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		  
             mCtxJFchIldR_Vh2Bl_UK 	&_3005399799907669332 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
 _3370013330161650239 msYULQMzegO_yKEHClq4d 	 
    	addNewPoint mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
    _16937201236903537060.fseq_idx mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     

            _3005399799907669332.setCoordinates mzMcErBSGlkrUG5JbnLeB 	 
    	_11093822286451.pose mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    	 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
  
             mlwqRLVVfk7dHu1DmcTTk 	 
    	  
    		   auto _11093822298882:_11093822286451.frame_kpt mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
    
                _3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    addMapPointObservation mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		 _3005399799907669332.id,_11093822298882.first,_11093822298882.second mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		    mx4wjZCbiqMiim6vdjgYv 	 

         mu0JQEoIPa09imKwZz_sq 	 
    	  
    		 
    _3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		  unlock mlloh2xU6rNB6XCwUP3wc 	 
    	__FUNCTION__,__FILE__,__LINE__ mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
      mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		 
    
      mi4LXHIjWjl798ubAOD5T 	 
    	  
  mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     _5860250156218117893.empty mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
   mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 
   mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
  
        _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
 lock mmFBAVydr4uCaigvQAzKR 	 
    	  
 __FUNCTION__,__FILE__,__LINE__ mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		  mwuKpk61WuwpkeXLjoGtV 	 
  
         mCWeiMbdSVV82CKZ_gl9t 	 
    	  
    		   
     _16937196451844060927 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		   
  _17400054198872595804 mzMcErBSGlkrUG5JbnLeB 	 
_16937201236903537060 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
  mwuKpk61WuwpkeXLjoGtV 	 
    	  

        _7124056634192091721.insert mVPMdrXc9zLZI1cgVbCRa 	 _7124056634192091721.end mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
  ,_16937196451844060927.begin mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
     
 
 ,_16937196451844060927.end mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
     mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
   mq9Ts26bheU92U5pmCopw 	 
    	 
        _3370013330161650239 mAnf7RSA13QJe6KQYTkEd 	 
    	  
 unlock mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
    __FUNCTION__,__FILE__,__LINE__ m_w4n_cgQC3AhYNK7cALm 	 
    	   mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     mU0887GS8dmvoj8KUxkkT 	 
    	  
    		   
     
     
 
  
    
    
    
    
     mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
 
     migMa2M0Nqi3KcutGTiFf 	 
_706246332319248 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
   0 mwuKpk61WuwpkeXLjoGtV 	 
   
     mLfoLARhDw8t6Z36Q1Us5 	 
    	 const  mbxcyYUJwW2czE9V2rAbK 	&_175247759380:_3370013330161650239 msYULQMzegO_yKEHClq4d 	 
    	  
    		   
     
  map_points mpBhwZNG5AmJSdqt9XeQH 	
         mQWdcRH7MPXqRzGqisNDP 	 mVPMdrXc9zLZI1cgVbCRa 	 
    _175247759380.isBad mxTcGZK7HJpSw0h6YXpMR 	 
    	  
  muSqeiR_y2eGzk1xMiMYn 	 
    	  
    _706246332319248 mC9oknUtxCs7_hcCdBD_Q 	 
    	  
  mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
 
 
      mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   
  
    
     mD6_mgBAuFfUggxveUx9R 	 
    	  
    		   
      mVPMdrXc9zLZI1cgVbCRa 	 mW9QCGrHAGAMpOOZcP__5 	 
    	  
   _4098394392539754261  mE48ogqhGNPAyMYcYPB7m 	 
    	  
     _3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	  
    		   
     
     
 
  	 keyframes.size mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
     
  myTCGpJdqJUBeZm4TxmBB 	 
    	  
    		   
     
1  m_w4n_cgQC3AhYNK7cALm 	 
    mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
     
     

        _11362629803814604768 mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 
_16937201236903537060.idx m_w4n_cgQC3AhYNK7cALm 	 
    	  mqIGVIwmhASOuS86BKsb2 	 
    	  
    
     mljGrNp0eerPSMsOgJrsG 	 
    	  
    		   
     
     
 

    
     mvrEIX2ffF9EooN46qRxt 	 
    	  
    		   
     
     
  mxbDcBoG4h5PnBcGmUN7G 	 
    	  
    		_4098394392539754261  m_w4n_cgQC3AhYNK7cALm 	  m_TiuvSTglPdgr78WSpyh 	 
    
        _2225497823225366210 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
     
 _12040998890815479673 mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
 _16937201236903537060.idx mqtVv5arA2zK0KQU3XuQa 	 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
   
         mlXmOyucHj7B4KGRt9QIZ 	 
    	  
    		   
     
auto _175247760268:_2225497823225366210 mqRw7ZRmykd5ZKdNrZFp8 	 

            _3370013330161650239 mBm9csSztXShbObeR5lOT 	 
  keyframes mi22kkdOXcVum8KBRPAq4 	 
    	  
    		   
     _175247760268 moOBjwVXvSP_4xCPk6CtM 	 
    	  
    		  .setBad  mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
true mE_L5Tl7PN2VKv5U871Ed 	 
   mx4wjZCbiqMiim6vdjgYv 	 
    	  

     mS4iHRMZIErx7QNz35j8M 	 
    	  
    		   
     
  
    _9129579858736004991 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		   
 WAITINGFORUPDATE mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     

 msM1xiWuQEM4B2LgYBGqq 	 
    	  

Se3Transform MapManager mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		 getLastAddedKFPose mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
     
     
 
  mUcZEU6iM4NgqmYg4Awt5 	 
 
 mfwMBWnWGUtSBkvH5hZXq 	 
    	  
    		   
     
     
 
  _13909239728712143806 mGqg2QR2z38G_RVNYw9pj 	
 mU0887GS8dmvoj8KUxkkT 	 

 mHiWFtCL9TZ_X42JLcrul 	 
    	  
    		   
  MapManager mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		   
    bigChange meqLefwsV4xVPlEPblAGO 	 
    	  
  const mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
     
     

     mbUsOy5pe03Ll6R_P7RAq 	 
    	  
    		   
     
  _1061304613240460439 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
   
 mu0JQEoIPa09imKwZz_sq 	 
    	  
 mA1SiPAlDQKFRPK4bbP3W 	 
    	  
    		MapManager mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
 _8669746328630631075 mopNeOuSjL2v0lWwCRZ8n 	 
    	  
  m_TiuvSTglPdgr78WSpyh 	 

    while mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 
  mrlaffTFM738Clt_zoPiu 	 
    	  
    		   
     
   _4090819199315697352 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    	 mbjmKZuZxJty9BQ69I2ML 	 
          
        _12295639104386009589 mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
  mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
     mljGrNp0eerPSMsOgJrsG 	 
    	  
    		   
    
 mu0JQEoIPa09imKwZz_sq 	 
    	  
    	
set mCjRiexLu0qRSi_O84UZJ 	 
  uint32_t mvtzMnUCcUz0W9AlVLusq 	 
    	  
    MapManager mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
 _12040998890815479673 mhzscBF3X5VupHbsC5y3S 	 
    	  
    	uint32_t _13776525365726664701 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    	  mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
   
    set meQwHHdvLY3F5yCxVdG4W 	 
    	  
    		   
 uint32_t mwSVL3MaPH7SRI8AC35ra 	 
 _6840168697625608294 mGqg2QR2z38G_RVNYw9pj 	
    
     mI37J5Pj1p_3lKB8inN7C 	 
    	  
    		 System mKLJVb84nIvZ68mR3FGpa 	 
    	  
 getParams mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
    .detectMarkers   mt_VZ0aLq9BHrRkFuFVoH 	 
 System mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
getParams mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
   .detectKeyPoints  mE_L5Tl7PN2VKv5U871Ed 	 mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
    
        vector mDJXSMZO6rT6qQlIqxXel 	 
    	  
    		   
     
uint32_t mFSQGH0yYhZjnwpbrENwW 	 
    	  
    		   
     
     
 
 _16164152718668857888 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
        _6840168697625608294 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		 _5122744303662631154 mUHB0pxB6QEsBLyWEMRLq 	 
    	  
   _13776525365726664701 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
        
         muyK7MMdERP7RMBakgK5U 	 
    	  
    		   
     
     
 
  	auto _175247760268:_6840168697625608294 m_w4n_cgQC3AhYNK7cALm 	 
    	   m_TiuvSTglPdgr78WSpyh 	 
    	  
    		 
            const  mnnXn3K_Bsu8MRKasLN2j 	&_6385920395377633917 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
     
     
 
  	_3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    		   
     
  keyframes mcr9lPM3CebPbFa00LmzJ 	 
    	  
    		   
    _175247760268 mblf22z7uvTM0nQxHiZHq 	 
  mGqg2QR2z38G_RVNYw9pj 	 
    	  
 
            
            std mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    		   
     
     
 
  set mYUnEIqfW0vQq2hXUrL63 	 
    	  
    		   
    uint32_t mUCtwgs6hmBzyAKqTQN3C 	  _1518844499189060237 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     
 
             mxbtp69LKYVpqiVsVfN2T 	 
    	  
    		   
     
 const  mcyGXnvTM2DvFhzZT8DQr 	 
    	  
    		   
     
 &_2654435878:_6385920395377633917.markers mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    	
                 mG1x28PWmMnF1ZZC1GPwP 	 
    	 auto _2654435871:_3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	map_markers mg3R8AcKNwM9dmJX8Znnh 	 
    _2654435878.id moOBjwVXvSP_4xCPk6CtM 	.frames mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 
 
                    _1518844499189060237.insert mcjVDrKj01QkSlNHJzRGK 	_2654435871 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
 
            _1518844499189060237.erase mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
 
  _175247760268 mgJtYRVhnIkDjYqP0pN1T 	 
  mx4wjZCbiqMiim6vdjgYv 	 
            
             mV7EvC__bzZJ5oyJWmieE 	 
    	  
    		   _10524377175219822767 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
  false mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     

             mlXmOyucHj7B4KGRt9QIZ 	 
    auto _706246330143240:_1518844499189060237 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		    mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		  
                 mgblCN4MzHsbpbt3YM7Vd 	 
    	  
    		   
     
 _3563538109826541639 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   
 0 mVV6TudP3Q6gowf1fGOGi 	
                 mlXmOyucHj7B4KGRt9QIZ 	 
    const  mCWeiMbdSVV82CKZ_gl9t 	 
    	  
    		   
     
&_2654435878:_3370013330161650239 mhMI2eT3nLLrJR39GW8UP 	keyframes mfPytrQtReEvytN8BDCL1 	 _706246330143240 mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   .markers mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
    
                     mvrEIX2ffF9EooN46qRxt 	 
    	  
    		   
     
     
 
 _6385920395377633917.getMarkerIndex mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
   _2654435878.id mqRw7ZRmykd5ZKdNrZFp8 	 
 mSbRzQQlMQxwdEhzEL5t0 	 
    	  
    	-1 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
   _3563538109826541639 mNA2fp1o6c4TsKF9zeotc 	  mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
 
                 mD6_mgBAuFfUggxveUx9R 	 
    	  
    		   
     mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     _3563538109826541639 mXaZ2xxXkU8ACs6ChHKSx 	 
    	  
    		   
   _6385920395377633917.markers.size meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     
     
 
 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
       miY1FBFPbZCPc731JzE76 	 
    	  
    		   
     
                    _10524377175219822767 mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   true mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
                    break mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
                 mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   

             mS4iHRMZIErx7QNz35j8M 	 
    	  
    	
             mfvaGLyju7d_oi11W8fzX 	 
    	  
 mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
 mxbDcBoG4h5PnBcGmUN7G 	_10524377175219822767 muVTEdbGsCBt5fmCFdNGc 	 
    	  
  
                _16164152718668857888.push_back mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     _175247760268 m_w4n_cgQC3AhYNK7cALm 	  mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
  
         mU0887GS8dmvoj8KUxkkT 	 
    	  
    		   
     
     
 

        
         mlXmOyucHj7B4KGRt9QIZ 	 auto _2654435871:_16164152718668857888 mqtVv5arA2zK0KQU3XuQa 	 
  
            _6840168697625608294.erase mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		  _2654435871 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
    
     mu0JQEoIPa09imKwZz_sq 	 
    	  
    		
    
     mkll49jutNf4uYxCnCAMV 	 
    	  
    m_DyFncuQp84EUMSNUYAw 	  mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
 System murwtTctRiHhTGZcIBKPl 	 
    	  getParams mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
     
 
  	.detectKeyPoints mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 
   _6840168697625608294 mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
     
     
 
  _5122744303662631154 mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
_13776525365726664701 m_w4n_cgQC3AhYNK7cALm 	 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
   
    
     mTEBuGit0gTf_vxdGoiHo 	 
    	  
    		   
     
    mcFm04z5jXrKPDRmTzQZ6 	 
    	  
  mhzscBF3X5VupHbsC5y3S 	 
    	  
  System mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		 getParams mmfidxTudvNfPyvzJ2Edq 	 
   .detectMarkers mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
  _6840168697625608294 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
  _17920146964341780569 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     
 
  	_13776525365726664701 mgJtYRVhnIkDjYqP0pN1T 	  mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
  
     mbUsOy5pe03Ll6R_P7RAq 	 
 _6840168697625608294 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     

 mwkDfOKxbbnPOpQCTuAmh 	 
    	 
set mDJXSMZO6rT6qQlIqxXel 	 
    	  
    		uint32_t myTCGpJdqJUBeZm4TxmBB 	 
    	  
    		   MapManager myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
_17920146964341780569 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
   uint32_t _13776525365726664701 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    miY1FBFPbZCPc731JzE76 	 
    	  
    		   
     
      mMrmXuyGsQctvG3qzx5ut 	 
    	  
    		   
    _706246308970949 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
     
 
   mg3R8AcKNwM9dmJX8Znnh 	 
    	  
    		   mM4n168wE7XxDXpTxryix 	 
 mmFBAVydr4uCaigvQAzKR 	 
  uint32_t _2654435866 , mpjmPCAzmrMFmZ5PgS_z0 	 
    	  
  _2654435867 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
  mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
     
     
 
         mOzO85Ea05Vq7EejRQhCE 	 
    	  _2654435866 mbq9o5ueImx1V6wV_C_u3 	 
    	  
    		   
_2654435867 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  swap mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
_2654435866,_2654435867 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
  mVwhWBkpUOLGUPjTHsAdn 	 
 
        uint64_t _11093821964632 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
  
         mLcmXGYgVoSuhaUw_Vq1V 	 
    	  
    		   
 *_6807034398601546557 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
   mhzscBF3X5VupHbsC5y3S 	 
uint32_t* mgJtYRVhnIkDjYqP0pN1T 	 
  &_11093821964632 mwuKpk61WuwpkeXLjoGtV 	 
    	  
 
        _6807034398601546557 mpxwp6NEFBHMfD6GmK9Qe 	 
    	  
    		   
     
   0 mblf22z7uvTM0nQxHiZHq 	 
    	  
    		 mHCoXYUc0g9I0NQfOPPUJ 	 
    _2654435867 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
   
        _6807034398601546557 mfPytrQtReEvytN8BDCL1 	 
    	  
    		   
     
     
 
  	 1 mM4n168wE7XxDXpTxryix 	 
    	  mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
_2654435866 mq9Ts26bheU92U5pmCopw 	 
    	
         mODIzUOe1uU7JX2RwXL7T 	 
    	  
    		   
     
     _11093821964632 mqIGVIwmhASOuS86BKsb2 	 
    	  
    	
     mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		  mwuKpk61WuwpkeXLjoGtV 	 
    	 
     
    
     m_7Ue9L48e5DzHoHpC7Wu 	 
    	  
    		   
     
  _46082575804458778 mZ39X63mOOECbrBHJ9Sbn 	 
  _3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
    TheKpGraph.getNeighbors mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 _13776525365726664701 mhMqkzrWlfc_6Y7e0scjV 	 
  mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
    
    _46082575804458778.erase mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
 
 _3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	  
    		   
 keyframes.front mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
     
 
 .idx mpBhwZNG5AmJSdqt9XeQH 	 
   mx4wjZCbiqMiim6vdjgYv 	
     std mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		   
     
     map mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
     
     
 
  	 uint64_t,float mfyvy2MvpZ6uXS6tXsr1m 	 
    	  _124580014028079534 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
  	 
    
    vector mT5iEPWCvAyIQXq3JvyDZ 	 
uint32_t mvtzMnUCcUz0W9AlVLusq 	 
   _3005399810248445333 mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		 _46082575804458778.begin meqLefwsV4xVPlEPblAGO 	 
,_46082575804458778.end mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
     
 
  mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
  	  mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     mlXmOyucHj7B4KGRt9QIZ 	 
    	  size_t _2654435874 mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
  0 mx4wjZCbiqMiim6vdjgYv 	 
    	  
_2654435874 mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		   
    _3005399810248445333.size mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
     
   mqib1onMeOPsOgYE4IKfX 	 
    	  
    	_2654435874 mNA2fp1o6c4TsKF9zeotc 	 
    	 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
   m_TiuvSTglPdgr78WSpyh 	 
    	  
    		   
 
        const auto&_175247759990 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
    _3370013330161650239 mAnf7RSA13QJe6KQYTkEd 	 
    	  
    		   
     
     
 
keyframes mi22kkdOXcVum8KBRPAq4 	 
    	  
 _3005399810248445333 mfPytrQtReEvytN8BDCL1 	 
  _2654435874 mICpSyqwpPjKIEZIL6txK 	 
    	  
    		   
     
 mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
     
 
  mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
  	 
         mxbtp69LKYVpqiVsVfN2T 	 
    	  
 size_t _2654435875 mtNhTdzc5aNVJy8tJ_6XY 	 
   _2654435874+1 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
   _2654435875 myUlBDVbNfKrGVTrhf2x8 	 
_3005399810248445333.size meqLefwsV4xVPlEPblAGO 	 
    	   mVwhWBkpUOLGUPjTHsAdn 	 
    	  
   _2654435875 mns0M5eWHewDeyQbqvPog 	 
    	  
    		   
     
     
 
  	 m_w4n_cgQC3AhYNK7cALm 	 
  m_TiuvSTglPdgr78WSpyh 	
            const auto&_175247759989 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
  _3370013330161650239 mAnf7RSA13QJe6KQYTkEd 	 
    	  
    		  keyframes meDjYlq7WdnMw_Ihbdm06 	 
    	  _3005399810248445333 meDjYlq7WdnMw_Ihbdm06 	 
    	  
    		   
   _2654435875 mVJXicJ5QqrHRdvZLo_zs 	 
  mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
     mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
  
          
            _124580014028079534 mldjRuUm1vO4TN4uSde9L 	_706246308970949 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
_3005399810248445333 mPsVn1gr5YPiDxLvmxcPF 	 
    	_2654435874 mIBMvgKkc2foCmes5xsAh 	 
    	  
    		   
,_3005399810248445333 mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     _2654435875 mICpSyqwpPjKIEZIL6txK 	 
    	  
    		   
     
     
 
 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
 
   mxmziAipNb9pM16l2UtZn 	 
     mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
     
    cv mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
norm mKk64KuQx6U14vMKJ8p3v 	 _175247759990.pose_f2g.getTvec mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
 -_175247759989.pose_f2g.getTvec mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
 mqtVv5arA2zK0KQU3XuQa 	 
    	 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     
 
  	 
             mcYShoOxi_Yage6jbefjR 	 
    	 
     mIhdUOC63xZPw9gcE1dpq 	 
    	  
    		   
     
    
    
    
    
    std mxJTLjVZ0K8E9UPSbgcn_ 	 
 map mYUnEIqfW0vQq2hXUrL63 	 
    	  
    		   
     uint32_t,set meQwHHdvLY3F5yCxVdG4W 	 
    	  
    		   
  uint32_t mNntmdNA_RNDvAWcgk79c 	 
    	   mtxoaXTIgdw6IckN5O_1r 	 
    	  
   _13773082371983786779 mx4wjZCbiqMiim6vdjgYv 	 
    	  

     mLfoLARhDw8t6Z36Q1Us5 	 
    	  
    		   
     
     auto _706246330143240:_46082575804458778 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
  mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
     
   
         mxbtp69LKYVpqiVsVfN2T 	 
    	  
    		   
 auto _2654435878:_3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	  
    		 keyframes mYalpbnALkVcZA_QR_cDN 	 
   _706246330143240 mdd34YWiAg3My2yImNqXl 	 
    	  
    		   
     
     
.markers mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
 
            _13773082371983786779 mpxwp6NEFBHMfD6GmK9Qe 	 
    	  
    		   
_2654435878.id mM4n168wE7XxDXpTxryix 	 
    	  
    		   
     
    .insert mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		_706246330143240 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 

     mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   
     
  
     mMrmXuyGsQctvG3qzx5ut 	 
    	  
    		   
     _10086624862567280113 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
     
    mi22kkdOXcVum8KBRPAq4 	 
    	  
& mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		   
     
   mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
    uint32_t _706246330143240,const set mT5iEPWCvAyIQXq3JvyDZ 	 
    uint32_t mRL2K7We_OTNrm8rZiFib 	 
    	   &_3005401603918369918 mE_L5Tl7PN2VKv5U871Ed 	 miY1FBFPbZCPc731JzE76 	 
    	  
    		   
     
     
 
             mnDEKEF1Q0AXA_wph4ZCp 	 
    	  
    		   
     
  _706246353090457 mNzkiimyygJ1VUtrj96RQ 	 0 mXqyc9gORXuLKEPtUgpHo 	 
    	 
             mxbtp69LKYVpqiVsVfN2T 	 
    	  
    		auto _46082543263580169: _3005401603918369918 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
  mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   

                 mWRUXQGuYGosipABxDGR2 	 
    	  
    	 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
 _46082543263580169 mgvYH3Bs7wMJHQzWkBaT4 	 
 _706246330143240  mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
                    _706246353090457 mO43FK_grPtpTezf_bduw 	 
    	_124580014028079534 mi22kkdOXcVum8KBRPAq4 	 
    	  
    		 _706246308970949 mALi2PTzYw049ADd6rVBj 	 
    	  
    		 _706246330143240,_46082543263580169 mqtVv5arA2zK0KQU3XuQa 	 
    	  
   mxmziAipNb9pM16l2UtZn 	 
    	  
    		   
     
  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
  
             mU0887GS8dmvoj8KUxkkT 	 
    	  
    		   
     
     
 
  	 
             mM6u_DIT2W6xWFuLmlYrQ 	 
    	  
    		   
     
     
 
  	 _706246353090457 mFKsGrLHwBt00i8an1Xc5 	 

     mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
  mq9Ts26bheU92U5pmCopw 	 
    	  
  
      
    std myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
 map mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		  uint32_t,set meQwHHdvLY3F5yCxVdG4W 	 uint32_t mwSVL3MaPH7SRI8AC35ra 	 
    	  
    		   
     
     
 
  mNntmdNA_RNDvAWcgk79c 	 
    	  
    		   
     
   _12358233879185425501 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
 
      mxbtp69LKYVpqiVsVfN2T 	 
    	  
    		   
 auto _175247759374:_13773082371983786779 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     m_TiuvSTglPdgr78WSpyh 	 
         mWRUXQGuYGosipABxDGR2 	 
    	  
    		   
     
  mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 
   _175247759374.second.size mcl9T2AihzOEplsBfKvzL 	 mttMkZXeEU183Ii_S10fa 	size_t mlloh2xU6rNB6XCwUP3wc 	 
    	  
System mX1wUUXA4K97wmsrdVAVK 	 
    	  
    		   getParams meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     .maxVisibleFramesPerMarker mgJtYRVhnIkDjYqP0pN1T 	 
    muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    	
            _12358233879185425501 mPsVn1gr5YPiDxLvmxcPF 	 
    	  
    		 _175247759374.first mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
     
 
.insert mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     
 
  _175247759374.second.begin mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
     
 
  ,_175247759374.second.end mH4LuIlTPWgwHrNL_50_T 	  mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     mx4wjZCbiqMiim6vdjgYv 	 
    
         msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   
     
     
 
 
        else mgiY6rJNBubapZpdDBOIp 	 
 
            
            
            vector mDJXSMZO6rT6qQlIqxXel 	 
    	  
    		   
    uint32_t mRL2K7We_OTNrm8rZiFib 	 
   _6807035637074954094 mKk64KuQx6U14vMKJ8p3v 	_175247759374.second.begin mH4LuIlTPWgwHrNL_50_T 	 
    	  
    ,_175247759374.second.end mmfidxTudvNfPyvzJ2Edq 	 
 m_w4n_cgQC3AhYNK7cALm 	 
    	  
 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     

            pair mCjRiexLu0qRSi_O84UZJ 	 
    	  
   size_t,size_t myTCGpJdqJUBeZm4TxmBB 	 
 _6806984971934960832 mqIGVIwmhASOuS86BKsb2 	 
    	  
     mtO4mkitZ9LLt0a01hBn9 	 
    	  
    		   
     
    _706246332997485 mHCoXYUc0g9I0NQfOPPUJ 	 
   std myQWm8kXQh88dCDeg0z7O 	 
   numeric_limits mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
     
     
 
 float mtxoaXTIgdw6IckN5O_1r 	 
    	   mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   
     
     
lowest mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    	
             muyK7MMdERP7RMBakgK5U 	 
    	  
    		   
     
 size_t _2654435874 mCB5_SJ6_oDTzuXLi4RDZ 	 
   0 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     _2654435874 mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		   
_6807035637074954094.size mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		  mGqg2QR2z38G_RVNYw9pj 	 
   _2654435874 mNA2fp1o6c4TsKF9zeotc 	 
    	  
   m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
     
 
  	 m_TiuvSTglPdgr78WSpyh 	 
    	 
                 moCSCzrxNS3K2y895STfz 	 
    	  
    		   
     
     
 size_t _2654435875 muI3DBWs0mfdbUKl3HHuK 	 
  _2654435874+1 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     
 
  	 _2654435875 mrSYLVqGT2okEHtq2SFBE 	 
    	  
   _6807035637074954094.size mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
    mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   _2654435875 mYM1M_Zz8iGIxeNqfDdgU 	 
    mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   

                     mCWeiMbdSVV82CKZ_gl9t 	 
    	  
    		  _706246353090457 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
     
   _124580014028079534 mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     
  _706246308970949 mALi2PTzYw049ADd6rVBj 	 
    	_6807035637074954094 mYalpbnALkVcZA_QR_cDN 	 
    	  
_2654435874 mblf22z7uvTM0nQxHiZHq 	 
    	,_6807035637074954094 mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   
   _2654435875 mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
     
 
   mhMqkzrWlfc_6Y7e0scjV 	 
   mdd34YWiAg3My2yImNqXl 	 
    	  
    		   
     
     
 
   mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
 
                     mWRUXQGuYGosipABxDGR2 	 
    	  
    		   
     
   mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     _706246353090457 myTCGpJdqJUBeZm4TxmBB 	 
 _706246332997485 mpBhwZNG5AmJSdqt9XeQH 	 m_TiuvSTglPdgr78WSpyh 	 

                        _6806984971934960832 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
     
     
 
 mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
     
 
_6807035637074954094 mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     
     
 
 _2654435874 mxmziAipNb9pM16l2UtZn 	 
    	  
    		   
    ,_6807035637074954094 mZOgFIQDtrRnRRUZEInHX 	 
    	  
    		   
     _2654435875 mblf22z7uvTM0nQxHiZHq 	 
    	  
    		   
  mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
   mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
 

                        _706246332997485 mJH7lxUAKxSn2qNlkRAAi 	 
    _706246353090457 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
 
                     msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   
     
 
                 mS4iHRMZIErx7QNz35j8M 	 
    	  
    		 
             mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
 
            
            _12358233879185425501 mPsVn1gr5YPiDxLvmxcPF 	 
    	  
    		   
    _175247759374.first mM4n168wE7XxDXpTxryix 	 
    	  
    		   
     
     . insert mUHB0pxB6QEsBLyWEMRLq 	 
   _6806984971934960832.first mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
 
            _12358233879185425501 mfPytrQtReEvytN8BDCL1 	 
    	  
    		   
     
_175247759374.first mxmziAipNb9pM16l2UtZn 	 
    	  
    		   
     
  . insert mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     _6806984971934960832.second mE_L5Tl7PN2VKv5U871Ed 	 
    	  
     mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 
            
            while mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		 _12358233879185425501 meDjYlq7WdnMw_Ihbdm06 	_175247759374.first mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		   
     
     
 
 .size mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
     
 
 mDJXSMZO6rT6qQlIqxXel 	 
    	  
    		 size_t mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     
 
  System mGNB13wn97gUPZujs4u4f 	 
    	  
    getParams mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
     .maxVisibleFramesPerMarker mE_L5Tl7PN2VKv5U871Ed 	 
   mgJtYRVhnIkDjYqP0pN1T 	 mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
     
    
                std mJZx42JEUsfKfMTCpWc4j 	 
    	  pair mCjRiexLu0qRSi_O84UZJ 	 
    	  
    		   
     
uint32_t,float mwSVL3MaPH7SRI8AC35ra 	 
    	  
    		   
     
     
 
   _706246351459982 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
0, std mJZx42JEUsfKfMTCpWc4j 	 
    	numeric_limits mCjRiexLu0qRSi_O84UZJ 	 
    	  
    		   
 float mNntmdNA_RNDvAWcgk79c 	 mKLJVb84nIvZ68mR3FGpa 	lowest mcl9T2AihzOEplsBfKvzL 	  muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     
 
   mwuKpk61WuwpkeXLjoGtV 	 
    	  
    	
                 mlXmOyucHj7B4KGRt9QIZ 	 
    	  
   size_t _2654435874 mtNhTdzc5aNVJy8tJ_6XY 	 
  0 mq9Ts26bheU92U5pmCopw 	 
    	  
    	_2654435874 meQwHHdvLY3F5yCxVdG4W 	 
    	  
    		   
     
  _6807035637074954094.size mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
      mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
    _2654435874 mmLWxH3uFwkkvDwff8Bk_ 	 
    	  
    		   
   muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
 mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
   
                     mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
      mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
   _12358233879185425501 mi22kkdOXcVum8KBRPAq4 	 
_175247759374.first mblf22z7uvTM0nQxHiZHq 	 
    	  
 .count mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
    _6807035637074954094 mfPytrQtReEvytN8BDCL1 	 
    	  
    		   
_2654435874 mM4n168wE7XxDXpTxryix 	 
     mgJtYRVhnIkDjYqP0pN1T 	 
    	  
   mzCa7QFPlhK3iex68eysF 	 
    	  
    		   
     
     
 0 mgJtYRVhnIkDjYqP0pN1T 	 
    	   mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   
     
     
 

                         mbxcyYUJwW2czE9V2rAbK 	 
    	  
    	_2654435869 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  _10086624862567280113 mcjVDrKj01QkSlNHJzRGK 	_6807035637074954094 mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   
     
     
 _2654435874 moOBjwVXvSP_4xCPk6CtM 	 
    	  
,_12358233879185425501 mfPytrQtReEvytN8BDCL1 	 
  _175247759374.first mxmziAipNb9pM16l2UtZn 	 
    	  
    		   
     
  muVTEdbGsCBt5fmCFdNGc 	 
    	  
    mq9Ts26bheU92U5pmCopw 	
                         mcFm04z5jXrKPDRmTzQZ6 	 
    	  
    		   
     
     mhzscBF3X5VupHbsC5y3S 	 
  _2654435869 mwSVL3MaPH7SRI8AC35ra 	 
 _706246351459982.second mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
   _706246351459982 mtNhTdzc5aNVJy8tJ_6XY 	 
  mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
  _6807035637074954094 mcr9lPM3CebPbFa00LmzJ 	 
    	  
    		   
     
 _2654435874 mdd34YWiAg3My2yImNqXl 	 
    	  
    		   
  ,_2654435869 mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
     
     
 
   mx4wjZCbiqMiim6vdjgYv 	 
    	  
    	
                     mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
                 mIhdUOC63xZPw9gcE1dpq 	 
    	  
    		   
     
     
 
  
                
                _12358233879185425501 mi22kkdOXcVum8KBRPAq4 	 
 _175247759374.first mxmziAipNb9pM16l2UtZn 	. insert mzMcErBSGlkrUG5JbnLeB 	 
    	  
   _706246351459982.first muSqeiR_y2eGzk1xMiMYn 	 
    	  
 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
    
             msM1xiWuQEM4B2LgYBGqq 	 
    	  
         mljGrNp0eerPSMsOgJrsG 	 
    	  

     mcYShoOxi_Yage6jbefjR 	
    
    std mX1wUUXA4K97wmsrdVAVK 	 
    	set mrSYLVqGT2okEHtq2SFBE 	 
    	  
    uint32_t myTCGpJdqJUBeZm4TxmBB 	 
    	  
    		   
     
     
  _16997237651734773759 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
 
     mlXmOyucHj7B4KGRt9QIZ 	 
    	  
    		   
     
auto _175247759379:_12358233879185425501 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		  
        _16997237651734773759.insert mmFBAVydr4uCaigvQAzKR 	 
_175247759379.second.begin mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
,_175247759379.second.end mcl9T2AihzOEplsBfKvzL 	 
    	  
   mE_L5Tl7PN2VKv5U871Ed 	 
    	  
 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     

    
    std murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
     
 
  set myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
  uint32_t mUCtwgs6hmBzyAKqTQN3C 	 
    	  _16997209188207231919 mVV6TudP3Q6gowf1fGOGi 	 
    
     mgGBi3p9VXo2bj1YoPmQb 	 
 auto _706246330143240:_46082575804458778 mgJtYRVhnIkDjYqP0pN1T 	    
         mI37J5Pj1p_3lKB8inN7C 	 
 _16997237651734773759.count mwyRMFQmWjm44OKwYlAHV 	 
    _706246330143240 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   mKkesnC12Ak5eQkNNWpXd 	 
    	  
    		   0 mhMqkzrWlfc_6Y7e0scjV 	 
    	 _16997209188207231919.insert mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		_706246330143240 mqRw7ZRmykd5ZKdNrZFp8 	 
    mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
     mNTy2WXcwc6BNgcVDQixE 	 
    	  
    	_16997209188207231919 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		  
 mcYShoOxi_Yage6jbefjR 	 
    	  
    		   
     
   
set meQwHHdvLY3F5yCxVdG4W 	 
    	 uint32_t mNntmdNA_RNDvAWcgk79c 	 
    	  
    		   
  MapManager myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     _5122744303662631154 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
 uint32_t _13776525365726664701, mZHbteUbSd66ZUyO1QLVg 	 
  _11093822290295 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
    mgiY6rJNBubapZpdDBOIp 	 
    	  
    set mYUnEIqfW0vQq2hXUrL63 	 
    	  
    		   
     
     uint32_t mUCtwgs6hmBzyAKqTQN3C 	 
    	  
    		   
     
    _632169897324785074 mXqyc9gORXuLKEPtUgpHo 	 
 
      mWRUXQGuYGosipABxDGR2 	 
    	   mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
 _3370013330161650239 msYULQMzegO_yKEHClq4d 	 
    	  
    		   
     
     
keyframes.size mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
     
 mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
     
     
 
  	size_t mwyRMFQmWjm44OKwYlAHV 	 
    System mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   
   getParams mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
     
 
 .minNumProjPoints mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
  mgrhXqWws_YrCFlke2onn 	 
    	  
     mR4IMBqcMIux9HvMzTO18 	 
    	  
    		   
     
     
 mCumyw3v8A1Jlx0sXTrxg 	 
    	 mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		 
     
     mCtxJFchIldR_Vh2Bl_UK 	 
    	  
_46082575804458778 mJH7lxUAKxSn2qNlkRAAi 	 
_3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    		   
 TheKpGraph.getNeighbors mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
_13776525365726664701 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
  mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
 
    _46082575804458778.erase mlloh2xU6rNB6XCwUP3wc 	0 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
   mx4wjZCbiqMiim6vdjgYv 	 
    	  
   
    _46082575804458778.erase mmFBAVydr4uCaigvQAzKR 	 
    	  1 mgJtYRVhnIkDjYqP0pN1T 	 
   mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
  
    
     muyK7MMdERP7RMBakgK5U 	 
    	  
    		   
    auto _11093821947229:_15327812228135655144 mgrhXqWws_YrCFlke2onn 	 
    	 
        _46082575804458778.erase mUHB0pxB6QEsBLyWEMRLq 	 
   _11093821947229.first m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		    mGqg2QR2z38G_RVNYw9pj 	 
    vector meQwHHdvLY3F5yCxVdG4W 	 
    	  
pair mw7pLJf0_zha7pwHjrBuI 	 
    	  
float,uint32_t mbq9o5ueImx1V6wV_C_u3 	 
    	  
    		   
     
   mbq9o5ueImx1V6wV_C_u3 	 
  _12397058489822015781 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		 
     mI44ZgfxIHthCzbdZ6udV 	 
    	  
    		   
     
     
 _16997202002988998048 mqDyD62nG3CVIoRGD6YW5 	 
    	  
 System mKLJVb84nIvZ68mR3FGpa 	 
   getParams mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
     
   .minNumProjPoints mwuKpk61WuwpkeXLjoGtV 	 
    	  
    	
     mlwqRLVVfk7dHu1DmcTTk 	 
    	 auto _706246330143240:_46082575804458778 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
     
 
  	  m_TiuvSTglPdgr78WSpyh 	 
    	  
    	
         migMa2M0Nqi3KcutGTiFf 	 
    	  
    		   
     
   _5934594266774536213 mtNhTdzc5aNVJy8tJ_6XY 	 
0,_6807035158273032389 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
     
     
 0 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
 
          mcyGXnvTM2DvFhzZT8DQr 	 
    	  
    		   
     
     &_46082543180066935 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   _3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		   
     
     
 
  	keyframes mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   
     
 _706246330143240 mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
     mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		
         miNcqP8y27Vzwe5pC5fan 	 
     mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    	_46082543180066935.isBad meqLefwsV4xVPlEPblAGO 	 
    	  
    		   m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
   continue mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
  
         mlwqRLVVfk7dHu1DmcTTk 	 
    	  
    		   
     
     
 
size_t _2654435874 mZ39X63mOOECbrBHJ9Sbn 	0 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
   _2654435874 mJ1IoQRruz9wl7O23xmH6 	 
    	  
_46082543180066935.ids.size mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
     
     
 
  	  mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   _2654435874 mYM1M_Zz8iGIxeNqfDdgU 	 
    	  
 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
 mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   
     
     
             mQWdcRH7MPXqRzGqisNDP 	 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
  _46082543180066935.ids mZOgFIQDtrRnRRUZEInHX 	 
    	  
    	_2654435874 moOBjwVXvSP_4xCPk6CtM 	 
  mUennHvvhfAGzuO2WDteV 	 
    	  
    		  std mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  
numeric_limits myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
     
   uint32_t mfyvy2MvpZ6uXS6tXsr1m 	 
    	  mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
     
    max mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
  mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
     
 
                 mCtxJFchIldR_Vh2Bl_UK 	 
    	  
    		   
  &_175247759380 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	 _3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
   map_points mg3R8AcKNwM9dmJX8Znnh 	 
    	  
    	_46082543180066935.ids mi22kkdOXcVum8KBRPAq4 	 
    	  
    _2654435874 mM4n168wE7XxDXpTxryix 	 
    	  
    mk5U52lna0dXdrh2Lw90b 	 
 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
  
                 meWq0IVDEwYXqm8zmM71v 	 
    	  
    		   
     
     
 
   mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 
_175247759380.isBad mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
     
   mE_L5Tl7PN2VKv5U871Ed 	continue mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
                _6807035158273032389 mC9oknUtxCs7_hcCdBD_Q 	 
    	  
   mGqg2QR2z38G_RVNYw9pj 	 

                
                 mQgosJM_B_T4l2BbNMnOt 	 
    	  
  _706246332142289 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
     
0 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
                 mdZe8IKTOp2UuAoyaVzOV 	 
    	  
    _175247759380.getNumOfObservingFrames mG1JPd3asQlBL_9E6kqi0 	 
    	 mbq9o5ueImx1V6wV_C_u3 	 
    	  
size_t mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
_16997202002988998048 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     
 
  	  m_w4n_cgQC3AhYNK7cALm 	 
    	   mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   

                     md4vzx4NDcDMY1msVIYDO 	 
    	  
const  mCtxJFchIldR_Vh2Bl_UK 	 
    	  
    		   
  &_11093822384882:_175247759380.getObservingFrames mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
     
 
  	  mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
 mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
     
     
 
  
                         mQWdcRH7MPXqRzGqisNDP 	 
     mcjVDrKj01QkSlNHJzRGK 	 
    	  
 _11093822384882.first mSbRzQQlMQxwdEhzEL5t0 	 
    	  
    		   
     
 _706246330143240  mtlGHbqBCRJIITRlM32U0 	 
    	  
    		   
     
      m_XhQLQUZ_TSRrhwtchgq 	 
 _3370013330161650239 mAnf7RSA13QJe6KQYTkEd 	 
 keyframes meDjYlq7WdnMw_Ihbdm06 	 
    	  
    		   
     
 _11093822384882.first mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
     
 
  	 .isBad mQvGyu6abdIsRcU7YMbbH 	 
  mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
                             meWq0IVDEwYXqm8zmM71v 	 
    	  
    		   
     
   mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    	 _3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    		   
     
  keyframes mZOgFIQDtrRnRRUZEInHX 	_11093822384882.first mxmziAipNb9pM16l2UtZn 	 
    	  
    		   .und_kpts meDjYlq7WdnMw_Ihbdm06 	 
    	  
    		   _11093822384882.second mdd34YWiAg3My2yImNqXl 	 
    	  .octave mXUd0YrAP5JgvykkY3SdF 	 
    	  
  _46082543180066935.und_kpts mYalpbnALkVcZA_QR_cDN 	 
    	  
 _2654435874 mxmziAipNb9pM16l2UtZn 	 
    	  
 .octave muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
  md_rgewqbpuPOotdS1R24 	 
    	  
    		   
     

                                _706246332142289 mmCtW0drSEnrS7Ddz8JcG 	 
    	  
    		   
     
 mwuKpk61WuwpkeXLjoGtV 	 
    	  
                                 ml6zAYOqkbeXrsPA65oYl 	 
    	  
    		   
     _706246332142289 miR7yLqZwn2enCIxkJJJq 	 
    	  
    		   
     
 _16997202002988998048 mgrhXqWws_YrCFlke2onn 	     mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
     
    
                                    _5934594266774536213 mmCtW0drSEnrS7Ddz8JcG 	 
    	  
    		   
     
     
 
   mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
                                    break mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
 
                                 mS4iHRMZIErx7QNz35j8M 	 
    	  
    		   
                             mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
     
 
 
                     msM1xiWuQEM4B2LgYBGqq 	 
    	  
 
                 mU0887GS8dmvoj8KUxkkT 	 
    	  
    		   
 
             mS4iHRMZIErx7QNz35j8M 	 
    	 
         mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		 
         mrHDvoLL_5atezoIyMH6A 	 
    	  
    		 _320895158734137168 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
     
     
 
 float mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   _5934594266774536213 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
/float mcjVDrKj01QkSlNHJzRGK 	 
    _6807035158273032389 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
   mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
  	
         mqHDtLGgdThiQ3pUGQWKu 	 
    	 _320895158734137168 mwSVL3MaPH7SRI8AC35ra 	 
    	  
    		  System murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
   getParams mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
   .KFCulling  mqtVv5arA2zK0KQU3XuQa 	 
    mUbfVC8XeBaV_IKq7GPQI 	 
            _12397058489822015781.push_back mwyRMFQmWjm44OKwYlAHV 	 mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
     _320895158734137168,_706246330143240  mIhdUOC63xZPw9gcE1dpq 	 
    	  
    		   
    mqRw7ZRmykd5ZKdNrZFp8 	 
    	   mVV6TudP3Q6gowf1fGOGi 	 
    	 
         mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
 
     msM1xiWuQEM4B2LgYBGqq 	 
    	  

    
     mWRUXQGuYGosipABxDGR2 	 
    	  
    		   
     
  mmFBAVydr4uCaigvQAzKR 	 
 _12397058489822015781.size meqLefwsV4xVPlEPblAGO 	 
    	  
    		   mvtzMnUCcUz0W9AlVLusq 	 
    	  
    		   
     
_11093822290295 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		 
        std mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   
     
  sort mALi2PTzYw049ADd6rVBj 	 
    	  
    		  _12397058489822015781.begin mopNeOuSjL2v0lWwCRZ8n 	 
 ,_12397058489822015781.end mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
     
 
, mPsVn1gr5YPiDxLvmxcPF 	 
    	  
    		   
     
     
 
 mxmziAipNb9pM16l2UtZn 	 
    	  
     mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
    const pair mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		   
     
     
 
  	float,uint32_t myTCGpJdqJUBeZm4TxmBB 	 
    	  &_2654435866,const pair mT5iEPWCvAyIQXq3JvyDZ 	float,uint32_t mbq9o5ueImx1V6wV_C_u3 	 
     &_2654435867 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 
  	  mynlbwF1mDjEDlyY2nNSZ 	 return _2654435866.first mNntmdNA_RNDvAWcgk79c 	 
    	  
    		   
     
 _2654435867.first mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
  mljGrNp0eerPSMsOgJrsG 	 
 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		 
        _12397058489822015781.resize mzMcErBSGlkrUG5JbnLeB 	 
    	  
    	_11093822290295 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		 
     mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    
     mLfoLARhDw8t6Z36Q1Us5 	 
    	 auto _706246328206728:_12397058489822015781 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     mgiY6rJNBubapZpdDBOIp 	 
        _632169897324785074.insert mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     _706246328206728.second mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
      mVwhWBkpUOLGUPjTHsAdn 	 
    	 
     mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
     
 
  	 
     mQeACzywVnNdBT_8ZH9SI 	 
    	  
    	_632169897324785074 mwuKpk61WuwpkeXLjoGtV 	 
  
 mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
     
     

vector mVOgPwAEFFIQV_xDshfLf 	 
    	uint32_t mbq9o5ueImx1V6wV_C_u3 	 
    	  
    	 MapManager mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		   
     
     
 
  	 _8352839093262355382 mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   m_w4n_cgQC3AhYNK7cALm 	 
    	  

 mynlbwF1mDjEDlyY2nNSZ 	 
    	  
    		
    std mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
     
   vector mDJXSMZO6rT6qQlIqxXel 	 
   uint32_t mFSQGH0yYhZjnwpbrENwW 	 
    	  
  _11398643651601173081 mwuKpk61WuwpkeXLjoGtV 	 
    	  
  
     mlXmOyucHj7B4KGRt9QIZ 	 
    	  
    		   
     
     
auto &_175247759380:_3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    		   
 map_points m_w4n_cgQC3AhYNK7cALm 	 
    	  
    mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
  
         meWq0IVDEwYXqm8zmM71v 	 
    	  
    		 mKk64KuQx6U14vMKJ8p3v 	 
    	  mIlDTJqsJqyypYUaaevvp 	 
    	  
    		   
     
     
 
  	 _175247759380.isStable mH4LuIlTPWgwHrNL_50_T 	 
   mtP0kqFwDWFCfzu04orbp 	  mQpIoyjmuLXV9LO6Q4wRv 	 
    	  
    		   
     
     
 
  _175247759380.isBad mopNeOuSjL2v0lWwCRZ8n 	 
    	  
 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		    mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
     

             moi1jvEIQYGdnVDTqcLgD 	 
    	  
    		   
     
     
 
  	_3005399801879480675 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    std mJZx42JEUsfKfMTCpWc4j 	 
    	  
    	min mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
 uint32_t mUHB0pxB6QEsBLyWEMRLq 	3 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		 ,_3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    		  keyframes.size mmfidxTudvNfPyvzJ2Edq 	 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
  	 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     
 
  	 
             mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
      mzMcErBSGlkrUG5JbnLeB 	 
  _175247759380.isStereo mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
   mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
  	 
                _3005399801879480675 mPecXVvVdS4vGCYv3b90P 	 
    	  
std mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		   
     
  min mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
    uint32_t mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     2 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
    ,_3370013330161650239 mAnf7RSA13QJe6KQYTkEd 	 
    	  keyframes.size mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
  mpBhwZNG5AmJSdqt9XeQH 	 
     mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
 
             mQWdcRH7MPXqRzGqisNDP 	 
    	  
 mhzscBF3X5VupHbsC5y3S 	 
   _175247759380.getVisibility mTC5zqOspkgnq_h6j8WFp 	 
    	  mCjRiexLu0qRSi_O84UZJ 	0.25  mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
  _175247759380.setBad  mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     true mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     
 
 
             mCWUNIyMkVRfx2i1Yzmyb 	 
    	  
    		   
     
     
 m_DyFncuQp84EUMSNUYAw 	 
    	  
 mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     
 
 _175247759380.kfSinceAddition mSPJcUebE5TJISeYndAhJ 	 
    	  
    		   
     
 1  m_y6lfzrX2UhscabhuaYk 	 
    	  
    		   
      _175247759380.getNumOfObservingFrames mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
     mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		   
     
     
 
  	 _3005399801879480675  muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		  _175247759380.setBad  mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
 true mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
             mi30yhHmNZZOoqEQzrjek 	 
    	  
    		   
     
     
 
  	 mdZe8IKTOp2UuAoyaVzOV 	 
    	  
    		   
     _175247759380.kfSinceAddition mYUggneqq4GdJMIogzvcK 	 
    	  
    		   
     
     
 
3 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
    _175247759380.setStable  mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
   true mqtVv5arA2zK0KQU3XuQa 	 
    	  
     mXqyc9gORXuLKEPtUgpHo 	
             mfvaGLyju7d_oi11W8fzX 	 
    	  
    		   
     
   mUHB0pxB6QEsBLyWEMRLq 	 _175247759380.kfSinceAddition myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   5 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
   _175247759380.kfSinceAddition mKxubmXnNCFf5m6IMqnGE 	 
    	  mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
  
         mljGrNp0eerPSMsOgJrsG 	
         meWq0IVDEwYXqm8zmM71v 	 
    	  
  mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		 _175247759380.isStable mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
      muVTEdbGsCBt5fmCFdNGc 	 
    	  
    	
             mD6_mgBAuFfUggxveUx9R 	 
 mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    	_175247759380.getVisibility mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
     
 
 mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
 0.1  mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     _175247759380.setBad  mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
 true mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
 mVV6TudP3Q6gowf1fGOGi 	 
    	  
  
         my1jnbEm_lp7a2P734nJC 	 
    	  
 _175247759380.isBad mmfidxTudvNfPyvzJ2Edq 	 
    	  m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   _11398643651601173081.push_back mALi2PTzYw049ADd6rVBj 	 
    	  
    		  _175247759380.id muVTEdbGsCBt5fmCFdNGc 	 
    	  
   mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
     mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    
     mj6Ks4i_WsqzUoOaSJmhO 	 
    	  
    		   
     
    _11398643651601173081 mFKsGrLHwBt00i8an1Xc5 	 
    	  
  
 mwkDfOKxbbnPOpQCTuAmh 	 
    	  
  
 mf9cxTP1a140lA3WZfHmo 	MapManager mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   
     
  _668185896188051300 mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     const Frame & _16997228172148074791 , mOEVWQP_oYW79QXCEZVJ_ 	 
    	  
    		   
     
_16940374161587532565 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
  
 miY1FBFPbZCPc731JzE76 	 
    
     mfJzMqY26LrkVP7Ch5GIF 	 
    	  
_46082575734385716 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
     
   false,_706246335356026 muI3DBWs0mfdbUKl3HHuK 	 false,_6807035406428482711 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
false mGqg2QR2z38G_RVNYw9pj 	 
     mfvaGLyju7d_oi11W8fzX 	 mwyRMFQmWjm44OKwYlAHV 	 
_16997228172148074791.imageParams.isStereoCamera mTC5zqOspkgnq_h6j8WFp 	 
    	  
   m_w4n_cgQC3AhYNK7cALm 	 
    	  
 
        _6807035406428482711 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
     
     
 _11138245882866350888 mALi2PTzYw049ADd6rVBj 	 
    	  
_16997228172148074791,_16940374161587532565  mgJtYRVhnIkDjYqP0pN1T 	 
    	 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
 
     mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
     
     
 
 mlloh2xU6rNB6XCwUP3wc 	 System mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		 getParams mQvGyu6abdIsRcU7YMbbH 	.detectKeyPoints  muVTEdbGsCBt5fmCFdNGc 	 
        _46082575734385716 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    _16884568726948844929 mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		_16997228172148074791,_16940374161587532565  mpBhwZNG5AmJSdqt9XeQH 	 
  mGqg2QR2z38G_RVNYw9pj 	 
    	
     mfvaGLyju7d_oi11W8fzX 	 
  mmFBAVydr4uCaigvQAzKR 	 
    	  
   mW9QCGrHAGAMpOOZcP__5 	 
    	  
    		   
     
     
_46082575734385716 & System murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
     
 
  getParams meqLefwsV4xVPlEPblAGO 	 
  .detectMarkers m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
   
        _706246335356026 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    _5906010176873986459 mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
 _16997228172148074791 ,_16940374161587532565 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
      mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     
 
  	
    
     mQeACzywVnNdBT_8ZH9SI 	 mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		 _46082575734385716  mbjWhHGT1O6UUXABodoj3 	 
  _706246335356026 mswzqvGXqtq2W3_x5iiyC 	 
    	 _6807035406428482711  muSqeiR_y2eGzk1xMiMYn 	 
  mVV6TudP3Q6gowf1fGOGi 	 
    	  
 
 msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   
   
 mjeN8wuteW5r08mKm66e1 	 
    	  
    		   
 MapManager mT6pnySI9xcvr4lVO9RYQ 	 
    	  
  _11138245882866350888 mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
 const Frame &_16997228172148074791, mpjmPCAzmrMFmZ5PgS_z0 	 
    	  
    		   _16940374161587532565 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		    miY1FBFPbZCPc731JzE76 	 
    	  
    		  
     m_DyFncuQp84EUMSNUYAw 	 
    	  
    		   
     
     
 
 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
  mzduKdBu2_A7Owmoj5Day 	 
    	  
    		   
     
     
 
  _16997228172148074791.imageParams.isStereoCamera mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
      mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
   mfwMBWnWGUtSBkvH5hZXq 	 
    	  
    		   
     
   false mwuKpk61WuwpkeXLjoGtV 	 
    
    
     mxTzs5MCrk57YYwOLx9iP 	 _13282101351954432384  mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
     
 0 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     migMa2M0Nqi3KcutGTiFf 	 
    	  
    		   
     
    _1339477524456856999 mGAGi__s4RGDOCR3uGJMS 	  0 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
  
    
     mgGBi3p9VXo2bj1YoPmQb 	 
    	  
    		   
     
     
 
size_t _2654435874 muI3DBWs0mfdbUKl3HHuK 	 0 mqIGVIwmhASOuS86BKsb2 	 
_2654435874 mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		   
     
     
 
  _16997228172148074791.und_kpts.size meqLefwsV4xVPlEPblAGO 	 
    	  
    		   mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
_2654435874 mnnV3093GPvSgoZfWe8AJ 	 
    	  
   mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
     
 
  	
         mWRUXQGuYGosipABxDGR2 	 
    	  
    		   
     
     
 
   mhzscBF3X5VupHbsC5y3S 	 
    	  
    		_16997228172148074791.getDepth mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
  _2654435874 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
 mbq9o5ueImx1V6wV_C_u3 	 
    	  
    		  0  mtlGHbqBCRJIITRlM32U0 	 
    	  
    _16997228172148074791.imageParams.isClosePoint mlloh2xU6rNB6XCwUP3wc 	 
    	  
    _16997228172148074791.getDepth mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
  _2654435874 mgJtYRVhnIkDjYqP0pN1T 	 
    	 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
   muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		    mUbfVC8XeBaV_IKq7GPQI 	 
             mWRUXQGuYGosipABxDGR2 	 mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		_16997228172148074791.ids mfPytrQtReEvytN8BDCL1 	 
    	  
    		   _2654435874 mM4n168wE7XxDXpTxryix 	 mjfLHi4u9Aemo9Qpiw4y_ 	 
    	std murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
     
 
  	 numeric_limits mCjRiexLu0qRSi_O84UZJ 	 
    	 uint32_t mtxoaXTIgdw6IckN5O_1r 	 
    	  
    		   
     
      mmFKjQ9D3Cx9UyZkFlHxc 	 max mxTcGZK7HJpSw0h6YXpMR 	 
    	  
     miF8HzTJ1yKBJh4JWRaVS 	 
    	  
    		   
     
     
 
    mQpIoyjmuLXV9LO6Q4wRv 	 
    	  
_16997228172148074791.flags mpxwp6NEFBHMfD6GmK9Qe 	 
    	  
    		   
     _2654435874 mdd34YWiAg3My2yImNqXl 	 
    .is mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     Frame mT6pnySI9xcvr4lVO9RYQ 	 
FLAG_OUTLIER mqtVv5arA2zK0KQU3XuQa 	 
    	  
 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
   
                _1339477524456856999 mmLWxH3uFwkkvDwff8Bk_ 	 
    	  
  mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		
            else
                _13282101351954432384 mVQseaqHOjuCLhqFe_GFr 	 
    	  
   mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
 
         mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
     
     
     mgHokv0mWqcLUnod7IEGq 	 
    	  
 
      miNcqP8y27Vzwe5pC5fan 	 
    	  
    		   
 mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
  mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		  _1339477524456856999 mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
     
     
 
  	180*System mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
     
     getParams mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
.KFMinConfidence mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
   mPazbCX0MemfBs9wuskQm 	 
   mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     
 _13282101351954432384 myTCGpJdqJUBeZm4TxmBB 	 
    	  
    		 120*System mT6pnySI9xcvr4lVO9RYQ 	 
  getParams mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		  .KFMinConfidence mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		  mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    	
         mj6Ks4i_WsqzUoOaSJmhO 	 
    	  
    		   
     true mVV6TudP3Q6gowf1fGOGi 	
      mTEBuGit0gTf_vxdGoiHo 	 
   mR4IMBqcMIux9HvMzTO18 	 
    	  
    		   
  false mqib1onMeOPsOgYE4IKfX 	 
  
 mu0JQEoIPa09imKwZz_sq 	 
    	  
  
 mHnE8UXvhpCYM8Ja8eTQ0 	 MapManager murwtTctRiHhTGZcIBKPl 	 _5906010176873986459 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
    const Frame & _16997228172148074791 , mpjmPCAzmrMFmZ5PgS_z0 	 
    	  
  _16940374161587532565 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     
 mGWPc5SQRv__WnS9lIKcF 	 
   
    
     meWq0IVDEwYXqm8zmM71v 	 
    	  
    		   mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     
 
  	 _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    		   
     
     
 
  	 map_markers.size mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
     
 
 mKkesnC12Ak5eQkNNWpXd 	 
    	  
    		   
0 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
 return false mqIGVIwmhASOuS86BKsb2 	 
 
     
     mgGBi3p9VXo2bj1YoPmQb 	 
    	  
    		   
     
     
 
  	auto _2654435878:_16997228172148074791.markers mhMqkzrWlfc_6Y7e0scjV 	 
   mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
     
     
 
  	 
         meWq0IVDEwYXqm8zmM71v 	 
    	  
    mKk64KuQx6U14vMKJ8p3v 	_3370013330161650239 msYULQMzegO_yKEHClq4d 	 
   map_markers.count  mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		  _2654435878.id m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   mBBzsM7ki8vgYjoNRue2D 	 
    	  
    		   
     
     
 
  0 mhMqkzrWlfc_6Y7e0scjV 	 
   md_rgewqbpuPOotdS1R24 	 
    	  
   
            cout mvgLSb6nvObH9RSOVH6V9 	 
 "\x20\x41\x64\x64\x20\x6b\x65\x79\x66\x72\x61\x6d\x65\x20\x62\x65\x63\x61\x75\x73\x65\x20\x6e\x65\x77\x20\x6d\x61\x72\x6b\x65\x72\x20" mPvFfNXpFpgiPe5VqfeNW 	_2654435878.id mDRXM9nCeYcB_HzamC7_A 	 
    	  
    		   
     
     
 
  endl mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
 
             mfwMBWnWGUtSBkvH5hZXq 	 
    	  
    		   
     
     
 
true mwuKpk61WuwpkeXLjoGtV 	 

         mU0887GS8dmvoj8KUxkkT 	 
    	  
  
     mEMBULFa2Mvh5ETGxFudd 	 

    
     mG1x28PWmMnF1ZZC1GPwP 	 
    	  
    		   
     
auto _2654435878:_16997228172148074791.markers muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
   mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    
         miNcqP8y27Vzwe5pC5fan 	 
    	  
     mlloh2xU6rNB6XCwUP3wc 	_3370013330161650239 mAnf7RSA13QJe6KQYTkEd 	 
    	  
    		   
     
  map_markers.count  mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
  _2654435878.id mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
  mSNPy6cbvglXs1K5qjAYC 	 
    	  
    		   
     
     
 0 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 
  	  mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
     
  
             my1jnbEm_lp7a2P734nJC 	 
    	  
    		   
   _3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
 map_markers.at mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
    _2654435878.id mhMqkzrWlfc_6Y7e0scjV 	 
    	  
   .pose_g2m.isValid mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
 mXaZ2xxXkU8ACs6ChHKSx 	 
    	  
    	false   mhMqkzrWlfc_6Y7e0scjV 	 
    	  
  mbjmKZuZxJty9BQ69I2ML 	 
    	  
 
                 meWq0IVDEwYXqm8zmM71v 	 
    	  
    		   
    mzMcErBSGlkrUG5JbnLeB 	 
    	  
      mcjVDrKj01QkSlNHJzRGK 	_16997228172148074791.getMarkerPoseIPPE mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
_2654435878.id mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
 .err_ratio mfyvy2MvpZ6uXS6tXsr1m 	 
    	  
    		 System mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		   
  getParams mH4LuIlTPWgwHrNL_50_T 	 
    .aruco_minerrratio_valid mqtVv5arA2zK0KQU3XuQa 	  meoZNkRFUt_Y1l1iBpbUF 	 System mX1wUUXA4K97wmsrdVAVK 	 
    	  
    		   
     
     getParams mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
     
 
 .aruco_allowOneFrameInitialization mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
  
                     mM6u_DIT2W6xWFuLmlYrQ 	 
    	  
true mVwhWBkpUOLGUPjTHsAdn 	 
    	
             mS4iHRMZIErx7QNz35j8M 	 
    	  
    		   
     

         mljGrNp0eerPSMsOgJrsG 	 
    	  
  
     mIhdUOC63xZPw9gcE1dpq 	 
    	  
    		   
     
     
 
  
    
     muyK7MMdERP7RMBakgK5U 	 
    	  
auto _2654435878:_16997228172148074791.markers mgrhXqWws_YrCFlke2onn 	 
 md_rgewqbpuPOotdS1R24 	 
    	  
    		   
 
         mfvaGLyju7d_oi11W8fzX 	 
    	  
    		   
     mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		  _3370013330161650239 msYULQMzegO_yKEHClq4d 	 
    	  
    		   
     
     
map_markers.count  mKk64KuQx6U14vMKJ8p3v 	 _2654435878.id mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     myEOY6zs_BCfNvVc99RmG 	0 mE_L5Tl7PN2VKv5U871Ed 	 
  mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
    
            const  m_7Ue9L48e5DzHoHpC7Wu 	 
    	  
    		&_3005399774724453457 mPecXVvVdS4vGCYv3b90P 	 
_3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		   
     
 map_markers.at mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
  _2654435878.id mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
      mx4wjZCbiqMiim6vdjgYv 	 
    	  
  
             mQGxHO03vnXvYsLbZIyCa 	 
    	  
   _3005399774724453457.frames.size mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
      mYUggneqq4GdJMIogzvcK 	 
    	System mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  getParams mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
    .maxVisibleFramesPerMarker mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    	continue mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
 
             mvnKS1jxMdHokHxGel0FQ 	 
    	  
    		   
     
     
 
  	  _3005399774724453457.pose_g2m.isValid mopNeOuSjL2v0lWwCRZ8n 	 
    	  muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
 mCumyw3v8A1Jlx0sXTrxg 	 
    	 
                 mrHDvoLL_5atezoIyMH6A 	 
    	  
    		   
 _6807036689763440555 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   std murwtTctRiHhTGZcIBKPl 	 
numeric_limits mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		   
     
     
 
float mFSQGH0yYhZjnwpbrENwW 	 
    	  
    		   
     
  mGNB13wn97gUPZujs4u4f 	 
    	  
    max mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
     
  mx4wjZCbiqMiim6vdjgYv 	 
    	  
    	
                 mgGBi3p9VXo2bj1YoPmQb 	 
    	   mCWeiMbdSVV82CKZ_gl9t 	 
    	  
    		   
     
     
 _2654435871: _3005399774724453457.frames muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     
 
 mynlbwF1mDjEDlyY2nNSZ 	 
    	  
    		   
     
  
                     mtO4mkitZ9LLt0a01hBn9 	 
    	  
    		   
     
     
 
  	 _706246353090457 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		   
     
     
 
  	  cv mKLJVb84nIvZ68mR3FGpa 	 
  norm mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
_3370013330161650239 mAnf7RSA13QJe6KQYTkEd 	 
    	  
    keyframes mZOgFIQDtrRnRRUZEInHX 	 
    	  
    		   
 _2654435871 mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		 .pose_f2g.getTvec mcl9T2AihzOEplsBfKvzL 	 
    	  ,_16997228172148074791.pose_f2g.getTvec mG1JPd3asQlBL_9E6kqi0 	 
    	  
     muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
      mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
    
                     ml6zAYOqkbeXrsPA65oYl 	 
    	  
    	_706246353090457 mrSYLVqGT2okEHtq2SFBE 	 
    	  
    		   
     
_6807036689763440555 mgJtYRVhnIkDjYqP0pN1T 	_6807036689763440555 mqDyD62nG3CVIoRGD6YW5 	 
    	 _706246353090457 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
 
                 msM1xiWuQEM4B2LgYBGqq 	 
   
                 my1jnbEm_lp7a2P734nJC 	 
    	  
   _6807036689763440555 mwEwKEOLE2wVqCjudr0qf 	 
    	  
 System mGNB13wn97gUPZujs4u4f 	 
    	  getParams mQvGyu6abdIsRcU7YMbbH 	 
    	  
  .minBaseLine mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
     miY1FBFPbZCPc731JzE76 	 
    	  
    		   
     
  
                    cout mcSxtLjoAnZ4OK3B2cL6H 	 
    	  
    		   
     "\x20\x41\x64\x64\x20\x6b\x65\x79\x66\x72\x61\x6d\x65\x20\x62\x65\x63\x61\x75\x73\x65\x20\x62\x61\x73\x65\x6c\x69\x6e\x65\x20" mDRXM9nCeYcB_HzamC7_A 	 
    	  
    		   
  endl mVwhWBkpUOLGUPjTHsAdn 	 
   
                     mODIzUOe1uU7JX2RwXL7T 	 
    	  
    		   
     
     
true mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     
                 mEMBULFa2Mvh5ETGxFudd 	
             mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
 
         mU0887GS8dmvoj8KUxkkT 	 
    	  
    		   
     
 
     mIhdUOC63xZPw9gcE1dpq 	 
    	  

    
    
     mvnKS1jxMdHokHxGel0FQ 	 
    	  
    		   
     
     
 
  	 _16997228172148074791.kpts.size mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
     
  msg_XfFtj6tvEeXkCdo58 	 
    0 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
  mRzhzNeZlqLjMSU8QVpDc 	 
    	  
    		   
     
  false mwuKpk61WuwpkeXLjoGtV 	 
    	  
    
     mSsrxEUyYs5Bs1IW7SDmD 	 
    	  
    		   
     
     
 
  	 _16940368387347594694 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
 cv mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   
norm mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
   _16997228172148074791.pose_f2g.getTvec mWdBGAZqkpvkpD9QHkIiT 	 
    	  
   ,_3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
     
 keyframes mfPytrQtReEvytN8BDCL1 	 
    	 _16940374161587532565 moOBjwVXvSP_4xCPk6CtM 	 
    	  
    		   
     
    .pose_f2g.getTvec mxTcGZK7HJpSw0h6YXpMR 	 
    	  
 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
    mFKsGrLHwBt00i8an1Xc5 	 
    	  
 
     mD6_mgBAuFfUggxveUx9R 	 
    	  
    		   
     mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
    _16940368387347594694 myTCGpJdqJUBeZm4TxmBB 	 
    	  
    		    System mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		   
  getParams mG1JPd3asQlBL_9E6kqi0 	 
   .minBaseLine mgrhXqWws_YrCFlke2onn 	 
    	  
    mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
   
        cout mPvFfNXpFpgiPe5VqfeNW 	 
    	 "\x20\x41\x64\x64\x20\x6b\x65\x79\x66\x72\x61\x6d\x65\x20\x62\x65\x63\x61\x75\x73\x65\x20\x62\x61\x73\x65\x6c\x69\x6e\x65\x20" mgSQH2AUBAeLNhSHu3Zf_ 	 
    	  
    		   
     
    endl mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
  	
         mj6Ks4i_WsqzUoOaSJmhO 	 
    	  true mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     
 
     mEMBULFa2Mvh5ETGxFudd 	 
    	  

     mDQx2srYBz1w7JVQxbPDm 	 
    	  
    		   
     
  false mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
 mS4iHRMZIErx7QNz35j8M 	 
    	  
    		   
     
     
 
  	 
 mfJzMqY26LrkVP7Ch5GIF 	 
    	  
    		   
     
MapManager mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
     
     
_16884568726948844929 mcjVDrKj01QkSlNHJzRGK 	 
   const Frame &_16997228172148074791,  mLcmXGYgVoSuhaUw_Vq1V 	 
    	  
    		   
    _16940374161587532565  m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
   
 miY1FBFPbZCPc731JzE76 	 
    	  
    		  
     muYex3fmCG6FNikpgyb8m 	_8222792191690573285 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
 mYalpbnALkVcZA_QR_cDN 	 
     mxmziAipNb9pM16l2UtZn 	 
    	  
    	 mwyRMFQmWjm44OKwYlAHV 	 
    	  const Frame &_2654435871 mqtVv5arA2zK0KQU3XuQa 	 
    	  
 mynlbwF1mDjEDlyY2nNSZ 	 
    
         mZHbteUbSd66ZUyO1QLVg 	 
 _2654435879 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
0 mqIGVIwmhASOuS86BKsb2 	 
         mG1x28PWmMnF1ZZC1GPwP 	size_t _2654435874 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
  0 mFKsGrLHwBt00i8an1Xc5 	_2654435874 mCjRiexLu0qRSi_O84UZJ 	 
    	  
    		   
     
_2654435871.ids.size mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
    mx4wjZCbiqMiim6vdjgYv 	 
  _2654435874 mmCtW0drSEnrS7Ddz8JcG 	 
    	  
     mE_L5Tl7PN2VKv5U871Ed 	 
    	 
             mQWdcRH7MPXqRzGqisNDP 	 
    	  
    		   
     
  mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
  _2654435871.ids meDjYlq7WdnMw_Ihbdm06 	 
    	  
    		   
    _2654435874 moOBjwVXvSP_4xCPk6CtM 	 
     mgvYH3Bs7wMJHQzWkBaT4 	 
 std myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     
 
  	numeric_limits mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		uint32_t mRL2K7We_OTNrm8rZiFib 	  myQWm8kXQh88dCDeg0z7O 	 
    	  
    max mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		 
                 mWRUXQGuYGosipABxDGR2 	 
 mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
  mdabCEOB6d7uJYi0JbPnF 	 
    	  
    		   
     
  _2654435871.flags meDjYlq7WdnMw_Ihbdm06 	 
 _2654435874 mblf22z7uvTM0nQxHiZHq 	 
   .is mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
Frame myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
  FLAG_OUTLIER mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
  
                   _2654435879 mns0M5eWHewDeyQbqvPog 	 
    	  
     mqib1onMeOPsOgYE4IKfX 	 
    	  
    		  
         mNTy2WXcwc6BNgcVDQixE 	 
    	  
    		   
     _2654435879 mx4wjZCbiqMiim6vdjgYv 	 
   
     msM1xiWuQEM4B2LgYBGqq 	 
    	  
     mwuKpk61WuwpkeXLjoGtV 	 
    
     mxTzs5MCrk57YYwOLx9iP 	 
    	  
_8367785432631711677 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
 _8222792191690573285 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
   _16997228172148074791 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     mD6_mgBAuFfUggxveUx9R 	 
    	  
    mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
   _8367785432631711677 meQwHHdvLY3F5yCxVdG4W 	 
    	  
    		   
     
    20 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
  return false mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
  
     mADSK0AOaLDYm81Gwhb7h 	 
    	  
    		   
     
     
 _10934236797308178385  mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
  System mKLJVb84nIvZ68mR3FGpa 	 
    	  
 getParams mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
     
  .KFMinConfidence mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
 
     mpjmPCAzmrMFmZ5PgS_z0 	 
    	  
_3005399795202072660 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    3 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     
 
     mdZe8IKTOp2UuAoyaVzOV 	 
    	  
    		   
 _3370013330161650239 mmTun3DTrJayzqbfp4aaE 	 
    	  
    		   
     
     
 keyframes.size mopNeOuSjL2v0lWwCRZ8n 	 
    	  
  meTrkIYUvARrjm51sjpRt 	 
    	  
    		   
     
    2 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
 mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		  
 
            _3005399795202072660 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
     
     
 
  	 2 mVV6TudP3Q6gowf1fGOGi 	 
    	  
     mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
     
     
 
 
    
     migMa2M0Nqi3KcutGTiFf 	 
   _16937194960156429046 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
     
0 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     

    const  m_7Ue9L48e5DzHoHpC7Wu 	 
    	  
    		   
     
     
 
  	 &_3005399819707726498 muI3DBWs0mfdbUKl3HHuK 	 
     _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  
   keyframes mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   
     
     
 
  _16940374161587532565 mk5U52lna0dXdrh2Lw90b 	 
    	  
     mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		
     mlXmOyucHj7B4KGRt9QIZ 	 
    	  
    		   
     
auto _175247760135:_3005399819707726498.ids mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
     
 
   mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
   
         mfvaGLyju7d_oi11W8fzX 	 
    	  
  mmFBAVydr4uCaigvQAzKR 	 
    	_175247760135 mpUKMXpaPT31M6l4lcQ4j 	std mmFKjQ9D3Cx9UyZkFlHxc 	 
    	numeric_limits mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
   uint32_t mtxoaXTIgdw6IckN5O_1r 	 
    	  
    		   
      mKLJVb84nIvZ68mR3FGpa 	 
    	  
   max mG1JPd3asQlBL_9E6kqi0 	 
    	  
 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
  m_TiuvSTglPdgr78WSpyh 	 
    	  

            const  mmwNmDdoxX1SmwQ3tS0J2 	&_706246332996939 mGAGi__s4RGDOCR3uGJMS 	 
    	  
  _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  
    		   
    map_points mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
 _175247760135 mM4n168wE7XxDXpTxryix 	 
    	  
    mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   

             m_DyFncuQp84EUMSNUYAw 	 
    	  
    		   
     mUHB0pxB6QEsBLyWEMRLq 	_706246332996939.isBad mxTcGZK7HJpSw0h6YXpMR 	 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
   continue mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     

             meWq0IVDEwYXqm8zmM71v 	 
    	  
    		   
     
     
 
   mhzscBF3X5VupHbsC5y3S 	 
    	  
    		 _706246332996939.getNumOfObservingFrames mQvGyu6abdIsRcU7YMbbH 	 mCjRiexLu0qRSi_O84UZJ 	 
_3005399795202072660 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    	 continue mXqyc9gORXuLKEPtUgpHo 	 
    	  
    	
             _16937194960156429046 mmLWxH3uFwkkvDwff8Bk_ 	 
    	  
    		   
     
  mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     

         mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
     
 
     mu0JQEoIPa09imKwZz_sq 	 
    	  
  
     mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
     mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		 _8367785432631711677 myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
     
     
 
 float mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
     
_16937194960156429046 mqRw7ZRmykd5ZKdNrZFp8 	* _10934236797308178385 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
   return true mFKsGrLHwBt00i8an1Xc5 	 
 
     mR4IMBqcMIux9HvMzTO18 	 
    	  
    		   
     
     
 
  	false mVV6TudP3Q6gowf1fGOGi 	 
    	
 mu0JQEoIPa09imKwZz_sq 	 
  
vector mT5iEPWCvAyIQXq3JvyDZ 	 
  uint32_t mFSQGH0yYhZjnwpbrENwW 	 
    	 MapManager mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   _489363023531416435 mlloh2xU6rNB6XCwUP3wc 	 
Frame &_16935669825082873233,size_t _1522768771151786324 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
       mbjmKZuZxJty9BQ69I2ML 	 
    	  
     
     mikQ0a6rwIGhsKubeefBG 	 
   mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
   _3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
     
     
 
  keyframes.size mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
     
 
 mttMkZXeEU183Ii_S10fa 	 
    	  
   2 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    
         mbUsOy5pe03Ll6R_P7RAq 	 
    	  
    		   
   mynlbwF1mDjEDlyY2nNSZ 	 
    	  
    		   
    _3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		   
     
  keyframes.front meqLefwsV4xVPlEPblAGO 	 
    	  
    .idx mljGrNp0eerPSMsOgJrsG 	 
    	  
    		   
      mXqyc9gORXuLKEPtUgpHo 	 
    vector mCjRiexLu0qRSi_O84UZJ 	 
   uint32_t mvtzMnUCcUz0W9AlVLusq 	 
    	  
    		   
     
     
 
 _1515469360845371082  mGAGi__s4RGDOCR3uGJMS 	 
    	  
   _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  TheKpGraph.getNeighborsV mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
_16935669825082873233.idx muVTEdbGsCBt5fmCFdNGc 	 
    	  
 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     

    
    size_t _2654435874 mNzkiimyygJ1VUtrj96RQ 	 
    	  
0 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     
 
  
    while mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     
 
 _2654435874 meQwHHdvLY3F5yCxVdG4W 	 
  _1515469360845371082.size mQvGyu6abdIsRcU7YMbbH 	 
   muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
  mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
    
         mi4LXHIjWjl798ubAOD5T 	 
    	  
    		   
   mlloh2xU6rNB6XCwUP3wc 	 
 _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
keyframes mg3R8AcKNwM9dmJX8Znnh 	 
    	  
    		   
     
     _1515469360845371082 meDjYlq7WdnMw_Ihbdm06 	 
    	  
    		  _2654435874 mVJXicJ5QqrHRdvZLo_zs 	 
    mIBMvgKkc2foCmes5xsAh 	 
    	  
  .isBad mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
   muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
  mgiY6rJNBubapZpdDBOIp 	 
    	  
    		   
 
            std myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     
 swap mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 
_1515469360845371082 mcr9lPM3CebPbFa00LmzJ 	 
    	  
    	_2654435874 mxmziAipNb9pM16l2UtZn 	 
,_1515469360845371082.back mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		  muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
  	 
            _1515469360845371082.pop_back mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
     
 
 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		 
         msM1xiWuQEM4B2LgYBGqq 	
         mTEBuGit0gTf_vxdGoiHo 	 
    _2654435874 mNA2fp1o6c4TsKF9zeotc 	 
    	  
    		   
  mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     
 

     mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   
     
   
     std mmFKjQ9D3Cx9UyZkFlHxc 	 
  sort mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		  _1515469360845371082.begin mTC5zqOspkgnq_h6j8WFp 	 
    	 ,_1515469360845371082.end mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
    , mi22kkdOXcVum8KBRPAq4 	 
    	  
    		  & mM4n168wE7XxDXpTxryix 	 
    	  
    		  mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
    uint32_t _2654435866,  mpjmPCAzmrMFmZ5PgS_z0 	 
_2654435867 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    	 md_rgewqbpuPOotdS1R24 	 
    	  
    		   
     
  return
                _3370013330161650239 mmTun3DTrJayzqbfp4aaE 	 
    	TheKpGraph.getWeight mKk64KuQx6U14vMKJ8p3v 	 
    	  
_2654435866,_16935669825082873233.idx m_w4n_cgQC3AhYNK7cALm 	 
    	  
  mFSQGH0yYhZjnwpbrENwW 	 
    	  
    		   
     
   _3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	 TheKpGraph.getWeight mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		  _2654435867,_16935669825082873233.idx muSqeiR_y2eGzk1xMiMYn 	 
    	   mq9Ts26bheU92U5pmCopw 	  mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     
  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    vector mYUnEIqfW0vQq2hXUrL63 	 
    	  
    		   
     
     uint32_t mtxoaXTIgdw6IckN5O_1r 	 
    	   _18082515013534369065 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
 
     mGNE6MYszOPOsO1IPh5LE 	 
    	auto _46082575804458778: _1515469360845371082 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
 
  	  mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
         mCtxJFchIldR_Vh2Bl_UK 	 
    	  
    	_542441255932743577 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
   _3370013330161650239 msYULQMzegO_yKEHClq4d 	 
    	  
    	getFrameMedianDepth mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
    _46082575804458778 mhMqkzrWlfc_6Y7e0scjV 	 
   mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
         mnnXn3K_Bsu8MRKasLN2j 	 
    	  
    		   
  _16940368387495537784 mJH7lxUAKxSn2qNlkRAAi 	 
    	 cv mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    		   
     
   norm mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
    _16935669825082873233.getCameraCenter mH4LuIlTPWgwHrNL_50_T 	 
    	  
  -_3370013330161650239 mAnf7RSA13QJe6KQYTkEd 	 
    	  
    		   
     
     
 keyframes meDjYlq7WdnMw_Ihbdm06 	 
    	  _46082575804458778 mw5gGymCpvseVLBTkYnHw 	 
    	  
    		   
     
     
 
  	 .getCameraCenter mcl9T2AihzOEplsBfKvzL 	 
     muVTEdbGsCBt5fmCFdNGc 	 mx4wjZCbiqMiim6vdjgYv 	 
    	  
         mOzO85Ea05Vq7EejRQhCE 	 
    _16940368387495537784/_542441255932743577 mFSQGH0yYhZjnwpbrENwW 	 
    	  
    		   System mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    getParams mmfidxTudvNfPyvzJ2Edq 	 
.baseline_medianDepth_ratio_min   mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
      _18082515013534369065.push_back mALi2PTzYw049ADd6rVBj 	 _46082575804458778 m_w4n_cgQC3AhYNK7cALm 	 
    	  
     mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 

         mWRUXQGuYGosipABxDGR2 	 
    	  
    		  mzMcErBSGlkrUG5JbnLeB 	_18082515013534369065.size meqLefwsV4xVPlEPblAGO 	 
    	  
    	 moYn18rymK0dRgMwidbxS 	 
    	  
  _1522768771151786324  m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		  break mXqyc9gORXuLKEPtUgpHo 	 
    	  
    
     mu0JQEoIPa09imKwZz_sq 	 
    	  
    	
     mDQx2srYBz1w7JVQxbPDm 	 
    	  
    		   
     
     
 _18082515013534369065 mVwhWBkpUOLGUPjTHsAdn 	
 mu0JQEoIPa09imKwZz_sq 	 
   
vector myUlBDVbNfKrGVTrhf2x8 	 
   uint32_t mfyvy2MvpZ6uXS6tXsr1m 	 
  MapManager murwtTctRiHhTGZcIBKPl 	 
    	_17400054198872595804 mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
     
 Frame &_9083779410036955469   muVTEdbGsCBt5fmCFdNGc 	 mgiY6rJNBubapZpdDBOIp 	 
 
     mCWeiMbdSVV82CKZ_gl9t 	 
    	  
    		   
 _4969073986308462195  mqDyD62nG3CVIoRGD6YW5 	_3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    		   
     
     TheKpGraph.getNeighbors  mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
    _9083779410036955469 .idx     mgrhXqWws_YrCFlke2onn 	 
    	  
     mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		  
    set mDJXSMZO6rT6qQlIqxXel 	 
    	  
    		   
    uint32_t mwSVL3MaPH7SRI8AC35ra 	 
    	  
    		   
     
     _8613511226855067609 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     

    vector meQwHHdvLY3F5yCxVdG4W 	 
    	  
    	uint32_t mtxoaXTIgdw6IckN5O_1r 	 
    	  
    		   
   _18198621160182713342 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
    
     mlwqRLVVfk7dHu1DmcTTk 	 
    	  
    		  auto _2654435879: _4969073986308462195 mE_L5Tl7PN2VKv5U871Ed 	 
    
         mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
  mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     
 m_XhQLQUZ_TSRrhwtchgq 	 
 _3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
     
 keyframes mfPytrQtReEvytN8BDCL1 	 
    	  
    		   
     
 _2654435879 mM4n168wE7XxDXpTxryix 	 
    	  
    		   .isBad mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
     
 
   mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
    
            _8613511226855067609.insert mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     _2654435879 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		  mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
  
     migMa2M0Nqi3KcutGTiFf 	 
 _1517243165919133649 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
    0,_3005399801165696099 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
     
    0 mx4wjZCbiqMiim6vdjgYv 	 
    	  
 
     mMrgM_Y9qbuuDqckx9Xqq 	 
_175247759809 mqDyD62nG3CVIoRGD6YW5 	 
2.5 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
   
    
    vector mYUnEIqfW0vQq2hXUrL63 	 
    	  
    		   
     
uint32_t mtxoaXTIgdw6IckN5O_1r 	 
    	  
 _13928263410240979211  mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
      _9083779410036955469.getMapPoints mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    mq9Ts26bheU92U5pmCopw 	 
    	  
    		   

       mxbtp69LKYVpqiVsVfN2T 	 
    	  auto _11093822376141: _8613511226855067609 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
  mUbfVC8XeBaV_IKq7GPQI 	 
        Frame &_16997205220810934492 mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
     
     
 
 _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  
    		   
     
   keyframes mi22kkdOXcVum8KBRPAq4 	 
    	  
    		   _11093822376141 mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
    mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		  
         cv mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    		   
     
     Point3f _16987816518187263273 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
     
   _16997205220810934492.getCameraCenter mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		  mx4wjZCbiqMiim6vdjgYv 	 
    	  
  
         md4vzx4NDcDMY1msVIYDO 	 
  auto _706246342527108:_13928263410240979211 muVTEdbGsCBt5fmCFdNGc 	 mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
     
     
 
  	 
             mWRUXQGuYGosipABxDGR2 	 
    	  
    		   
     
     
 
  	  mzMcErBSGlkrUG5JbnLeB 	 
    mfVbyjAc8hQQ79E8Pyycm 	 
    	  
    		_3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  
 map_points.is mcjVDrKj01QkSlNHJzRGK 	 
    	  
_706246342527108 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
  mpBhwZNG5AmJSdqt9XeQH 	 
    	  
  continue mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		 
            MapPoint&_175247761420 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   
     
  _3370013330161650239 mmTun3DTrJayzqbfp4aaE 	 
    	  
    		   
     
     
 
  	 map_points mZOgFIQDtrRnRRUZEInHX 	 
    	  
    		   
_706246342527108 mIBMvgKkc2foCmes5xsAh 	 
 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		  
             mQWdcRH7MPXqRzGqisNDP 	 
    	  
    		   mUHB0pxB6QEsBLyWEMRLq 	 
 _175247761420.isBad meqLefwsV4xVPlEPblAGO 	 
    	  
    		  mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
continue mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
  
             miNcqP8y27Vzwe5pC5fan 	 
    	  
  mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
 
 _175247761420.frames.count mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
     
_16997205220810934492.idx muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
  mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
  continue mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     
 

            
            cv mKLJVb84nIvZ68mR3FGpa 	 
    Point2f _11093822300120 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
  _16997205220810934492.project mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
     
_175247761420.getCoordinates mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
     
     
,true,true mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    	 mqib1onMeOPsOgYE4IKfX 	
             mdZe8IKTOp2UuAoyaVzOV 	 
   isnan mALi2PTzYw049ADd6rVBj 	 
    	  
    		   _11093822300120.x m_w4n_cgQC3AhYNK7cALm 	 
    	   muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
    continue mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		
             mmsUE8QbOXlulZS7EXYI1 	 
  _706246353090457 mNzkiimyygJ1VUtrj96RQ 	 
    	  
     cv mKLJVb84nIvZ68mR3FGpa 	 
  norm mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     
 
  _16987816518187263273-_175247761420.getCoordinates mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
  m_w4n_cgQC3AhYNK7cALm 	 
   mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     
 
  
             mD6_mgBAuFfUggxveUx9R 	 
    	  
    		   
     
      mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
_706246353090457 mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
   0.8f*_175247761420.getMinDistanceInvariance mG1JPd3asQlBL_9E6kqi0 	 
    	  
  mbjWhHGT1O6UUXABodoj3 	 
     _706246353090457 mFSQGH0yYhZjnwpbrENwW 	1.2f*_175247761420.getMaxDistanceInvariance mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		  mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 
  continue mXqyc9gORXuLKEPtUgpHo 	 
            
             mI37J5Pj1p_3lKB8inN7C 	 
    	  
    		  _175247761420.getViewCos mlloh2xU6rNB6XCwUP3wc 	_16987816518187263273 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
    mCjRiexLu0qRSi_O84UZJ 	 
    	  
    		  0.5 mgJtYRVhnIkDjYqP0pN1T 	 
continue mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
 
            
             mj3O_HRIo8HZCQaTnABD3 	 
    	  
    		   
     
     
 
  	_16341578645184805751  mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
     
     
  _9083779410036955469.predictScale mhzscBF3X5VupHbsC5y3S 	 
    	  
  _706246353090457,_175247761420.getMaxDistanceInvariance mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
     
     
 
  	  muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		    mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
 
            
               mtO4mkitZ9LLt0a01hBn9 	 
    	  
    		   
     
    _3005399817140385615  mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   
     
   _175247759809*_16997205220810934492.scaleFactors mi22kkdOXcVum8KBRPAq4 	 
    	  
    		   
     
     
_16341578645184805751 moOBjwVXvSP_4xCPk6CtM 	 
    	  
    mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
  	 
             mi4LXHIjWjl798ubAOD5T 	 
    	  
    		  mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     
 
_175247761420.getViewCos mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
 _16987816518187263273 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
 mrSYLVqGT2okEHtq2SFBE 	 
    	  
    		   
     0.98 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 _3005399817140385615 mI2xNOxs3LAsOh0kd9rag 	1.4f mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
 
            vector mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		   
     
 uint32_t mvtzMnUCcUz0W9AlVLusq 	 
    	  
    		   
     
  _3005399810012306975 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
   _16997205220810934492.getKeyPointsInRegion mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     
 _11093822300120,_3005399817140385615,_16341578645184805751-1,_16341578645184805751 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     mGqg2QR2z38G_RVNYw9pj 	 
    	  

            
            pair mrSYLVqGT2okEHtq2SFBE 	 
    float,int mUCtwgs6hmBzyAKqTQN3C 	 
    _706246351459982 mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
System mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
     getParams mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
   .maxDescDistance+1e-3,-1 muVTEdbGsCBt5fmCFdNGc 	 
  mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
   
             mLfoLARhDw8t6Z36Q1Us5 	 
    	  
    		  auto _46082543320896749:_3005399810012306975 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
  md_rgewqbpuPOotdS1R24 	 
    	
                 mrHDvoLL_5atezoIyMH6A 	 
    	  
    		   
_16940392174182767813 mPecXVvVdS4vGCYv3b90P 	 
    	 _175247761420.getDescDistance mUHB0pxB6QEsBLyWEMRLq 	 
  _16997205220810934492.desc.row mwyRMFQmWjm44OKwYlAHV 	 
    	  _46082543320896749 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   mqib1onMeOPsOgYE4IKfX 	 
    	  
    		
                 mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
     
     
 
   mmFBAVydr4uCaigvQAzKR 	 
   _16940392174182767813 myUlBDVbNfKrGVTrhf2x8 	 
    	  
    	_706246351459982.first muSqeiR_y2eGzk1xMiMYn 	 
    	  
  
                    _706246351459982 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
     mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
     
    _16940392174182767813,_46082543320896749 mEMBULFa2Mvh5ETGxFudd 	 
 mq9Ts26bheU92U5pmCopw 	 
    	  
  
             mcYShoOxi_Yage6jbefjR 	 
    	  
    		   

             mQWdcRH7MPXqRzGqisNDP 	 
    	  mALi2PTzYw049ADd6rVBj 	 
    	  
    	_706246351459982.second mbWacJGWPCVAN2_8fa2kV 	 
    	  
    		   
     
     
 
 -1 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
  mUbfVC8XeBaV_IKq7GPQI 	 
    	
                 mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
     mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
     _16997205220810934492.ids mYalpbnALkVcZA_QR_cDN 	 
   _706246351459982.second mw5gGymCpvseVLBTkYnHw 	 
    	  
    		   
     
     
 
 mjfLHi4u9Aemo9Qpiw4y_ 	 
    	  
    		   
     
  std mX1wUUXA4K97wmsrdVAVK 	numeric_limits mrSYLVqGT2okEHtq2SFBE 	 
   uint32_t mvtzMnUCcUz0W9AlVLusq 	 
    	  
    		   
     
     
 
   mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  
    		   
   max mopNeOuSjL2v0lWwCRZ8n 	 
    	  
   muVTEdbGsCBt5fmCFdNGc 	  mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   
     
   
                    _3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
     
 fuseMapPoints mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
    _16997205220810934492.ids mPsVn1gr5YPiDxLvmxcPF 	 
    	  
    		   
_706246351459982.second mblf22z7uvTM0nQxHiZHq 	 
    	  
    		   
 ,_175247761420.id,false muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
   
                    _18198621160182713342.push_back mlloh2xU6rNB6XCwUP3wc 	 
_175247761420.id m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
     
 
   mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
                    _175247761420.setBad  mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
 true mgrhXqWws_YrCFlke2onn 	  mVV6TudP3Q6gowf1fGOGi 	 
    
                    _3005399801165696099 mKxubmXnNCFf5m6IMqnGE 	 
    	  
    		   
     
     
 
 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
    
                 mcYShoOxi_Yage6jbefjR 	 
    	  
    		   

                else mGWPc5SQRv__WnS9lIKcF 	 
    	  

                    _3370013330161650239 mhMI2eT3nLLrJR39GW8UP 	 
    	  
    		 addMapPointObservation mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
_175247761420.id,_16997205220810934492.idx,_706246351459982.second mqRw7ZRmykd5ZKdNrZFp8 	 
    mFKsGrLHwBt00i8an1Xc5 	 
    	  
  
                    _1517243165919133649 mnnV3093GPvSgoZfWe8AJ 	 
     mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
                 mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   
     
     
 
  
             mS4iHRMZIErx7QNz35j8M 	 
    	  
    
         mljGrNp0eerPSMsOgJrsG 	 
    	  
    		   
     mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
     
   
    std mrtQ8ThKp75Qrrqfkm7Cv 	 vector mDJXSMZO6rT6qQlIqxXel 	 
    	  
    		   
     
 uint32_t mNntmdNA_RNDvAWcgk79c 	 
    	  
    		   
     _16997228247169055403 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
     
     
 
  _3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    getMapPointsInFrames mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		 _8613511226855067609.begin mmfidxTudvNfPyvzJ2Edq 	 
    	  ,_8613511226855067609.end mcl9T2AihzOEplsBfKvzL 	 
  mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
   
    
    
     mADSK0AOaLDYm81Gwhb7h 	 
    	  
    		   
  _13976965695925359212 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		   
     
log mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 _9083779410036955469.getScaleFactor mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
     
 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
  mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
    cv myQWm8kXQh88dCDeg0z7O 	 
    	  
    		  Point3f _16987816518187263273 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   
     
     
 
  	_9083779410036955469.getCameraCenter mTC5zqOspkgnq_h6j8WFp 	 
    	  
   mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     
     mlwqRLVVfk7dHu1DmcTTk 	 
    	  
    		   auto &_706246332803866:_16997228247169055403 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
   miY1FBFPbZCPc731JzE76 	 
    	  
    		   
     
         mbxcyYUJwW2czE9V2rAbK 	 
    	  
   &_175247761420 mZ39X63mOOECbrBHJ9Sbn 	 
   _3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  map_points mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     
_706246332803866 mIBMvgKkc2foCmes5xsAh 	 
    	  
    		    mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
 
         meWq0IVDEwYXqm8zmM71v 	 
    	  
    		   
     mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
_175247761420.isBad mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
  continue mVV6TudP3Q6gowf1fGOGi 	 
   
         mI37J5Pj1p_3lKB8inN7C 	 
    	  
    		   
     
  _175247761420.isObservingFrame mcjVDrKj01QkSlNHJzRGK 	 
   _9083779410036955469.idx mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
    mhMqkzrWlfc_6Y7e0scjV 	 continue mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
   
        cv mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  Point2f _11093822300120 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
     
     
 
  	 _9083779410036955469.project mlloh2xU6rNB6XCwUP3wc 	 
 _175247761420.getCoordinates meqLefwsV4xVPlEPblAGO 	 
    	  ,true,true mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     

         my1jnbEm_lp7a2P734nJC 	 
    	  
    		   isnan mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
 
  _11093822300120.x mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		    m_w4n_cgQC3AhYNK7cALm 	continue mq9Ts26bheU92U5pmCopw 	 
  
         mADSK0AOaLDYm81Gwhb7h 	 
    	  
    		   
     
     
 
  _706246353090457 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   cv mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  
    		   
     
     
 
norm mKk64KuQx6U14vMKJ8p3v 	 
   _16987816518187263273-_175247761420.getCoordinates meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     
  muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		 
         mD6_mgBAuFfUggxveUx9R 	 
    	  
    mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 
  	 _706246353090457 mw7pLJf0_zha7pwHjrBuI 	0.8f*_175247761420.getMinDistanceInvariance mxTcGZK7HJpSw0h6YXpMR 	 
     mr9B7XJzQ6I6_AzWT06sa 	 
    	  
    		   _706246353090457 mUCtwgs6hmBzyAKqTQN3C 	 
    	  
    		   
     
     
1.2f*_175247761420.getMaxDistanceInvariance mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
    muSqeiR_y2eGzk1xMiMYn 	continue mwuKpk61WuwpkeXLjoGtV 	 
    	  
    
        
         mI37J5Pj1p_3lKB8inN7C 	 
    	  
    		    _175247761420.getViewCos mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 _16987816518187263273 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		    mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		   
   0.5 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
  continue mVwhWBkpUOLGUPjTHsAdn 	 
    	  
 
        
         mxTzs5MCrk57YYwOLx9iP 	 
    	  
    		 _16341578645184805751  mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
 _9083779410036955469.predictScale mwyRMFQmWjm44OKwYlAHV 	 
    _706246353090457,_175247761420.getMaxDistanceInvariance mH4LuIlTPWgwHrNL_50_T 	 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
     mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
  
        
        const  mX9K5HXbqpb1oLzLf8pTT 	 _3005399817140385615  mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
    _175247759809*_9083779410036955469.scaleFactors mfPytrQtReEvytN8BDCL1 	 
    	 _16341578645184805751 mw5gGymCpvseVLBTkYnHw 	  mVV6TudP3Q6gowf1fGOGi 	 
    	  
  
        vector mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
uint32_t mvtzMnUCcUz0W9AlVLusq 	 
    	  
    		   
     
     
 
  	 _3005399810012306975 mGAGi__s4RGDOCR3uGJMS 	 
 _9083779410036955469.getKeyPointsInRegion mVPMdrXc9zLZI1cgVbCRa 	_11093822300120,_3005399817140385615,_16341578645184805751-1,_16341578645184805751 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
    mGqg2QR2z38G_RVNYw9pj 	 
    	  
 
        
        pair mCjRiexLu0qRSi_O84UZJ 	 
    	  
    		  float,int mFSQGH0yYhZjnwpbrENwW 	 
    	  
    	  _706246351459982 mcjVDrKj01QkSlNHJzRGK 	 
    	System murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
   getParams mmfidxTudvNfPyvzJ2Edq 	 
    	.maxDescDistance+1e-3,-1 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
 
         mG1x28PWmMnF1ZZC1GPwP 	 
    	  
    		   
     
 auto _46082543320896749:_3005399810012306975 m_w4n_cgQC3AhYNK7cALm 	  mynlbwF1mDjEDlyY2nNSZ 	 
    	  
    		
             mmsUE8QbOXlulZS7EXYI1 	 
    	  
    		   
     
     
 
_16940392174182767813 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
     
   _175247761420.getDescDistance mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
 _9083779410036955469.desc.row mwyRMFQmWjm44OKwYlAHV 	 
    	  
  _46082543320896749 mqtVv5arA2zK0KQU3XuQa 	 
    	 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     

             mi4LXHIjWjl798ubAOD5T 	 
    	  
    		    mmFBAVydr4uCaigvQAzKR 	 
    	  _16940392174182767813 mDJXSMZO6rT6qQlIqxXel 	 
    	  
    		   
 _706246351459982.first mqtVv5arA2zK0KQU3XuQa 	 
    	
                _706246351459982 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		   
    mynlbwF1mDjEDlyY2nNSZ 	 
    	 _16940392174182767813,_46082543320896749 mwkDfOKxbbnPOpQCTuAmh 	 
 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
   
         mS4iHRMZIErx7QNz35j8M 	 
 
         mcFm04z5jXrKPDRmTzQZ6 	 
    	  
    		   
     
     
 
  mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
     
 
_706246351459982.second myEOY6zs_BCfNvVc99RmG 	 
    	  
    		   
     
     
 
  -1 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
      mynlbwF1mDjEDlyY2nNSZ 	 
    	  
    	
             mikQ0a6rwIGhsKubeefBG 	 
  mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
  _9083779410036955469.ids meDjYlq7WdnMw_Ihbdm06 	 
    	  
    		   
     
     _706246351459982.second mIBMvgKkc2foCmes5xsAh 	 
    	 mjfLHi4u9Aemo9Qpiw4y_ 	 
    	  
   std myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     
 
  numeric_limits mVOgPwAEFFIQV_xDshfLf 	uint32_t myTCGpJdqJUBeZm4TxmBB 	 
    	  
    		   
     
  mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  
    		   
     
     
 
  max mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
     
    mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
 mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
     
     
                _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    		   
     
     
 
  	fuseMapPoints mcjVDrKj01QkSlNHJzRGK 	 
    	 _9083779410036955469.ids mg3R8AcKNwM9dmJX8Znnh 	 
   _706246351459982.second mdd34YWiAg3My2yImNqXl 	 
    	  ,_175247761420.id,false mqRw7ZRmykd5ZKdNrZFp8 	 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
 
                _18198621160182713342.push_back mALi2PTzYw049ADd6rVBj 	 _175247761420.id mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
    mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
 
                _175247761420.setBad  mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		 true muVTEdbGsCBt5fmCFdNGc 	 
    	  
    mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 

                _3005399801165696099 mYM1M_Zz8iGIxeNqfDdgU 	 
     mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
 
             mcYShoOxi_Yage6jbefjR 	 
    	
            else mCumyw3v8A1Jlx0sXTrxg 	 
    	  
 
                _3370013330161650239 mmTun3DTrJayzqbfp4aaE 	 
    	  
    		   
     
     
addMapPointObservation mcjVDrKj01QkSlNHJzRGK 	 
    	_175247761420.id,_9083779410036955469.idx,_706246351459982.second mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     mGqg2QR2z38G_RVNYw9pj 	 
    	
                _1517243165919133649 mmCtW0drSEnrS7Ddz8JcG 	 
    	  
    		   
     
     
  mVV6TudP3Q6gowf1fGOGi 	 
    	 
             mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   
     
     

         mEMBULFa2Mvh5ETGxFudd 	 
    	  
    		   

     mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		 
     mQeACzywVnNdBT_8ZH9SI 	 
   _18198621160182713342 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     

 mU0887GS8dmvoj8KUxkkT 	 
    
std mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		   
 list mCjRiexLu0qRSi_O84UZJ 	MapManager mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  
    		   
     
     
 
 NewPointInfo mfyvy2MvpZ6uXS6tXsr1m 	 
    	  
    		   
     
     
 
  	 MapManager myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     
 _8820655757626307961 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
    Frame & _16935669825082873233, mxTzs5MCrk57YYwOLx9iP 	 
    	  
    		   
     
 _175247759447 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
    mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		 
     mD6_mgBAuFfUggxveUx9R 	 
  mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 
  	  mxbDcBoG4h5PnBcGmUN7G 	 
    	  
    		   
     
     
 
 _16935669825082873233.imageParams.isStereoCamera meqLefwsV4xVPlEPblAGO 	 mqRw7ZRmykd5ZKdNrZFp8 	 
    	    mNTy2WXcwc6BNgcVDQixE 	 
    	  
    		   
     
   mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
     
     mljGrNp0eerPSMsOgJrsG 	 
    	  
    		   
     
    mwuKpk61WuwpkeXLjoGtV 	 
    
    
     mTDAKvXETuQN6vGi47QsH 	 
    	  
    		   
     
     
 
 _14315452481299618814 mgiY6rJNBubapZpdDBOIp 	 
    	 
         mrHDvoLL_5atezoIyMH6A 	 
    	  _12588370873618802307 mx4wjZCbiqMiim6vdjgYv 	 
  
        size_t _6629638613544833547 mwuKpk61WuwpkeXLjoGtV 	 
    	  
 
         mf9cxTP1a140lA3WZfHmo 	operator  mT5iEPWCvAyIQXq3JvyDZ 	 
    	  
    		   
     
   mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     const _14315452481299618814&_175247760080 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
  const mynlbwF1mDjEDlyY2nNSZ 	 
    	  
   return _12588370873618802307 mrSYLVqGT2okEHtq2SFBE 	 
    	  
    		   
   _175247760080._12588370873618802307 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
      mljGrNp0eerPSMsOgJrsG 	 
 
         mIDhxn95_YxHg5IVYckWZ 	 
    	  
    		   
     
     
 
  	 operator  mtxoaXTIgdw6IckN5O_1r 	 
    	  
    		   
     
      mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
  const _14315452481299618814&_175247760080 mqRw7ZRmykd5ZKdNrZFp8 	 
 const mUcZEU6iM4NgqmYg4Awt5 	return _12588370873618802307 mfyvy2MvpZ6uXS6tXsr1m 	 
    	  
   _175247760080._12588370873618802307 mx4wjZCbiqMiim6vdjgYv 	 mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   
     
   
     mgHokv0mWqcLUnod7IEGq 	 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
  
     mQGxHO03vnXvYsLbZIyCa 	 
    	  
    		   
     
     
 
  System mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		   
     
 getParams mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
.KPNonMaximaSuppresion muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
 
        _16935669825082873233.nonMaximaSuppresion mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
   mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     

    
     mxTzs5MCrk57YYwOLx9iP 	 
    	  
    		   
  _3005399800714804280 mtNhTdzc5aNVJy8tJ_6XY 	 
  0 mXqyc9gORXuLKEPtUgpHo 	 

     mG1x28PWmMnF1ZZC1GPwP 	 
    	  
    		   
    size_t _2654435874 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
     
     
 
  	 0 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
  _2654435874 mCjRiexLu0qRSi_O84UZJ 	 
    	  
    		   
     
_16935669825082873233.ids.size mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
_2654435874 mmLWxH3uFwkkvDwff8Bk_ 	 mE_L5Tl7PN2VKv5U871Ed 	 
   
         miNcqP8y27Vzwe5pC5fan 	 mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
     _16935669825082873233.ids mfPytrQtReEvytN8BDCL1 	 
    	  
    		_2654435874 mM4n168wE7XxDXpTxryix 	 
    	  
    		   mfMX2Fl1zJz1RpxUeuDUn 	 
    	  
    		   
     
     std murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
     
 
  numeric_limits myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
     
    uint32_t mfyvy2MvpZ6uXS6tXsr1m 	  murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
max meqLefwsV4xVPlEPblAGO 	 
    	  
   mtP0kqFwDWFCfzu04orbp 	 
    	  
    		   
   _16935669825082873233.und_kpts mPsVn1gr5YPiDxLvmxcPF 	 
    	  
    		   
    _2654435874 mblf22z7uvTM0nQxHiZHq 	 
    	  .octave mBBzsM7ki8vgYjoNRue2D 	 
    	  
    		   
0  mtlGHbqBCRJIITRlM32U0 	 
    	  
    		   
     
     
   m_XhQLQUZ_TSRrhwtchgq 	 
    	  
    		   
     
     
 
  	_16935669825082873233.flags mfPytrQtReEvytN8BDCL1 	_2654435874 moOBjwVXvSP_4xCPk6CtM 	 
    	  
    		   
     
.is mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     Frame mX1wUUXA4K97wmsrdVAVK 	 
    	  
    		   
 FLAG_NONMAXIMA mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		  mtP0kqFwDWFCfzu04orbp 	  _16935669825082873233.getDepth mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 
  _2654435874 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
  	 mwSVL3MaPH7SRI8AC35ra 	 0  mrQSgjz5JUWIuhzSDANIL 	 
    	  
    		   
        _16935669825082873233.imageParams.isClosePoint mALi2PTzYw049ADd6rVBj 	 
    	  
    _16935669825082873233.getDepth mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 
  	_2654435874 mpBhwZNG5AmJSdqt9XeQH 	 
    	 mgrhXqWws_YrCFlke2onn 	 
    mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
  
                _3005399800714804280 mKxubmXnNCFf5m6IMqnGE 	 
    mqIGVIwmhASOuS86BKsb2 	
    std mJZx42JEUsfKfMTCpWc4j 	 
    	  
    		   
     
   vector mVOgPwAEFFIQV_xDshfLf 	 
    	  
    		   
     
  _14315452481299618814 mFSQGH0yYhZjnwpbrENwW 	 
   _4942080735137527395 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
   
    _4942080735137527395.reserve mALi2PTzYw049ADd6rVBj 	 
    	  
    		   std murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
  max mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
   _3005399800714804280,100 mqtVv5arA2zK0KQU3XuQa 	 
    	  
  mgJtYRVhnIkDjYqP0pN1T 	 
 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
  	
    
     mvnKS1jxMdHokHxGel0FQ 	 
    	  
  _3005399800714804280 myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
     
     
 
  	 100 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
      md_rgewqbpuPOotdS1R24 	 
    	  
    		   
     
     

        MinBag myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
  _14315452481299618814 mwSVL3MaPH7SRI8AC35ra 	 
    	  
    		   
     _11093822056261 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 
  	
         mlXmOyucHj7B4KGRt9QIZ 	 
   size_t _2654435874 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		   
     
     
 0 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
  _2654435874 myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
     _16935669825082873233.ids.size mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
_2654435874 mVQseaqHOjuCLhqFe_GFr 	 
    mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
  
             m_DyFncuQp84EUMSNUYAw 	 
    	  
    		   
     
     
 
 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
_16935669825082873233.ids mYalpbnALkVcZA_QR_cDN 	 
  _2654435874 mdd34YWiAg3My2yImNqXl 	 
    	  
    		   
     
   meTrkIYUvARrjm51sjpRt 	 
    	  
    	std mGNB13wn97gUPZujs4u4f 	 
    numeric_limits mCjRiexLu0qRSi_O84UZJ 	 
    	  
    		   
     
     uint32_t mUCtwgs6hmBzyAKqTQN3C 	 
    	  
    		   
     
   myQWm8kXQh88dCDeg0z7O 	 
    	  
    		max meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     
     
 
    meoZNkRFUt_Y1l1iBpbUF 	 
    	 _16935669825082873233.und_kpts mZOgFIQDtrRnRRUZEInHX 	 
    	  
    		   
     
    _2654435874 mxmziAipNb9pM16l2UtZn 	 
    	  
    		   
 .octave mb0v60nrqCipJp43YBHzi 	 
0  m_y6lfzrX2UhscabhuaYk 	 
    	  
    		   
   _16935669825082873233.getDepth mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
 _2654435874 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   mvtzMnUCcUz0W9AlVLusq 	 
    	  
    		  0   mrQSgjz5JUWIuhzSDANIL 	 
    	  
    		   
 mrlaffTFM738Clt_zoPiu 	 
    	  
    _16935669825082873233.flags mfPytrQtReEvytN8BDCL1 	 
    	  
    		 _2654435874 mICpSyqwpPjKIEZIL6txK 	 
    	  
    		   
 .is mVPMdrXc9zLZI1cgVbCRa 	 
    	  
Frame murwtTctRiHhTGZcIBKPl 	 
    	 FLAG_NONMAXIMA muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
    mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
    
                _11093822056261.push mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		 mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
    _16935669825082873233.getDepth mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
  _2654435874 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
,_2654435874 mU0887GS8dmvoj8KUxkkT 	 
    	  
    		   
     muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
 
        
        while mALi2PTzYw049ADd6rVBj 	 
   mUGdvEajfIdFM8nFbePYp 	 
    	  
    		   
 _11093822056261.empty mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		    mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    	
            _4942080735137527395.push_back mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		 _11093822056261.pop mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
     
  muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
  mGqg2QR2z38G_RVNYw9pj 	 
     mU0887GS8dmvoj8KUxkkT 	 
    	  
    		   
     
     
    else md_rgewqbpuPOotdS1R24 	 
    	  
    		 
         mlXmOyucHj7B4KGRt9QIZ 	 
    	  
    		   
     
   size_t _2654435874 mqDyD62nG3CVIoRGD6YW5 	0 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		  _2654435874 mrSYLVqGT2okEHtq2SFBE 	 
_16935669825082873233.ids.size mcl9T2AihzOEplsBfKvzL 	 
    	  
    		  mx4wjZCbiqMiim6vdjgYv 	 
    	  
    _2654435874 mnnV3093GPvSgoZfWe8AJ 	 
    	  
   mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
 
             m_DyFncuQp84EUMSNUYAw 	 
    	  
    		   
  mmFBAVydr4uCaigvQAzKR 	 _16935669825082873233.ids mfPytrQtReEvytN8BDCL1 	 
 _2654435874 mIBMvgKkc2foCmes5xsAh 	 
    	   mBBzsM7ki8vgYjoNRue2D 	 
    	 std mT6pnySI9xcvr4lVO9RYQ 	numeric_limits meQwHHdvLY3F5yCxVdG4W 	 
    	  
    		  uint32_t myTCGpJdqJUBeZm4TxmBB 	 mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
max mcl9T2AihzOEplsBfKvzL 	 
    mE48ogqhGNPAyMYcYPB7m 	 
    	  
    		   
     
   _16935669825082873233.und_kpts mldjRuUm1vO4TN4uSde9L 	_2654435874 mw5gGymCpvseVLBTkYnHw 	 
    	  
    	.octave mb0v60nrqCipJp43YBHzi 	0  mrQSgjz5JUWIuhzSDANIL 	 
    	  
    		   
  m_XhQLQUZ_TSRrhwtchgq 	 
    	  
    		   
     
     
 _16935669825082873233.flags mi22kkdOXcVum8KBRPAq4 	 
    	  
    		 _2654435874 mxmziAipNb9pM16l2UtZn 	 
    	  
    		   
     
     
 
  	.is mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
  Frame mxJTLjVZ0K8E9UPSbgcn_ 	 
    	FLAG_NONMAXIMA muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
      mt_VZ0aLq9BHrRkFuFVoH 	 
    	  
    		   

                    _16935669825082873233.getDepth mmFBAVydr4uCaigvQAzKR 	 
 _2654435874 mE_L5Tl7PN2VKv5U871Ed 	 
  myTCGpJdqJUBeZm4TxmBB 	0  mE48ogqhGNPAyMYcYPB7m 	 
    	  
    		   
      _16935669825082873233.imageParams.isClosePoint mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
     
 _16935669825082873233.getDepth mhzscBF3X5VupHbsC5y3S 	 
   _2654435874 muSqeiR_y2eGzk1xMiMYn 	 
    mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
  	  muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		
                _4942080735137527395.push_back mVPMdrXc9zLZI1cgVbCRa 	  mgiY6rJNBubapZpdDBOIp 	 _16935669825082873233.getDepth mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 
  _2654435874 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
  ,_2654435874 mcYShoOxi_Yage6jbefjR 	 
    	  
    		   
     
   m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		  mwuKpk61WuwpkeXLjoGtV 	 
   
     mcYShoOxi_Yage6jbefjR 	 
    	  
    		   
     
 
    std mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		   
     
     
 
  	 list mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		   
MapManager murwtTctRiHhTGZcIBKPl 	NewPointInfo mwSVL3MaPH7SRI8AC35ra 	 
    	  
 _4622533121193472218 mVwhWBkpUOLGUPjTHsAdn 	 
    	
    
     m_7Ue9L48e5DzHoHpC7Wu 	 
    	  
   _16937226146608657651 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
_16935669825082873233.pose_f2g.inv mopNeOuSjL2v0lWwCRZ8n 	 
    	  
  mGqg2QR2z38G_RVNYw9pj 	 
   
     mGNE6MYszOPOsO1IPh5LE 	 
    	  
    		   
     
auto &_11093822348564:_4942080735137527395 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 mbjmKZuZxJty9BQ69I2ML 	 
  
        MapManager mX1wUUXA4K97wmsrdVAVK 	 
    	  
    		   
     
     NewPointInfo _16937373753124017671 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
   
        
        _16937373753124017671.pose mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
     
     
 
  	_16937226146608657651*_16935669825082873233.get3dStereoPoint mALi2PTzYw049ADd6rVBj 	 _11093822348564._6629638613544833547 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
        _16937373753124017671.frame_kpt.push_back mALi2PTzYw049ADd6rVBj 	 
    	  
     mgiY6rJNBubapZpdDBOIp 	 
    	   _16935669825082873233.idx,_11093822348564._6629638613544833547 mu0JQEoIPa09imKwZz_sq 	 
 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    	 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
   
        _16937373753124017671.isStereo mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
     
  true mx4wjZCbiqMiim6vdjgYv 	 
        _4622533121193472218.push_back mUHB0pxB6QEsBLyWEMRLq 	 
  _16937373753124017671 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
  mwuKpk61WuwpkeXLjoGtV 	 
    	  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    	
     msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   
     
  
    
     mR4IMBqcMIux9HvMzTO18 	 _4622533121193472218 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
 mljGrNp0eerPSMsOgJrsG 	 
    	  
    		   
    
std mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  
    		   
     
     vector mVOgPwAEFFIQV_xDshfLf 	 
    	 MapManager mrtQ8ThKp75Qrrqfkm7Cv 	NewPointInfo mUCtwgs6hmBzyAKqTQN3C 	 
     MapManager mX1wUUXA4K97wmsrdVAVK 	 
    	  
    	_13988982604287804007 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		  Frame &_16935669825082873233 , mLcmXGYgVoSuhaUw_Vq1V 	_175247759447, mIR0irh8phA4G3jyRUTn9 	 
    	  
  _1522768807369958241 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   

     mikQ0a6rwIGhsKubeefBG 	 
    	 mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 
  	_16935669825082873233.ids.size mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
     
 
  	  mKkesnC12Ak5eQkNNWpXd 	 
    0 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 return md_rgewqbpuPOotdS1R24 	 
    	  
    		  msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		    mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     
 
  
    
    
     mWXCUaIyuUwntiX8Cd5Rx 	 
    	  
    		   
     
     _3005401605294789533 m_TiuvSTglPdgr78WSpyh 	 
 
        _3005401605294789533 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    uint32_t _13388472731815556334, mOEVWQP_oYW79QXCEZVJ_ 	 
    	  
    		   
_1513938270035531338, mhn7QjZtAK2WpaYOhP3Aw 	 
  _7736357855027240696,cv mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  
    		   
   Point3f _11093821910177, mmsUE8QbOXlulZS7EXYI1 	 
    	 _16937031022796222526 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
  md_rgewqbpuPOotdS1R24 	 
    	  

            _18030119007246525509 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
     
     
 _13388472731815556334 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    
            _681165095198498101 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
     
     
 
_1513938270035531338 mGqg2QR2z38G_RVNYw9pj 	 
 
            _10333569979786346575 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   
     
  _7736357855027240696 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
  
            _16701867013855893038 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
   _11093821910177 mqIGVIwmhASOuS86BKsb2 	 
    	 
            _11690406023733055431 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
  _16937031022796222526 mFKsGrLHwBt00i8an1Xc5 	 
    	  
         mU0887GS8dmvoj8KUxkkT 	 
    	  
    
         moi1jvEIQYGdnVDTqcLgD 	 
    	  
    		   _18030119007246525509 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		 
         mhn7QjZtAK2WpaYOhP3Aw 	 
    	  
    		   
   _681165095198498101 mqIGVIwmhASOuS86BKsb2 	 
   
         mpjmPCAzmrMFmZ5PgS_z0 	 
    _10333569979786346575 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     
 
  
        cv mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    		   
     
     
 
  	 Point3f _16701867013855893038 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    	
         mtO4mkitZ9LLt0a01hBn9 	 
    	  
_11690406023733055431 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     mljGrNp0eerPSMsOgJrsG 	 
    	  
    	 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
  	
    
    
    
     Se3Transform _3005399792197371186 mNzkiimyygJ1VUtrj96RQ 	 
    _16935669825082873233.pose_f2g.inv mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   
     
     mqIGVIwmhASOuS86BKsb2 	 
    	  
   
    
    vector myUlBDVbNfKrGVTrhf2x8 	uint32_t mfyvy2MvpZ6uXS6tXsr1m 	 
 _13920901643832806846  mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		_489363023531416435 mzMcErBSGlkrUG5JbnLeB 	 
    	  
  _16935669825082873233,_175247759447 muVTEdbGsCBt5fmCFdNGc 	 
  mwuKpk61WuwpkeXLjoGtV 	 
    
    vector mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		   
     
 vector mYUnEIqfW0vQq2hXUrL63 	 
   _3005401605294789533 mfyvy2MvpZ6uXS6tXsr1m 	 
    	  
    		   
  mvtzMnUCcUz0W9AlVLusq 	 
    	  
    		   _8361296960174125730 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
 
  _13920901643832806846.size mcl9T2AihzOEplsBfKvzL 	 
    	  
     mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
      mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   

    FrameMatcher _16937386958649118140 mVwhWBkpUOLGUPjTHsAdn 	 
 
    _16937386958649118140.setParams mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
 _16935669825082873233,FrameMatcher mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    MODE_UNASSIGNED,System mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    		   
  getParams mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		   .maxDescDistance*2,0.6,true,std myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     
 numeric_limits mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		  int myTCGpJdqJUBeZm4TxmBB 	 
    	  
    mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    	max meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
 mqRw7ZRmykd5ZKdNrZFp8 	 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 


    #pragma omp parallel for
     mG1x28PWmMnF1ZZC1GPwP 	 
    	int _175247759374 mZ39X63mOOECbrBHJ9Sbn 	 
  0 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		 _175247759374 mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		   
 int mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
_13920901643832806846.size mxTcGZK7HJpSw0h6YXpMR 	 
    	 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
  mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
  _175247759374 mVQseaqHOjuCLhqFe_GFr 	 
    	  
    		 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    	 md_rgewqbpuPOotdS1R24 	 
    	  
    		
        Frame &_3005401603918369727 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		_3370013330161650239 miykdOG68WiHnxkuteCJP 	 
 keyframes mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     
   _13920901643832806846 mPsVn1gr5YPiDxLvmxcPF 	 
_175247759374 mVJXicJ5QqrHRdvZLo_zs 	  mdd34YWiAg3My2yImNqXl 	 
    	  
    		   
   mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
  
        
        cv myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     Mat _11093821994550 muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
     
     
 
  	computeF12 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
     
_16935669825082873233.pose_f2g,_16935669825082873233.imageParams.CameraMatrix,_3005401603918369727.pose_f2g,_16935669825082873233.imageParams.CameraMatrix mhMqkzrWlfc_6Y7e0scjV 	 
     mVV6TudP3Q6gowf1fGOGi 	
        vector mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		   
     cv mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
     
DMatch mfyvy2MvpZ6uXS6tXsr1m 	 
    	  
    _6807036698572949990 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
 _16937386958649118140.matchEpipolar mALi2PTzYw049ADd6rVBj 	 
    	  
    _3005401603918369727,FrameMatcher myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
MODE_UNASSIGNED,_11093821994550 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
        vector mw7pLJf0_zha7pwHjrBuI 	 
   cv mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
Point3f myTCGpJdqJUBeZm4TxmBB 	 
    	  
    _11093822296219 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
    Triangulate mzMcErBSGlkrUG5JbnLeB 	 
 _16935669825082873233,_3005401603918369727,_3005401603918369727.pose_f2g* _16935669825082873233.pose_f2g.inv mH4LuIlTPWgwHrNL_50_T 	 
   ,_6807036698572949990 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 
 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
    
        
         mrHDvoLL_5atezoIyMH6A 	 
   _17138640259027827142 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
     
     
1.5f*System mrtQ8ThKp75Qrrqfkm7Cv 	 
    	 getParams mopNeOuSjL2v0lWwCRZ8n 	 
    	 .scaleFactor mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
         muyK7MMdERP7RMBakgK5U 	 
    	  
    		   
     
     
 
  size_t _2654435874 mCB5_SJ6_oDTzuXLi4RDZ 	 
   0 mwuKpk61WuwpkeXLjoGtV 	 
_2654435874 myUlBDVbNfKrGVTrhf2x8 	 
    	  
    		   
_6807036698572949990.size meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     
 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     
 
  	 _2654435874 mKxubmXnNCFf5m6IMqnGE 	 
    	  
    		  mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
   
             meWq0IVDEwYXqm8zmM71v 	 
    	  
    		   
     mlloh2xU6rNB6XCwUP3wc 	 mdabCEOB6d7uJYi0JbPnF 	 
    	  
 isnan mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
      _11093822296219 mg3R8AcKNwM9dmJX8Znnh 	 
    	  
    		   
     
     
 
  	 _2654435874 mIBMvgKkc2foCmes5xsAh 	 
    	  
    		   
     
    .x m_w4n_cgQC3AhYNK7cALm 	 
    	   muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
 m_TiuvSTglPdgr78WSpyh 	 
    	  
    		 
                
                cv mGNB13wn97gUPZujs4u4f 	 
  Point3f _16937228587826293356 mHCoXYUc0g9I0NQfOPPUJ 	 
  _3005399792197371186*_11093822296219 mi22kkdOXcVum8KBRPAq4 	_2654435874 mw5gGymCpvseVLBTkYnHw 	 
    	  
    		   
     
     
 
   mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
 
                
                 mMrgM_Y9qbuuDqckx9Xqq 	 
    	  
    		   _3005399609920862424 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     cv murwtTctRiHhTGZcIBKPl 	 
    	  
norm mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
_16937228587826293356-_16935669825082873233.getCameraCenter mopNeOuSjL2v0lWwCRZ8n 	 
    	   muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     
 
  	  mq9Ts26bheU92U5pmCopw 	
                 mrHDvoLL_5atezoIyMH6A 	 
    	  
    		  _3005399609920862950 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
cv mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		   
     
norm mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
 _16937228587826293356-_3005401603918369727.getCameraCenter mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
  mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     
 
  
                 ml6zAYOqkbeXrsPA65oYl 	 
    	  
    _3005399609920862424 meTrkIYUvARrjm51sjpRt 	 
    	  
   0  mAUkMSq4ApFdt1vmi7tIn 	 
    	  
    		 _3005399609920862950 mKkesnC12Ak5eQkNNWpXd 	 
    	  
    		   
   0 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     continue mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    	
                const  mX9K5HXbqpb1oLzLf8pTT 	 
    	  
   _1520116976143911186  mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
  _3005399609920862424/_3005399609920862950 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		
                 mI44ZgfxIHthCzbdZ6udV 	 
    	  
    		  _15879076394176213166 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
     
     
   _16935669825082873233.und_kpts mg3R8AcKNwM9dmJX8Znnh 	 
    	  
    		   
     
    _6807036698572949990 mi22kkdOXcVum8KBRPAq4 	 
 _2654435874 mw5gGymCpvseVLBTkYnHw 	 
.trainIdx mk5U52lna0dXdrh2Lw90b 	 
.octave mqIGVIwmhASOuS86BKsb2 	 
    	  
                 mZHbteUbSd66ZUyO1QLVg 	 
    	  
_5942253698289074032 mNzkiimyygJ1VUtrj96RQ 	 
    _3005401603918369727.und_kpts mZOgFIQDtrRnRRUZEInHX 	 
 _6807036698572949990 mZOgFIQDtrRnRRUZEInHX 	 
    	  
    		   
     _2654435874 mw5gGymCpvseVLBTkYnHw 	 
    	  
    		   
     
     
 
.queryIdx mblf22z7uvTM0nQxHiZHq 	 
    	  
    		   
     
     
 
  	 .octave mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
 
  
                const  mADSK0AOaLDYm81Gwhb7h 	_17138640781187484270  mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
_16935669825082873233.scaleFactors mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     _15879076394176213166 mblf22z7uvTM0nQxHiZHq 	 /_3005401603918369727.scaleFactors mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   _5942253698289074032 mdd34YWiAg3My2yImNqXl 	 
    mx4wjZCbiqMiim6vdjgYv 	 

                 mvrEIX2ffF9EooN46qRxt 	 _1520116976143911186*_17138640259027827142 mrSYLVqGT2okEHtq2SFBE 	 
    	  
    		 _17138640781187484270  mswzqvGXqtq2W3_x5iiyC 	 
    	  
    		    _1520116976143911186 mRL2K7We_OTNrm8rZiFib 	 
    	  
    		   
     
    _17138640781187484270*_17138640259027827142 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
    
                    continue mqib1onMeOPsOgYE4IKfX 	 
    
                _8361296960174125730 mcr9lPM3CebPbFa00LmzJ 	 
    	  
    		   
     
_175247759374 mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
     
 
 .push_back mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		 _3005401605294789533 mwyRMFQmWjm44OKwYlAHV 	 
    uint32_t mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		_6807036698572949990 mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     
     
 
  	_2654435874 mw5gGymCpvseVLBTkYnHw 	 
    	.trainIdx muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
  ,_3005401603918369727.idx, uint32_t mlloh2xU6rNB6XCwUP3wc 	 
 _6807036698572949990 mi22kkdOXcVum8KBRPAq4 	 
    	  
    		   
     
  _2654435874 mIBMvgKkc2foCmes5xsAh 	 
  .queryIdx m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
     
 
 ,_16937228587826293356,_6807036698572949990 mi22kkdOXcVum8KBRPAq4 	_2654435874 mdd34YWiAg3My2yImNqXl 	 
    	  
 .distance muSqeiR_y2eGzk1xMiMYn 	 
    	  
 mgrhXqWws_YrCFlke2onn 	 
    	  mx4wjZCbiqMiim6vdjgYv 	
             mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     mS4iHRMZIErx7QNz35j8M 	 
    	  
    		 
     mbxcyYUJwW2czE9V2rAbK 	 
    	  
    		   
     
  _5829441678613027716 mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
     mpxwp6NEFBHMfD6GmK9Qe 	 
    	  
    		   
     
     
 
  	 mw5gGymCpvseVLBTkYnHw 	 
    	  
    		   
     
     
 
   mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
 const uint32_t&_11093821926013 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
    mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   
     
     
 
  	 std myQWm8kXQh88dCDeg0z7O 	 
stringstream _706246330191125 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
 _706246330191125 mcSxtLjoAnZ4OK3B2cL6H 	 _11093821926013 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
 mj6Ks4i_WsqzUoOaSJmhO 	 
    	  
    _706246330191125.str mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
   mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		    mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
   
    
    std myQWm8kXQh88dCDeg0z7O 	 
    	  
    		  map mrSYLVqGT2okEHtq2SFBE 	 
    	  
  uint32_t,vector meQwHHdvLY3F5yCxVdG4W 	 
  _3005401605294789533 mbq9o5ueImx1V6wV_C_u3 	 
    	  
  myTCGpJdqJUBeZm4TxmBB 	 
    	  
    		  _11350249437170142625 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
  
     mLfoLARhDw8t6Z36Q1Us5 	size_t _175247759374 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
     
     
 
  0 mqib1onMeOPsOgYE4IKfX 	 
    	  
 _175247759374 mrSYLVqGT2okEHtq2SFBE 	 
    	  
    		   
     
 _8361296960174125730.size mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
     
   mFKsGrLHwBt00i8an1Xc5 	_175247759374 mmLWxH3uFwkkvDwff8Bk_ 	 
     mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		 
         md4vzx4NDcDMY1msVIYDO 	 
    	  
    		   
     
  const  mRcNw9LctVT4dMUHF3iuE 	 &_46082575882272165: _8361296960174125730 mfPytrQtReEvytN8BDCL1 	 
    	  
    		   
     
     
 
  	_175247759374 moOBjwVXvSP_4xCPk6CtM 	 
    	  
     mqtVv5arA2zK0KQU3XuQa 	 

            _11350249437170142625 mi22kkdOXcVum8KBRPAq4 	 
    	 _46082575882272165._18030119007246525509 mdd34YWiAg3My2yImNqXl 	 
    	  
    		   
  .push_back mwyRMFQmWjm44OKwYlAHV 	 
   _46082575882272165 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
    std mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  
    vector mJ1IoQRruz9wl7O23xmH6 	 
    	  
    		   
     
 MapManager mKLJVb84nIvZ68mR3FGpa 	 
   NewPointInfo mtxoaXTIgdw6IckN5O_1r 	 
    	  
    		   
      _4622533121193472218 mwuKpk61WuwpkeXLjoGtV 	 
   
     mlXmOyucHj7B4KGRt9QIZ 	 
    	  
    		   
     
    auto &_175247760278:_11350249437170142625  mqRw7ZRmykd5ZKdNrZFp8 	 
 
     mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   

        MapManager mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
     
     
 
 NewPointInfo _16937373753124017671 mx4wjZCbiqMiim6vdjgYv 	 
    	  
   
        
         mj3O_HRIo8HZCQaTnABD3 	 
    	  
    	_16940367568811450714 mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
 -1 mqIGVIwmhASOuS86BKsb2 	 

         mWzq4TbDdpF_h4YMshq8X 	 
_14213191106379209118 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
 std mT6pnySI9xcvr4lVO9RYQ 	 
    	  
 numeric_limits meQwHHdvLY3F5yCxVdG4W 	 
    	  
  int mFSQGH0yYhZjnwpbrENwW 	 
    	  
  mrtQ8ThKp75Qrrqfkm7Cv 	 
  max mG1JPd3asQlBL_9E6kqi0 	 mXqyc9gORXuLKEPtUgpHo 	 
    	  
  
         mxbtp69LKYVpqiVsVfN2T 	 
    	  
    		  size_t _175247762932 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  0 mVV6TudP3Q6gowf1fGOGi 	 
 _175247762932 mT5iEPWCvAyIQXq3JvyDZ 	 
    	_175247760278.second.size mTC5zqOspkgnq_h6j8WFp 	 
    	   mqIGVIwmhASOuS86BKsb2 	 
    	  
    	_175247762932 mmLWxH3uFwkkvDwff8Bk_ 	 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
 
  mCumyw3v8A1Jlx0sXTrxg 	 
    	  
    		   
     
     

            const  mbxcyYUJwW2czE9V2rAbK 	 
    	  
    		   
     
 &_16997228172148075180 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		 _3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	  
    		   
     
     
 
  	keyframes mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   
     
     
 
   _175247760278.second mfPytrQtReEvytN8BDCL1 	 
    	_175247762932 mk5U52lna0dXdrh2Lw90b 	 
    	  
    		   
     
     
 
  	._681165095198498101 mdd34YWiAg3My2yImNqXl 	 
    	  
    		.und_kpts mldjRuUm1vO4TN4uSde9L 	 
    	  
    		   
     
     
 
 _175247760278.second mPsVn1gr5YPiDxLvmxcPF 	 
  _175247762932 mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		   
     
     
 ._10333569979786346575 mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		   
   mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
             mQGxHO03vnXvYsLbZIyCa 	 
    	  
    		   
     
    _16997228172148075180.octave mYUnEIqfW0vQq2hXUrL63 	 
    	  
    		 _14213191106379209118 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 
  mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
  _16940367568811450714 mZ39X63mOOECbrBHJ9Sbn 	 
_175247762932 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
   msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   
     
   
 
         mljGrNp0eerPSMsOgJrsG 	 
    	  
    		  
        const  mcyGXnvTM2DvFhzZT8DQr 	 
 &_14213185128593570709 mqDyD62nG3CVIoRGD6YW5 	 
    	  
    		   
   _175247760278.second mYalpbnALkVcZA_QR_cDN 	 
    	  
    		   
     
  _16940367568811450714 mICpSyqwpPjKIEZIL6txK 	 
    	 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		 
        _16937373753124017671.pose mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
     
     
 
  	  _14213185128593570709._16701867013855893038 mwuKpk61WuwpkeXLjoGtV 	 
    	  
 
        _16937373753124017671.dist muI3DBWs0mfdbUKl3HHuK 	 
   _14213185128593570709._11690406023733055431 mqIGVIwmhASOuS86BKsb2 	 
    	  

        _16937373753124017671.frame_kpt.push_back mzMcErBSGlkrUG5JbnLeB 	 
    	  
    	   mUcZEU6iM4NgqmYg4Awt5 	 
    _16935669825082873233.idx, _175247760278.first  mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		  mGqg2QR2z38G_RVNYw9pj 	 
    	  
 
        
       
         mlwqRLVVfk7dHu1DmcTTk 	 
    	  
    		   
   auto _11093822383940:_175247760278.second m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
    
            _16937373753124017671.frame_kpt.push_back mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     mUcZEU6iM4NgqmYg4Awt5 	 
    	  _3370013330161650239 mhMI2eT3nLLrJR39GW8UP 	 
    	  
    		 keyframes mfPytrQtReEvytN8BDCL1 	 
    	  
    		   
     
     
 _11093822383940._681165095198498101 moOBjwVXvSP_4xCPk6CtM 	 
   .idx, _11093822383940._10333569979786346575  mu0JQEoIPa09imKwZz_sq 	 
   mgrhXqWws_YrCFlke2onn 	 
     mqib1onMeOPsOgYE4IKfX 	 
    	
        _4622533121193472218.push_back mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 
  _16937373753124017671 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
      mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     
 
  	
     mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
    
     mi4LXHIjWjl798ubAOD5T 	 
    	   mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     _4622533121193472218.size mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     mwSVL3MaPH7SRI8AC35ra 	 
    _1522768807369958241 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
 mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
     
     
 
        std mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   
     
     sort mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   _4622533121193472218.begin mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		,_4622533121193472218.end mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
     , mi22kkdOXcVum8KBRPAq4 	 
    	  
    		  mxmziAipNb9pM16l2UtZn 	 
    	  
     mcjVDrKj01QkSlNHJzRGK 	 
  const MapManager myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
NewPointInfo &_2654435866,const MapManager mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
   NewPointInfo &_2654435867 mqtVv5arA2zK0KQU3XuQa 	 
    	  
   mGWPc5SQRv__WnS9lIKcF 	 
 return _2654435866.dist mYUnEIqfW0vQq2hXUrL63 	 
    	  
    		   
     
     
 
_2654435867.dist mqIGVIwmhASOuS86BKsb2 	 
    msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
      mVV6TudP3Q6gowf1fGOGi 	 
    	  
   
        _4622533121193472218.resize mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
     
 
  	 _1522768807369958241 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		    mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
    
     mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   
     
     
 
 
     mbUsOy5pe03Ll6R_P7RAq 	 
    	  
    		   
 _4622533121193472218 mq9Ts26bheU92U5pmCopw 	 
    	  
   
 mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
     
     
 
  	 
 mFFJf7a8oontOuy75XfqA 	 
    	  
    		   
     
    MapManager mGNB13wn97gUPZujs4u4f 	 
  _10758134674558762512 mmFBAVydr4uCaigvQAzKR 	 
    	  
 int _3005399800582873013  mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		 
     GlobalOptimizer mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   
     
     
 
ParamSet _3005399798454910266 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
      debug mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    	Debug mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
getLevel meqLefwsV4xVPlEPblAGO 	 
     moYn18rymK0dRgMwidbxS 	 
    	11 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
    mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		 
    
    _3005399798454910266.fixFirstFrame mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		  true mVV6TudP3Q6gowf1fGOGi 	 
    _3005399798454910266.nIters mHCoXYUc0g9I0NQfOPPUJ 	 
    	  
    		   
    _3005399800582873013 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
  
    _3005399798454910266.markersOptWeight mPecXVvVdS4vGCYv3b90P 	 
    	  
    		   
 System mX1wUUXA4K97wmsrdVAVK 	 
    	  
    		   
getParams mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
  .markersOptWeight mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		
    _3005399798454910266.minMarkersForMaxWeight mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    System mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    		   
     getParams mQvGyu6abdIsRcU7YMbbH 	 
  .minMarkersForMaxWeight mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     

     mikQ0a6rwIGhsKubeefBG 	 
    	  
    		   
 mcjVDrKj01QkSlNHJzRGK 	 
    	  
  _3005399798454910266.fixed_frames.size mcl9T2AihzOEplsBfKvzL 	 mHCWJjFTJjYO22VuFzjYy 	 
 0  mE48ogqhGNPAyMYcYPB7m 	 
    	  
    		   _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	map_markers.size mWdBGAZqkpvkpD9QHkIiT 	 
    	  
    		   
     
   mEhFq9skOMYS1QtCAsK0C 	 
    	  
    		 0 mhMqkzrWlfc_6Y7e0scjV 	  mCumyw3v8A1Jlx0sXTrxg 	 
    	  
        
         m_7Ue9L48e5DzHoHpC7Wu 	 
    _175247760151 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		_3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
     
     keyframes.begin mcl9T2AihzOEplsBfKvzL 	 
    	 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
        _3005399798454910266.fixed_frames.insert mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   _175247760151 mhMI2eT3nLLrJR39GW8UP 	 
    	  
    idx mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		  
         mns0M5eWHewDeyQbqvPog 	_175247760151 mVwhWBkpUOLGUPjTHsAdn 	 
   
         meWq0IVDEwYXqm8zmM71v 	 
    	  
    		   
     
     
 
  mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		 _175247760151 mSbRzQQlMQxwdEhzEL5t0 	 
    	  
    		   
     
  _3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    		   
     
     
 
  	keyframes.end mxTcGZK7HJpSw0h6YXpMR 	 
    	  mhMqkzrWlfc_6Y7e0scjV 	 
    	   md_rgewqbpuPOotdS1R24 	
             my1jnbEm_lp7a2P734nJC 	 
_3005399798454910266.used_frames.count mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
     
 
 _175247760151 mKDnoL1LUVlIxZu6JM04U 	 
    	  
    		idx mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
    mPg4j1ghUVPlyPcN9rtnL 	 
    	  
    		    _3005399798454910266.used_frames.size mH4LuIlTPWgwHrNL_50_T 	  mzCa7QFPlhK3iex68eysF 	 
  0  mhMqkzrWlfc_6Y7e0scjV 	 
    	  
                _3005399798454910266.fixed_frames.insert mKk64KuQx6U14vMKJ8p3v 	 
    	  
    _175247760151 mmTun3DTrJayzqbfp4aaE 	 
    	  
    		   
    idx mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
  mqIGVIwmhASOuS86BKsb2 	
         mcYShoOxi_Yage6jbefjR 	 
    	  
    		   
     
     
 
     mu0JQEoIPa09imKwZz_sq 	 
    	  
    _15944432432468226297 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    	GlobalOptimizer mT6pnySI9xcvr4lVO9RYQ 	 
    	  
    create mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		  System mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		   
getParams mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		 .global_optimizer mE_L5Tl7PN2VKv5U871Ed 	 
    	  
 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     

    _15944432432468226297 msYULQMzegO_yKEHClq4d 	 
    	  
    		 setParams mKk64KuQx6U14vMKJ8p3v 	 
  _3370013330161650239,_3005399798454910266 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
    
     mHnE8UXvhpCYM8Ja8eTQ0 	 
    	  
    		_16997241708697414575 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
 false mq9Ts26bheU92U5pmCopw 	 
 
    _15944432432468226297 mmTun3DTrJayzqbfp4aaE 	 
    	  
    		 optimize mKk64KuQx6U14vMKJ8p3v 	 
    	  &_16997241708697414575 mgrhXqWws_YrCFlke2onn 	 
    	  
    		    mx4wjZCbiqMiim6vdjgYv 	 
    	  
    _15944432432468226297 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    		   
     
     
 
  	getResults mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
   _3370013330161650239 mqtVv5arA2zK0KQU3XuQa 	 
    	  mx4wjZCbiqMiim6vdjgYv 	 
   
    _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    		   
     
    removeBadAssociations mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		 _15944432432468226297 mmTun3DTrJayzqbfp4aaE 	 
    	  
   getBadAssociations mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
    ,System mX1wUUXA4K97wmsrdVAVK 	 
    	  
    		   
  getParams mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
     
     
 
  	.minNumProjPoints mqtVv5arA2zK0KQU3XuQa 	 
   mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     
 
 
    _15944432432468226297 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	 nullptr mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     

 msM1xiWuQEM4B2LgYBGqq 	 
  
 mo0msV3ikalfY3l_L0OWj 	 
    	  
    		   
     
     
 
MapManager murwtTctRiHhTGZcIBKPl 	 
    	  
  _11362629803814604768 mhzscBF3X5VupHbsC5y3S 	 
    	 uint32_t _16937255065087280628, mQgosJM_B_T4l2BbNMnOt 	 
    	  
    		_3005399802176474746 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
   m_TiuvSTglPdgr78WSpyh 	 
    	  
    		   
     

      
    
    
     mHnE8UXvhpCYM8Ja8eTQ0 	 
    	  
    		   
     
     _16116701644373052209 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   
     
     
 
false mx4wjZCbiqMiim6vdjgYv 	 
    	 
     mlXmOyucHj7B4KGRt9QIZ 	 
    	  
    		auto _2654435871:_3370013330161650239 mmTun3DTrJayzqbfp4aaE 	 
    	  
    		   
     
   keyframes mgrhXqWws_YrCFlke2onn 	 
    	
         m_DyFncuQp84EUMSNUYAw 	 
    	  
    		   
    mVPMdrXc9zLZI1cgVbCRa 	 
  _2654435871.imageParams.isStereoCamera mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		   
     
     
 
 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
 mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
     
 

            _16116701644373052209 mtNhTdzc5aNVJy8tJ_6XY 	 
  true mwuKpk61WuwpkeXLjoGtV 	 
   
            break mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		  
         mgHokv0mWqcLUnod7IEGq 	 
    	  
  
    std myQWm8kXQh88dCDeg0z7O 	 
   set mT5iEPWCvAyIQXq3JvyDZ 	 
    	  uint32_t mNntmdNA_RNDvAWcgk79c 	 
    	  
    	 _46082575804458778 mPecXVvVdS4vGCYv3b90P 	 
     _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	 TheKpGraph.getNeighbors mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     
 
_16937255065087280628,true mqtVv5arA2zK0KQU3XuQa 	 
    	  
   mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     GlobalOptimizer mGNB13wn97gUPZujs4u4f 	 
    	  
    		   
  ParamSet _3005399798454910266 mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
 debug mX1wUUXA4K97wmsrdVAVK 	 
    	Debug mxJTLjVZ0K8E9UPSbgcn_ 	 
    	getLevel mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   
     
     
 
  mZ7M8ku2FactDWMI_91QS 	 
    	  
11 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		  mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
 
     _3005399798454910266.markersOptWeight mGAGi__s4RGDOCR3uGJMS 	 
    System murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
getParams mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
 .markersOptWeight mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
   
     _3005399798454910266.minMarkersForMaxWeight mJH7lxUAKxSn2qNlkRAAi 	 
    	  
  System myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     
getParams mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
     
     
.minMarkersForMaxWeight mXqyc9gORXuLKEPtUgpHo 	 
    	  
 
     _3005399798454910266.used_frames.insert mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    	_46082575804458778.begin mTC5zqOspkgnq_h6j8WFp 	 
    	  
    		  ,_46082575804458778.end mmfidxTudvNfPyvzJ2Edq 	 
 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 
  	 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
    
    _3005399798454910266.fixFirstFrame mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
     
     
 
  	 true mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
    
    _3005399798454910266.nIters muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
     
 _3005399802176474746 mqib1onMeOPsOgYE4IKfX 	 
    	 
     mWRUXQGuYGosipABxDGR2 	 
    	 mVPMdrXc9zLZI1cgVbCRa 	_3005399798454910266.fixed_frames.size mcl9T2AihzOEplsBfKvzL 	 
    	  
    		  mp37wQYr4Z4O3Ifpikccy 	 
    	  
    		   
     
     
 
  0  meoZNkRFUt_Y1l1iBpbUF 	 
    	  
 _3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	  
    		   
   map_markers.size mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
     mb0v60nrqCipJp43YBHzi 	 
    	  
    		   
    0  mtP0kqFwDWFCfzu04orbp 	 
    	  
    		   
     mQpIoyjmuLXV9LO6Q4wRv 	 
    	  
    		   
   _16116701644373052209 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
 md_rgewqbpuPOotdS1R24 	 
    	  
    		   
     
   
        
         m_7Ue9L48e5DzHoHpC7Wu 	 
    	  
    		   
     
_175247760151 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		_3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    		   
 keyframes.begin mopNeOuSjL2v0lWwCRZ8n 	 
    	  
    		   
     
     
 
 mFKsGrLHwBt00i8an1Xc5 	 
    	  
   
        _3005399798454910266.fixed_frames.insert mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		_175247760151 mAnf7RSA13QJe6KQYTkEd 	 
    	  
   idx mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
  mq9Ts26bheU92U5pmCopw 	
         mVQseaqHOjuCLhqFe_GFr 	 
    	  
    		   
     
     
 
_175247760151 mq9Ts26bheU92U5pmCopw 	 
    	  
    
         mcFm04z5jXrKPDRmTzQZ6 	 
    	  
    	 mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
  _175247760151 mgvYH3Bs7wMJHQzWkBaT4 	 
    	  
    		   
     
   _3370013330161650239 miykdOG68WiHnxkuteCJP 	 
    	  
    		   
     
     
 
 keyframes.end mxTcGZK7HJpSw0h6YXpMR 	 
    	  
    		   
     
     
  m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
     
  mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
     
    
             mdZe8IKTOp2UuAoyaVzOV 	 
    	  
    		   
     
     
 _3005399798454910266.used_frames.count mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
    _175247760151 mhMI2eT3nLLrJR39GW8UP 	idx mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
 mgrhXqWws_YrCFlke2onn 	 
    
                _3005399798454910266.fixed_frames.insert mzMcErBSGlkrUG5JbnLeB 	 
  _175247760151 mmTun3DTrJayzqbfp4aaE 	 
    	 idx mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    mXqyc9gORXuLKEPtUgpHo 	 
    	  
    	
         mS4iHRMZIErx7QNz35j8M 	 
    	  
    	
     mU0887GS8dmvoj8KUxkkT 	 
    	  
    		   
 
    _15944432432468226297 mqDyD62nG3CVIoRGD6YW5 	 
    	  
GlobalOptimizer mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
create mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     
 
System mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		   
     
getParams mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
 .global_optimizer muVTEdbGsCBt5fmCFdNGc 	  mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
 
    _15944432432468226297 mhMI2eT3nLLrJR39GW8UP 	 
    	  
    		   
     
     
 
 setParams mALi2PTzYw049ADd6rVBj 	 
    	  
_3370013330161650239,_3005399798454910266 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
      mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     
 
  	 
    _15944432432468226297 mmTun3DTrJayzqbfp4aaE 	 
    	  
    		   
     
     
 
  	optimize mKk64KuQx6U14vMKJ8p3v 	 
    	  &_4098394392539754261 mgrhXqWws_YrCFlke2onn 	 
     mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    	
 mcYShoOxi_Yage6jbefjR 	 
   
 md3v21F3Qkomk1dfGHdPg 	 
    	  
    		   
     
     
 
 MapManager mGNB13wn97gUPZujs4u4f 	 
    	  
    		toStream mhzscBF3X5VupHbsC5y3S 	 
    	std mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    		   
     
     
 ostream &_11093822381060 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		  mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		 
    
    while mALi2PTzYw049ADd6rVBj 	 
_9129579858736004991 mXaZ2xxXkU8ACs6ChHKSx 	 
    	  
    		   
 WORKING mhMqkzrWlfc_6Y7e0scjV 	 
     std mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
this_thread myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
     sleep_for mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
  std mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    		  chrono myQWm8kXQh88dCDeg0z7O 	 
    	  
    		   
     
  milliseconds mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     
 
 10 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
   mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 
  	
    
     mapUpdate meqLefwsV4xVPlEPblAGO 	 
    	  
    		  mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
    uint64_t _11093822380353 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
     
 
 1823312417 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    	
    _11093822381060.write mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		 mlloh2xU6rNB6XCwUP3wc 	 char* mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
 &_11093822380353,sizeof mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     _11093822380353 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
     
  mgrhXqWws_YrCFlke2onn 	 
  mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 

    _11093822381060.write mzMcErBSGlkrUG5JbnLeB 	 
    	 mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
char* mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   &_5097784010653838202,sizeof mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		 _5097784010653838202 mE_L5Tl7PN2VKv5U871Ed 	 
    	 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
   mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
  
    _11093822381060.write mlloh2xU6rNB6XCwUP3wc 	 
    	 mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
  char* muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
&_9728777609121731073,sizeof mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
  _9728777609121731073 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
   mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 
    _11093822381060.write mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
   char* mqtVv5arA2zK0KQU3XuQa 	 
  &_4090819199315697352,sizeof mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
_4090819199315697352 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
     
  mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
  	
     muYex3fmCG6FNikpgyb8m 	 
    	  
    	_11093821926013 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
     
_9129579858736004991.load mcl9T2AihzOEplsBfKvzL 	 
  mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
 
  	
    _11093822381060.write mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   mVPMdrXc9zLZI1cgVbCRa 	 
    	  
char* mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		 &_11093821926013,sizeof mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
   _11093821926013 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  m_w4n_cgQC3AhYNK7cALm 	 
    	 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 

    toStream__ mKk64KuQx6U14vMKJ8p3v 	 
 _5860250156218117893.buffer_,_11093822381060 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
    toStream__ mKk64KuQx6U14vMKJ8p3v 	 
    	  
  _7124056634192091721,_11093822381060 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
     
 
  	  mwuKpk61WuwpkeXLjoGtV 	 

    toStream__ mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
 _2225497823225366210,_11093822381060 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
     
 
   mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     

    toStream__kv mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
    _15327812228135655144,_11093822381060 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		  mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     

    _11093822381060.write mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
    mmFBAVydr4uCaigvQAzKR 	 
    	  
  char* m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
&_13990461397173511559,sizeof mmFBAVydr4uCaigvQAzKR 	 _13990461397173511559 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		    mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 
  mGqg2QR2z38G_RVNYw9pj 	 
 
    _13909239728712143806.toStream mUHB0pxB6QEsBLyWEMRLq 	_11093822381060 m_w4n_cgQC3AhYNK7cALm 	 
     mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     

    _11093822381060.write mhzscBF3X5VupHbsC5y3S 	 
    	 mUHB0pxB6QEsBLyWEMRLq 	 
    	char* mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
    &_1061304613240460439,sizeof mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     _1061304613240460439 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
 mhMqkzrWlfc_6Y7e0scjV 	 
   mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
    _11093822381060.write mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
   mhzscBF3X5VupHbsC5y3S 	char* muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     &_11028815416989897150,sizeof mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
 _11028815416989897150 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
 
    _11093822381060.write mlloh2xU6rNB6XCwUP3wc 	 
   mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 
  	 char* muSqeiR_y2eGzk1xMiMYn 	 &_12303014364795142948,sizeof mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     _12303014364795142948 muSqeiR_y2eGzk1xMiMYn 	 
     muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
    _11093822381060.write mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
    char* mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
 &_4098394392539754261,sizeof mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     
 _4098394392539754261 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
      mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		  
    _8346364136266015358.toStream mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     _11093822381060 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
    
 mu0JQEoIPa09imKwZz_sq 	 
    	  
    		   

 mo0msV3ikalfY3l_L0OWj 	 
    	 MapManager mrtQ8ThKp75Qrrqfkm7Cv 	 
 fromStream mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
     std mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		   
  istream &_11093822381060 muVTEdbGsCBt5fmCFdNGc 	 mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
     

    stop mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
     
     
 
 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    
    uint64_t _11093822380353 mVV6TudP3Q6gowf1fGOGi 	 
    	  
    _11093822381060.read mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
   char* mE_L5Tl7PN2VKv5U871Ed 	 
 &_11093822380353,sizeof mzMcErBSGlkrUG5JbnLeB 	 
 _11093822380353 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
      m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		    mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   

     ml6zAYOqkbeXrsPA65oYl 	 
    	  
    		   
 _11093822380353 mpUKMXpaPT31M6l4lcQ4j 	 
    1823312417 mgrhXqWws_YrCFlke2onn 	 
    	  
    throw std mmFKjQ9D3Cx9UyZkFlHxc 	 
    runtime_error mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     
 
  	string mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
     
 
 __PRETTY_FUNCTION__ mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
     
 
 +"\x43\x6f\x75\x6c\x64\x20\x6e\x6f\x74\x20\x72\x65\x61\x64\x20\x73\x69\x67\x6e\x61\x74\x75\x72\x65\x20\x6f\x66\x20\x4d\x61\x70\x6d\x61\x6e\x61\x67\x65\x72\x20\x69\x6e\x20\x73\x74\x72\x65\x61\x6d" m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
   mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
  
    _11093822381060.read mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
   mlloh2xU6rNB6XCwUP3wc 	 
   char* mqtVv5arA2zK0KQU3XuQa 	 
 &_5097784010653838202,sizeof mKk64KuQx6U14vMKJ8p3v 	 
    	  
 _5097784010653838202 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    	 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		  mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
    _11093822381060.read mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
     
     
 
  mwyRMFQmWjm44OKwYlAHV 	char* mgJtYRVhnIkDjYqP0pN1T 	 
    	  
  &_9728777609121731073,sizeof mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		  _9728777609121731073 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
 muVTEdbGsCBt5fmCFdNGc 	 
    mFKsGrLHwBt00i8an1Xc5 	 
    	  
   
    _11093822381060.read mwyRMFQmWjm44OKwYlAHV 	 
    	   mKk64KuQx6U14vMKJ8p3v 	 
    	  
    	char* mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
 
  	&_4090819199315697352,sizeof mmFBAVydr4uCaigvQAzKR 	 
 _4090819199315697352 mqtVv5arA2zK0KQU3XuQa 	 
    	 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
      mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     mbxcyYUJwW2czE9V2rAbK 	 
    	  _16987968640077875288 mPecXVvVdS4vGCYv3b90P 	 
    	 _9129579858736004991.load meqLefwsV4xVPlEPblAGO 	 
    	  
  mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     

    _11093822381060.read mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
      mUHB0pxB6QEsBLyWEMRLq 	 
    	  
    		   
char* mgrhXqWws_YrCFlke2onn 	 
 &_16987968640077875288,sizeof mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		 _16987968640077875288 mgJtYRVhnIkDjYqP0pN1T 	 
    	  
    		   
     
     
  mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
     
 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    _9129579858736004991 mqDyD62nG3CVIoRGD6YW5 	 
   _16987968640077875288 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
    fromStream__ mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
     
 
  _5860250156218117893.buffer_,_11093822381060 m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		    mwuKpk61WuwpkeXLjoGtV 	 
  
    fromStream__ mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
 _7124056634192091721,_11093822381060 mgrhXqWws_YrCFlke2onn 	 mXqyc9gORXuLKEPtUgpHo 	 
   
    fromStream__ mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		_2225497823225366210,_11093822381060 muVTEdbGsCBt5fmCFdNGc 	 
    	  mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     
 
  	
    fromStream__kv mzMcErBSGlkrUG5JbnLeB 	 
    	 _15327812228135655144,_11093822381060 mE_L5Tl7PN2VKv5U871Ed 	 
    	  mFKsGrLHwBt00i8an1Xc5 	
    _11093822381060.read mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
     
     
 mcjVDrKj01QkSlNHJzRGK 	 
    	  
    		   
     
 char* mhMqkzrWlfc_6Y7e0scjV 	 
    	  
&_13990461397173511559,sizeof mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     
 _13990461397173511559 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
     mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		   
     
     mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
     
     
 
  	
    _13909239728712143806.fromStream mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     
 
 _11093822381060 muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
 mVwhWBkpUOLGUPjTHsAdn 	 
   
    _11093822381060.read mALi2PTzYw049ADd6rVBj 	 
    	  
 mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
  char* mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
 &_1061304613240460439,sizeof mcjVDrKj01QkSlNHJzRGK 	 
    _1061304613240460439 mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
      mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		  mVwhWBkpUOLGUPjTHsAdn 	 
    	  
   
    _11093822381060.read mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
  mKk64KuQx6U14vMKJ8p3v 	 
    	  
 char* m_w4n_cgQC3AhYNK7cALm 	 
    	  
  &_11028815416989897150,sizeof mlloh2xU6rNB6XCwUP3wc 	 
    	  
  _11028815416989897150 mgrhXqWws_YrCFlke2onn 	 
    	  
    mqRw7ZRmykd5ZKdNrZFp8 	 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
    
    _11093822381060.read mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     mVPMdrXc9zLZI1cgVbCRa 	 
    	  
    		   
     
     char* mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
   &_12303014364795142948,sizeof mVPMdrXc9zLZI1cgVbCRa 	 
    	  
 _12303014364795142948 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
  	 muVTEdbGsCBt5fmCFdNGc 	 
    	  
   mq9Ts26bheU92U5pmCopw 	 
  
    _11093822381060.read mALi2PTzYw049ADd6rVBj 	 
   mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
     
 
char* mhMqkzrWlfc_6Y7e0scjV 	 &_4098394392539754261,sizeof mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		  _4098394392539754261 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
     
  mgrhXqWws_YrCFlke2onn 	 
    	 mq9Ts26bheU92U5pmCopw 	 
    	  
 
    _8346364136266015358.fromStream mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     
_11093822381060 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     
 
  	 mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     

 msM1xiWuQEM4B2LgYBGqq 	 
    	  
    		   
     

uint64_t MapManager mrtQ8ThKp75Qrrqfkm7Cv 	 
    	  
    		   
 getSignature mH4LuIlTPWgwHrNL_50_T 	 
    	  
    		   
  mUcZEU6iM4NgqmYg4Awt5 	 
    	  
 
    Hash _11093822380353 mqib1onMeOPsOgYE4IKfX 	 
    	  
  
    _11093822380353 myO9ywX4M4JhMo5qekIpJ 	 
   _5097784010653838202 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   

   
    _11093822380353 mXMuST24StKOjlvcK_5h3 	 
    	  
    		   
  _9728777609121731073 mFKsGrLHwBt00i8an1Xc5 	
   
    _11093822380353 mccZbQBLh1fRpUWnNjQnt 	 
    	  
    		   
  _4090819199315697352 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    
   
    _11093822380353 mJyuGXrQTnGWSExZP6RWG 	 
    	  
    		   
     
     
 
_9129579858736004991.load mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
     
     
 
  mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
  
   
    _11093822380353 myO9ywX4M4JhMo5qekIpJ 	 
    	  
 _5860250156218117893.size meqLefwsV4xVPlEPblAGO 	 
    	   mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
  	
   
     moCSCzrxNS3K2y895STfz 	 
    	  
    	auto _175247760284:_7124056634192091721 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
 
  	  _11093822380353 mxil_uV1iThq_MpHvQWPB 	 
    	  
    		   
     
     _175247760284 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
  	
   
     mxbtp69LKYVpqiVsVfN2T 	 
  auto _175247760284:_2225497823225366210 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
     
     
  _11093822380353 mdnlR3GhvDYY2QvDk1n_h 	 
    	  
    		   
     
     
 
  	_175247760284 mGqg2QR2z38G_RVNYw9pj 	 
    	  
   
     mLfoLARhDw8t6Z36Q1Us5 	 
    	  
    		   auto _175247760284:_15327812228135655144 mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		    mUbfVC8XeBaV_IKq7GPQI 	 
    	  
    		   
     
_11093822380353 mJyuGXrQTnGWSExZP6RWG 	 
    	  
_175247760284.first mqIGVIwmhASOuS86BKsb2 	 
    	  
    		   
     
     
 
_11093822380353 mccZbQBLh1fRpUWnNjQnt 	 
 _175247760284.second mwuKpk61WuwpkeXLjoGtV 	 
    	  mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
     
     
 
 
   
    _11093822380353 mxil_uV1iThq_MpHvQWPB 	 
    	  
    		   
     
    _13990461397173511559 mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
   
   
    _11093822380353 mXMuST24StKOjlvcK_5h3 	 
    	  
    		   
     
     
 
  	_13909239728712143806 mqib1onMeOPsOgYE4IKfX 	 
    	  
    		   
     
     
 
 
   
    _11093822380353 mO43FK_grPtpTezf_bduw 	 
    	  
    		 _1061304613240460439 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
    
   
    _11093822380353 mdnlR3GhvDYY2QvDk1n_h 	 
    	  
    		_11028815416989897150 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   

   
    _11093822380353 myO9ywX4M4JhMo5qekIpJ 	 
 _12303014364795142948 mqIGVIwmhASOuS86BKsb2 	 
    
   
    _11093822380353 m_SKk5KJjFFi8Al_1PtU8 	 
    	  
 _8346364136266015358.getSignature meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
   mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     

   
     mbUsOy5pe03Ll6R_P7RAq 	 
    	  
    		   
    _11093822380353 mFKsGrLHwBt00i8an1Xc5 	 
    	 
 mEMBULFa2Mvh5ETGxFudd 	 
    	  
    	

 mFFJf7a8oontOuy75XfqA 	 
    	  
    		   
     
MapManager mKLJVb84nIvZ68mR3FGpa 	 
    	  
    		   
  _12244964123780599670 mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
     
     
 
  Frame &_6807141023702418932, const LoopDetector mrtQ8ThKp75Qrrqfkm7Cv 	 
   LoopClosureInfo &_11093822343890 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    mynlbwF1mDjEDlyY2nNSZ 	 
    	  
    		   
     
  
     mmwNmDdoxX1SmwQ3tS0J2 	 
    	  
    		 _46082543279161383 mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
      mpxwp6NEFBHMfD6GmK9Qe 	 
    	  
    mw5gGymCpvseVLBTkYnHw 	 
    	  
    		   
     
     
 
  	 mzMcErBSGlkrUG5JbnLeB 	 
    	  
    		   
     
     
 
 const vector meQwHHdvLY3F5yCxVdG4W 	 
    	  
 uint32_t mUCtwgs6hmBzyAKqTQN3C 	  &_2654435887 mqtVv5arA2zK0KQU3XuQa 	 
    	  
  mynlbwF1mDjEDlyY2nNSZ 	 
   
        std mrtQ8ThKp75Qrrqfkm7Cv 	 
 set mw7pLJf0_zha7pwHjrBuI 	 
    	  
    		   
  uint32_t mfyvy2MvpZ6uXS6tXsr1m 	 
    	  
    		    _2654435884 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
   
         muyK7MMdERP7RMBakgK5U 	 
    	  
    		   
     
     
 
auto _2654435870:_2654435887 mgrhXqWws_YrCFlke2onn 	 
    	  
    		    _2654435884.insert mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
 _2654435870 mgJtYRVhnIkDjYqP0pN1T 	 mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
     
 
 
         mODIzUOe1uU7JX2RwXL7T 	 
    	 _2654435884 mVwhWBkpUOLGUPjTHsAdn 	 

     mwkDfOKxbbnPOpQCTuAmh 	 
    	  
   mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
  	 
     mbxcyYUJwW2czE9V2rAbK 	_5232059496476615978 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    		   
     
     
 _3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		  TheKpGraph.getNeighborsV mwyRMFQmWjm44OKwYlAHV 	 
    	  
    		   
   _11093822343890.matchingFrameIdx,true mhMqkzrWlfc_6Y7e0scjV 	 
    	  
    		   
   mFKsGrLHwBt00i8an1Xc5 	 
    	  
   
     mmwNmDdoxX1SmwQ3tS0J2 	 
    	  
    		   
     
  _5232059496475995487 mGAGi__s4RGDOCR3uGJMS 	 _3370013330161650239 msYULQMzegO_yKEHClq4d 	 
TheKpGraph.getNeighborsV mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   
     
      _11093822343890.curRefFrame,true muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
     
     
  mGqg2QR2z38G_RVNYw9pj 	 
    	  
    		   
     
     
 
  	
    






    



     mCWeiMbdSVV82CKZ_gl9t 	 
    	  
    	&_16935669825082873233 mGAGi__s4RGDOCR3uGJMS 	 
    	  
    		   _6807141023702418932 mXqyc9gORXuLKEPtUgpHo 	 

     mWRUXQGuYGosipABxDGR2 	 
    	  
    		   
     
   mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
     
  mIlDTJqsJqyypYUaaevvp 	 
    	  
    		_3370013330161650239 mCeCXfJD4sWSaHy2J5DWI 	 
    	  
    keyframes.is mALi2PTzYw049ADd6rVBj 	_6807141023702418932.idx mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
   mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
     mynlbwF1mDjEDlyY2nNSZ 	 
    	  
    		
            _16935669825082873233.pose_f2g muI3DBWs0mfdbUKl3HHuK 	 
    	  
    		   
  _11093822343890.expectedPos mqib1onMeOPsOgYE4IKfX 	 
    	  
    	
           _16935669825082873233 mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
   _1018502486064296669 mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
     
  &_6807141023702418932 mqRw7ZRmykd5ZKdNrZFp8 	 
    	  
    		  mVwhWBkpUOLGUPjTHsAdn 	 
    	  

     mcYShoOxi_Yage6jbefjR 	 
    	  
    		   
     
    
     mxTzs5MCrk57YYwOLx9iP 	 
    	  
    		   
     
     
 
  	_706246332364647 mPecXVvVdS4vGCYv3b90P 	 
    	  
    		  0 mqIGVIwmhASOuS86BKsb2 	 
    	  
    
     mlwqRLVVfk7dHu1DmcTTk 	 
 auto _46082575882272165:_11093822343890.map_matches muVTEdbGsCBt5fmCFdNGc 	  m_TiuvSTglPdgr78WSpyh 	 
    	  
    		   
  
         mQWdcRH7MPXqRzGqisNDP 	 
    	  
    		   
     
     
 
  	 mzMcErBSGlkrUG5JbnLeB 	 
    	  
    	_16935669825082873233.ids mi22kkdOXcVum8KBRPAq4 	 
    	  
    		  _46082575882272165.queryIdx mICpSyqwpPjKIEZIL6txK 	 mEhFq9skOMYS1QtCAsK0C 	 
    	  
    		   
     
     std mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
numeric_limits mDJXSMZO6rT6qQlIqxXel 	 
    	  uint32_t mRL2K7We_OTNrm8rZiFib 	 
    	  
    		   
 mxJTLjVZ0K8E9UPSbgcn_ 	 
    	  
    		   
     
    max mG1JPd3asQlBL_9E6kqi0 	 
    	  
    	  mrQSgjz5JUWIuhzSDANIL 	 
    	  
   mfVbyjAc8hQQ79E8Pyycm 	 
    	  
    		   
     
     
 
  	_3370013330161650239 mhMI2eT3nLLrJR39GW8UP 	 
    	  
    		   
     
     
 
  	 map_points mcr9lPM3CebPbFa00LmzJ 	 
    	 _46082575882272165.trainIdx mICpSyqwpPjKIEZIL6txK 	 
    	  
    		   
   .isObservingFrame mVPMdrXc9zLZI1cgVbCRa 	 
    	  
_16935669825082873233.idx mgrhXqWws_YrCFlke2onn 	 
    	  
    		 mE_L5Tl7PN2VKv5U871Ed 	 
    	  
    		   
     
     
  md_rgewqbpuPOotdS1R24 	 
    	  
    		   
     
   
            _3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		   
     
     
 
addMapPointObservation mhzscBF3X5VupHbsC5y3S 	 
    	  
    		   
 _46082575882272165.trainIdx,_16935669825082873233.idx,_46082575882272165.queryIdx muVTEdbGsCBt5fmCFdNGc 	 
    	  
     mx4wjZCbiqMiim6vdjgYv 	 
    	  
    		   
     
             _706246332364647 mmLWxH3uFwkkvDwff8Bk_ 	 
    	 mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
     
     
 
 
         mEMBULFa2Mvh5ETGxFudd 	 
 
     mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   
    _10758134674558762512 mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
     
 
 20 muVTEdbGsCBt5fmCFdNGc 	 
    	  
    		   
      mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
     
     
 
     mCtxJFchIldR_Vh2Bl_UK 	 
  _16937290651980367310 mZ39X63mOOECbrBHJ9Sbn 	_3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    		   
     
     
 TheKpGraph.getNeighborsV mKk64KuQx6U14vMKJ8p3v 	 
    	  
    		   _16935669825082873233.idx,true mpBhwZNG5AmJSdqt9XeQH 	 
    	  
    		   
     
      mVwhWBkpUOLGUPjTHsAdn 	 
  
    vector mDJXSMZO6rT6qQlIqxXel 	 
    	  
    		   
   float mNntmdNA_RNDvAWcgk79c 	 
    	  
 _16988745808691518194 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		   
     
     
 
  	 mbjmKZuZxJty9BQ69I2ML 	 
   4,2.5 mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
      mGqg2QR2z38G_RVNYw9pj 	 
    
     mG1x28PWmMnF1ZZC1GPwP 	 
    	  
    		   
  size_t _175247759441 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
    		  0 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     _175247759441 meQwHHdvLY3F5yCxVdG4W 	 
    	  
    		_16988745808691518194.size mmfidxTudvNfPyvzJ2Edq 	 
    	  
    		    mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
     
 
  _175247759441 mns0M5eWHewDeyQbqvPog 	 
    	  
   mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
    m_TiuvSTglPdgr78WSpyh 	 
 
        _706246332364647 mJH7lxUAKxSn2qNlkRAAi 	 
    	  
 0 mqIGVIwmhASOuS86BKsb2 	
         mZHbteUbSd66ZUyO1QLVg 	 
    	  
    		   
     
     
 
 _16937202366523037989 mtNhTdzc5aNVJy8tJ_6XY 	 
    	  
    		   
     
     0 mVV6TudP3Q6gowf1fGOGi 	 

         mGNE6MYszOPOsO1IPh5LE 	 
    	  
    		   
     
     
auto _706246330143240:_16937290651980367310 mE_L5Tl7PN2VKv5U871Ed 	 mbjmKZuZxJty9BQ69I2ML 	 
    	  
    		   
     
 
             mRcNw9LctVT4dMUHF3iuE 	 
    	  
  &_16934301453639377411 mZ39X63mOOECbrBHJ9Sbn 	 
   _3370013330161650239 mAjXTL_Z6M0KR6s06hQaK 	 
    	  
    		   keyframes mi22kkdOXcVum8KBRPAq4 	_706246330143240 mM4n168wE7XxDXpTxryix 	 
  mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
     
 
                
                 muYex3fmCG6FNikpgyb8m 	 
    	  
    		   
  _768618160192377675 mZ39X63mOOECbrBHJ9Sbn 	 
    	  
    _46082543279161383 mALi2PTzYw049ADd6rVBj 	 
    	  
  _16934301453639377411.getMapPoints mQvGyu6abdIsRcU7YMbbH 	 
    	  
    		   mgJtYRVhnIkDjYqP0pN1T 	 
    	  
     mq9Ts26bheU92U5pmCopw 	 
    
                 mcyGXnvTM2DvFhzZT8DQr 	 
    	  
    		   
     
 _637068542992099399  mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
     
     
 _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  
    		   
matchFrameToMapPoints mALi2PTzYw049ADd6rVBj 	 _16937290651980367310, _16934301453639377411,
                                                                 _16934301453639377411.pose_f2g,System murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
     
     
 
 getParams mcl9T2AihzOEplsBfKvzL 	 
    	  
    		   
     
     
 
.maxDescDistance*2, _16988745808691518194 mi22kkdOXcVum8KBRPAq4 	 
 _175247759441 mw5gGymCpvseVLBTkYnHw 	 
    	  
    		   
   ,
                                                                 false,true,_768618160192377675 mE_L5Tl7PN2VKv5U871Ed 	 
    	 mwuKpk61WuwpkeXLjoGtV 	 
    	  
    		   
                 mlwqRLVVfk7dHu1DmcTTk 	 
    	  
    		   
     
   auto _46082575882272165:_637068542992099399 mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
 md_rgewqbpuPOotdS1R24 	 
                    
                     my1jnbEm_lp7a2P734nJC 	  _16934301453639377411.ids mpxwp6NEFBHMfD6GmK9Qe 	 
    	  
    		   
 _46082575882272165.queryIdx mVJXicJ5QqrHRdvZLo_zs 	 
    	  
    		   
     myEOY6zs_BCfNvVc99RmG 	 
    	  
    		   
     
    std murwtTctRiHhTGZcIBKPl 	 
    	  
    		   
numeric_limits mrSYLVqGT2okEHtq2SFBE 	 
    	  
    		   
     
    uint32_t mwSVL3MaPH7SRI8AC35ra 	 
    	  
    		   
     
     
 
 mKLJVb84nIvZ68mR3FGpa 	max meqLefwsV4xVPlEPblAGO 	 
    	  
    		   
     
    muSqeiR_y2eGzk1xMiMYn 	 
    	  
    		   
     
     
 
  mUbfVC8XeBaV_IKq7GPQI 	
                        _3370013330161650239 mhG3DJNHXub3UpRaIip78 	 
    	  
    	fuseMapPoints mlloh2xU6rNB6XCwUP3wc 	 
    	  
    		   
     
     
 _46082575882272165.trainIdx,_16934301453639377411.ids meDjYlq7WdnMw_Ihbdm06 	 
    	  
    		   
     
     _46082575882272165.queryIdx mM4n168wE7XxDXpTxryix 	 
    	  
    		   
     
     
 
,true mqtVv5arA2zK0KQU3XuQa 	 
    	  
    		   
     
 mq9Ts26bheU92U5pmCopw 	 
    	  
    		   
     
     
 
  	
                        _16937202366523037989 mns0M5eWHewDeyQbqvPog 	 
    	  
    		   
     
     
 
 mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
    
                     mgHokv0mWqcLUnod7IEGq 	 
   
                    else mUcZEU6iM4NgqmYg4Awt5 	 
    	  
    		   
 
                        _3370013330161650239 mBm9csSztXShbObeR5lOT 	 
    	  
    		   
     
     
 addMapPointObservation mALi2PTzYw049ADd6rVBj 	 
    	  
    		   
_46082575882272165.trainIdx,_16934301453639377411.idx,_46082575882272165.queryIdx m_w4n_cgQC3AhYNK7cALm 	 
    	  
    		   
     
     
 mVwhWBkpUOLGUPjTHsAdn 	 
    	  
    		   
                        _706246332364647 mYM1M_Zz8iGIxeNqfDdgU 	 
    	  
    		   
     
     
 mqIGVIwmhASOuS86BKsb2 	 
 
                     msM1xiWuQEM4B2LgYBGqq 	 
    	  
   
             mS4iHRMZIErx7QNz35j8M 	
         mwkDfOKxbbnPOpQCTuAmh 	 
    	  
    		   
     
   
          mfvaGLyju7d_oi11W8fzX 	 
    	  
    		   
     
     
 
   mVPMdrXc9zLZI1cgVbCRa 	 
    _706246332364647 mtxoaXTIgdw6IckN5O_1r 	 
    	  
    		   
     
   0  mdtPB3BqquuMT7AZci9rD 	 
    	  
     _16937202366523037989 mtxoaXTIgdw6IckN5O_1r 	 
    0 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   
     
     
 
   mGWPc5SQRv__WnS9lIKcF 	 
    	  
    		   

            _11362629803814604768 mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
     
 _16935669825082873233.idx,20 mgrhXqWws_YrCFlke2onn 	 
    	  
    		   mFKsGrLHwBt00i8an1Xc5 	 
    
            _3370013330161650239 mKDnoL1LUVlIxZu6JM04U 	 
    	  
    		   
     
 removeBadAssociations mmFBAVydr4uCaigvQAzKR 	 
    	  
    		   
    _15944432432468226297 mhG3DJNHXub3UpRaIip78 	 
    	  
getBadAssociations mQvGyu6abdIsRcU7YMbbH 	,System mmFKjQ9D3Cx9UyZkFlHxc 	 
    	  
    		   
     
     
getParams mG1JPd3asQlBL_9E6kqi0 	 
    	  
    		   
     
     
 
 .minNumProjPoints mqtVv5arA2zK0KQU3XuQa 	 
   mVV6TudP3Q6gowf1fGOGi 	 
    	  
    		   
     
 
         mljGrNp0eerPSMsOgJrsG 	 
   
     mgHokv0mWqcLUnod7IEGq 	 
    	  
    		   
     
     
 
 
    _6807141023702418932.pose_f2g mCB5_SJ6_oDTzuXLi4RDZ 	 
    	  
    		   
     
     _16935669825082873233.pose_f2g mXqyc9gORXuLKEPtUgpHo 	 
    	  
    		   
     
    
    _6807141023702418932.ids mNzkiimyygJ1VUtrj96RQ 	 
    	  
    		   
     
 _16935669825082873233.ids mFKsGrLHwBt00i8an1Xc5 	 
    	  
    		   
  
 mwkDfOKxbbnPOpQCTuAmh 	 
 mU0887GS8dmvoj8KUxkkT 	 
    	 

#ifdef _10098161629446870671
#undef  mI0jycv9I8hdyz5okpiOn 
#undef  mIu8CC4fTlLukwbAqkGF5 
#undef  mblf22z7uvTM0nQxHiZHq 
#undef  mCB5_SJ6_oDTzuXLi4RDZ 
#undef  mrJwc3SYLdRneJzJrOJDO 
#undef  mAjXTL_Z6M0KR6s06hQaK 
#undef  mmwNmDdoxX1SmwQ3tS0J2 
#undef  mZHbteUbSd66ZUyO1QLVg 
#undef mNiaSdQ0mKMJcjnj4lKWPONAgXci5Ga
#undef mTxEMa9qLPguKp3sVZMc3XJt7JtC2LS
#undef  mHbmThHe3MAVWLhRMCEAq 
#undef  mSNPy6cbvglXs1K5qjAYC 
#undef  mC9oknUtxCs7_hcCdBD_Q 
#undef  mnDEKEF1Q0AXA_wph4ZCp 
#undef  maQmVYcxqv3tQ0bqHkGeG 
#undef mPu2j7LZ90QGNii_CT1hzNQtfro4Ypx
#undef  mbjWhHGT1O6UUXABodoj3 
#undef  msYULQMzegO_yKEHClq4d 
#undef  mYalpbnALkVcZA_QR_cDN 
#undef  mXqyc9gORXuLKEPtUgpHo 
#undef  moCSCzrxNS3K2y895STfz 
#undef  mfJzMqY26LrkVP7Ch5GIF 
#undef  mwSVL3MaPH7SRI8AC35ra 
#undef  mq9Ts26bheU92U5pmCopw 
#undef  mlloh2xU6rNB6XCwUP3wc 
#undef  mjQ3qi_g_Vm3YnmUGhqmU 
#undef  mOYjY4qcD1f7kaXofCwRJ 
#undef  mHgMC3p14E1RE2m39dDPh 
#undef  mCwhtKniTBE0LaA7UtZJR 
#undef  meWq0IVDEwYXqm8zmM71v 
#undef  mh4ne_A5hTHHqBnF96BXq 
#undef  mqIGVIwmhASOuS86BKsb2 
#undef  mxmziAipNb9pM16l2UtZn 
#undef  mkP4U04MLzSVJ2uFraD9q 
#undef  moef0c8X9PHLRUXiGcCiG 
#undef mhL5U_qnr0t6Q2FTZ16uMiIHY3r6qET
#undef  meqLefwsV4xVPlEPblAGO 
#undef  mm6HOQbzHWlUG_1HYTYT4 
#undef  mmJTX2qjGytM1z4JwqHV7 
#undef  mTDAKvXETuQN6vGi47QsH 
#undef mHQxYR0Q7Pl_ZEq94fwyNvY4oKFSAzO
#undef  mwkDfOKxbbnPOpQCTuAmh 
#undef mt0If_txOHlYq6KWw3ASRces48stFDf
#undef  mSlmE1u3FYlDj0WQbN290 
#undef  mlZv7FvRSVlSJeUgF15N5 
#undef  mYtsRV6z3tHy0K9gnzrGx 
#undef  mSQLcWfnEfgZ0PuCrfnNB 
#undef  mGNE6MYszOPOsO1IPh5LE 
#undef  mpxwp6NEFBHMfD6GmK9Qe 
#undef  md_rgewqbpuPOotdS1R24 
#undef  mm8EtLbxngqrzH150msXn 
#undef  mns0M5eWHewDeyQbqvPog 
#undef  mUXM_fmI6nrofKOPL0U02 
#undef  mVjq7_MnUW_VodC3RucOw 
#undef  mIlDTJqsJqyypYUaaevvp 
#undef mafhvqKAT_C3xKaRnF_r1ENQ2174B48
#undef  mCumyw3v8A1Jlx0sXTrxg 
#undef  mYUggneqq4GdJMIogzvcK 
#undef  meTrkIYUvARrjm51sjpRt 
#undef  myQWm8kXQh88dCDeg0z7O 
#undef  mXUd0YrAP5JgvykkY3SdF 
#undef  mcSxtLjoAnZ4OK3B2cL6H 
#undef  macsdG5dMTheYGCKtgl16 
#undef  mZ92g_U8LXv0r191oMvRP 
#undef  mVgKPt5c1T6HVyb7sG6Ct 
#undef  mIDhxn95_YxHg5IVYckWZ 
#undef mMG6FavND6r98J7cFnRnkFyQxBlb6_U
#undef  mCjRiexLu0qRSi_O84UZJ 
#undef  mCWUNIyMkVRfx2i1Yzmyb 
#undef  mWXCUaIyuUwntiX8Cd5Rx 
#undef  miF8HzTJ1yKBJh4JWRaVS 
#undef  mnNOk56m3W9_qN6SMk4ns 
#undef  mMrgM_Y9qbuuDqckx9Xqq 
#undef  mr0wDGa8Sl8VkmTJOuriV 
#undef  m_w4n_cgQC3AhYNK7cALm 
#undef  mo9tssPwI29nKPz1mdfBg 
#undef  mNGVI9gkuN4ZqEMQyAkbl 
#undef  mDrLQRCJrz_dcXepmLTcw 
#undef  moYn18rymK0dRgMwidbxS 
#undef  mhMqkzrWlfc_6Y7e0scjV 
#undef  mInMjQRPzmPf71S5M_OAU 
#undef mpydSIHyrz3s9DKNmrwtdhkSKB5RJx6
#undef  mNG0Lr81q6dS71UCL5R6t 
#undef  mcpXRRK9_x4QFeWWGpDW2 
#undef  mJH7lxUAKxSn2qNlkRAAi 
#undef mJtOzAJh610Fvjd2R2pOBARlxOvBPxc
#undef  mb8K833BVz8wAkko_ly_D 
#undef  mgHokv0mWqcLUnod7IEGq 
#undef  miNcqP8y27Vzwe5pC5fan 
#undef mVJTXaSDIsOG7CAegcj4Zh7pwBy8N2q
#undef mpe645CMry_wt8oLOsjqCUjRiMTRiSg
#undef  mxil_uV1iThq_MpHvQWPB 
#undef  mZhx3VftB3hUlzelroO_F 
#undef  mdtPB3BqquuMT7AZci9rD 
#undef  melMfsk6aoDoC_TT7FBTX 
#undef  mcbkteCbIqKuKtrLgUIfd 
#undef  mvgLSb6nvObH9RSOVH6V9 
#undef  mMvMsqBap9Hw9LF2cAj9b 
#undef  mUGdvEajfIdFM8nFbePYp 
#undef  mIBMvgKkc2foCmes5xsAh 
#undef  meQwHHdvLY3F5yCxVdG4W 
#undef  mbq9o5ueImx1V6wV_C_u3 
#undef mbBrVmMKas9GTKof_TJxilrVJBR9KWo
#undef  mfvaGLyju7d_oi11W8fzX 
#undef  mAW3bu5hMgaP7aKeEYYnI 
#undef  mjy7HRx1LpwVATcMN09gh 
#undef  mUOXqjOCjC3AVzs3dZH3o 
#undef  myUlBDVbNfKrGVTrhf2x8 
#undef  mgGBi3p9VXo2bj1YoPmQb 
#undef  mmTun3DTrJayzqbfp4aaE 
#undef  mgiY6rJNBubapZpdDBOIp 
#undef  mHT3d9ddsvwZdu1VRxFPi 
#undef  mzduKdBu2_A7Owmoj5Day 
#undef  mBBzsM7ki8vgYjoNRue2D 
#undef  mgL5HHnLD_hk4XcCExqJI 
#undef  mn_tZgjZuM7KAeTAz_421 
#undef mbASmjOyeKebRPl5GYneyheglwnvdpg
#undef mTAFgXoCrp4U5ZS8dHBLAMJfglolc96
#undef  m_7Ue9L48e5DzHoHpC7Wu 
#undef  mFPeZygiNoVb66EsgDYr3 
#undef  mtNhTdzc5aNVJy8tJ_6XY 
#undef mvbI0ZM1kSh_tMdTDurtLmGk677NjFv
#undef  mevbPKKoZMKYI5wWj7pC6 
#undef  mkll49jutNf4uYxCnCAMV 
#undef  m_TiuvSTglPdgr78WSpyh 
#undef mgFfYtkwCCFca0v5nsUUffyugY_qoU5
#undef  mcjVDrKj01QkSlNHJzRGK 
#undef  mGqg2QR2z38G_RVNYw9pj 
#undef  mcEiiavQdXIc_9u1RSo4Z 
#undef  mgJtYRVhnIkDjYqP0pN1T 
#undef  mcYShoOxi_Yage6jbefjR 
#undef  mgblCN4MzHsbpbt3YM7Vd 
#undef  mpRrGRVWahWZBUkeUcAM2 
#undef  mR4L5cNGaOQGGQOh89RXM 
#undef  mAqRObqw339IP4cFf1Si6 
#undef  mUGfl6xTNalW2k1tY9yUc 
#undef  mqHvBkPdFTe5X6Pa18O8n 
#undef  mnxkj2qFgeOjrrT0gHAC_ 
#undef  mNdNKilI4un3GVK4Sigfl 
#undef mdKHTsg5nO8w1OX7PAXonJsK83UWtMR
#undef  mOEVWQP_oYW79QXCEZVJ_ 
#undef  mZ7M8ku2FactDWMI_91QS 
#undef  mj3O_HRIo8HZCQaTnABD3 
#undef  msokfyBquqxjfod3JIEUP 
#undef  mtP5oHq1iCvqkZMI6rDgh 
#undef  mYk49PGDChDSFdaVxCFL_ 
#undef moH1g12LQXrI2hVFiMMShgNnWXDf005
#undef  mEhFq9skOMYS1QtCAsK0C 
#undef mAiOvKFbgllVkHOwDMSz_7Rm2SIM34q
#undef mj1BZfqMpao9ejGH6oD1MxrPyJGAT8R
#undef  mtlGHbqBCRJIITRlM32U0 
#undef  mfKMOGKv4NOhldV0moFQT 
#undef  mg3R8AcKNwM9dmJX8Znnh 
#undef mYfpcIpb1yP9t2TMh7so6Er5JtS93pM
#undef  mUa1EU6yGMKZvX3XlifJ2 
#undef  mxNFEUSIIE9qRMSlXkt5M 
#undef  mM4n168wE7XxDXpTxryix 
#undef  mOnSciWrXfPz0wba7g0za 
#undef  muTNXl7Tk7NghGgmF1sVN 
#undef mhojpwrE4Ejpo4p7Xh_SBxWM3A2Y5Jh
#undef  myEOY6zs_BCfNvVc99RmG 
#undef  mUCtwgs6hmBzyAKqTQN3C 
#undef  mk6iMcMr10T4CoqxUJ7uW 
#undef  mOzO85Ea05Vq7EejRQhCE 
#undef  mw_mkEMiaehl6JKL_WhQI 
#undef mZxQAmlo5OsISZjhhxScQGv77COIgQT
#undef  mrnjAImSi2ErsLqe_yEoM 
#undef  mYJRpt4V1whNP6WA1fhTC 
#undef  mAmHOxdD1j7TzUWdCwxhA 
#undef  mDQx2srYBz1w7JVQxbPDm 
#undef mbdogFr_F7R52NrnSy7m90KccK8zZfr
#undef  mQWdcRH7MPXqRzGqisNDP 
#undef  mpBhwZNG5AmJSdqt9XeQH 
#undef mb3Nm1Ykd9s3emL6KbdtrScvQNKtxUb
#undef  mPXIcefmOdWsicz8IpvUN 
#undef  mT6pzPi26S6IymQoERJwO 
#undef mUL9qyepciYZmU_rCrmyKjSJAgs8edl
#undef  mmFKjQ9D3Cx9UyZkFlHxc 
#undef  mbUsOy5pe03Ll6R_P7RAq 
#undef  mGWPc5SQRv__WnS9lIKcF 
#undef  mfMBEtrFWQQFUegSB78hy 
#undef  mYUnEIqfW0vQq2hXUrL63 
#undef  mCOan7kdhEtn47Msawdb7 
#undef  mJAHS9_z8er6lWzCLUnRO 
#undef  mx4wjZCbiqMiim6vdjgYv 
#undef  mljGrNp0eerPSMsOgJrsG 
#undef  mKkesnC12Ak5eQkNNWpXd 
#undef  mtxoaXTIgdw6IckN5O_1r 
#undef  mhXIL231gO2k67E6seNp1 
#undef  mRzhzNeZlqLjMSU8QVpDc 
#undef  mpjmPCAzmrMFmZ5PgS_z0 
#undef  mfdVdAvLU6fq_tnw5_bBn 
#undef  mVOgPwAEFFIQV_xDshfLf 
#undef  mL7BP7Bp_ezQ3vWbxBywq 
#undef  mWRUXQGuYGosipABxDGR2 
#undef mYT60t8QeO9tAegQY9MtX3zBJ0fu7qg
#undef  m_DyFncuQp84EUMSNUYAw 
#undef  mwuKpk61WuwpkeXLjoGtV 
#undef  mw5gGymCpvseVLBTkYnHw 
#undef  migMa2M0Nqi3KcutGTiFf 
#undef  mVV6TudP3Q6gowf1fGOGi 
#undef  mfVbyjAc8hQQ79E8Pyycm 
#undef  mlgQQgqJptRopt8MHyqpW 
#undef  mI2xNOxs3LAsOh0kd9rag 
#undef  mx950BNJPshhiaRX2Ay0A 
#undef mOJ_Qi96hdaoSSbw92X4xMzZ9GYITZB
#undef  murwtTctRiHhTGZcIBKPl 
#undef mqiykuSRdhK7aITYzqQIQEVINMcX4Gl
#undef  mI44ZgfxIHthCzbdZ6udV 
#undef  mTiEKGOFuG5CzvVLEi4ct 
#undef  mlwqRLVVfk7dHu1DmcTTk 
#undef mk3DMhmvu3KHsRWFpKTbwv7V1vAj8po
#undef  mgSQH2AUBAeLNhSHu3Zf_ 
#undef  mXMuST24StKOjlvcK_5h3 
#undef  mRldtTgztYHN1IdEucRhE 
#undef  mN7MiwBiEdgq0ggPj2nFa 
#undef  mupbUOqfSC_nVtTSXffC9 
#undef  mWVeb4vXHTIAIyKlPWUFF 
#undef  mT5iEPWCvAyIQXq3JvyDZ 
#undef ma4YUPcQA41oTu5YWW7ZGaIR6inVghd
#undef  mFKsGrLHwBt00i8an1Xc5 
#undef  mX9K5HXbqpb1oLzLf8pTT 
#undef  mAwK1UaOguYx9zQxriz_j 
#undef  mCCmBN7UYYEzWawqrwSrj 
#undef  mBjuGBAw2vOzhzZzhYVov 
#undef  mPecXVvVdS4vGCYv3b90P 
#undef mfqlABorV1_5R1yxiZlw1ytGl5wakvw
#undef  mFqfBSRBisjn6g4Th7PSf 
#undef mdp8fNPp6pYdhRPl2bMgCPENsq4spIE
#undef  mqXilDJRHCpE4Dr4qdyiQ 
#undef md9VfjT4TsaiSAtn6gm1pAB1Xd5PjK0
#undef mimQjvHyuJQghimDmP88SNtwm0obVVR
#undef mnIbwQAp_4mxFQDA87hb_nJXkH2BxeM
#undef mheAUWU8s9SXd0vH_RNmAN5KAJ1swea
#undef  mvrEIX2ffF9EooN46qRxt 
#undef  m_ge1iGc_KOZ7YqBP1RQD 
#undef mNtDkzcyg57ZXfl0qBMN_WAbdkMaKh5
#undef  mu0JQEoIPa09imKwZz_sq 
#undef  mTqs15X3WDAV_qbRAk2QQ 
#undef  mB7JgvHUdX06fCRwTbLAN 
#undef mBfrg0ip1reDFnE9rHd286xQC3ZAT5O
#undef  mYs38GO3Q4UBP2ME4JWjz 
#undef  mpDC1DcS2h1EtP3VtsnLy 
#undef mf5dqAB0Vq0xf7gQ3BY9DpgDgGoKSWl
#undef muND_V0lj5_v6bMmI33DWM6l8yQANR7
#undef  mzmYh1SxXGCcirIamom6c 
#undef  mL4UxjzZuKcSLz7emkYex 
#undef  mtP0kqFwDWFCfzu04orbp 
#undef  mrqAWZP8k7OV5eM6RIR2a 
#undef  mKTSlYiNahEka5gZEC4MJ 
#undef  mCeCXfJD4sWSaHy2J5DWI 
#undef  mH21yIuXNXiJ61mLm8g9c 
#undef  mA1SiPAlDQKFRPK4bbP3W 
#undef  mNTy2WXcwc6BNgcVDQixE 
#undef  mZ3ST2EFJdi6ASEKgEnxs 
#undef mUwJWeJ0XyFUo4cNikCq0YqNANhpcQB
#undef  mS9iu7WO8UL_Iuz0ZUu_v 
#undef  mnnXn3K_Bsu8MRKasLN2j 
#undef  mNA2fp1o6c4TsKF9zeotc 
#undef  mhbj_1hIoOAj671Jmwy_w 
#undef mxLqhhzzukdHfAiJa49DYz_BJhm6SiG
#undef  mxRhIlNl30OdWntAgbJ4c 
#undef  mwmZX9vYHZD9ZOWmxqkFX 
#undef  mNDghLC5p_fEBUZ7ume_6 
#undef  mLfoLARhDw8t6Z36Q1Us5 
#undef  mZ39X63mOOECbrBHJ9Sbn 
#undef  m_LEYmqun_thbvcWGKmb7 
#undef  mqLboYvGKMePFjn_VVXGm 
#undef  mf9cxTP1a140lA3WZfHmo 
#undef  mtO4mkitZ9LLt0a01hBn9 
#undef  mFaDF6Sbr4h3uKR8UvtW0 
#undef  mP664ona8C1_RbEJ3JqjD 
#undef  mbK6VdnkRkaSrM2UPZZgN 
#undef  mDz4u7HXChSKYFNSyKmjs 
#undef  mP_aslRf7PvTaeTuN4UTQ 
#undef  mDcc3r5LdsrjbJNiMvYMD 
#undef  mfyvy2MvpZ6uXS6tXsr1m 
#undef mhas04XCO6WR9CCv2VpnfDmYyiWU1B2
#undef  mOK2f4ajpGyviNqOABsg9 
#undef  miykdOG68WiHnxkuteCJP 
#undef  mU0887GS8dmvoj8KUxkkT 
#undef  mCR1oszzbai7dRmXRkIBL 
#undef  mGMg6KOfoCZuqEh8N9lym 
#undef  mQGxHO03vnXvYsLbZIyCa 
#undef  mBn1Pz4_J9H2eBPziW0gt 
#undef  mcRKPLE_QHTEdCKtARkjM 
#undef  mqRw7ZRmykd5ZKdNrZFp8 
#undef  mo0msV3ikalfY3l_L0OWj 
#undef  mR4IMBqcMIux9HvMzTO18 
#undef  mXq8MCFueCVV9ZVPzE9Vc 
#undef  mADSK0AOaLDYm81Gwhb7h 
#undef  mccZbQBLh1fRpUWnNjQnt 
#undef  muVTEdbGsCBt5fmCFdNGc 
#undef  mIhdUOC63xZPw9gcE1dpq 
#undef  mQgosJM_B_T4l2BbNMnOt 
#undef  mrBnoDChobd0Jvp7EM1TH 
#undef  mj6Ks4i_WsqzUoOaSJmhO 
#undef  mC2nVdu94JAlqr4Eiuptd 
#undef  mr9B7XJzQ6I6_AzWT06sa 
#undef  mURiIvbAix7YwMDFXZHA6 
#undef  mtRUYxRlBojLEhyKyUFgg 
#undef  mi30yhHmNZZOoqEQzrjek 
#undef  mxTzs5MCrk57YYwOLx9iP 
#undef  mUcZEU6iM4NgqmYg4Awt5 
#undef  mfQNf2aZ_GkKYQm8SAyg8 
#undef  mODIzUOe1uU7JX2RwXL7T 
#undef  mICpSyqwpPjKIEZIL6txK 
#undef  mRL2K7We_OTNrm8rZiFib 
#undef  mHiWFtCL9TZ_X42JLcrul 
#undef  mFSQGH0yYhZjnwpbrENwW 
#undef  mcl9T2AihzOEplsBfKvzL 
#undef  mVQseaqHOjuCLhqFe_GFr 
#undef  mG1JPd3asQlBL_9E6kqi0 
#undef  mMmtquMhRg6yCdLY858D1 
#undef  mNzsDjNyaUJvQGgM15Sbt 
#undef  mnnV3093GPvSgoZfWe8AJ 
#undef  mDJXSMZO6rT6qQlIqxXel 
#undef  meG6UW6Dq9R0gyvgq_EdY 
#undef  mSPJcUebE5TJISeYndAhJ 
#undef  mBm9csSztXShbObeR5lOT 
#undef  mI37J5Pj1p_3lKB8inN7C 
#undef  mQ9QZKCqU6iNNhKKqL0or 
#undef  mxbtp69LKYVpqiVsVfN2T 
#undef  mWdBGAZqkpvkpD9QHkIiT 
#undef  mfJVDwoC0VGHdZGHXFrws 
#undef mie9fuFs_nXJ_SqWHZ9NUWZ0phhOdnj
#undef  mBkPaqOLhw8MlBr9LICSk 
#undef  muYex3fmCG6FNikpgyb8m 
#undef  mdnlR3GhvDYY2QvDk1n_h 
#undef mKvDLxbSKPh31eolOJ2n96j41kO8POV
#undef  mFDZj2QvdtCnfyY0kunXP 
#undef  mmCtW0drSEnrS7Ddz8JcG 
#undef  mtBbZNQC8mOA2pZhB2nS1 
#undef  mrIhlmutvZpmCGRCLq46w 
#undef mLeTfYRIBJ30zKzY_gnxt9LP6tQnxlz
#undef  mIvyTIRlNytd3GAkEsWlR 
#undef  mALi2PTzYw049ADd6rVBj 
#undef  mfwMBWnWGUtSBkvH5hZXq 
#undef  mihiVFV8OBTUq_yEAywNP 
#undef mj3dZcXmDcU_WlhqvtsFMHDL9YH5FY_
#undef  mWi1t2_NQ_UnMuIDbvW2L 
#undef  mhzscBF3X5VupHbsC5y3S 
#undef  mqDyD62nG3CVIoRGD6YW5 
#undef mrPNZd9_D3xQ6z93PYTgYUErbveiPL6
#undef  mbjmKZuZxJty9BQ69I2ML 
#undef mi8dUAlN_H2evlwqH0RsTwwJjtpga3z
#undef  mWR50ZawS5wHcMJg_LCaJ 
#undef  mUbfVC8XeBaV_IKq7GPQI 
#undef  mUGPDj5SLHcqbDV4yB_ua 
#undef  mKLJVb84nIvZ68mR3FGpa 
#undef  mah8QBrW01dlehoVe2fbA 
#undef  mmXJILAEp1xyQ9Hwh5wEN 
#undef  mKDnoL1LUVlIxZu6JM04U 
#undef  miK2qg7yudg5N36IYfUBC 
#undef  mixmK_MWhW5N42M4nDs2p 
#undef  mNntmdNA_RNDvAWcgk79c 
#undef  m_XhQLQUZ_TSRrhwtchgq 
#undef mrwosjIxTYfjeaK3D80oqlRXsjKXuvT
#undef  mqHDtLGgdThiQ3pUGQWKu 
#undef  mOvn27C2XcG1Z28w5Gr8a 
#undef mIQ3pGhymOxCJt1kn3ATOVVTcl5BHHt
#undef mquL6i79f4ca2A3Q480ELzz5EdUNkJv
#undef  mjueF1WX8jQ95ephOsQUi 
#undef  mE48ogqhGNPAyMYcYPB7m 
#undef  mPJNpZuG5NL1tjqjKmBGJ 
#undef  mb_Pnxs72kcb_ftPjNF1W 
#undef  mSIHsYVCCPUNVrlVeVRgc 
#undef  mzMcErBSGlkrUG5JbnLeB 
#undef  mcFm04z5jXrKPDRmTzQZ6 
#undef  mt_VZ0aLq9BHrRkFuFVoH 
#undef  mUennHvvhfAGzuO2WDteV 
#undef  mveZyghau7H09KUvl3Sxz 
#undef  mdwCPmudIjhxhtawwa62U 
#undef  mHCoXYUc0g9I0NQfOPPUJ 
#undef  m_SKk5KJjFFi8Al_1PtU8 
#undef mHqnFWFxIWOsjWV6ZbAPOaPUvLsYBxb
#undef  my1jnbEm_lp7a2P734nJC 
#undef  mfPytrQtReEvytN8BDCL1 
#undef  m_y6lfzrX2UhscabhuaYk 
#undef  mhhM9xGBWxAhZVySJBtHr 
#undef  mCtxJFchIldR_Vh2Bl_UK 
#undef  myfA2o93uA3w_K66ORh57 
#undef  mCCnzan6KXz4FedPeuA99 
#undef  mbMl8EWn0sIUsLbLuMiSo 
#undef  mlXmOyucHj7B4KGRt9QIZ 
#undef  mEMBULFa2Mvh5ETGxFudd 
#undef  mtj0rcX0Y0d4c8xv3jmFL 
#undef  mAnf7RSA13QJe6KQYTkEd 
#undef  mmfidxTudvNfPyvzJ2Edq 
#undef  mVPMdrXc9zLZI1cgVbCRa 
#undef mU9zoPF248k_LkRLeck1OLJzetE5tsO
#undef  mX1wUUXA4K97wmsrdVAVK 
#undef  mgT5lNXMjikdXgbZIZJv6 
#undef mlJwLAFX4teybmTsMff7wMwjYR3jRMj
#undef  mrlaffTFM738Clt_zoPiu 
#undef  myO9ywX4M4JhMo5qekIpJ 
#undef  mi4LXHIjWjl798ubAOD5T 
#undef  mrQSgjz5JUWIuhzSDANIL 
#undef  mkKP9_n1OFiKLu7NSr2O_ 
#undef  mI5Bsmz3MIuVhKAQeucLT 
#undef  mdd34YWiAg3My2yImNqXl 
#undef  mbidxjDSeDL0eqrujFQOt 
#undef  mdabCEOB6d7uJYi0JbPnF 
#undef  mSsrxEUyYs5Bs1IW7SDmD 
#undef  mKRW_rfku582o1jF_lL3D 
#undef mVh79K9TtMWNYgtHCKN6A_KrAj9YNIH
#undef  mxJTLjVZ0K8E9UPSbgcn_ 
#undef  mEyrrb58CWnwTqVop_IS_ 
#undef  mWyATZ0VZXif4Auih2_PN 
#undef  mhMI2eT3nLLrJR39GW8UP 
#undef  mp37wQYr4Z4O3Ifpikccy 
#undef  mW9QCGrHAGAMpOOZcP__5 
#undef  mCWeiMbdSVV82CKZ_gl9t 
#undef  muI3DBWs0mfdbUKl3HHuK 
#undef  msg_XfFtj6tvEeXkCdo58 
#undef m_dzrefArqxixkw4XXby_lEtCdUoVC3
#undef  mkzaZhXiFLY6L2ulJ8dCX 
#undef mjcMTxGGHeHYj4FlWPDSgY_G5XMVopz
#undef mGTfqtdQLk_k1KB7Dpb6WewaT0IONPI
#undef  mwEwKEOLE2wVqCjudr0qf 
#undef  mu0pKwcyCv2xvYmgb1jJI 
#undef  msM1xiWuQEM4B2LgYBGqq 
#undef  mJ1IoQRruz9wl7O23xmH6 
#undef  mp0E2EqyjrJLlBOrkgoNX 
#undef mgqhaf_SbS0o3_gKfpkBJ_4UrBd9I5C
#undef  mYLC_qjdaDA4Wcd4m6QzY 
#undef  mwyRMFQmWjm44OKwYlAHV 
#undef mUpT_7yMbQU7VcPzLnaq2iLWfgM2tCc
#undef  mGNB13wn97gUPZujs4u4f 
#undef  mQeACzywVnNdBT_8ZH9SI 
#undef  mNzkiimyygJ1VUtrj96RQ 
#undef  mqib1onMeOPsOgYE4IKfX 
#undef  mMrmXuyGsQctvG3qzx5ut 
#undef  meoZNkRFUt_Y1l1iBpbUF 
#undef  mQbxqpSN4dTRZK3M8XTxa 
#undef  mcshRtOqNU0JzGlAvTP8W 
#undef  mcr9lPM3CebPbFa00LmzJ 
#undef  mUHB0pxB6QEsBLyWEMRLq 
#undef mDxmRRfx1Pg3kd6B5kj4jjolQOVJTWi
#undef  msiNvFeVYaaYDJZGevDA1 
#undef  mrN_iGCUj63DYEJ_Pu847 
#undef mQQ7SZaMz9qOpzZcDKXe7Gr2Bq0VKEU
#undef  md3v21F3Qkomk1dfGHdPg 
#undef  mHnE8UXvhpCYM8Ja8eTQ0 
#undef  mCNYwJsXZdoXiqyjZ3mhG 
#undef  mLcmXGYgVoSuhaUw_Vq1V 
#undef  mukQXCE7YwL_DR4go8EFo 
#undef  mVJXicJ5QqrHRdvZLo_zs 
#undef  mNhiE5rOwXWQ904e6iYM1 
#undef mSkuyx_RUq4Q0STkMZ5ozhxiFf5mJcT
#undef  mgrhXqWws_YrCFlke2onn 
#undef  mwAssFo1DgaMWzHa_sMv7 
#undef  mopNeOuSjL2v0lWwCRZ8n 
#undef  mPazbCX0MemfBs9wuskQm 
#undef  muG1imrLOEspqvQqTRN2o 
#undef  mcNrDWgymw2zYtd9SAQxN 
#undef  meDjYlq7WdnMw_Ihbdm06 
#undef  mgvYH3Bs7wMJHQzWkBaT4 
#undef  mynlbwF1mDjEDlyY2nNSZ 
#undef mKDcmr7oM_Qm_fhBMV567AN7c3iEEQN
#undef  mOATb6IpKhH55GJ7qSHK6 
#undef  mE94kJ6N0Yb4TBvzGgxeI 
#undef  mQpIoyjmuLXV9LO6Q4wRv 
#undef  mH4LuIlTPWgwHrNL_50_T 
#undef  mPWwa7xP2lPIuMC45VJBx 
#undef  mOZTWJ4gBfLAlZ99WNTpb 
#undef  mutb79NU6aj2Op6Wytwh_ 
#undef  mVwhWBkpUOLGUPjTHsAdn 
#undef mNIcxPtwVxXllb694pvdrVig0kAbi7N
#undef  mwB9zDucs6IBiVmjiVLOT 
#undef mlEmlW3Nvm7fKRAsjQMjZzFvfuhAM7f
#undef  mKlep6wnvjHcYjA0LndsY 
#undef  msWL_GqW9oZ8tTzIlNxEE 
#undef maEfyaVLFZOj8GWwlcYL0jcQibVHSpq
#undef mTaf1CsDY_nAuauCSZtFFzXSffDrX27
#undef mBvNHWlf0wJtxaBGpjKOEejSjmn7Ljc
#undef  mJyuGXrQTnGWSExZP6RWG 
#undef  mCU6h85dLu_Q8EG3Fd30r 
#undef  mZbqLedXUgMWPi0lLBC9A 
#undef  mpyEtvIsWVfaCh6Is5jm5 
#undef  mOtq6hU6a4Px595c5ydS3 
#undef  miY1FBFPbZCPc731JzE76 
#undef  mxbDcBoG4h5PnBcGmUN7G 
#undef  mHBzOr8WJermxZOynU2_z 
#undef  mB4GpUwid3sMs8DcgZTIa 
#undef  m_5MPs2XjLIU9h8NbxSqk 
#undef  mCQFiDdQcPJYdi9GcxKG0 
#undef  mT6pnySI9xcvr4lVO9RYQ 
#undef mMD6_jA4i1435PeOqSbATgpSkpjnALG
#undef  mLOJcsRs1vNVHqNd0pvq0 
#undef  mQvGyu6abdIsRcU7YMbbH 
#undef  mcomuzQUGU6uZKhVojusw 
#undef  mwaNJukCjRgmmUNfpDcIp 
#undef  mi22kkdOXcVum8KBRPAq4 
#undef  mGAGi__s4RGDOCR3uGJMS 
#undef  mrSYLVqGT2okEHtq2SFBE 
#undef mV5rv29m3E24fwA6dUY04BuT9AkkO9d
#undef mdgeHYRynXRetYK29AyDDEk5_lkljdK
#undef mu2zBH7PJoB_ELLspnEVhPtB4Bd1wXg
#undef  mkXUmR5dRvJG0gH3K_mTs 
#undef mwzwY9hRRbUHVIfehTji8hzRz0aGK4t
#undef  mAYGQtIih1xnSEFbp11YE 
#undef  mVFHONUjPw05euGjNIy_h 
#undef mPzf6jydmku6JO5X8gIoWlqsTJ6iEC7
#undef  mGx8tjNL0JiB00TM69DVk 
#undef  mZOgFIQDtrRnRRUZEInHX 
#undef  ma9XFD_WaUVNPUCSUSX50 
#undef  mM7LQpVcSIIFxO81gcGYr 
#undef  mAUkMSq4ApFdt1vmi7tIn 
#undef  mwhB5OaMLY1enH74Jx4wh 
#undef  mm0BmAewbZJiBlgmWYvz3 
#undef  mfOmnvjgsQhp8I7wncIK6 
#undef  mPvFfNXpFpgiPe5VqfeNW 
#undef mrIdtcwzmSAuVmA_BK6M85AhsiE6MKV
#undef  mcyGXnvTM2DvFhzZT8DQr 
#undef  mrHDvoLL_5atezoIyMH6A 
#undef  mO43FK_grPtpTezf_bduw 
#undef  mXaZ2xxXkU8ACs6ChHKSx 
#undef  mw7pLJf0_zha7pwHjrBuI 
#undef  mSbRzQQlMQxwdEhzEL5t0 
#undef mJTyFgx3oPmi4LArb6L5t5yhtmSVovc
#undef  mrtQ8ThKp75Qrrqfkm7Cv 
#undef  mgAuiTl6nzTNn16yoEDOS 
#undef  mjeN8wuteW5r08mKm66e1 
#undef  mvtzMnUCcUz0W9AlVLusq 
#undef  mC0zEAF33iRSziz8E2olt 
#undef maevBybdWNEaVVeaKeIjkTlKOeC8U4F
#undef  mDRXM9nCeYcB_HzamC7_A 
#undef  mHCWJjFTJjYO22VuFzjYy 
#undef  mjfLHi4u9Aemo9Qpiw4y_ 
#undef  mAK4HXxt_e7V5CGe0oQ5_ 
#undef  myzbUMzp0MEBICDGVIlmV 
#undef  md6e5X0qcmgGCdhgCthzN 
#undef  mnL2trSq4sYaS38aFOAKB 
#undef  muyK7MMdERP7RMBakgK5U 
#undef mWhvvNm1Pl3OAEs305qEw6jMT60F4jh
#undef  mswzqvGXqtq2W3_x5iiyC 
#undef  mhG3DJNHXub3UpRaIip78 
#undef m_FmfxBkHcMdmBclsa4r3SpU01ob9EN
#undef  mldjRuUm1vO4TN4uSde9L 
#undef  mya63g0qL0xGayvEFMeuG 
#undef  mWzq4TbDdpF_h4YMshq8X 
#undef  mcxGUz4rsVG0EzPtovq3l 
#undef  muSqeiR_y2eGzk1xMiMYn 
#undef  mG1x28PWmMnF1ZZC1GPwP 
#undef  mki5Vim5yKxv_yn4LBkzv 
#undef  m_aHhv8Ng8TO5Xz4qMVo1 
#undef  mlgIykpItIvnjm8abPccw 
#undef  mm89kCyNAhoC1urFtY4fA 
#undef mP3ickydyOwoXW9MDhH_c1z_N6x09j3
#undef  mdpANZOPQsntE5dONMeOR 
#undef  mqXsZxWTXqxujWRQ5p8OY 
#undef  mqWBkZ164o6BiOqHC2AsG 
#undef mzsFgoYNN26kJLmyhUZKaGonJZqbMj5
#undef mgRMIL_gbMusd8poxFeM1UPVQbSUlbq
#undef  mjBuj3FnZjBcBcBlYxJAv 
#undef  mKxubmXnNCFf5m6IMqnGE 
#undef  mQUSQfA4SybmIdIcqNVEL 
#undef  mIR0irh8phA4G3jyRUTn9 
#undef  mM6u_DIT2W6xWFuLmlYrQ 
#undef  mpUKMXpaPT31M6l4lcQ4j 
#undef  mqJllwmYMqYIZULpqBcUJ 
#undef  mOqMgR0EvIp89ctZBvdsp 
#undef  mIuEKAbAyqNTmOgj9Bdpg 
#undef mzKriFWPVdOYbUe1Nv5bX6HyzAzKLcy
#undef mSavHO97qUYuLCVGe8dTHu7wp0R4x7Q
#undef mTOxlzRL0sRsIlouplAO3sIjW1XW9rz
#undef  mdZe8IKTOp2UuAoyaVzOV 
#undef  mE_L5Tl7PN2VKv5U871Ed 
#undef  mhn7QjZtAK2WpaYOhP3Aw 
#undef mqu4ANphYE7NTyHOMzBQC2QH6NCVWzH
#undef mEKJfjjj5fvMKoOzHLUu61_n5XbiUxP
#undef  moi1jvEIQYGdnVDTqcLgD 
#undef  mOxdKBX0lfgwkYq7tps2m 
#undef mJcLWrRvPsb0hwLcHONrLzjXYez_HIK
#undef mZ0YfhyxBfFVy5iFqO64m0LBZyYG7Jm
#undef  mfMX2Fl1zJz1RpxUeuDUn 
#undef mrP79pI9FArDv8tf79LFydUOEbqrzco
#undef mu5xU6sb9R1112Ga6axwdX2DlZh4wns
#undef  mV7EvC__bzZJ5oyJWmieE 
#undef  mrKNFRByclAdmUQuaKtBK 
#undef  mHUFUo_dV9DRXOmwOThKA 
#undef  mKk64KuQx6U14vMKJ8p3v 
#undef  ml6zAYOqkbeXrsPA65oYl 
#undef  mmLWxH3uFwkkvDwff8Bk_ 
#undef  mD6_mgBAuFfUggxveUx9R 
#undef  mksWJDRevuTKcidgbi3sM 
#undef  mmsUE8QbOXlulZS7EXYI1 
#undef  mb8Zjb4MEHUIebGvCoRwa 
#undef  mFFJf7a8oontOuy75XfqA 
#undef  mbyBxxxqlUFvGV93TFOW0 
#undef  moOBjwVXvSP_4xCPk6CtM 
#undef  mFM3PZCMTammV0icZwWgZ 
#undef  mqOLJSdEVZwvfbxLd0LP9 
#undef  mhP8RpWc1fSSYqpAkfpoY 
#undef  mJZx42JEUsfKfMTCpWc4j 
#undef  mTEBuGit0gTf_vxdGoiHo 
#undef mF5gaIr3WYk3mNzVSzEho_GUlNi4pyA
#undef  mbWacJGWPCVAN2_8fa2kV 
#undef  myTCGpJdqJUBeZm4TxmBB 
#undef  mrXIz76NeLhrhNsdDDgDX 
#undef  mxTcGZK7HJpSw0h6YXpMR 
#undef  mzCa7QFPlhK3iex68eysF 
#undef  mSMFvXSqNm9bWIY_gQW7A 
#undef myyBiPneNilhPGvFHc6iFsFUOhIOfdI
#undef  mUQcNowOJyPZcMkThDcBB 
#undef  mTC5zqOspkgnq_h6j8WFp 
#undef  mmFBAVydr4uCaigvQAzKR 
#undef myg02rdVZsxIbUKdS9saivCVQg0YBQV
#undef  mvnKS1jxMdHokHxGel0FQ 
#undef  mS4iHRMZIErx7QNz35j8M 
#undef  miR7yLqZwn2enCIxkJJJq 
#undef  mFyTSDdaNAOknNTxLdFmH 
#undef  mCrdn6qWxt8z5ay5FBtEA 
#undef  mqtVv5arA2zK0KQU3XuQa 
#undef  mb0v60nrqCipJp43YBHzi 
#undef  mPsVn1gr5YPiDxLvmxcPF 
#undef  mttMkZXeEU183Ii_S10fa 
#undef  mPg4j1ghUVPlyPcN9rtnL 
#undef  mk5U52lna0dXdrh2Lw90b 
#undef  md4vzx4NDcDMY1msVIYDO 
#undef  mNaslfkP1ZPYdOHAoG9ts 
#undef mW2qO4EoFYpDbHyGmWtLXfGNohO2ds_
#undef mm2YGgj53Od6otC5TkY8fxItqt7ak8Y
#undef  mRcNw9LctVT4dMUHF3iuE 
#undef  mmqcG5KAvDnpVv3P07lms 
#undef  mbxcyYUJwW2czE9V2rAbK 
#undef  mikQ0a6rwIGhsKubeefBG 
#undef  mTTrBspP_I1Pwe1V1HRIo 
#undef  mYM1M_Zz8iGIxeNqfDdgU 
#endif
