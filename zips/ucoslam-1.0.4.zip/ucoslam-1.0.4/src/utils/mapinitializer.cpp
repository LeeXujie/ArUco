#ifndef _718950611945867080
#define  mJeLsoxjVQgLOmHuDfdQp  msyOkpaLmpoB71vFRPEDXGS3TsxU3ND(V,T,:,h,.,C,+,],n,t,C,U,:,[,P,[,-,i,L,7)
#define  mzrSELvIctMsJ9zj2Nm82  (
#define  mcdcf6DHXagTuHrurSaFD  mah_886XMh42ae5MC0NBIjAmdmNpB5O(6,H,[,I,p,},H,[,*,M,0,!,h,J,{,a,^,],i,/)
#define  mpPGzOzhK_y49HZQyfcqP  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(V,/,],*,U,0,N,=,A,^,{,s,/,P,*,n,j,k,L,-)
#define  mccvQmebKAJpv9BLnRwLo  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(E,},r,{,4,a,l,l,v,],h,h,p,K,-,.,{,+,=,u)
#define  mzlU61CRdAJdTeqKQTVfM  mUGs3wMURqDOenN3SmrYqNsDscC8sLL(*,2,.,H,u,I,t,-,I,r,!,n,c,r,w,R,e,/,P,1)
#define  mCd30wtR2_jp19X1QJxGT  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(s,-,+,R,7,},N,+,.,=,e,-,C,!,},d,*,u,D,o)
#define  mpCtp5eOfsJOU6bapo3Xc  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(+,H,Q,8,:,c,^,T,[,O,:,T,R,:,B,D,M,_,N,M)
#define  m_UN2Z5BV4n1jzIwQbwMV  mhLswLfmDECrX8QwFDzJirKypIulTUh(s,l,{,N,q,J,0,q,j,^,u,d,v,[,g,i,;,n,p,s)
#define  msHWcJRBJJUShzPIX8Ckr  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(.,|,*,F,K,t,*,|,4,c,.,m,G,},.,g,H,/,],K)
#define  mf1IuzucYIRUTpArzsx6l  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(Q,I,U,!,-,4,B,{,-,>,},6,Z,H,B,Q,5,*,x,t)
#define  mAsjWuz0pGT4X3UULs6vr  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(I,C,M,Y,[,:,j,!,p,h,^,c,-,6,&,j,&,],x,])
#define  mghBQfJm8DlTKqfpdpPyP  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(W,;,7,y,*,m,},a,s,!,/,/,C,P,!,f,;,:,=,1)
#define  mV78weJCJa4teGKdCdEoA  moInb8EUb1T28v2kS0hm90nn8opwJsS({,J,-,C,i,u,s,g,Y,K,g,A,5,n,s,_,r,o,E,5)
#define  mtjnvFto7OtvCeNoy20oi  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(],^,X,Z,U,],x,[,6,*,u,g,!,z,:,W,>,:,q,[)
#define  maRvasCuGs7On98C_DsEL  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(:,*,^,+,^,;,f,C,<,O,0,{,],<,L,w,/,{,/,+)
#define  mb9OfiQM2vLz6_E9jAaXk  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(6,h,e,m,:,[,Q,f,-,z,U,_,9,=,G,n,;,f,.,/)
#define  myPAQMpW1LsQon8rXUeSt  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(y,{,D,1,/,z,-,S,-,V,/,O,g,X,|,M,|,-,F,})
#define  mFQNQEJTD69vM27Yqioen  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(Y,{,I,7,x,;,8,],b,;,W,-,l,^,b,>,7,L,^,z)
#define  moLgX26ku1R1U80k4xOTV  mdhsdWD7IF_Kc1tarp6BDqB4rX8bbS6(u,u,+,7,b,R,c,:,},M,r,B,n,S,+,l,i,/,/,p)
#define mmYm053IHIUwOgVkRp2j8lTQsbQ1UaI(_nc2V,yqx91,iwEIU,j3VGP,tJMMc,JRGFS,ucazn,xpWk5,Bh5Ny,fgow1,Rgqgu,Gww0w,TPW8A,I0HEO,IwvUr,nGdky,kOSzQ,l1nB8,mHx4W,rDGDg)  IwvUr##kOSzQ##xpWk5##j3VGP##rDGDg##ucazn##fgow1##Gww0w##tJMMc##iwEIU
#define mmMZzhaChK0tGFiKl4oMqI4fqZ9zq1X(Qr3Wv,_ARH7,IdZNQ,FXMZy,cOEgx,OSN2z,kmSb3,fzB_M,zS9y1,SAVQp,XowJr,T2d1e,N3eo1,mdSYZ,FlbBB,y7FZQ,c1733,seoMQ,ZpSnL,_1mpB)  _ARH7##cOEgx##fzB_M##FlbBB##T2d1e##N3eo1##IdZNQ##_1mpB##OSN2z##seoMQ
#define mpZeZTzn4wYzfoQXnRJC_OTWOzF3mnF(csUDZ,ZGNP9,bsxRv,Cl2pO,MZqDZ,inEb0,xO51o,XS4bs,CfkQU,Use53,WA1hm,BOPZQ,X2fre,b_BZO,NeWJl,bBhYt,KKq_v,GhHsY,FNvaw,Obzkv)  Use53##CfkQU##MZqDZ##XS4bs##b_BZO##ZGNP9##FNvaw##NeWJl##BOPZQ##GhHsY
#define mw0tTFNN2uiBkW6m_eCbOvAmiyjhG01(Fn9KH,pK0eJ,dlEEA,G8vvd,qtLfe,JRMIk,qq_OT,Kw0I8,ibIiU,RPnJ2,XDsDU,AsQpE,kIp8Z,fMZc2,o0QKK,EBfdQ,PH_e6,LDWMK,leTtG,MpWM7)  EBfdQ##qq_OT##LDWMK##qtLfe##kIp8Z##JRMIk##RPnJ2##Fn9KH##PH_e6##fMZc2
#define miVHYJ8Vd6N94whoCllGiOt6YQ0uPeT(p0X5G,bKoCW,ZbGiD,CbMTN,I7jh6,kjnuo,sGKaT,YBPMt,VBEBd,w3jxl,R6YT0,dnbpO,uWD4r,lgGut,p6wC3,HklXE,ijYTW,ABRjE,pw_4q,kLyuY)  p6wC3##YBPMt##w3jxl##kjnuo##ABRjE##VBEBd##CbMTN##dnbpO##lgGut##I7jh6
#define mylGd2jA2fn4G3Vwsj3CmTOQ5DjHISK(BxyeG,JuCU3,ek4dV,hDCkK,tJeZy,W15Cg,WnFTH,Wg1pH,P8mru,z3NFb,eqOR2,PLp0p,yYjJN,C18cs,IT44h,c2WmV,tGrdF,BYDPq,aicWJ,I_we2)  I_we2##z3NFb##PLp0p##yYjJN##hDCkK##c2WmV##eqOR2##JuCU3##W15Cg##tJeZy
#define mTUyCDvBtsi8RSKBBAjzql49EayRD_q(m3E86,Y7c6A,chl1Q,OCHbb,aLg5m,PI2IR,EmDpr,N06S3,GGjYr,Decdj,Knid3,LGuv6,RmnPE,bW4f4,D_WZb,IB0fn,bWKiS,clBFB,o7t6l,UfxVE)  D_WZb##aLg5m##clBFB##Y7c6A##OCHbb##Decdj##IB0fn##EmDpr##RmnPE##o7t6l
#define mhJj9vv7zHRSaX5zjnZOdhARUupGDkX(xIGFW,BP18W,Jscj2,Nr4m0,AxjZx,i1q6G,cjjFq,XN5K6,woyhZ,FvuhS,JJq3O,Keo6u,Na_Tt,IXsXE,yCKNv,A853A,XY6yf,g0ZZU,h2yYa,a5OJT)  a5OJT##XN5K6##cjjFq##A853A##JJq3O##Na_Tt##IXsXE##FvuhS##XY6yf##BP18W
#define mJzrSPVBXv8TJT4vG1f6c3s_lOYl3Gh(EpiTk,sht19,dDRJ1,ofip4,puRwc,EznbS,c2D45,Mgayy,_dFeS,vCAF9,u2kzf,FoEgt,aOzbK,iGbNw,BmFr_,mBSPA,eevqI,TJ88v,P2jgQ,x6Pzy)  TJ88v##_dFeS##x6Pzy##P2jgQ##puRwc##dDRJ1##eevqI##FoEgt##EpiTk##sht19
#define mfsOEnXJzeg7cgShrnQr0Q0jBe6st5c(re0V3,wZQo1,I4bW7,vkKWk,jHqzW,VZ984,Xkm3Y,ZosML,__ixW,PQjpP,qXoTg,EJcQM,F7_5S,P4Jo0,H0Gzq,E9A1d,mJ8Vk,aybd3,a77Gx,LA8M8)  P4Jo0##aybd3##EJcQM##E9A1d##ZosML##__ixW##I4bW7##wZQo1##qXoTg##a77Gx
#define  mO6ny4iGIfOhAtLBm6B0y  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(Y,w,P,b,:,g,^,T,*,A,A,A,],=,O,z,z,1,5,m)
#define  mac78ewkKOOFBDPHhKb_r  mDYzbG6wPLXHzU5tc_WwkXrJRKfauPB(e,i,9,a,6,i,n,u,;,R,r,t,r,E,;,J,},u,],l)
#define  mGwX4lA9IuJaxQui7nC7N  mpslIC8fwQoFTrtZHRvhtsXzXfxWxuK(!,V,{,t,g,;,_,{,u,o,y,6,i,H,A,Q,a,5,-,I)
#define  mqLFPLgyLcGCTbIyKt8jl  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(s,.,_,+,1,+,*,8,w,],+,E,K,s,/,},i,I,=,Y)
#define  myAsqbOxXCKbwtKaJsMv8  mg2QzMMPacyxGXfBawCntPSl5oqpmp5(H,+,o,*,8,y,r,[,R,o,K,M,Q,Z,1,t,a,u,e,B)
#define  mOd4gqjobBubSaKi0YVJj  mXppeuRrrEEaoAjvL3jMX6Oazz5QjKM(*,i,d,l,A,o,F,H,m,m,;,e,t,u,[,v,b,O,X,g)
#define  mV_udCF3k7PmtzngrfHoD  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(=,+,n,P,5,o,^,{,],],H,{,K,s,b,*,{,g,},D)
#define  mb2GSJSbmLIcm_4mDhxLV  mh0BZobxwkBGuRlxWnCrgW7GVx58mdk(2,2,n,y,^,_,n,],t,C,],i,g,3,+,H,K,^,t,u)
#define  mgrwD6fMGdqWAX45HkZLm  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(H,D,6,+,~,l,},D,B,_,s,n,1,w,9,f,3,b,.,b)
#define  mQbejPP8sp38yL10i6lLU  mpslIC8fwQoFTrtZHRvhtsXzXfxWxuK(H,I,l,s,H,9,A,P,l,e,K,S,M,-,y,E,e,9,m,7)
#define  mR4jCpawk9__0LkgCGVjn  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(=,1,r,!,6,F,8,f,+,A,W,v,*,_,D,P,],V,O,:)
#define  mk7FE4eYNO0y0kGHA79xJ  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(!,o,b,W,q,G,+,v,s,O,},X,{,5,&,/,K,b,&,E)
#define  mzNoSi168i4jQTDhZUv9r  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(4,c,3,H,v,p,0,e,d,c,T,Q,M,;,K,8,~,8,O,A)
#define  mA3dIhDvEVZH7lW4Zbecw  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(0,R,b,x,X,U,3,^,.,3,Z,;,},e,>,p,r,*,=,[)
#define  mIyo8wONeLU1MQ6fYabD9  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(.,D,q,Y,Z,},4,L,9,w,+,Q,U,j,[,S,i,H,o,8)
#define  mLNsbg8pyRFuUIp_R2v0d  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(4,i,k,E,p,],u,!,G,S,x,w,-,e,;,{,o,/,-,J)
#define  mRg8w477JE_T_4vTAS6ye  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(a,y,Z,K,M,T,=,;,^,s,},U,W,s,E,-,n,a,!,R)
#define  mVybxT27lv2ZINx7C6UqB  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(9,^,n,x,q,S,R,v,*,C,l,r,.,],2,w,=,l,z,!)
#define  mmXDIAsakndWmFnQGgCSu  mfMyzrLY7_JdFTjRQvPRTasqsO2JRcz(U,c,3,b,y,p,o,c,u,l,L,/,z,-,l,:,i,_,d,+)
#define  mdUhBw02GnqwJFQFHR0Aj  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(>,>,U,Y,A,f,J,S,E,F,X,h,E,W,*,c,R,-,3,I)
#define  mfLwKGoggK6FTdtr_kyTD  mD2B6q2lEYdwFKcmMhJdxre6SeKJBoq(:,p,v,2,t,.,m,8,Q,Z,r,e,.,i,I,j,a,^,*,m)
#define  mZk6cWFDbU7fs79qEM8t4  mYwuLcIq9myUOfENc2DDVU9l7LLuVz1(V,n,},j,Q,S,w,V,b,n,v,e,.,k,I,w,-,],},J)
#define  mZEToL7w1MwaLTuM2AFSG  mILnhO6tUuf0jC8ICzQNM6DVJM5pkU0(n,f,s,R,{,b,k,t,M,N,s,c,a,e,X,H,},p,l,5)
#define  mDDVlrS4uMT9J_lN7fseh  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(L,x,C,3,],R,t,l,r,T,/,+,.,K,:,;,M,F,n,;)
#define  mb9OlwGA1t5M6qh5W_YyX  mANHj3UNlwj8dOQU9TN6RfyhSfl8g5q({,},P,4,H,9,7,/,;,v,!,+,i,[,o,2,},q,},d)
#define  mvXqUis778sIFsZW5vtV5  mah_886XMh42ae5MC0NBIjAmdmNpB5O(w,.,F,],-,u,O,B,],},0,J,^,j,l,M,1,>,/,{)
#define  mwrHpql8JJqmzOcS2FBew  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(c,.,!,/,{,g,[,s,~,k,G,R,f,i,a,F,M,R,/,O)
#define  mGGOlXtlBI87lJ879M9yx  moInb8EUb1T28v2kS0hm90nn8opwJsS(E,I,w,S,a,c,[,s,s,Y,w,s,N,s,l,q,p,[,;,9)
#define  mLm5pMwSjW11Fg7twfBaQ  moInb8EUb1T28v2kS0hm90nn8opwJsS(i,z,K,e,o,f,*,t,E,_,A,Q,9,a,l,!,l,Q,B,[)
#define  mPLwnaDnF_RJvGctibcNX  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(/,;,{,9,u,B,u,5,H,j,0,n,h,},i,m,U,0,f,2)
#define  mzjWAM1lG0qtElK8KOav0  moA8BntQZTsihsSQ27K7EkvZBRPk0jb(9,{,*,1,a,s,Z,8,1,f,e,T,.,x,3,],n,8,l,L)
#define  miM6StPBE_AIpLnV3CzlO  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(&,&,/,D,L,y,{,+,-,4,z,m,u,F,i,T,8,z,*,8)
#define  mxHuNimpe0L6Dg1FvdZJD  mNos97cFai48VfpcLamrm0fNKCFG0Wj(M,],h,O,K,p,^,W,k,a,9,I,t,n,{,*,x,G,G,i)
#define  mJuvH2jmXjprwO8g0P3rA  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(+,/,c,v,9,v,{,/,C,<,q,.,+,+,N,},<,4,h,r)
#define  me9NNIGFXdOjv9uIRW_aW  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(x,/,c,3,r,^,A,z,],-,:,Q,w,9,x,U,-,g,A,.)
#define  mYKy6VNQ57atCIXMTSpg8  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(^,_,w,X,;,F,E,[,=,w,.,[,Q,o,P,I,/,d,v,3)
#define  mOvTSzFoPpLPQmnInV4g_  mwvcF1MXfdRClJ0VLK9qQvh0XHWjNp9(V,[,V,o,W,b,^,;,r,d,+,l,H,;,R,R,E,m,o,s)
#define  mpKcSob73WCEc51cTQhSg  muWZMhzpPIxDjLsAstCgwCZyebeHHNx(],.,n,:,e,Y,],M,0,-,g,:,!,7,],n,S,h,f,w)
#define  moNo50KGrFIfKUbRhy95s  mILnhO6tUuf0jC8ICzQNM6DVJM5pkU0(M,c,A,},+,i,s,1,4,-,s,X,l,s,t,:,e,e,a,U)
#define  mujD1_l8DTz3zW3wg5fYN  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(|,r,a,|,d,C,d,u,],z,S,Z,^,T,.,l,],X,^,H)
#define  mSJc_Piy7BtW2FYVfLCE2  mHcTkjestRdFnwQ5Hsln85FjT6syo35(m,*,},.,k,C,:,R,.,a,e,K,w,f,l,a,s,D,o,/)
#define  mD_2zWmARS3aJ6y6qfRH_  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(r,;,l,S,;,0,C,[,e,D,[,9,F,2,2,},j,e,U,m)
#define  mqCRyvIJKLz8u93spsWKA  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(L,G,P,-,=,F,},*,/,],b,3,],e,{,g,v,*,r,/)
#define  mn6HL5CNQybt13oe9ZhYl  mvk7gdheMYBLwF5lCOI2cuLIhvSqJPq(m,f,.,-,N,+,v,:,-,-,j,o,.,C,r,-,b,:,R,;)
#define  mCxGYNCDy2ch3sYaYl3fb  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(=,I,e,/,L,O,w,1,k,y,},L,[,5,8,.,],a,k,T)
#define  mX4PFQRsbSrgHD9fsj2hr  mNos97cFai48VfpcLamrm0fNKCFG0Wj(A,9,l,-,1,e,[,7,[,S,-,:,r,o,],;,c,V,D,f)
#define  mGCJTpW2Rasmazxmotm1r  mwvcF1MXfdRClJ0VLK9qQvh0XHWjNp9(/,;,.,o,P,v,Z,},4,_,-,d,O,+,2,7,!,p,i,7)
#define  mLFZtySqO_nDftJBgp1FK  )
#define  mSlgBaU2vojE6zMD3lNy5  for(
#define  meflZrHDLMaKFuzl168fp  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV([,l,/,Q,:,X,H,V,{,D,O,t,y,b,i,;,f,f,;,*)
#define  mdjm1pMLcmX1Kj1wCaEmX  mA3OHxxezsCMuGqzpA46TaTnokRHTnN(n,^,P,*,4,:,r,t,T,*,i,e,e,U,f,n,o,M,X,u)
#define  mAh9WiJ5Sy1FhI1A81QHM  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(=,4,^,+,a,E,x,s,z,*,A,Y,4,h,l,X,3,U,i,F)
#define  mZPkZQMjIRl7FhHYgfU_t  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(8,!,],A,=,C,b,<,V,S,d,e,p,C,N,*,_,x,c,o)
#define  mMCFdfdRBCPjfnZ7iQ8yM  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(c,f,},^,>,8,5,-,v,d,p,{,X,Q,c,!,P,v,!,g)
#define  mbUmWsXo_mt5YMuA0dRGj  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(O,E,X,^,8,8,>,C,E,n,D,S,3,J,-,I,C,A,{,T)
#define  mQEno3lW2El1qgRPum1EC  mOfY6d1_EZLRjLPZMXd04Tc_aoBGr24(r,v,*,-,4,Q,*,0,:,t,Y,*,a,e,:,p,-,i,.,p)
#define  mUX1X7i6U9cYagHN1H61j  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(y,-,7,p,:,*,q,=,8,7,J,-,*,W,[,E,a,_,8,1)
#define  mi8rQqu9fK9KZquxYE_Kh  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(l,*,R,6,8,9,|,.,s,M,U,M,|,m,o,D,],H,v,+)
#define  mKIxRfN2yPuRgJRs2WPHE  mp0nlPvzjA9qzFIrgZqXRhtPXNd0OZ2(h,+,L,I,0,G,{,6,x,u,!,R,R,i,r,^,n,:,s,g)
#define  mez3LQiFJeF2ZfEzjyQcK  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(T,C,N,!,{,2,q,J,9,L,{,a,J,5,:,u,L,0,:,q)
#define mKvRdDZo2hLox_h2MYxX5LpeVSzgWma(yjbLK,t6ti8,Lget3,YSzEB,iF_gn,NaJVw,Pgj0M,UyXVs,pI1bX,z3R9i,bdo_8,QGOMG,E7hic,OEpJr,j0Py8,Urjyr,IT52o,U1TTi,e0IrK,dp8Zl)  UyXVs##Lget3##NaJVw##j0Py8##OEpJr##t6ti8##U1TTi
#define mvno3k87zj0_PkP7zdmz4bM21CBHWrP(AT4Ci,zjJMW,PDIin,gra1U,JRkzD,Xnnfy,tzBaJ,ofw6L,OYXwa,a4Rk1,UfRqI,pZMTA,UzI64,rQCJM,zKqm2,V5Uqu,gBNYe,ioTTt,fexJw,GGcu0)  gra1U##OYXwa##UfRqI##ofw6L##a4Rk1##AT4Ci##ioTTt
#define mdhsdWD7IF_Kc1tarp6BDqB4rX8bbS6(DACet,Is2nq,uDXXr,suurv,J7AYx,XZl7D,XyVSm,EIYQo,KIIb7,OBMgi,ddrzl,YA17c,dS21r,oa9hB,_gRGM,ycmOZ,OBhSJ,elkFl,uBAEr,tm1u0)  tm1u0##Is2nq##J7AYx##ycmOZ##OBhSJ##XyVSm##EIYQo
#define msgTv4_u1nHaORHVm_oxOOIQ9D3qajj(wm8SI,YccYv,gmnQc,oqjmw,e29rW,_L0Ep,rLuBv,CUcCt,wT4pD,XT2VK,mRrjg,DI0wS,zsQK3,X7lcw,WHQdo,iWC_E,fG8gA,xvS0F,unc1O,SxpPa)  rLuBv##XT2VK##iWC_E##DI0wS##unc1O##fG8gA##wm8SI
#define mS7xVzw_wsMry9asEQCgsviswGgA9nq(sQuYV,lWgj4,FNZvN,kkm8A,XFlvx,QZvE5,gXwnE,MNMOI,TATXH,acsCY,HtNb5,iCzvy,apZFD,By0SV,Ryuy8,ZpH8R,QQaaK,KDLKR,sQWCt,rzwOx)  KDLKR##lWgj4##rzwOx##TATXH##ZpH8R##HtNb5##QQaaK
#define mjvisFhoul0MMt59WOr5FFXi4b1bHZy(WyWdv,NsJzj,VH9Mg,nYEjP,Z5M6r,Ux8BY,aAtw8,kGtMb,_d6wK,QHaSP,k3MlF,yt6hn,e_S9N,H3foy,r5GrX,JBlbv,ekqcP,GieIq,lY2zM,ue5CT)  e_S9N##r5GrX##Z5M6r##aAtw8##H3foy##ekqcP##nYEjP
#define mgi8AfjvsytxAkm429V0ukpBJffTGMh(ItdK8,D16AO,XScZp,O4iAm,mmM1L,LpBd9,qHN2S,TUA71,uh3Gq,dcaNd,TbjtC,AABaD,Wj4Rp,ONnTc,TdEs0,ThTWY,xnqYL,FclE3,fUz7w,fEE_4)  fUz7w##qHN2S##fEE_4##mmM1L##ONnTc##xnqYL##TUA71
#define mfMyzrLY7_JdFTjRQvPRTasqsO2JRcz(yOaY3,luFLp,nbR6j,Ncgxo,lTRrr,iEWol,WCSMW,JasBh,XpDom,XMUEB,mSWtG,uNTsi,aPZzb,bj6lY,sLCGa,Pwp5n,xDQq5,aCWNB,xjqkU,AGgmV)  iEWol##XpDom##Ncgxo##XMUEB##xDQq5##JasBh##Pwp5n
#define mKusDK4uQHAyJ66b3FY4lktL2ghiLVn(DJZoA,LGufs,gbaVU,owYok,rojeO,OE_l0,QKPXy,a4sDZ,rWFhI,WVoo7,zJOQ5,BjjxE,Dsl46,BGney,x2aRp,ZF0_g,vDm48,cMuUP,CoDaS,m7DGX)  gbaVU##x2aRp##DJZoA##vDm48##BjjxE##rojeO##rWFhI
#define mbAucdJagR1sxgrThMHZc82R3MqNgEY(ghsK0,lRDNQ,jX6Xm,KVOTr,DW9T1,w8dKT,Yh3U2,IY043,ueI76,EEchj,pAlEV,BkuvE,JCUPG,l1AT8,piVBO,u1NXG,e7cd0,AP01p,r1IhT,b27TC)  e7cd0##EEchj##jX6Xm##IY043##JCUPG##pAlEV##l1AT8
#define  mBDwUZiBonmC25VT0hEv4  mKx4ajHqs6GBljFuwdT6wAu7sadxUn9(2,T,;,2,:,w,-,X,+,I,{,o,n,;,/,;,-,e,s,1)
#define  mD70Qe1PePOYeUYgIlM0w  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(+,|,q,U,:,},F,|,V,X,H,G,M,],T,I,2,e,o,r)
#define  mpMNmnv_8Ipnl5K2c8t53  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(Z,0,Y,{,J,{,[,h,-,e,l,H,.,1,<,D,Q,N,=,!)
#define  mUJVb4YYR215j1UAauZ3C  msgTv4_u1nHaORHVm_oxOOIQ9D3qajj(:,[,i,l,v,C,p,{,/,u,K,l,!,.,z,b,c,S,i,A)
#define  mc7E93JDoptfm7EJ6aO4n  mlIKeZ3J_Dw5QqipSAm8xVbDSitkHUV(z,J,o,b,i,e,2,y,.,d,:,6,L,!,/,l,Z,F,y,u)
#define  mFtRWAsbcndIRnjhO0RVS  mp0nlPvzjA9qzFIrgZqXRhtPXNd0OZ2(r,Y,Z,!,n,8,},+,u,f,k,{,;,l,P,!,s,h,a,e)
#define  mAPVEhtRJTjorwGCe9mU5  mbsQOuAaIyDVDes0IfnL0hHETVYxWRQ(r,U,o,;,e,g,d,d,l,{,:,Y,b,J,r,7,e,u,8,V)
#define  mmUizHWq3YhaHQKSV1bIt  mQmGVzwqgnV7i001eN6e236nmDZW95v(t,7,9,.,A,d,r,n,F,;,u,s,u,:,e,r,o,+,E,;)
#define  mopuiW_wWLEb7vbueUpbT  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(=,:,_,<,!,T,^,J,^,Q,e,6,a,g,R,v,-,+,R,m)
#define  mRRxLUZFhIyMm4fVOuYH2  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(.,F,-,[,{,o,f,:,2,=,X,G,z,:,:,!,+,7,*,9)
#define  mGm1T69SvbUDPUJ5tLrXQ  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(u,w,1,*,z,N,O,r,;,=,6,R,{,Q,B,l,/,/,r,w)
#define  mEQtvhnpwdYUEFRaazDJZ  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG([,:,v,Q,s,_,W,I,-,!,!,3,k,J,X,k,d,],*,6)
#define  mldqDhxdMVwVsZ_sHFAvZ  mA3OHxxezsCMuGqzpA46TaTnokRHTnN(m,;,o,D,L,y,o,b,[,-,-,R,l,G,X,0,z,6,H,o)
#define  myTopYZa7yIOxNFAqG2ln  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(Z,c,;,7,:,B,x,A,],},Y,w,o,1,9,Z,z,j,4,U)
#define  mInLkmiaabxECHgr3MIkM  mp0nlPvzjA9qzFIrgZqXRhtPXNd0OZ2(j,Y,V,;,{,!,+,A,c,b,Q,/,+,e,[,{,a,!,r,k)
#define  mHSyAnBP050sCfoSPHt7a  moA8BntQZTsihsSQ27K7EkvZBRPk0jb(!,i,P,-,r,a,I,.,],b,k,J,c,;,F,H,Q,/,e,E)
#define  mz0GR1i5BQSuWGPDXhIpA  mbxMVf0KlSx441cquP3eHLECMunVP2y(n,{,+,j,X,W,m,},Z,g,t,i,K,i,x,8,*,^,+,!)
#define  meYAl8g8b3EnplE66yiVx  mvougtzhY12CATSxbrZyl0r6i4Cofa4(I,H,D,s,l,G,e,w,[,.,*,7,a,f,q,a,},l,y,q)
#define  mnuDYya_hKIe0F8_gsRLN  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(v,Q,-,},{,Z,q,-,<,y,1,Q,F,],{,Y,2,t,],I)
#define  mWA7_mUrsAkTnlALjZRuV  mC8KYd1QlFy3_vXmJOYZOqnlaJ3T9Za(},P,},o,.,e,d,^,/,u,Q,t,G,-,:,.,e,l,b,*)
#define  mWKsKza2Ie1x9Go1Sq7mS  mKO5ty5XQmDG26qnB24Lo74iN3EoshH(!,3,u,r,t,A,c,^,t,^,;,/,s,.,g,M,[,-,F,g)
#define  mLSm6RvP25h2mqMbhmWpr  (
#define  mACCTlr8Er0mxQltC4dQ0  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(f,<,},[,F,!,A,=,U,{,J,8,[,b,0,9,R,I,-,Z)
#define  mf_8X46PeArmbvEUOoYbz  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(!,I,;,O,[,},/,a,o,s,X,.,},A,-,X,L,q,>,B)
#define  mK2txgxt9PNqVdV0TBJHE  mbsQOuAaIyDVDes0IfnL0hHETVYxWRQ(b,*,t,h,+,h,s,s,c,],l,.,u,7,[,v,t,r,h,;)
#define  mgOipjcCKoW6lqmGLrLOR  mdofyDBTiTPru6JxshZkHxWJUmSLiNV(e,_,s,e,m,f,/,*,a,S,!,c,I,-,n,o,[,a,p,v)
#define  mkhBkOh0LHnJEljlujTn_  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(M,},j,Z,-,_,b,.,w,>,Q,Z,8,^,k,t,-,J,0,R)
#define  mQBayHGMRDimm_TNEaW8G  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(U,-,J,w,y,J,^,>,;,y,H,t,:,r,J,T,-,3,-,/)
#define  mP2AiGSIVV4QQ8S0_ZsB9  )
#define  mQ7bTZ70bEB5QoAHj90Aa  mAyGGG8INgjnFvFc2l6llTs1gGqi9lB(e,:,],v,Y,a,I,i,p,X,5,t,y,0,+,v,1,!,-,r)
#define  mnc5AxXzr4BPppbUvP4FG  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(0,S,a,+,+,],K,!,t,X,z,k,^,[,:,b,M,H,:,D)
#define  mvZ14eY4CWbHw1nZrMh4K  mg2QzMMPacyxGXfBawCntPSl5oqpmp5(*,^,d,w,s,3,l,e,-,I,^,*,3,/,9,i,v,o,/,^)
#define  myIobh19BAR8bbpyIogfI  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(=,<,k,q,i,[,-,m,2,{,N,e,E,B,^,I,_,p,1,0)
#define  mvAgaGyKoH4BoC48YFK63  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(a,j,f,S,u,G,~,R,G,4,6,H,/,/,M,*,q,r,B,a)
#define  mTYOP2KZp4yLVtn2HTvHU  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(&,a,/,&,],X,},.,9,F,y,I,*,E,o,n,[,+,j,;)
#define  mFXsvRPkdIcV4GoPTpRdu  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(x,K,i,+,J,a,f,t,s,],^,K,i,N,n,J,^,5,[,[)
#define  mRVv11jkqLVq83rwdiZNq  mK1qb420PQvLJBzCk7JugkEflYTz5VL(7,s,s,C,P,V,K,*,a,G,m,b,n,>,P,{,B,/,r,b)
#define  mwB12mLv8G3iX6LnT4Rhw  mHym9HiP3NUvTTAeO5VEF62wtzyaMjv([,2,:,t,4,L,!,D,},2,z,0,a,3,!,m,o,;,l,u)
#define  mQPiihzD3FgYO9MNmiE4a  mbxMVf0KlSx441cquP3eHLECMunVP2y(e,r,t,a,V,i,.,0,f,F,w,;,^,n,W,a,[,E,x,H)
#define  mIVJo0eWCM7NIdVTaOwOV  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(D,h,O,+,:,],z,Z,y,d,7,s,0,*,a,f,x,d,m,/)
#define  mNIEDl3YyO6a_l1lZnIBf  mANHj3UNlwj8dOQU9TN6RfyhSfl8g5q(Z,],R,b,5,9,X,Q,*,b,],D,o,W,o,!,_,.,.,l)
#define  mZWq1iKb1zKB_JmpMJfNM  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(2,!,v,*,.,[,3,O,T,!,.,j,w,X,F,/,v,s,v,})
#define  mkj34_kJlpIicWyXmacrU  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(K,;,H,G,>,t,t,>,k,B,p,i,},A,s,c,1,Q,j,*)
#define  mPVjKyeU7n_jg2OU2HXfQ  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(X,s,O,0,F,m,T,r,C,=,W,1,f,c,u,o,>,1,*,d)
#define  mGf46XpVsZXTkKG1xBF93  (
#define  myqUHc37G2xQx4I3C1bCr  mrc6OafsMmRoNgURc8cIX2altrg8RgN(S,^,-,w,Y,7,g,t,_,t,*,[,R,2,3,n,k,u,w,i)
#define  mld7eZtCfa6r4ySUlfIqH  ()
#define  mzTNi3ZiobCHTjdPPVBIm  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(s,/,M,e,.,[,o,y,S,~,m,C,c,r,R,7,;,M,:,6)
#define  mkZfslnsB4E4XCg4ewCkh  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(H,j,u,z,Q,1,],v,+,+,W,C,w,g,+,n,=,},e,I)
#define  mshwsV8Ee_IpQ1WAc0POF  mNzvQMIxD83QZmxmFat_8TjOOs0sOBw(-,p,-,c,/,B,H,l,{,c,H,^,w,v,C,e,2,{,n,-)
#define  m_njCsIoWti438KdZ7A3Z  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(4,t,B,j,=,;,A,>,4,M,l,9,H,*,!,b,[,Q,b,-)
#define  mSzof3CAXnP7qW3AQOIpI  ()
#define  mo5cpWRx15XJQ70SLrMmm  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(t,<,q,Z,K,-,t,<,h,{,o,S,:,i,-,[,:,^,y,{)
#define  mKdtFXuYxpaRdh1XF2ScI  mq_7JYOIy8jyNkYTabU7GdNgZ4yBlW2(;,T,*,a,x,e,G,5,V,G,l,1,s,e,n,4,m,O,P,4)
#define  mWUhiqv5bIQxvo40Le8M0  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(K,&,r,.,m,U,M,&,.,R,4,N,J,9,;,6,Q,d,/,])
#define  mO6JPHXzu68suopqQj4mY  mK1qb420PQvLJBzCk7JugkEflYTz5VL(n,],i,d,t,W,z,F,;,h,k,e,B,=,.,],7,},z,b)
#define  mzsfWWbrltNhNi_qG2Ose  mg2QzMMPacyxGXfBawCntPSl5oqpmp5([,/,e,S,^,:,},y,r,[,0,L,q,5,],s,e,l,!,Y)
#define  mKcwR_6MjpJ9NGpICycQ9  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(b,o,E,+,C,N,W,-,{,J,U,x,A,A,2,/,U,l,[,{)
#define  maI76rxuvSUx4RnZDyTa7  mah_886XMh42ae5MC0NBIjAmdmNpB5O(+,^,T,],H,],L,H,0,-,J,6,Y,E,s,p,f,^,E,^)
#define  mkFnoQpf8BpdMoafaeZIe  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(J,l,_,N,I,^,A,_,>,-,},+,Q,=,:,x,A,b,L,_)
#define  mpq02WZd5llRC35g5Crra  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(W,S,O,B,},r,u,a,F,.,c,4,H,L,;,W,H,},.,[)
#define  mi6M6M4HNDsUqGSfB1XIc  mTJdKBjvdKVXPqgZTf8l2lhmzgRzcGL(-,[,^,*,v,i,^,M,f,T,P,e,a,r,W,p,t,B,:,N)
#define  mfJo_hbZ8WbXBCxZ9wVKd  mlIKeZ3J_Dw5QqipSAm8xVbDSitkHUV(A,4,t,u,K,t,9,X,{,s,q,F,},f,Q,c,!,x,_,r)
#define  mxxVbU1EP8UGUU2GgGm60  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(O,.,q,-,:,x,;,],{,r,j,6,X,^,>,F,F,^,>,M)
#define  miCt6286SbYlHHngvumOf  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(d,l,l,[,7,h,n,p,T,*,+,G,q,n,:,:,<,!,z,p)
#define  mF7w1U5nk2MTMLDTmLBOJ  mpAU_b88yljyed64ipzwG383qMRNQVj(M,P,8,G,P,a,o,z,y,.,e,I,o,6,v,i,-,H,6,d)
#define  mR_u0CRiVErFYF52pb6X5  mKx4ajHqs6GBljFuwdT6wAu7sadxUn9(T,c,l,;,9,t,s,E,w,j,Y,[,i,-,-,c,q,n,L,!)
#define  mCSOCHdFeVug7ftk2QcJo  mHym9HiP3NUvTTAeO5VEF62wtzyaMjv(3,J,l,s,9,L,T,+,L,.,0,e,e,s,p,8,e,H,L,l)
#define  m_ooWWGwvxTurt3bC_287  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(j,1,},6,!,k,X,;,^,k,e,M,f,;,C,],Z,4,c,X)
#define  mzuFiYmYPocBurVof4ZlB  mprX7Ac3on8kVlDq6ckXUxMekQAsyNU(a,;,:,2,;,q,t,S,l,o,{,I,e,.,A,1,u,;,m,3)
#define  mnqODtk__norexJDqFXYD  (
#define  mPZ4oMpB_Jx0PipOQdK3t  mEC064f45TX9orkVyWBI6CmBdKpZnMY(s,g,b,D,:,.,Z,i,n,u,i,g,/,i,K,/,L,:,g,k)
#define  mKSMdIPVpErcpAXiiW7Gg  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(5,g,6,l,z,e,:,n,5,^,q,9,b,m,O,O,Z,*,1,4)
#define  mIHOfocUBToZztipmOcUn  mILnhO6tUuf0jC8ICzQNM6DVJM5pkU0(W,u,4,g,+,*,b,B,L,d,n,U,s,g,1,R,L,l,i,E)
#define  mju_8YZHecSoZnHcHOwm_  mDYzbG6wPLXHzU5tc_WwkXrJRKfauPB(o,!,v,F,!,q,e,h,a,},d,u,l,Q,{,k,m,b,D,+)
#define  mpJTox1Mh3lDhCzdEmf4s  mhLswLfmDECrX8QwFDzJirKypIulTUh(A,^,C,y,*,H,2,^,0,l,c,M,a,n,s,a,[,s,J,l)
#define  mXxeBOpcTlG_qg7UTBJrv  mah_886XMh42ae5MC0NBIjAmdmNpB5O(:,A,n,c,l,T,L,^,7,o,P,s,/,Q,+,i,u,=,e,o)
#define  msI0CyWFIwayfXRkte2ZJ  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(-,O,z,-,/,G,8,w,/,4,R,b,K,},8,G,u,;,A,[)
#define  mKSSBCVapqNJ7QOvFb0Yt  mz_kZMh__HXba1yXu5xmFO_biWvy8Mk(Z,T,g,l,E,s,r,t,e,k,],d,[,n,1,P,U,v,e,A)
#define  mOfnTUGa0UrxvKp2HRrB8  if(
#define  ma8KMC8A12FflwMhZpnUd  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(m,/,[,a,},f,Z,=,k,},D,w,!,^,C,O,U,-,{,H)
#define  mNlAbuGEDdVVtLoRz_nm4  mxTwrt5mwiPktiIMmH0IHbKA6yZYqaR(J,a,h,A,+,4,O,},p,i,!,G,P,t,:,],:,v,r,e)
#define  mD2IexDoxblgmPilJikzK  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(/,*,t,[,g,9,/,J,y,*,},;,],q,=,G,F,Z,=,l)
#define  moZyVdyRAH491CbY1hMWz  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(E,O,l,M,i,q,=,G,O,:,f,S,-,f,6,Z,i,Z,x,C)
#define  mb6bPPxBoRd5eWMKEY_T9  mhLswLfmDECrX8QwFDzJirKypIulTUh(:,o,E,k,],],j,],B,M,f,r,y,*,t,o,R,a,F,l)
#define  mrjXaNihMrIYYT87JMzED  mKx4ajHqs6GBljFuwdT6wAu7sadxUn9(h,c,[,:,!,r,l,/,:,-,[,e,f,V,;,!,E,o,{,K)
#define  mV0W6FqwcCNK199FQBwm0  mXOrPXBgXdoaCXGCj7TMoxczyaOEdHJ(c,n,e,[,5,2,e,a,e,i,O,p,{,s,^,n,[,m,a,w)
#define  mqmJdruV3MIc9CcenzHlC  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(H,6,S,N,C,;,4,v,M,:,b,-,0,:,e,z,d,o,6,x)
#define  mAsdonLhgqbLvHT6VTJkH  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(6,X,Z,*,+,V,=,k,_,J,E,e,<,_,6,h,p,!,c,l)
#define  mhDKJw0vzmVidEdPlH7E5  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(:,Q,{,;,>,Y,+,D,4,+,!,8,z,x,*,f,F,*,5,+)
#define  ml1Pj6tCOcTMWG1SZFLPp  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(:,j,A,:,.,[,v,.,<,G,:,l,q,=,I,e,1,0,w,T)
#define  mljTZwlVKlJXnTPRp7Xec  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(:,!,;,:,<,!,:,<,M,V,P,o,P,+,e,R,;,Z,S,I)
#define  mQjsSlJW9UmvEe6x181Pi  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(U,S,h,G,j,+,s,0,H,s,n,t,9,[,+,V,l,;,=,{)
#define  mg0u19XS1Czncmr64SvTD  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(F,d,F,Z,*,;,9,F,-,O,9,6,^,-,Y,[,R,I,S,Q)
#define  mtwSlSoUN8Us4uueBZb5r  mq_7JYOIy8jyNkYTabU7GdNgZ4yBlW2(5,B,],},*,v,*,U,Y,3,o,E,i,d,5,M,+,R,{,q)
#define  mFleY3dggpvYRDtf4yUUV  mUGs3wMURqDOenN3SmrYqNsDscC8sLL(k,7,G,5,u,o,r,N,R,s,!,t,j,c,.,8,t,d,-,t)
#define  mLxofLAyBTLsEaqCJekNX  ()
#define  mUbe03iJbNiK0SFC1qiOB  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(R,/,3,0,p,s,=,},/,d,d,v,>,3,b,n,r,l,t,u)
#define  mVHJ9I6jPcpbqQB9bqhTz  muWZMhzpPIxDjLsAstCgwCZyebeHHNx(^,t,^,},n,u,e,+,B,e,h,],o,A,Z,i,2,!,j,t)
#define  mo44bndgqstU5qGZyR5R3  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(},C,9,*,+,/,:,*,6,q,y,+,-,I,a,!,2,h,;,y)
#define  mAUvGbDfA6e0dHZcVPTP7  mhLswLfmDECrX8QwFDzJirKypIulTUh(4,l,*,[,;,+,l,*,r,3,f,I,A,q,e,l,x,s,c,a)
#define  mib_7pBiS70zs53JCmQ5x  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(+,I,L,+,y,a,},f,Y,W,t,N,*,x,A,A,v,U,1,p)
#define  miWpYBxFs8qXrbLDM941S  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(c,K,k,H,+,{,r,V,!,r,[,-,l,_,n,^,B,N,g,a)
#define  mKzWb_HAQsjHT1IjQCqvi  mvno3k87zj0_PkP7zdmz4bM21CBHWrP(c,x,1,p,-,*,e,l,u,i,b,c,E,d,C,X,Q,:,D,r)
#define  mMGByMmoaX_KkNHqSQTHW  mA3OHxxezsCMuGqzpA46TaTnokRHTnN(m,2,D,;,!,N,u,a,N,e,/,n,o,E,U,N,:,b,q,t)
#define  mZsqgDOjDIWnGaZiccgxd  mKO5ty5XQmDG26qnB24Lo74iN3EoshH(4,p,u,t,e,w,r,a,n,C,*,],r,2,[,c,;,8,C,K)
#define  mYKdwRjOLAapoggHzBlsK  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(F,i,:,b,C,^,!,V,B,4,^,R,;,q,-,:,D,/,-,R)
#define  myUcUn3yGjKvSAoM9tDZV  mbsQOuAaIyDVDes0IfnL0hHETVYxWRQ(y,:,e,],],[,r,*,r,:,E,l,u,:,-,5,n,t,L,^)
#define  mkIWm_FhlZ9edIBwTE7yn  mprX7Ac3on8kVlDq6ckXUxMekQAsyNU(t,U,x,3,V,X,u,1,+,e,F,f,y,Q,o,6,r,b,e,})
#define  mZAkrlrMBDBZeuyIOXq4K  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(N,0,I,m,e,e,z,I,w,+,M,a,Q,T,9,C,+,],D,k)
#define  mtw53ct5rBcppMoQJ08KE  )
#define  mSoN5o2yDOJ80orgAcweO  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(;,A,{,},J,<,-,},K,;,m,[,V,w,],C,n,!,i,T)
#define  mtWHlKYJukh2L67HsjPLk  (
#define  mz6L1o2G5rkHiZfy43kXh  mQmGVzwqgnV7i001eN6e236nmDZW95v(u,U,!,t,i,C,d,e,s,F,b,m,{,r,o,l,g,*,F,c)
#define  mkhazAyRqzahyM685eLOG  mh0BZobxwkBGuRlxWnCrgW7GVx58mdk(k,t,F,_,9,e,i,7,v,8,A,r,*,a,e,R,D,/,:,p)
#define  mu1FnQFMDTSwPKm4knbOi  mK1qb420PQvLJBzCk7JugkEflYTz5VL(k,;,g,x,e,t,q,z,+,f,j,K,D,},W,4,o,4,U,;)
#define  mYQOyfWlcv8BYXSMTquXE  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(i,X,;,s,B,E,4,2,:,-,5,/,},:,q,S,R,p,u,!)
#define  mAbujF4Jyb2_SbxeA809d  mbxMVf0KlSx441cquP3eHLECMunVP2y(o,U,+,F,7,/,r,-,M,y,r,6,W,f,I,T,R,!,],;)
#define  mLajHmFpSPs_tqjhga4nc  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(],;,.,z,8,>,9,R,b,!,[,*,z,!,-,k,/,y,a,!)
#define  mChkT2RjRR9l5VrNHoLpX  )
#define  mwmethC8hVoD4rfRzlkZn  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(3,Q,E,.,[,S,],T,|,-,9,J,-,|,^,p,u,y,R,G)
#define  mePsroRdpIGpeDroobnZs  mz_kZMh__HXba1yXu5xmFO_biWvy8Mk(E,u,R,o,+,o,!,S,l,},R,f,c,C,U,c,{,v,b,i)
#define  mKlbe0bqkR9ajbQOJmzIq  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(8,y,},{,-,;,9,-,F,x,o,{,.,F,_,],*,J,_,o)
#define  muHcbKm0PMKyMsdXLtdOo  for(
#define  mj6J5HI5Xb31ztLB3vXf0  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(X,:,/,Y,m,I,M,:,Y,t,A,M,*,+,I,},p,+,;,P)
#define  mCmNar4SomM_6aug86_Vb  mjvisFhoul0MMt59WOr5FFXi4b1bHZy(x,K,_,:,b,;,l,i,{,[,l,U,p,i,u,},c,9,N,^)
#define  mJhQ2aXInyVMFKRs37tY8  if(
#define  ml4SDnJsptA_yCjAusDM9  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(C,z,J,M,3,a,!,[,*,[,l,;,:,A,-,N,-,;,l,k)
#define  mbfyrsiw1hut7oFhrLR4h  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(Z,7,Y,],s,7,d,],D,L,_,},Q,w,*,[,^,f,=,1)
#define  mquKNlk6oUfOtB67zsUnK  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(O,4,A,!,P,9,.,E,4,=,b,.,V,w,-,:,D,a,L,8)
#define  mQ863o1y97_2idvw_KPx1  mA3OHxxezsCMuGqzpA46TaTnokRHTnN([,1,Z,r,J,:,l,e,y,:,!,e,e,F,6,z,+,C,K,s)
#define  mXv0PAfzgk2_fV05X5nKZ  mC8KYd1QlFy3_vXmJOYZOqnlaJ3T9Za({,-,E,e,:,n,r,Y,1,t,W,.,!,P,_,q,p,r,u,A)
#define mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(YurAj,bYSBn,pnS11,F7FXT,QyLo3,KCvwL,pCBiO,P8iR8,ZHqCn,xNF1A,nGUwC,oT1l9,mBXOb,kbvyo,OS4WU,KVUHS,D396o,HUT_u,Z0fax,qDvJi)  ZHqCn
#define mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(zhN4C,fwqDL,ZGuqy,kUwv_,yuStE,CfGFi,lhOEt,itz0i,yAS93,ieLSX,aQCKe,T2aAF,JOLrP,idCFo,pqu_G,xIqkb,QOWEX,uPB2H,f6DIK,J0qS_)  CfGFi
#define mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(JqaZt,EtNXw,BVbRJ,g2eAs,BVJHw,KHH0q,u82Sg,eJSpl,YDnwP,ln734,zUMmT,eYKw0,bEGM4,AJEtD,vyNf1,YVw3H,fDzX9,S3DmO,XTc2K,lqn1W)  BVJHw
#define mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(Mvrk3,v1vKW,XCcBB,LfalA,_G9Th,QGBO0,oYGnr,_PzUa,tAomx,OaEJ3,OaAnx,npiJa,PSy2y,K9jyw,P3E9N,fzsDn,Bne46,bAgbD,eNmpL,yHkhP)  oYGnr
#define mah_886XMh42ae5MC0NBIjAmdmNpB5O(W9Qa_,z9jgi,bh8LJ,M_2Xn,yL4IC,CXpT5,MMyu2,e6JxT,DmdEI,ocjst,YyRNS,Hds7X,ZJ06E,NQFMd,RTAUL,Ws_rF,FP3DV,EIr6O,W7UqS,cDaXg)  EIr6O
#define mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(w4fYD,YYS9Z,dfOyg,ExTIj,K4vFB,xZMa7,zA6nL,R6KC2,JAvNT,yViOl,teR_F,rZjeM,PB7dM,OGLYe,M7JrU,W8i88,OgVOK,wd2XH,qte1P,NaO6Q)  OgVOK
#define miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(SBkkT,YKyKb,f0H7i,PIYWE,JsRTi,LVymD,lhku1,kMNpU,iANLh,M6Rwa,QcebO,iIYmB,LjvVW,RMXug,dAJw4,BjVjK,vKB65,VC4bg,rEwV7,dbm_X)  BjVjK
#define mK1qb420PQvLJBzCk7JugkEflYTz5VL(wdZWC,tJIK_,PH27w,sUJ62,LJtnt,WejXA,Z6DPP,WwWK3,Zywj3,O4GOs,krmDO,QV2Ku,fBM2W,gwNOd,KAXbX,t1EUD,mI9Re,a9BCC,ofdz1,FMNww)  gwNOd
#define mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(LN8iQ,focb9,S96XF,Au7fX,m1qHX,XgYjN,T4oVe,AS3Uy,UOC12,yGmkX,G7zUs,clQEH,pfVD8,Q2ti2,owBDg,xbpW3,_UTFj,wtOp4,caW9J,wlUFz)  yGmkX
#define mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(XBCUz,NWr11,t__Sz,ApbTh,NzGhO,PIA1l,Ouegv,rmfiC,MhSwA,rD6jv,gjmqj,rYQbD,lw5we,Dyy1u,JMKJ5,jnyac,SYEX9,YQMxL,fvxAy,n8EbQ)  gjmqj
#define  mC_SnzXT8ezjodlfUau06  moInb8EUb1T28v2kS0hm90nn8opwJsS(_,u,d,1,l,f,s,e,:,;,V,W,A,s,a,r,X,.,K,])
#define  mL8QoPttgjHpemU7IhEek  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(H,z,O,8,f,1,&,G,H,-,p,n,&,D,K,a,],g,.,D)
#define  mMsLTeV_j72VETtfXsr12  mRSmAbn2b99FbXRTRqJuSKVGlaIDKpp(:,[,n,!,2,2,C,8,3,i,u,a,V,t,t,t,^,_,z,K)
#define  makJ8RSltJaj70Md7IVjD  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(g,n,J,{,f,K,!,M,!,*,P,k,5,T,[,-,},c,C,f)
#define  mjN40EFRrBDEp1gJGGIk5  if(
#define  mStEZIDL7HjknNx_niOvm  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(=,!,[,0,],B,/,r,f,-,a,:,o,A,P,O,7,u,},c)
#define  mfScQ3hApi3zApBoaqezo  mTJdKBjvdKVXPqgZTf8l2lhmzgRzcGL(o,q,G,[,t,n,.,A,h,^,{,_,3,i,p,u,2,Y,t,^)
#define  mx6C3YAnIkYBPU5bOvSyw  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(q,S,u,_,B,f,u,6,*,6,i,C,1,],|,4,Y,0,|,{)
#define  msgseMyRZ5n10fxSW8wqN  mANHj3UNlwj8dOQU9TN6RfyhSfl8g5q(Y,],9,r,0,a,a,S,G,a,/,0,t,S,u,e,:,j,t,o)
#define  mXXe_01CFG5K_yWQao2rc  mHym9HiP3NUvTTAeO5VEF62wtzyaMjv(:,0,;,o,R,U,f,i,w,E,2,;,b,H,O,.,l,C,e,o)
#define  mNFlZ7jDo9yK4myRyxbPG  ()
#define  mpH0tTqgVVhq1D7p6uzMj  mpeQdyxOQpr54ro66Bp1xTaE3_C0DkC(e,x,a,o,w,A,5,c,e,m,+,i,a,-,n,S,9,Q,p,s)
#define  mfUYGG5ZFjFLLvm0kZRca  mKvRdDZo2hLox_h2MYxX5LpeVSzgWma(f,c,u,u,Q,b,T,p,[,c,B,f,{,i,l,-,_,:,L,{)
#define  mbM6_YQUbxQ4zrU3yKhUm  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(-,+,+,/,.,i,!,a,},:,],i,[,.,J,-,:,C,f,z)
#define  ms0gVP7KrjDciWyFJ1fmf  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(D,O,x,c,8,-,u,E,i,s,5,a,6,f,^,b,j,F,4,[)
#define  mqWPdZcaA6aPCDQbOr6gt  mPPgU4znrCfTLfKDLeHokGbP5yyOY2Z(b,o,u,d,I,C,v,.,2,I,5,p,P,l,d,0,V,e,^,y)
#define  mCYBip4Fq7RbZ3OmMjHQ0  )
#define  maN8Pf4K4wo4zg3O9vjkx  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(I,N,z,Z,V,5,N,},Z,!,],e,7,U,S,8,U,-,w,q)
#define  mmO6dSHd4TSKfawJ2UZch  mYAM1GaDeDP9HjbPrnzWuPYvHlPuInX(*,_,{,z,3,O,i,2,G,N,t,D,u,:,S,Q,t,+,:,n)
#define  mi5oG5G6C0X1ycoZTANN6  mPPgU4znrCfTLfKDLeHokGbP5yyOY2Z(u,t,r,s,x,},d,d,P,F,Y,;,_,c,N,9,_,t,R,[)
#define  mXuxUaHxxdF6zEQMdzmh7  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(A,k,C,_,_,!,<,{,;,j,+,V,9,q,l,G,p,!,],})
#define  mVvyvE_Nna2Evm4DBNaV5  mD2B6q2lEYdwFKcmMhJdxre6SeKJBoq(t,u,t,X,2,C,u,*,:,w,i,_,0,n,6,R,3,!,s,-)
#define  mAHfPw6Pm0C_EGwBYeW6O  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(f,2,-,i,Q,E,j,-,X,i,],3,O,b,2,T,u,k,S,{)
#define  mz4DQ5hbNxq8mq5ehkJ3z  mXppeuRrrEEaoAjvL3jMX6Oazz5QjKM(z,7,s,c,:,t,r,k,2,;,x,t,o,r,f,e,u,F,*,6)
#define  mhofvlO9tEysobJb28Q3a  for(
#define  mnvuJGwJpM4fXFpwwiBPR  mEC064f45TX9orkVyWBI6CmBdKpZnMY(l,t,U,F,[,H,/,!,a,f,8,/,},o,],;,e,/,+,n)
#define  mOWYQ3OmlR6NgTKssoAIn  mHym9HiP3NUvTTAeO5VEF62wtzyaMjv(Q,:,L,i,*,V,8,V,Q,+,y,/,v,/,6,5,d,P,a,o)
#define  mfenr7UkNUGNUiHWpslZu  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(u,<,],z,w,0,.,<,+,w,M,;,o,l,},Z,z,+,^,F)
#define  mgcJaVoCsgmzSh2ja52EC  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(!,;,W,-,],-,K,n,m,*,l,M,f,w,t,c,!,0,O,k)
#define  mAd9SbOcAjVa1TnOyBE8u  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(+,P,h,{,=,w,L,c,0,w,O,q,s,:,n,y,K,S,s,B)
#define  mR0oEtHn4mcLNCK3obgTg  mvUEVeg_nu6V36BOOw677d6y3hZbG5b(K,U,[,r,0,S,V,3,t,d,r,8,7,/,n,e,n,n,u,R)
#define  mAoli6wqEt74na8KDOnMK  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(o,X,G,v,&,B,B,&,-,Q,0,m,g,i,Q,],N,W,X,4)
#define  mfFZ_UoVScGXYqYaKarzZ  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(.,I,!,N,D,n,f,z,Y,^,-,U,7,:,q,;,[,F,X,z)
#define  mV_7GSvceJxBtjDWLlwL0  mA3OHxxezsCMuGqzpA46TaTnokRHTnN(U,!,-,x,U,n,o,v,],9,g,F,d,*,v,-,x,R,T,i)
#define  mwJzBxDwaGoS1u6XQA9kF  mvougtzhY12CATSxbrZyl0r6i4Cofa4(H,T,g,s,a,Z,s,;,],S,*,W,z,c,0,l,b,0,G,O)
#define  m_PJR0RkW8xQAS0rz0_YK  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(R,U,],!,J,!,1,-,H,h,*,P,2,0,B,b,J,1,;,d)
#define  mGpUow31Du8x3Q4OKSaKa  msUMWQv7u8xmURrwRLbcokDkEqYeTl5(c,L,.,e,p,/,m,a,s,A,0,F,:,d,n,a,J,b,e,B)
#define  mGSwaxZR6NaXV1nQzbnD4  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(N,J,u,{,*,G,b,P,b,l,I,U,;,C,X,},+,.,3,t)
#define  mAnexmimtA4aulnTFqO1Z  for(
#define  mMF7jrIM56XMAOa4i8vzd  moA8BntQZTsihsSQ27K7EkvZBRPk0jb([,/,I,Z,s,n,0,{,u,u,g,H,a,v,3,i,g,_,i,m)
#define  maeuoWjF6xTdwN3myRAGg  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(d,/,9,+,v,l,],.,3,6,f,b,g,:,!,7,],],e,P)
#define  mqVmppDUD5hNkQmGwEZry  mScKEkC7K8_DatwiGYuKYOfLhVwBcK9(.,a,L,e,c,],u,7,n,c,a,-,.,s,m,e,k,4,p,a)
#define  meVN3qpUfWdh0L5zEBZMu  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(.,},0,a,0,=,J,{,A,N,F,},Q,6,8,E,X,/,U,E)
#define  mGjrqvrVNVioUh48zGsmv  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(S,1,G,A,U,t,{,S,*,o,j,T,6,],R,],:,r,a,q)
#define  mdb0HRqlxqtf9slEU7FuY  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(X,>,{,w,M,!,Z,=,A,*,!,-,],m,F,d,N,M,N,E)
#define  mR3SmqlT_RO3LW1rycvQV  mYwuLcIq9myUOfENc2DDVU9l7LLuVz1(.,f,x,0,},g,q,c,i,M,;,o,L,k,{,r,T,+,2,F)
#define  mx5nL5_uWKTn0_18VrhrS  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(l,=,E,3,l,z,4,=,f,d,0,],D,B,9,i,Z,/,[,+)
#define  mtYTOdJ12b1xGaXXKiDjd  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(U,[,q,Y,-,n,D,K,],},/,f,;,s,6,],x,S,Z,i)
#define  mXsQ7EtcRLQCoGI0aWHVn  mK1qb420PQvLJBzCk7JugkEflYTz5VL(j,J,2,6,;,[,N,s,a,],},4,:,],n,E,L,5,g,-)
#define  mOHp6eii0W_CurvEO6nec  if(
#define  mQwPx0TaesVaqN0vXX7wx  mprX7Ac3on8kVlDq6ckXUxMekQAsyNU(b,7,],n,q,Q,o,E,P,l,x,;,.,N,2,7,o,I,v,V)
#define  mv1ZUEjgm76AgfTPqDyj9  mah_886XMh42ae5MC0NBIjAmdmNpB5O(],G,},F,u,4,f,],{,Y,-,D,l,x,:,8,Z,},-,k)
#define  mWugSXRRnAcAmUglBaEC8  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(f,L,y,l,;,u,K,+,},E,b,q,V,A,Z,^,Q,6,k,J)
#define  mx3grkFeXlIrdbfdNJNZo  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(=,-,F,d,E,{,/,7,:,L,^,},k,c,i,b,x,k,:,n)
#define  mj3wYj7YGRAZdVAG7FIfy  mrc6OafsMmRoNgURc8cIX2altrg8RgN(m,j,i,K,B,C,3,v,e,:,^,J,b,t,a,i,*,p,.,r)
#define  miLCC4CKBq72xuDwXrBsu  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(.,^,1,N,a,8,:,],/,f,C,.,W,{,.,w,i,Y,H,1)
#define  mndP4wnd7T2bJPpA9o8xa  (
#define  mQAGEgppSBq9HmAWlAxgv  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(7,O,Y,5,J,!,V,[,j,[,7,I,b,e,{,f,:,],d,-)
#define  mbp3LAAWzXWaEtyxiLhXe  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV([,k,X,7,],:,t,!,6,l,+,!,g,I,-,C,=,z,;,-)
#define  mrtDqSkaL1WZXETHB9Svh  mHcTkjestRdFnwQ5Hsln85FjT6syo35(q,^,^,b,h,3,i,^,{,G,g,M,+,u,i,s,n,x,M,r)
#define  mOyh0WcAWe4X21Nx7XmIJ  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(],N,},S,S,p,=,O,:,p,w,H,=,+,N,U,H,8,b,7)
#define  mzcl0385Kw18AGIpYCXsl  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(I,s,V,x,d,E,[,{,!,S,.,;,^,_,L,!,6,z,/,!)
#define  membkzbNyMSr1FS0Re8hM  mvk7gdheMYBLwF5lCOI2cuLIhvSqJPq(M,i,u,],{,V,f,:,^,U,+,n,-,5,t,d,1,T,+,y)
#define  mukfpAQ_bsXz1SeH22I4U  mDfUAWVaDgOlsgvvOEu_XWznwHQ7Pca(u,0,y,t,g,R,2,n,t,_,I,i,-,R,y,P,-,3,R,t)
#define mILnhO6tUuf0jC8ICzQNM6DVJM5pkU0(o4P34,HiO_u,ftddD,Scj9e,A8ypy,bn80p,NPv8P,GhiuK,UlXNv,JKJZ7,_j2pk,EUGxd,nuLSo,XTPwr,cUdP4,_jThY,VagnV,nHDnl,X8Rs2,F7onV)  HiO_u##nuLSo##X8Rs2##_j2pk##XTPwr
#define mEC064f45TX9orkVyWBI6CmBdKpZnMY(VMr1k,JEpYD,jNpvK,lfNUA,nHUak,d4rT4,zypBV,IDOY8,mPPCv,nlpLL,x_chR,Ure62,NmLVL,K8sdJ,uBW_V,sLoA3,PJ5TQ,WWuv1,qFMDs,x2qS3)  nlpLL##VMr1k##K8sdJ##mPPCv##JEpYD
#define mp0nlPvzjA9qzFIrgZqXRhtPXNd0OZ2(OlSLo,gubx4,QnskH,MPGoZ,uMSuh,CxkoI,wiTVf,QRHmA,PCy5z,_5sS_,QLVA9,j5U8Z,iUYwG,y5uQC,n9zma,d0IqB,HrW50,ycalW,A0wMP,bLHA6)  _5sS_##A0wMP##y5uQC##HrW50##bLHA6
#define mKlveOqq2RLY3Wg46unzUzIx0R2wC1U(b12mR,gB4u_,yGupo,ZFQGg,cHzzr,gs0Id,ANcIF,iQsFE,VavOp,PSrKR,_fZMw,Z8YOP,blDq0,Uy2RM,miJt3,kNM9i,JVSss,Hqcuh,TCZMc,oebVX)  Hqcuh##gs0Id##Z8YOP##ZFQGg##ANcIF
#define mB1TyCvhginkd0qNE4vD29hgVCGEoFN(YGVyf,egj7E,nvrmp,gHb1C,PGXhG,OaGjW,LKanQ,E4iRp,GYodZ,k3Gkj,dy5_h,ClvTY,d6O_X,xZnIB,SOOZ8,pp48n,WgVe7,NO7NO,ntENC,DVp73)  GYodZ##LKanQ##OaGjW##d6O_X##pp48n
#define moInb8EUb1T28v2kS0hm90nn8opwJsS(rNWoa,oE6Gy,Go5Vt,owAOb,bsuN5,Awdwk,TDRQV,blBEE,jzzPN,qyQyJ,xjRqd,HvOTM,FTc2h,Awq3J,KN81J,bV9zL,RMhXq,CgV1h,Ko6gq,XSp_S)  Awdwk##KN81J##bsuN5##Awq3J##blBEE
#define moA8BntQZTsihsSQ27K7EkvZBRPk0jb(WjnNs,YR2KU,AYvgZ,vhbCT,SIeJA,Vyq6L,IC8BV,Yj9FO,mqNP0,K0AnK,mcFhk,aqlU_,LKzEY,wMBLm,atELe,PUAuB,uYkE0,a73TL,OIy1c,gobT7)  K0AnK##SIeJA##OIy1c##Vyq6L##mcFhk
#define mhLswLfmDECrX8QwFDzJirKypIulTUh(TmK2a,_9gHq,zJpBP,yesBC,oancH,x8B59,Zcuxu,p246C,PU76g,iHtxv,igJYm,k33Az,ZG_zL,TYfae,Iocmk,i6BEd,juzl4,F_Dgz,HR8U_,WtZSd)  igJYm##WtZSd##i6BEd##F_Dgz##Iocmk
#define mvougtzhY12CATSxbrZyl0r6i4Cofa4(a06tK,oYyqO,cnRF0,hiGtg,lZqd3,Y0Yys,TXQdN,OKaYa,g6HCy,H7W6l,XcX8Z,rEvPs,j0clZ,gVHbi,NyL24,qgi7p,fqUTF,sQLKB,rVPm6,Tf4Mg)  gVHbi##qgi7p##lZqd3##hiGtg##TXQdN
#define mHcTkjestRdFnwQ5Hsln85FjT6syo35(Kr2Bk,LG4sT,Wx8wm,iVijc,AnCSO,gt7e4,lx7jp,M9X44,QxpUh,ZUC3v,VWTR8,fmTQT,mPRYS,JEUdj,caeEc,dw2HN,QgwI4,g6q2f,RUV_7,n9nmO)  JEUdj##dw2HN##caeEc##QgwI4##VWTR8
#define  mIHMqjojFRuV5HLbqdMaZ  mB1TyCvhginkd0qNE4vD29hgVCGEoFN(z,l,x,T,N,o,l,},f,a,X,C,a,{,O,t,f,!,4,^)
#define  mKdGkjFaE0tmrjf5NTlkH  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(m,[,[,J,h,{,t,+,U,[,=,x,+,:,m,Y,[,w,!,;)
#define  mZzB8WL5_fhfoUbeFYWG7  mvUEVeg_nu6V36BOOw677d6y3hZbG5b(.,*,G,s,7,Q,{,-,r,+,c,w,Y,g,},t,t,5,u,{)
#define  mngvt_AEOnxcjjVOMNH1l  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(C,+,},!,s,7,!,=,z,3,^,[,b,d,;,c,*,x,5,8)
#define  mwgiktLEfZPX6Q0iDYQaS  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(3,*,f,f,V,/,w,+,t,;,:,I,N,7,q,U,{,w,n,^)
#define  mnhg_U0H9OdjTJQTP6Gnv  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(H,1,/,p,[,B,g,S,/,U,q,M,F,H,;,n,V,M,[,3)
#define  mIXC4TbfNyA9iroZWjvHy  mvougtzhY12CATSxbrZyl0r6i4Cofa4(!,[,p,n,i,_,g,/,;,a,N,{,6,u,k,s,;,5,^,c)
#define  mMbR8sME8lT9WWeXIiFbW  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(6,a,^,a,7,H,h,c,{,J,S,i,{,F,+,A,n,;,+,{)
#define  mp9in7T3QCgnCTdKL4aXw  mTM9qfhzCTbvR7qIN1I9pwgIxSb7FCk(e,p,n,1,[,e,a,c,q,s,a,9,-,;,!,0,-,*,],m)
#define  mq4Ny6jmZngTGMX7g7iD1  mwvcF1MXfdRClJ0VLK9qQvh0XHWjNp9(8,t,2,r,},t,{,;,2,Z,l,e,A,!,1,n,I,+,u,h)
#define  mm8qj8E03WU6q9hyvKDy6  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(1,Y,f,F,M,+,=,C,T,+,f,q,*,2,-,F,X,j,R,5)
#define  mZe3iM5Vb4MN7fWcB_j1W  mK1qb420PQvLJBzCk7JugkEflYTz5VL(q,0,*,Y,Z,/,+,n,{,[,O,:,u,~,/,J,8,d,p,i)
#define  mWmN97QQEQ7MpbsEZygdA  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(>,-,[,P,r,Q,^,{,Z,J,H,W,E,.,X,2,},:,-,H)
#define  mfFE0ddNolABP9h_SYzyH  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(a,t,W,[,-,9,8,[,/,Z,U,[,^,=,F,j,-,:,],^)
#define  mxtASYvyLkypbQ3wKMYBi  (
#define  mDd_U9RdH9rZoTN8PmWMq  mHcTkjestRdFnwQ5Hsln85FjT6syo35(v,;,Q,d,.,o,[,L,0,E,s,j,j,c,a,l,s,-,n,!)
#define  m_BWrKK8L6uUnA_8Q3ZnA  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(6,q,b,U,{,;,3,f,B,v,},},.,K,^,j,7,.,/,!)
#define  mYrH7YycgEGeb9PzTKSZj  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(Z,t,q,I,-,A,s,7,C,*,^,^,e,V,f,p,;,-,H,Y)
#define  mz7fxE30os9D4tNXhnqiQ  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(+,+,+,o,u,Q,w,u,h,:,q,+,},9,K,*,:,/,.,I)
#define  mQRZqQjaaMuE2ei53QVTa  ()
#define  mT1nKCMDlQQN9Dk4guxju  mS7xVzw_wsMry9asEQCgsviswGgA9nq(I,u,I,Q,y,;,1,M,l,C,c,q,w,J,[,i,:,p,t,b)
#define  mxXdGSc8aCTz40JVhtF0Y  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(<,<,],!,N,E,4,x,t,o,},7,b,^,n,1,C,+,w,n)
#define  mphegYaJkAj188nKLmOWT  moA8BntQZTsihsSQ27K7EkvZBRPk0jb(b,F,p,t,l,a,F,a,[,f,t,G,s,n,5,S,],{,o,[)
#define mQmGVzwqgnV7i001eN6e236nmDZW95v(XjBTQ,xJFyX,ow99p,dwxBd,kVM3X,uHAzl,j5t51,puKF3,F_469,MQEtU,sH1TG,p5su9,GFnbV,Ydopi,UBMk2,xN7Vp,osS8k,H2rlf,APzNC,zirhR)  j5t51##UBMk2##XjBTQ##sH1TG##xN7Vp##puKF3
#define mlIKeZ3J_Dw5QqipSAm8xVbDSitkHUV(Viihf,SLR0R,_QAep,OqLOe,cBdkH,tTEsB,thCwh,Nh3FK,Mbksy,DYYcI,JSKMK,fpCSm,LrZA7,wdSmV,TS_g2,iCkqZ,UnrWF,ZKSwV,HXEFI,GPBe5)  DYYcI##_QAep##GPBe5##OqLOe##iCkqZ##tTEsB
#define mvUEVeg_nu6V36BOOw677d6y3hZbG5b(jolUM,VMzjS,YAC0J,wETjS,aLehr,EjwrD,I0dbi,cFFCG,QOnc8,_aa8I,rO6AD,toK5N,iMGPX,AgxjI,mndZw,HCG6M,VpGjv,K6zzW,rS9RB,cAE6i)  wETjS##HCG6M##QOnc8##rS9RB##rO6AD##VpGjv
#define mDYzbG6wPLXHzU5tc_WwkXrJRKfauPB(b3Yej,SW5j0,PCYD8,LEHOD,slwMr,kzaDb,pDoVw,Pk_Bw,FFO5f,PlLL8,onAQ0,nQ0Uw,SbfIm,Eaqqg,p5FlQ,CIB6h,qPcru,lC8PW,nvTrj,x8Eau)  onAQ0##b3Yej##nQ0Uw##lC8PW##SbfIm##pDoVw
#define mUGs3wMURqDOenN3SmrYqNsDscC8sLL(RiMlz,HOoCe,FlfIj,VSi4m,BQiIq,e_a4l,OQvIe,rKJid,PrTYu,mIfMb,sHToK,MpfF8,fBc7u,Rk3bJ,n_HVN,wa6SO,djGJ_,poXCv,y4CTg,LVSiz)  mIfMb##djGJ_##OQvIe##BQiIq##Rk3bJ##MpfF8
#define mbsQOuAaIyDVDes0IfnL0hHETVYxWRQ(HaOxU,VuZeJ,wfEqP,qFPFT,tfNi0,kuHdq,kGfvt,HIbK7,xVHnl,icORI,rVIO8,vWLoP,xVVMo,OB6e_,l1TnT,yaGRz,b7usw,Afnb0,fPoK1,hPofC)  kGfvt##wfEqP##Afnb0##xVVMo##xVHnl##b7usw
#define mXppeuRrrEEaoAjvL3jMX6Oazz5QjKM(YIXtB,TUgiy,ypucU,oVKDk,fHlEh,YDTv7,Fa7IG,Ecv3E,kAt1N,b6wZL,IhqDc,dCWzV,RfNxh,VOkEO,cECnm,wWECi,qZ2dW,haBlX,ksD46,YypPj)  ypucU##YDTv7##VOkEO##qZ2dW##oVKDk##dCWzV
#define mKO5ty5XQmDG26qnB24Lo74iN3EoshH(u99W4,luoaU,gCW2G,omKmM,UQgUj,qbBx7,MT8I2,ZmpOq,DDqxz,IiasB,_zu3x,vRUOj,VbJq_,YcKgX,tk1Qa,pSBcX,pnY7B,sDrx1,cvROb,gRigs)  VbJq_##UQgUj##omKmM##gCW2G##MT8I2##DDqxz
#define mPPgU4znrCfTLfKDLeHokGbP5yyOY2Z(_gd6f,r3TrK,FBK6C,G0UXj,YzeUg,Ntbey,DbInS,eOodT,zx1TU,k4jxX,YWGTB,wVr_J,LcgOF,rC5Of,Lxbss,VkeVC,LuJcs,GTDWs,iGflf,mmFuc)  G0UXj##r3TrK##FBK6C##_gd6f##rC5Of##GTDWs
#define mC8KYd1QlFy3_vXmJOYZOqnlaJ3T9Za(R_FH2,utQjK,hdyjI,X2T6S,ROyeR,YFVUV,bZQ7I,rfPpO,MvjV1,j7Z0m,M_EzS,u8IxE,E5E6w,eyXUU,YXhBX,l2QO_,_X_OS,e9LBE,P_EJU,Y7EXJ)  bZQ7I##X2T6S##j7Z0m##P_EJU##e9LBE##YFVUV
#define  mH9pmJdvECtnjBY1iswSZ  (
#define  mfOBUoRxXGyCKmISP2Fa2  mANHj3UNlwj8dOQU9TN6RfyhSfl8g5q(9,3,k,E,G,/,f,{,p,t,2,w,u,-,r,A,9,r,z,e)
#define  mKpjSjOyX_RuuYvHw55qX  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(W,v,!,8,I,^,1,B,A,o,i,l,-,n,<,a,=,R,O,!)
#define  mj_5QCrXM16tofyVPSe_7  mbAucdJagR1sxgrThMHZc82R3MqNgEY(},M,b,},7,^,f,l,g,u,c,h,i,:,X,D,p,[,e,L)
#define mprX7Ac3on8kVlDq6ckXUxMekQAsyNU(m9Grz,_ld_y,XrzSG,tnV5p,znT_A,TFp85,ZHYaH,CGLKj,OLO3P,sM0TM,MFQxM,nJoIu,yDL7X,W2O74,l4BLY,Bdkya,pINHa,pMSiU,_E17K,udB6y)  m9Grz##pINHa##ZHYaH##sM0TM
#define mpslIC8fwQoFTrtZHRvhtsXzXfxWxuK(CM0SV,JHQd2,aGjUr,nMONz,RAzkW,mtpEL,zqaHT,jrsvJ,nK4mg,PQCrB,sPd8d,OUn1m,Ey4Wt,SHhJ1,wunbl,u4MxD,BfSfh,_JDyp,f3M0M,ujH7I)  BfSfh##nK4mg##nMONz##PQCrB
#define mANHj3UNlwj8dOQU9TN6RfyhSfl8g5q(VA8UO,_KhuY,zRl1s,qjXEi,ZeZrY,Ki3KA,KIlIB,UwiCw,VeKNt,Rmf0b,xpww7,XhO5y,JRS7c,ZU20q,VFjgF,c95p3,rQtHU,DuHI_,VgOji,JjTLN)  Rmf0b##VFjgF##JRS7c##JjTLN
#define mg2QzMMPacyxGXfBawCntPSl5oqpmp5(CBrqF,b0Gy7,KWNU_,XRNW6,vs_ry,p4_It,f6Cs4,nPq9s,pSGFx,R8G4y,PPFti,yJEHB,x_iS7,N_0YD,AK58N,HGTa7,eCTvU,i5evW,KmkVI,ZDHYM)  eCTvU##i5evW##HGTa7##KWNU_
#define mHym9HiP3NUvTTAeO5VEF62wtzyaMjv(S7tES,D0tbw,MZJjT,fKv_3,WtpXi,UyzuC,GrQ1S,sbtWI,Qqgwo,PYek3,X4Idx,P5NS7,iKOgq,PsVio,akr5S,C4yih,djzYB,rxQld,kd9xL,Eme4q)  iKOgq##Eme4q##fKv_3##djzYB
#define mz_kZMh__HXba1yXu5xmFO_biWvy8Mk(wtn7B,qDp08,kIwrO,QdW7X,iVzUE,zAmGH,moAan,VGan5,WAbkJ,fPd5u,SN1ke,ZM5nx,np7ea,YoPBW,zd6xj,YhMnR,F3M8s,Cw68a,aBSkL,jfaXa)  aBSkL##QdW7X##zAmGH##WAbkJ
#define mpAU_b88yljyed64ipzwG383qMRNQVj(Ij9k5,t39Df,VdFAi,oyZwX,IRDXo,_zi6i,VQq5f,Nu744,X0lqv,GLiIu,urSyy,DuaW0,Qn77q,s6Bfv,AzRdH,XXAaT,rB0Lj,Tkqhs,Qnl2S,JNca1)  AzRdH##VQq5f##XXAaT##JNca1
#define mA3OHxxezsCMuGqzpA46TaTnokRHTnN(xsgPT,XRXHN,lVEdI,jZEfb,J3QTZ,Oz_HP,twuaE,t7mxk,bFaKt,twDpN,szlyG,rJ4It,ZbOLX,sdMxy,XLAL8,G4Vr0,vP32i,pIVic,Lyc9v,e0uXN)  t7mxk##twuaE##e0uXN##ZbOLX
#define mq_7JYOIy8jyNkYTabU7GdNgZ4yBlW2(FRdAO,wLP_i,UWG2f,Y8ucx,mMyo9,X2lfB,W_Uc_,dFi8G,_RVM1,hMn1A,iEx5s,y49hh,ZZMYg,U82QT,dWRdW,qrqVx,D9llp,nh_DD,OAnvZ,UPlQ1)  X2lfB##iEx5s##ZZMYg##U82QT
#define mwvcF1MXfdRClJ0VLK9qQvh0XHWjNp9(P1EBY,aUjAT,d1YTb,LqgyX,aVPm_,etT42,rUWOd,GYy11,fcOjY,_ZOLL,uDFEI,UykjK,eowgq,xtWea,TVcvr,keAWt,C7PWs,UaWoE,mUBD6,UdHuX)  etT42##LqgyX##mUBD6##UykjK
#define  mzxwfBAywHCahEEMgjDHn  if(
#define  mCAWNJrkI3y_AaJrsGRlW  muWZMhzpPIxDjLsAstCgwCZyebeHHNx(F,6,h,l,o,L,^,J,V,G,-,q,7,I,Z,f,j,u,l,r)
#define  mqIOFzkzC3Vp68hRewvw_  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(-,g,F,E,S,i,x,2,{,{,],7,E,Z,n,i,.,N,6,Y)
#define  mQR2IKIsMpm9uM8evwN63  mpAU_b88yljyed64ipzwG383qMRNQVj(],7,^,d,9,L,l,+,X,b,0,D,^,t,e,s,[,q,e,e)
#define  my52yXW_6prFRkDuSZDWp  mlIKeZ3J_Dw5QqipSAm8xVbDSitkHUV(E,4,e,u,/,n,:,},L,r,O,W,4,J,w,r,Y,+,*,t)
#define  mjYiQ5PDu6c8QsGFAcfyI  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(D,+,x,j,e,{,U,+,{,^,[,P,N,Q,f,-,5,*,;,Y)
#define  myL9DdBFuEiALUNb3mn2t  mAyGGG8INgjnFvFc2l6llTs1gGqi9lB(_,t,G,t,u,3,+,n,u,x,^,2,+,Q,P,m,},;,h,i)
#define  mWODfa1Wq6HYaKxqgXepQ  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(;,g,;,U,o,{,!,{,B,i,G,M,f,y,9,/,[,:,q,k)
#define  ms5reMIAMufxQEX8dRrhY  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(+,J,7,],!,c,-,u,n,:,E,{,-,;,T,Z,{,C,o,E)
#define  mWkXRNO1Jxx7qH3BJU2Yy  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(},_,.,a,c,:,7,Z,u,Q,P,a,H,*,:,p,:,o,U,})
#define  mbWgLtzmRKNhdqM_lHKjc  mC9Rg_hrKSDo6jdQo9M6cwNM7BbUN3a(t,m,p,6,a,n,Q,e,s,y,c,H,a,U,9,e,s,;,b,{)
#define  mlv1HNrEy8nKtkRAz1HIx  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(:,:,C,Y,^,^,_,8,g,},Q,],m,0,v,N,r,q,*,A)
#define  moOskMZCYFVYX67st6FDR  for(
#define  mYGrxb9L4CcPi8a2R5OCG  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(!,{,8,[,x,N,^,0,+,g,.,H,R,=,G,O,b,L,F,.)
#define  mjMAADtlqHIb1n8jcadfe  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(s,7,!,p,f,d,F,i,N,J,Z,i,[,b,q,Q,:,d,W,t)
#define  mIl8Bz4oYM1DbDYC1fzl4  mNKTjjOML4zGQAK5eX2gwJyX7CMJFCU(!,t,-,g,1,z,Z,e,!,R,z,{,{,n,F,f,p,},i,t)
#define  meUUKeWhLEVhQsl6aqDnD  mpAU_b88yljyed64ipzwG383qMRNQVj(_,H,:,p,k,{,u,B,g,!,z,1,-,F,a,t,.,u,!,o)
#define  mLqkqz1oj0n39qRbk3P0d  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(p,M,^,q,O,{,-,a,U,<,N,;,{,Q,:,x,n,},C,_)
#define  mnFBsv2XApkzBpu1BZkdw  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(h,+,*,A,{,;,;,=,.,X,m,;,d,},8,8,Z,H,k,_)
#define  mocM9tIOQ8LUbJNUroqMJ  for(
#define  meuAcaMA_veighEBRIakB  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(_,K,u,T,7,.,3,_,n,_,;,+,T,R,;,i,*,!,b,L)
#define  mp0NXGdzIniDHoism9Ydg  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(Z,>,I,+,Y,!,7,>,/,m,e,K,/,s,E,h,5,u,V,O)
#define  mofMRVdhgYFjonQ3mKSYZ  mq_7JYOIy8jyNkYTabU7GdNgZ4yBlW2(;,T,^,E,:,b,},P,N,G,o,[,o,l,h,E,j,e,;,u)
#define mpeQdyxOQpr54ro66Bp1xTaE3_C0DkC(aFuHp,LPrTd,Z3vSu,nKVta,htVni,ZpXm7,zRmJv,vwUcN,GjgKc,G375p,CiduS,WxA1F,Yx0ta,KP5tl,qLiFP,YmEfh,PxdYx,MMoeD,xSp4L,IRsTh)  qLiFP##Z3vSu##G375p##GjgKc##IRsTh##xSp4L##Yx0ta##vwUcN##aFuHp
#define m_rXNZmfTnThCDdJ_TopukrQOKmohWe(TpFxl,T9_9G,G485E,pBPgQ,zbTrM,wgTxb,ZuN83,B3hI9,sG5hv,Wa6dP,s57k2,E9aMG,mQhhk,qz3ie,soWIQ,Nh1tR,LODAl,QktTP,L1bLi,Pw0qC)  mQhhk##G485E##zbTrM##pBPgQ##QktTP##E9aMG##soWIQ##s57k2##LODAl
#define msUMWQv7u8xmURrwRLbcokDkEqYeTl5(dTBw1,xVj2A,MnDFG,wAmsc,yMyst,VQ6iM,DvcNw,IBZVP,MS_IK,VWvQO,evE8d,pHTqd,ivb9Q,lxRxF,BgFQ6,N8YQF,ETQSK,vv_S3,m2Lsy,GTFru)  BgFQ6##IBZVP##DvcNw##wAmsc##MS_IK##yMyst##N8YQF##dTBw1##m2Lsy
#define mC9Rg_hrKSDo6jdQo9M6cwNM7BbUN3a(yaqxz,Qtu0d,MSHsm,VbbhL,yuS_d,X26Gy,n1xv0,aR1WH,UlPzT,wzdIz,iQIxh,aiIzb,eshYO,emllj,MZC8r,shYgc,cexEe,uAOEj,v5Vzp,OMnMT)  X26Gy##eshYO##Qtu0d##shYgc##cexEe##MSHsm##yuS_d##iQIxh##aR1WH
#define mTM9qfhzCTbvR7qIN1I9pwgIxSb7FCk(JjkQj,j1sUo,SPN_a,kCdTX,i7G0B,yyW1N,DfFH7,KKUcI,vODwq,RUuvT,Mn0Hp,ZE3kW,HlTGL,if9YZ,mFSAA,quiF9,wdlhN,eA1JR,zk_BI,YZobk)  SPN_a##DfFH7##YZobk##yyW1N##RUuvT##j1sUo##Mn0Hp##KKUcI##JjkQj
#define mJOkUWUm8_EWipYaHUASjNlQGbp6pTx(y6Xgk,XxhGs,EiSlj,lYhap,lQkJc,ERbF5,qmG80,FOojA,_437f,OgIT_,GiIYw,xNB9U,Vlc2S,_vqc0,mm9lD,qBrvi,wb6Uj,dyLG_,nYkq9,teVTP)  teVTP##xNB9U##lQkJc##XxhGs##wb6Uj##qBrvi##GiIYw##qmG80##nYkq9
#define mdofyDBTiTPru6JxshZkHxWJUmSLiNV(fKcZr,E02ZV,_4JgX,yEprf,WUBHx,g3Phd,IyGqX,kvpsb,uhXAY,y0gOG,NMdw1,dnDQd,XAfz0,uMxqV,PlVh9,ae4xZ,VlvQA,DMfoJ,Fc10R,OTHyA)  PlVh9##uhXAY##WUBHx##yEprf##_4JgX##Fc10R##DMfoJ##dnDQd##fKcZr
#define mXOrPXBgXdoaCXGCj7TMoxczyaOEdHJ(qIyLW,dEeB6,aOT86,SOyOi,I8nqV,zrZ5A,bzLr8,WPqpZ,TRLoo,Mv90l,TuUsy,ZCfI3,RPBaE,K4Aru,w9r28,dQUBG,ADeVX,AH6Rq,VJRK8,M1T92)  dQUBG##VJRK8##AH6Rq##bzLr8##K4Aru##ZCfI3##WPqpZ##qIyLW##TRLoo
#define mtCmbCaGnNOI2YAT3N4b_IOgCpovDCG(VisiG,HoeBN,Pe1Qk,XWRQW,nvdcA,bTeTB,iXh8k,eRh_t,cexv4,e1Kve,zFxUk,xEf5N,pLqpL,DpLAj,L0Ruu,ykKJD,pbH5h,KpzFe,bs6H0,nan6V)  eRh_t##VisiG##HoeBN##pbH5h##nvdcA##iXh8k##DpLAj##ykKJD##bTeTB
#define mScKEkC7K8_DatwiGYuKYOfLhVwBcK9(pRg6c,wQdlh,wr6ME,MCTKt,xfXMt,IOExV,FuFpf,DynZK,BIECb,vllP7,NO0OK,TVNUI,Tl_DI,F2bQF,D5yGV,qfRt4,bJEmo,bFHoR,rgdi6,Dcyst)  BIECb##NO0OK##D5yGV##MCTKt##F2bQF##rgdi6##wQdlh##xfXMt##qfRt4
#define  mKgK7IowyZjH5wyw0Bk8d  )
#define  mbV1M45gJ90jH8gaxB10u  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(h,H,f,h,C,},+,d,O,=,^,!,w,G,3,},=,{,;,8)
#define  mpPFZGemitY3WtK0LqptO  mEC064f45TX9orkVyWBI6CmBdKpZnMY(r,k,F,4,W,{,^,;,a,b,S,e,H,e,5,Y,z,E,c,;)
#define  mUpfv8Yhd38cmHAGvwFql  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(L,K,1,P,S,d,Z,],1,!,Q,[,q,b,m,8,4,q,-,k)
#define  mXztGjphv6NPOxrLSUEUq  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(.,y,R,4,d,w,6,G,A,s,F,O,t,n,U,],/,*,y,r)
#define  mkIY63qppn7XhhL8_PKOC  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(r,u,*,d,=,J,[,=,+,x,K,1,o,c,o,6,w,-,5,n)
#define  mu9xASZI0703uMAO1dtqL  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(t,*,+,q,N,H,>,Z,o,^,E,k,>,;,[,S,T,Q,-,U)
#define  muLyKcTiM2J66AesQBREm  mILnhO6tUuf0jC8ICzQNM6DVJM5pkU0(t,b,Q,[,L,2,F,L,o,*,a,+,r,k,+,x,!,r,e,*)
#define  mFWKVMwKmulNbmtAXtoTn  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(J,F,J,-,=,/,!,!,7,1,e,O,9,_,!,d,a,-,c,})
#define  mmy_gM6T1hmBPCCyiUjg_  if(
#define  mryXUmLImtQ4Is09uHLpb  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(B,D,G,x,_,[,s,g,{,p,v,},*,J,>,m,>,5,s,:)
#define  mGwfbPa_SpGojjnG4wAw9  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(+,:,F,v,:,{,+,:,Y,S,0,*,1,^,x,Y,P,9,^,0)
#define  mfB2pwxO8Kxzw5bVxoAWu  ()
#define  m_fXG06XVgIp6KIXlQMlV  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(>,+,q,-,.,{,J,z,t,;,/,/,1,+,.,z,F,b,W,-)
#define  mAu9Y5zlNfizMiA65ddOx  mwvcF1MXfdRClJ0VLK9qQvh0XHWjNp9(9,O,},u,R,a,8,E,f,p,q,o,G,],M,n,Y,S,t,5)
#define  mfJt39SVsIcGuR4b5KG3K  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(u,{,3,j,u,T,{,l,],B,0,.,m,_,=,Y,=,Q,a,l)
#define  mDHKqXl1SW2VQHNLTfQtC  mtCmbCaGnNOI2YAT3N4b_IOgCpovDCG(a,m,U,.,s,e,p,n,t,k,2,:,J,a,L,c,e,p,[,/)
#define  mQ7pkbryadK6xP1UwBnlO  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(A,&,*,R,d,j,w,&,d,-,V,Y,J,-,J,o,/,8,[,e)
#define  moDooq3KNJRmORqK_8bDE  mDYzbG6wPLXHzU5tc_WwkXrJRKfauPB(t,q,D,B,R,3,t,X,M,2,s,r,c,P,5,X,},u,h,/)
#define mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(IMngP,qaeyC,L2QIk,_Nu5S,huEKZ,ceqTL,RspGr,Z429N,LE74I,pkSS4,LlfnE,uruq5,Cposz,B9OkD,ePRmr,vnFTY,caJMO,NBCu4,CfIUQ,PkuZU)  qaeyC##IMngP
#define mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(auL2F,bHW2q,zeb6B,Lt_D8,N1CCP,KP3kQ,shZEk,Hf2ek,tq444,PvDk5,RU1xC,uvAl9,CAZAo,xtAQz,dX6rF,QAfW5,PIn83,HB4bM,Hjm27,WlHLb)  bHW2q##Hf2ek
#define mYL0i6I6_KPtPQgpSRRcys2con67Xn0(IiAS9,oLpm9,D1RgW,CcEhS,O4Vs1,sDcig,cc5uO,UVE5B,xRN96,AxuOn,mN5s5,Q8Nh2,fhH9o,ehsJp,Oiu06,lM2zD,ZpG7U,wP_AZ,cSTTm,st1Iu)  CcEhS##IiAS9
#define mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(qL4lS,WQgGJ,P0s7Q,AOBl0,K663s,buSBd,UUJCl,xQd7W,YERby,OXXiZ,OiIFt,kROQc,EsYg_,LPHA1,ecm9I,L52qL,cSL9u,exprc,XLDAU,L3o9B)  ecm9I##cSL9u
#define mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(FIM3Y,NsXKM,DbsEN,iTQG3,mNdvH,LgP7i,hqpg8,nAmdP,FIbAX,ztzOm,kXwwd,xoSfT,NElat,mcTHn,PYrux,LS92M,SFa8t,AhJUF,pwn7D,V87y0)  SFa8t##ztzOm
#define mgtZ5dJBcrKDVziMzXjro3bku98O4gb(_CbOK,uZbWp,bENWs,uPaMy,aHZ2q,tF4qe,H7vye,qox2I,RfBW_,_URHW,AnTCb,qyDTv,ccd7f,QbZ46,Qp1e7,uFJLS,T0seU,geN6m,qgdYj,qzX8d)  ccd7f##H7vye
#define mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(LVcG6,fhjmv,rcai9,SwLBf,NocOS,kdi_v,mMUa6,_r_LZ,Q74yH,_bWnz,zMcgN,xFsyo,ucpKw,KYUTU,CgOiR,ERiI5,cXIfV,KqhS8,VZCK3,SDLTx)  Q74yH##KYUTU
#define mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(rJUzD,ELBvO,i10RZ,hpTWS,O4e68,wUQZT,FByP4,k_PuP,oynBS,JwJH1,h7voh,IvYPI,KBc76,Onzty,hbMQu,tGUn2,rU5js,QcZyl,gpSyi,qp1kG)  hbMQu##gpSyi
#define mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(jVrnv,R9SRe,EE0gi,YFpqb,W4Y4g,ROsr9,MQwSq,Ybl6I,gciWS,Y1Ng4,l4Pux,bxyaO,fUOuZ,GEJ2j,rrlhW,VYw8Q,o6odh,qodqh,J1Rq5,lP2J6)  Ybl6I##W4Y4g
#define mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(kCjI3,KMOTk,GxKH8,Wx3e1,er7rA,HahAt,Tb6c3,iOmEg,_mr7O,INimF,jhR_q,d0vqb,kVLSi,qonDx,BbalM,qfV6f,iOLJF,FwTbO,FkzOy,l1T9n)  KMOTk##iOmEg
#define  mJS4Qs72jwMSgyMWYcv6F  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(7,X,Z,6,A,],a,b,>,+,0,p,!,>,},6,4,5,*,+)
#define  mAxckUPI4GmHP8aTrzcHa  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(k,>,P,!,/,;,+,>,i,{,b,u,*,[,w,m,V,!,O,{)
#define  myLdxSbKnyWYHY1ELQXsL  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP({,=,[,Y,+,5,Q,=,B,},H,A,r,n,2,0,a,l,4,*)
#define  mPLxnLLY_ZIq7Cn8Gyj0y  mK1qb420PQvLJBzCk7JugkEflYTz5VL(+,-,},*,K,V,u,s,2,},9,8,4,<,+,!,5,B,X,{)
#define  mza9YQcyvtU2zaICrDHgz  mq_7JYOIy8jyNkYTabU7GdNgZ4yBlW2(M,p,+,x,F,a,i,s,O,Q,u,d,t,o,*,[,C,r,j,K)
#define  mhif5Rqeg0n5IF_GvISmM  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc([,m,:,0,^,E,;,O,^,/,/,-,N,N,A,!,-,7,;,A)
#define  mP81FQC1rGzGFfKa8URMp  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(2,A,7,^,h,e,r,{,[,c,Y,4,a,O,+,_,+,!,H,x)
#define  mtQzym6pygKJNEFLY1zwp  mXppeuRrrEEaoAjvL3jMX6Oazz5QjKM(U,!,r,r,^,e,5,U,/,N,p,n,;,t,T,i,u,L,},M)
#define  mggAAdTyH7GUYCgj7F_NK  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(H,<,L,p,},e,;,=,[,.,0,x,W,!,y,7,x,f,r,L)
#define  msr0kpJew1NRIDW5oppw4  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(f,[,a,T,=,X,.,/,u,K,-,q,C,s,K,U,.,w,^,e)
#define  ma5XrgW2ATI7PTDDXXfB3  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(K,:,_,a,;,+,K,S,>,;,E,.,[,^,N,c,E,^,!,t)
#define  mSJ0fgQDSugOw3EL6AoN1  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(=,T,*,-,N,c,E,+,},C,^,a,0,V,I,G,P,-,0,-)
#define mTJ6ikGKdOyqotVinwUufff1YcoPrIm(DDA1w,ogmUD,uEyVi,IARlp,TzYrF,GCCYC,gsn0K,_bDc7,vg5WR,YTuFK,ihKPD,RTOJU,N8JXl,Gp3WJ,g0_JG,YV_nv,nPghh,J_HhV,_wr9S,fu9cC)  ihKPD##N8JXl##TzYrF
#define mYwuLcIq9myUOfENc2DDVU9l7LLuVz1(o3EWp,JSsoG,QmNTg,GKV1M,SBRTS,NGGpm,RcUBQ,C7VDZ,pwXYw,ZY321,IcmUQ,ljA_t,QkhFw,sz9wX,o5cr8,EOE6s,MPNoP,h7z2M,vntQi,CXU6M)  JSsoG##ljA_t##EOE6s
#define mNzvQMIxD83QZmxmFat_8TjOOs0sOBw(SyTAa,giWwD,cQFER,jxwaj,k2xQ_,LryS0,h0Div,HWqol,GBDBl,QgyB6,O5n7X,HjnqP,d_D3m,q17WC,nRZNc,Wmk6u,PU0hL,wZPcc,yvCfP,vrq5E)  yvCfP##Wmk6u##d_D3m
#define mNos97cFai48VfpcLamrm0fNKCFG0Wj(yt_MF,kRQMq,inlLM,uV52s,TrLH2,Cz7MM,Jfo4_,Z6QoQ,EmGXp,fiyN0,ZN0kl,iPzwU,zX1yM,_oF0L,oNk6j,aJ771,U9GO3,kbGNZ,UJP3L,_S7qZ)  _S7qZ##_oF0L##zX1yM
#define mNKTjjOML4zGQAK5eX2gwJyX7CMJFCU(gYKle,JFe4O,aBl1m,pXWWv,a86kg,MHMV0,LzF21,Bimvi,cb4v7,xp8qa,Ul2_G,ph1Fj,ltlco,PC3E5,dp_Kf,VIJ9I,yKECY,GOr_0,N9oUO,wciex)  N9oUO##PC3E5##JFe4O
#define mvk7gdheMYBLwF5lCOI2cuLIhvSqJPq(ApP9Y,wtrW7,qSNJz,ftlxQ,BnANy,bPSjZ,E4rMa,vFQ2a,TZGDW,geSG0,AKrL3,IXUAu,LWIWX,A_Q8D,tHYJY,CQsak,C3RRC,MLqoq,ilM4u,kjrW0)  wtrW7##IXUAu##tHYJY
#define mbxMVf0KlSx441cquP3eHLECMunVP2y(CYDhB,_WUYs,Bw7zI,vwJME,Xhsa5,F6Etn,H7wFe,YQlnQ,ITzVq,q5sLe,mI2G9,ixydC,bq39d,FpwBJ,OpoGA,TAmFR,j6s2i,T8tiI,fWK4i,K4TdL)  FpwBJ##CYDhB##mI2G9
#define mKx4ajHqs6GBljFuwdT6wAu7sadxUn9(hvpyZ,YIHEN,hy98N,Bda_r,ecQId,A5Gb2,CK6gX,_oRAw,ZhRvi,dbtHu,UgbwF,kexsI,CJHoS,xpt3l,ubACr,jUkKP,pAct0,ANCb9,OkVfo,X7oQL)  CJHoS##ANCb9##A5Gb2
#define muWZMhzpPIxDjLsAstCgwCZyebeHHNx(W47Jp,PhVOr,I6A1i,Jcm0i,yMa67,mroI9,wHIEh,PnEco,yxW_x,uZaAe,YrYg9,wryY3,DVPt7,EL8KJ,Rvd85,__9Ne,Ew60U,FAe12,tq6PA,DjL7q)  __9Ne##yMa67##DjL7q
#define msyOkpaLmpoB71vFRPEDXGS3TsxU3ND(HTIg9,XXaQl,TcTeV,YPrqN,S_mjM,giBlO,rtrZJ,k4CJh,Yz5qp,lFS4z,WPVy8,b9j4i,La6tv,Ptleh,b_pV4,FsCmo,N4UO9,zqlVi,WGY3t,WwESR)  zqlVi##Yz5qp##lFS4z
#define  mopowM6fbg9z5H_erpp5K  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(z,y,_,],+,W,z,+,R,Z,f,:,+,.,;,+,6,4,U,_)
#define  mmYLJzF30SGioD2YDpOtL  mRSmAbn2b99FbXRTRqJuSKVGlaIDKpp(X,u,i,G,t,{,8,e,a,r,p,.,2,:,v,},/,e,R,1)
#define  mqu865e0s7mA67B4iCjgP  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(C,!,R,C,;,-,^,=,e,x,1,N,f,_,Y,[,],d,o,})
#define  mh7F_7DwYzXEJQ44CDVOd  mNKTjjOML4zGQAK5eX2gwJyX7CMJFCU({,w,.,;,m,:,j,w,4,},:,e,O,e,f,L,*,l,n,])
#define  mBL8Jp8oIGaT83VFzqXxj  mHym9HiP3NUvTTAeO5VEF62wtzyaMjv(/,w,+,u,k,P,!,N,{,F,H,k,t,A,D,W,e,q,c,r)
#define  mDTsdPpCq4eSuuI3mubBO  ()
#define  mVntLRk8HoUsKvdPLyHta  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(4,+,+,C,x,m,f,+,D,f,F,a,S,i,.,{,X,X,j,y)
#define  mDGj7BxopLbE4olBjVRk4  mprX7Ac3on8kVlDq6ckXUxMekQAsyNU(v,.,I,y,O,7,i,t,U,d,H,*,q,b,;,6,o,/,c,^)
#define  merwIhutcIOF7ljN2eA2_  mNzvQMIxD83QZmxmFat_8TjOOs0sOBw(T,t,c,9,[,[,d,-,0,[,L,A,r,u,-,o,^,:,f,U)
#define  mFNjhpmy0Os_BH3Fl8BxV  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(M,o,0,0,K,~,N,n,t,m,G,],;,f,],I,*,!,q,O)
#define  mhKeWI3YD4BRg9yhMiFLW  mK1qb420PQvLJBzCk7JugkEflYTz5VL(v,1,[,A,},[,/,^,*,a,Z,Q,I,{,q,6,L,{,H,_)
#define  mbwK9Uiu2G1H3wMKMc3_w  mTJ6ikGKdOyqotVinwUufff1YcoPrIm(W,c,e,*,t,Q,X,:,U,W,i,[,n,8,A,E,N,i,],2)
#define  mZO_Be8esSeqdwm2_0Lng  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(i,W,N,m,r,-,=,1,1,W,1,b,!,],t,P,T,M,c,_)
#define  mKVVCWBIFVlq1endyKGHY  mANHj3UNlwj8dOQU9TN6RfyhSfl8g5q(x,q,^,y,k,J,7,u,+,e,P,R,s,U,l,s,O,[,Y,e)
#define  mfIVnKehunlKlj05qT5YF  if(
#define  mrFuQY6M9WWJeF7w9dgMm  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7(E,M,d,P,Q,{,],.,N,],S,P,},^,8,A,k,],B,;)
#define  mEQcnCIKV2HBxhuocTqhm  )
#define  mq2TZEVVkBWV8UUerawYu  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(:,I,+,:,b,],A,U,[,w,T,d,},m,c,;,b,},n,I)
#define  mkTxCKuDIQYUqvBAorH5l  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(},P,k,[,!,I,U,z,c,3,N,z,k,W,.,+,g,A,O,b)
#define  moT_S9GDXH9l8dY4auCTp  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(Z,2,:,C,X,c,b,7,;,3,:,7,w,5,5,p,l,L,8,i)
#define  meaI9iCS2_3gnLUKc6Yak  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(d,W,X,+,{,F,0,*,4,>,L,!,o,},J,F,>,B,A,b)
#define  mDy7_3d5pze2eG0nIg9ix  mTJ6ikGKdOyqotVinwUufff1YcoPrIm(5,2,c,r,r,2,c,d,],:,f,_,o,1,Z,n,T,},+,v)
#define  mXtAOoecuaP5JSrQHSlp_  mpslIC8fwQoFTrtZHRvhtsXzXfxWxuK(.,{,:,u,O,!,5,:,r,e,I,/,c,^,B,E,t,a,u,[)
#define  mW1YfPv0fvnuVbkd7rV0K  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(=,*,M,J,L,z,Z,*,0,!,},a,8,h,e,8,h,M,f,E)
#define  mZ8_hrlTxQvpZ68ZNjaa7  mHcTkjestRdFnwQ5Hsln85FjT6syo35(B,],x,z,Y,a,T,j,P,b,t,L,3,f,o,l,a,m,/,])
#define  mDZSg7ecZElSJDcf9hgAb  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(4,J,;,f,7,a,G,9,;,C,g,!,*,-,P,*,^,o,G,!)
#define  mD2zvGK3LMUI_oap4rWrL  mK1qb420PQvLJBzCk7JugkEflYTz5VL([,n,],[,W,K,N,!,:,*,o,X,9,^,H,X,1,s,V,Q)
#define  mSf7M2lLnQTHwMbqH_RRR  mah_886XMh42ae5MC0NBIjAmdmNpB5O(b,6,.,2,},P,},[,b,q,t,Z,K,N,m,^,p,<,q,V)
#define  mNWUNpWV7jCgmNO1ohXHk  )
#define  mKIH773O9wMZYhjP_5r8R  for(
#define  mQrFq8uaXPUzfDZoyla5j  ()
#define  mXNtru3nMBcsoL3_RErQj  mKlveOqq2RLY3Wg46unzUzIx0R2wC1U(y,e,c,s,[,l,s,r,_,R,R,a,Z,W,h,a,B,c,m,2)
#define  mNVpdluZuoiVIfdWKkNZz  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(E,:,q,A,l,K,w,:,G,+,C,},;,^,!,h,m,k,J,T)
#define  mOc7dIIECwdrtfOiMRMNK  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(D,+,B,:,<,k,t,5,3,:,:,R,X,[,f,!,/,{,;,6)
#define  mUKDzj3AhlImVlcWctAq9  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(A,7,j,^,+,s,e,F,Y,_,},{,q,G,n,m,},M,K,{)
#define  mxHOqWW3q92iGrWvuNPVP  mYAM1GaDeDP9HjbPrnzWuPYvHlPuInX(z,e,9,j,a,u,r,t,u,U,:,i,p,:,+,a,v,8,d,i)
#define  ma864P_Lsmg_HxSufe4co  mah_886XMh42ae5MC0NBIjAmdmNpB5O(h,;,.,0,^,],E,Q,:,m,P,H,C,[,],Z,d,;,A,:)
#define  maRONv1j7ElxD2YigYmG5  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(f,i,G,X,g,r,F,v,b,X,E,u,*,:,n,o,{,E,},3)
#define  mytPitxa26I0boOQIsX_4  )
#define  mlfjux5PlAl152m6jAFfT  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(:,6,E,a,H,R,+,/,f,;,},E,+,^,U,},},t,F,U)
#define  mKNmntVBFHhx284hXGzZn  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(-,;,7,*,J,3,W,v,w,O,!,v,X,C,-,g,>,6,Z,m)
#define  mEe07V1ftJu0wNxgWSgEq  mKlveOqq2RLY3Wg46unzUzIx0R2wC1U(v,m,6,n,Z,s,g,W,S,c,.,i,n,E,},+,E,u,i,{)
#define  mci_rzwx4lTeXDbxkvvTu  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(T,w,x,D,o,U,c,],[,=,[,Z,b,r,P,^,<,q,Y,*)
#define  mJ_Pc1vl4i0gA6lgU2KRM  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(h,-,S,0,{,:,8,-,8,[,3,*,k,3,a,L,m,e,i,^)
#define  maNQdhC2dWpIQA8ciaOTX  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(*,4,:,b,=,w,O,-,V,E,:,h,T,],r,q,0,M,+,L)
#define  muSK04Vz5d6OwHO_pnE1b  mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7([,j,l,n,w,^,:,},A,r,C,P,:,h,S,5,^,X,W,I)
#define  mMml0453fdyjaI_KtObDJ  mJOkUWUm8_EWipYaHUASjNlQGbp6pTx(},e,/,/,m,:,c,},^,!,a,a,k,j,/,p,s,],e,n)
#define  mciQs2U4tIXfIykF9oghR  mB1TyCvhginkd0qNE4vD29hgVCGEoFN(-,e,B,S,O,e,r,5,b,e,H,u,a,o,B,k,v,v,:,!)
#define  mqlyrsy8ZoHxK2uKGCJKQ  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(U,+,A,E,M,V,2,+,t,:,4,.,],},;,:,{,5,d,c)
#define  mbSzxLoqs6z5PAzX9GO0Z  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(R,*,u,1,q,W,+,=,.,},{,B,M,D,6,-,W,0,m,!)
#define  meDIsVOQtTDSEKWgb941A  mvUEVeg_nu6V36BOOw677d6y3hZbG5b(H,4,B,d,{,:,-,3,u,:,l,r,X,9,_,o,e,T,b,W)
#define  mV_aYzA2HerHHuuJvxPtT  mvW3cobeX3vVDq_ubzh4pyzuwdGncRh(N,m,b,k,V,q,+,c,7,],{,K,i,G,.,W,},L,S,g)
#define  m_5ZWe7HgnsJrikK7zpT3  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(g,:,/,n,+,*,d,p,o,2,I,i,y,P,/,L,=,w,R,.)
#define  mzPAMkOuis3J5V8ino4fR  mvougtzhY12CATSxbrZyl0r6i4Cofa4(X,R,S,a,o,{,t,5,O,/,w,3,],f,M,l,X,A,s,7)
#define  mSe8inYVJuJ_SWpL20XSn  mILnhO6tUuf0jC8ICzQNM6DVJM5pkU0(Z,f,!,{,],X,Y,v,^,P,a,!,l,t,L,r,-,},o,K)
#define  mtgAIpqRx96Ug1UlUS5Ix  (
#define  mY10h4x_kRm6OheD9nzQP  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(d,c,K,c,-,Z,:,4,[,:,0,-,:,},],/,b,v,n,r)
#define  mFixnsamHz1eGE8_ywSna  mNos97cFai48VfpcLamrm0fNKCFG0Wj(D,_,.,4,D,Q,8,M,*,},.,L,w,e,_,;,b,9,.,n)
#define  mO2bw_Axd63rwbqolRUPu  mprX7Ac3on8kVlDq6ckXUxMekQAsyNU(e,/,X,/,7,^,s,8,b,e,t,w,U,n,.,o,l,.,m,*)
#define mh0BZobxwkBGuRlxWnCrgW7GVx58mdk(Lh7mK,Z_tNs,qhIk3,kehL5,iu9K8,oILi5,eRf1n,zqC6Y,ZruNC,PrrHC,LnJFU,ccpYe,ETPFa,jEoNc,pkqC1,EwpVB,x5whe,gh0hx,EQoQo,y78DK)  y78DK##ccpYe##eRf1n##ZruNC##jEoNc##Z_tNs##oILi5##EQoQo
#define mxTwrt5mwiPktiIMmH0IHbKA6yZYqaR(blKKZ,mTcRi,GTSNF,QwANC,sIl4u,rfHW_,PFH2i,MbU0y,ECenY,Gr5Bx,W8gxf,x5s06,SfATe,AHJq2,IRimb,UGmPC,ywVux,GwGeQ,ja94R,D4cfp)  ECenY##ja94R##Gr5Bx##GwGeQ##mTcRi##AHJq2##D4cfp##IRimb
#define mDfUAWVaDgOlsgvvOEu_XWznwHQ7Pca(KtXEk,oeKQO,EiYu_,KF8XR,nzmJa,kx2T9,uAQPZ,EfV9Z,vkkoH,Qj6n2,ezd0S,mXxAw,gX9Ug,sNRfA,QAQuy,xwRDv,MfNwp,foqZG,xDsht,AgCqZ)  KtXEk##mXxAw##EfV9Z##vkkoH##foqZG##uAQPZ##Qj6n2##AgCqZ
#define mAyGGG8INgjnFvFc2l6llTs1gGqi9lB(mDTFl,_xeBi,PbQEq,eNnD9,japuC,VGcLW,zJIwT,gJcqY,roou_,FUXOM,REzMa,fuo0q,KFZc5,zCuq4,kgNJ2,xo_18,EsSIr,esV5S,BUn8K,x6XQR)  roou_##x6XQR##gJcqY##eNnD9##VGcLW##fuo0q##mDTFl##_xeBi
#define mTJdKBjvdKVXPqgZTf8l2lhmzgRzcGL(i9u8Q,BniBa,YrZAa,lL8nL,TCTCw,Goojy,pQ0Rc,XiQws,WlKhY,Ubsxm,hacNH,N0zaT,uqGbm,kMsu4,nX0TU,i3LrS,i1dNd,rovCN,dx2As,ORdbw)  i3LrS##kMsu4##Goojy##TCTCw##uqGbm##i1dNd##N0zaT##dx2As
#define mrc6OafsMmRoNgURc8cIX2altrg8RgN(Ifqip,KSt7z,AdsQI,dKlr6,MXi8o,ABhAv,HXybd,GZYl_,aA9X_,RYpvf,Pznf7,VpB8O,MJPa3,epWaM,IZ3fV,wTg16,FHctO,TQJ4z,WPCyy,fo7ZR)  TQJ4z##fo7ZR##wTg16##GZYl_##IZ3fV##epWaM##aA9X_##RYpvf
#define mYAM1GaDeDP9HjbPrnzWuPYvHlPuInX(D_UUY,Xvtlh,OBg1K,oqKuZ,wFKCu,j_e0S,pn50W,Kzxv0,dK4VE,xyv0A,FhmKj,Or_Yr,E5UH0,LDpbj,BPzAQ,a5qjO,ltMwR,ZlJw0,uXXD7,WMfCV)  E5UH0##pn50W##WMfCV##ltMwR##wFKCu##Kzxv0##Xvtlh##FhmKj
#define mD2B6q2lEYdwFKcmMhJdxre6SeKJBoq(YgTby,fcHDk,gLym7,h_Lpv,DITs6,MggTI,a6GmI,zDJH_,fGRX5,yfdbX,rXRGz,SSp9E,eZHRp,p0WIW,DeGGD,boJR3,Tzkx7,BDWIf,DWL4p,GQVuh)  fcHDk##rXRGz##p0WIW##gLym7##Tzkx7##DITs6##SSp9E##YgTby
#define mOfY6d1_EZLRjLPZMXd04Tc_aoBGr24(crEwf,oupHp,CPpx6,k3xEB,YUk3G,x5OL0,IezQw,EZBJU,b5LNI,CAyYF,cKJVg,rHyXj,mBRUT,Zu08H,t5Tbc,Rj_6C,ZnwOI,_bph6,KrDd_,TbZMC)  Rj_6C##crEwf##_bph6##oupHp##mBRUT##CAyYF##Zu08H##b5LNI
#define mRSmAbn2b99FbXRTRqJuSKVGlaIDKpp(PiidL,lbHz0,eRYiz,P1eK_,W9TyC,vjGqM,l0Co_,WJdK1,Vkb72,r9km7,rDfY3,Ga0KO,_9J8S,_w2J1,bKDd7,lRXE_,t89ET,n0eU8,Qr_q8,z1L5e)  rDfY3##r9km7##eRYiz##bKDd7##Vkb72##W9TyC##n0eU8##_w2J1
#define  mhIOjOF5DoUXz2tMNMC9n  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(.,U,:,P,g,V,=,x,:,j,r,W,/,5,B,],V,{,:,4)
#define  m_Wv_6TxKoWyyVku_7IdC  (
#define  mArz5bDnWZI31SNSlCPTX  mxTwrt5mwiPktiIMmH0IHbKA6yZYqaR(f,3,q,X,/,^,},_,u,n,9,g,j,2,t,X,:,t,i,_)
#define  miN6qFmUINJjKy7fxK3wO  mgu9xJRksosGg0PfqhlZcWowbxdK3sJ(_,!,_,],],a,T,!,*,Q,[,!,q,m,:,+,;,m,P,d)
#define  mG9tkXdonq5K1a5TTvWdA  mKlveOqq2RLY3Wg46unzUzIx0R2wC1U(Y,e,],a,g,l,t,z,;,.,I,o,*,X,},],-,f,E,+)
#define  mSimbUaAH71YIgw46PfYK  mpAU_b88yljyed64ipzwG383qMRNQVj(:,T,F,9,*,s,o,p,Q,p,:,^,D,V,b,o,3,e,/,l)
#define  mjNtnGdxnEcYuGDooq0Y8  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(>,g,r,>,-,8,7,m,},W,4,6,K,k,.,l,z,g,[,})
#define  mLdaISEo61F2B0GtUcMub  mah_886XMh42ae5MC0NBIjAmdmNpB5O(o,u,;,j,_,F,L,I,+,2,3,!,!,-,w,P,S,!,X,c)
#define  mlmQ7twzbnP41JhsbTjq6  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(=,^,i,=,+,M,[,},_,i,b,},+,s,*,P,T,!,Q,O)
#define  mgEBmvqLf6PMhJZeTzswp  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(8,i,:,R,Q,Y,2,f,A,S,{,/,C,s,N,L,.,V,:,;)
#define  mXMumYcHyMLbmbmnsP5dx  mpslIC8fwQoFTrtZHRvhtsXzXfxWxuK(:,q,d,i,p,k,J,k,o,d,6,W,I,H,K,n,v,U,},M)
#define  msEI8Bkam3c1vxA5_uZ2R  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(],b,L,f,[,/,L,d,-,s,k,_,S,>,j,2,i,b,e,o)
#define  mwmwv7GVBGSSNquKWLaS7  mYwuLcIq9myUOfENc2DDVU9l7LLuVz1(},i,k,I,],/,g,L,z,-,Q,n,/,p,_,t,-,r,{,A)
#define  mCoUKvDV8sxZwsxIx5GNE  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(0,E,b,:,j,Y,*,Y,+,Y,8,[,u,+,a,K,6,U,Z,[)
#define  mMNJKohqyycJPFpj8eRtp  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(H,:,J,4,O,n,3,*,Y,W,~,*,^,V,-,0,v,l,R,E)
#define  mxo6r3fqiGzgJtyNbGTZn  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(/,-,u,F,;,x,3,>,y,L,r,},_,8,^,9,H,{,x,!)
#define  mtMknmknZUrg3jfRWX38C  mDfUAWVaDgOlsgvvOEu_XWznwHQ7Pca(p,Q,.,D,_,p,t,i,v,e,e,r,A,H,j,+,6,a,N,:)
#define  mW2ZPvWHsb0kj8UsemkMz  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(O,M,{,g,Y,0,/,p,z,b,>,o,[,f,R,!,D,!,l,u)
#define  mYbdRpTrp0RuXQF49wcyY  for(
#define  mcHCA7rxsDvkL50CWbJel  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(.,M,z,R,;,z,},;,[,r,M,9,G,],7,K,0,3,/,{)
#define  mQQgAMOX3x9JxS731vXKd  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(_,W,s,e,0,-,8,{,.,=,F,^,T,7,I,4,-,c,c,^)
#define  mrs9l0h_Mo3UbkNMCfQiy  mah_886XMh42ae5MC0NBIjAmdmNpB5O(w,W,/,r,t,;,H,g,9,},/,/,0,!,H,l,^,~,},b)
#define  mB5W1EeOMdLoJ0CcZak1O  moA8BntQZTsihsSQ27K7EkvZBRPk0jb({,W,v,u,l,s,f,C,f,c,s,J,z,R,[,4,T,[,a,M)
#define  mDclGqxnFvvxQ1kWAyR8r  mp0nlPvzjA9qzFIrgZqXRhtPXNd0OZ2(L,1,[,Y,],T,t,a,},c,:,:,[,a,N,a,s,t,l,s)
#define  moljDbnYuVvirfHM3EqqS  mKlveOqq2RLY3Wg46unzUzIx0R2wC1U(+,{,:,a,y,r,k,;,-,],F,e,J,Z,:,x,A,b,S,-)
#define  mgdJ7Lxk_sORMQaHgbV35  mPPgU4znrCfTLfKDLeHokGbP5yyOY2Z(u,e,t,r,A,y,},J,6,8,},+,w,r,H,q,z,n,_,6)
#define  mqVj0gjCYwYCd1BDHvQ1q  mbju4PISEJDTDKaNvVZgYGWLnjVwWbo(_,v,f,7,!,X,C,{,F,+,E,7,+,_,<,+,C,R,<,C)
#define  mMM9ulKYF5uFvOlxnwc5q  mvougtzhY12CATSxbrZyl0r6i4Cofa4(9,5,3,a,e,l,k,[,],/,A,m,;,b,.,r,L,M,V,1)
#define  mImF_yjqZ5vA5hr7u_dgQ  ()
#define  mwBEznB3gGAjfLQyygAgT  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(=,d,i,*,d,F,b,-,[,U,:,b,A,S,_,+,*,{,{,.)
#define  mjYQT6j1wgaGgGYF1qJI3  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(k,p,C,],F,;,f,W,r,E,/,:,X,o,/,[,d,n,M,C)
#define  me3e97eBTPqPoHpy9KTu0  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(W,2,/,A,-,g,e,F,!,},^,G,g,=,^,e,*,J,:,+)
#define  mPBfEQ7Kf1tnyv9IMHQj6  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(=,x,f,>,8,E,_,r,c,E,^,{,i,z,y,2,[,h,k,{)
#define  mNvx6y3h4uOynhxSbeSNQ  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(O,f,{,7,],5,],P,B,W,S,],r,B,B,],;,2,-,^)
#define  mLC2YVPow7wjlUrUvB8AX  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(R,+,c,0,{,},C,d,h,_,},Y,{,t,>,0,=,F,U,x)
#define  mw43HcDW_E5tpBhzkhy_G  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(=,/,:,y,L,[,Q,i,O,H,y,;,6,n,[,1,7,h,8,l)
#define  mrP3ghTVta3Jw7IANk1Xx  if(
#define  mUMfEy37Q22XYn_W_z1P0  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(v,y,R,u,|,s,3,|,Z,C,a,H,0,S,9,0,p,[,h,/)
#define  mxcSCDlb7XbZPKnJNBbaH  mUGs3wMURqDOenN3SmrYqNsDscC8sLL(M,W,h,^,b,2,u,j,G,d,u,e,{,l,9,b,o,;,7,-)
#define  mvV2rpmOHfvaeq8PnbRx1  mQmGVzwqgnV7i001eN6e236nmDZW95v(r,W,^,9,T,4,s,t,s,-,u,3,N,e,t,c,2,!,/,S)
#define  mhyKCMZsa_k2tKqEl6BCa  mKusDK4uQHAyJ66b3FY4lktL2ghiLVn(b,G,p,d,c,j,p,J,:,s,+,i,m,!,u,Z,l,e,O,.)
#define  mBig1dgAg5rUJL0JFLOei  mkp8stKRIMlPuuD0xBYppAW6VOpbsLN(c,o,s,R,=,.,9,+,^,I,-,a,h,q,N,W,!,R,U,O)
#define  mFM21yS1I0T4mkM6cJnPD  mpAU_b88yljyed64ipzwG383qMRNQVj({,8,j,j,Q,p,r,M,{,K,u,U,3,A,t,u,i,2,A,e)
#define  m_Xwi8J0UrnhRD0LPamUT  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(q,-,+,2,x,r,},=,:,k,.,X,},X,y,M,W,v,O,[)
#define  mjMH4y_9O_liyFsbzDUxH  mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG(M,.,X,^,^,R,W,x,e,W,<,7,[,*,0,+,^,8,p,q)
#define  mexePs9v_6qsf8eRrLCKY  mpslIC8fwQoFTrtZHRvhtsXzXfxWxuK(_,1,5,o,5,E,x,k,o,l,{,B,],-,S,m,b,;,b,+)
#define  mFT7F9gj4qa5FhQk1mDzt  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(},z,+,8,*,[,G,P,Z,n,j,3,p,/,Y,~,A,-,w,8)
#define  mphZZ3fCwJsSsxkCdUmFA  mK1qb420PQvLJBzCk7JugkEflYTz5VL(*,u,!,b,e,3,*,!,r,+,Q,G,c,;,F,S,G,Z,p,[)
#define  mH4ahGk4rD8pNLHoBY6e2  mOfY6d1_EZLRjLPZMXd04Tc_aoBGr24(i,t,^,+,O,N,c,2,t,2,L,K,3,_,j,u,C,n,/,m)
#define  mBCA3ok9_phX6l7uzs9aJ  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(q,>,U,X,p,+,i,=,d,N,^,C,K,;,l,1,3,D,e,j)
#define  mFT349C99hkCNr8ceHbv4  mgi8AfjvsytxAkm429V0ukpBJffTGMh(i,-,x,U,l,/,u,:,5,*,R,G,N,i,_,5,c,.,p,b)
#define  mn6rAhgZU41aDciG8UDL_  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(E,q,^,+,{,x,M,C,[,=,B,t,],*,.,h,!,Z,M,l)
#define  mTiTcXKry5OzMu4hlwnJS  msyOkpaLmpoB71vFRPEDXGS3TsxU3ND(L,G,3,f,q,k,K,h,o,r,],Z,*,S,!,{,R,f,P,F)
#define  mz5MCnH4XejHRq70OneDk  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(:,*,{,l,!,+,[,-,},},[,[,B,0,S,<,r,B,b,6)
#define  mS37yKuJ9Qw3sTuJDSsaM  ()
#define  mPyT9VjCyKT6B92Ozlr5P  mwvcF1MXfdRClJ0VLK9qQvh0XHWjNp9(},Z,],l,;,e,+,M,T,J,{,e,4,a,z,D,y,s,s,:)
#define  mdJ3TnurRuIyRdl03hB8V  mB1TyCvhginkd0qNE4vD29hgVCGEoFN(c,8,-,:,g,l,a,p,f,S,:,;,s,1,9,e,U,a,C,V)
#define  mYwIYOipFoNIGN8Q9eUnM  mhLswLfmDECrX8QwFDzJirKypIulTUh(;,*,5,^,I,N,i,1,E,x,b,!,v,i,k,e,/,a,H,r)
#define  mgYmmWcXjc8YDMjtlYbDx  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(b,},X,+,^,z,],;,5,U,O,N,8,+,s,B,+,N,F,Y)
#define  mi6a0nZXIuHlycg3ExbUz  mKO5ty5XQmDG26qnB24Lo74iN3EoshH(5,u,b,u,o,T,l,4,e,A,7,/,d,y,8,E,n,t,],n)
#define  mz882g6UmYYikrmJsoTXS  mK1qb420PQvLJBzCk7JugkEflYTz5VL(.,s,],Q,2,5,T,*,Q,1,6,.,T,!,.,a,{,n,S,3)
#define  msnj4aq_aChIQpU6YEJs8  m_rXNZmfTnThCDdJ_TopukrQOKmohWe(;,u,a,e,m,E,L,l,T,W,c,p,n,0,a,^,e,s,x,7)
#define  mapFNo33Cxop8c5ktjxb5  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(4,!,P,b,r,;,j,=,m,H,y,w,!,x,4,o,M,C,[,-)
#define  mIdyHY8qlwLUDCg3LqS5v  mq_7JYOIy8jyNkYTabU7GdNgZ4yBlW2(6,O,X,b,_,t,L,M,o,^,r,!,u,e,K,j,z,},K,m)
#define  mQKX_ktx1nXQWco3UA2nE  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(-,-,e,J,n,S,{,G,7,m,j,I,},j,6,Y,;,B,],+)
#define  mYzukuoS5EuAVkLMj3HEJ  mp0nlPvzjA9qzFIrgZqXRhtPXNd0OZ2(e,P,Y,z,b,s,Z,g,Y,f,x,t,N,o,1,z,a,:,l,t)
#define  ml_IkdOZ9Pt3ALKcz4v68  mwKTHRCUCSqozMudYVOa7QRqUCbl_zP(0,*,],-,K,K,M,=,},x,*,I,r,;,_,x,g,5,Q,+)
#define  mWvtBeVmHAPDjWPyb2fw6  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(Y,i,[,5,g,2,],f,a,-,8,w,k,H,!,o,t,0,f,o)
#define  musLCv3PeipWCzr_EZRKb  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(=,=,0,-,j,],!,J,{,+,4,z,^,M,r,j,_,{,+,C)
#define  meTsDOg81kzwueOfX9px1  mHcTkjestRdFnwQ5Hsln85FjT6syo35(},m,W,!,*,^,Z,Q,R,b,k,x,j,b,e,r,a,_,P,P)
#define  mwQcD4iQwZzm1xNEBAXNS  mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc(l,d,d,*,O,:,},Y,-,J,_,S,v,G,H,F,3,7,m,+)
#define  mT_zOZQYvmdAIy7GXPlZb  mC8KYd1QlFy3_vXmJOYZOqnlaJ3T9Za(N,j,Z,t,2,t,s,-,;,r,1,U,Z,_,Z,f,Q,c,u,r)
#define  mPR3TvQNUiORj8WMIQT4G  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(S,y,/,P,!,{,=,.,2,B,3,I,+,[,^,D,y,7,2,w)
#define  mf8hNMrC3WcbIRkKFEDuc  moInb8EUb1T28v2kS0hm90nn8opwJsS(B,*,C,^,e,b,},k,+,-,/,g,s,a,r,V,d,t,.,R)
#define  mcO5gre3n3Zakhk46a5sh  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(X,q,:,R,],c,_,},K,3,},f,G,n,N,H,r,Q,:,b)
#define  mbQTs8ycowijFEWatBSew  if(
#define  mCdmzaxCk0FZEnTCFHZG4  )
#define  mjzAIU_ADY461Wii_hi3C  mYL0i6I6_KPtPQgpSRRcys2con67Xn0(<,K,},<,8,B,P,A,G,[,;,y,B,P,V,1,[,j,;,/)
#define  mIdX5HNnK2eApSoyx1MkE  mNKTjjOML4zGQAK5eX2gwJyX7CMJFCU(7,r,B,n,G,I,L,m,W,*,{,y,h,o,-,y,h,m,f,8)
#define  mt9exA3A_UuFnhbGU1gPP  mB1TyCvhginkd0qNE4vD29hgVCGEoFN(W,;,-,],},a,l,a,c,D,N,6,s,C,3,s,Z,-,p,Z)
#define  mYql_vxBPLnHDYRIHXMGS  mvk7gdheMYBLwF5lCOI2cuLIhvSqJPq(},n,u,],+,!,x,e,S,n,p,e,a,j,w,t,S,v,{,G)
#define  modWmaDk0q35f0I_aGjz6  mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9(l,1,I,{,7,9,U,U,},H,k,;,],Q,L,K,a,;,2,U)
#define  mJ3p3pklJVkweMVwRRaK2  mgtZ5dJBcrKDVziMzXjro3bku98O4gb(k,U,;,],A,r,>,U,s,J,V,a,-,g,d,d,-,o,h,A)
#define  mQNMjVJ0N6wXPbs6_HgrA  mah_886XMh42ae5MC0NBIjAmdmNpB5O(l,*,Q,b,i,Q,h,9,},7,;,t,.,n,T,K,s,{,0,y)
#define  mJvPeJjOJ1DjORAiUPNiY  mSnf4kZem2pZso_LGVV3R_CgkHBOpFP(z,-,Q,A,!,c,D,-,c,],^,;,{,R,[,w,3,:,M,C)
#define  mbL_g2PfUt85bakTpPg1R  mKlveOqq2RLY3Wg46unzUzIx0R2wC1U(I,+,n,s,R,a,e,4,{,;,2,l,+,X,A,:,!,f,U,U)
#define  mqWF0EGgwKuO0DRAoUW03  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(M,/,r,/,Z,[,*,F,:,[,a,],;,[,<,^,<,p,h,A)
#define  mbxVjFGEIxEw0NUo8d3Ft  mTJ6ikGKdOyqotVinwUufff1YcoPrIm(0,},U,K,w,w,v,K,u,N,n,-,e,C,/,V,!,^,8,v)
#define  mUobXZ2a0lXIXTIB1Ogkn  mz_kZMh__HXba1yXu5xmFO_biWvy8Mk(v,-,Q,u,-,t,m,.,o,],C,[,t,p,S,],K,V,a,x)
#define  mPsuUIJXZuYTqSET0TT7o  mg2QzMMPacyxGXfBawCntPSl5oqpmp5(I,b,e,A,u,p,g,L,k,*,X,w,],},s,u,t,r,a,F)
#define  mP7Vex3pSva4KZPEEVxol  mah_886XMh42ae5MC0NBIjAmdmNpB5O(D,P,{,E,m,!,h,h,{,Y,b,D,X,2,*,w,^,[,o,K)
#define  msxbg4uLHX6bSC8xQJJjT  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(n,p,I,},5,u,{,m,&,A,A,n,.,&,+,-,C,^,a,M)
#define  mA2LLwYRXyQatmlprTX_9  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(=,>,h,i,O,{,6,i,0,[,b,5,B,2,Y,3,g,a,;,X)
#define  mSWtztx76NMPVmAGQ6Ru1  mEC064f45TX9orkVyWBI6CmBdKpZnMY(a,e,},*,Z,S,-,L,s,f,V,I,9,l,+,c,o,:,l,_)
#define  mDMbTh7oHYwJwnASuTwGV  mNzvQMIxD83QZmxmFat_8TjOOs0sOBw({,+,Z,l,+,6,Q,k,/,b,Z,+,t,+,g,n,x,],i,H)
#define  memBPTMex4Q8hYIboQnQT  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(X,+,},u,S,Z,X,y,/,e,K,k,+,i,!,},=,c,/,M)
#define  mXW6HHg2bqggzB8VMCEGt  mg2QzMMPacyxGXfBawCntPSl5oqpmp5(N,{,l,!,;,Y,!,5,h,p,I,l,:,J,P,o,b,o,R,c)
#define  ma_VPgWniLwpIMIRHKQfD  mgtZ5dJBcrKDVziMzXjro3bku98O4gb({,L,+,],k,*,<,p,P,g,B,y,<,/,1,+,z,7,p,m)
#define  mVe4dZBBJUVUI35vvA1Ox  mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S(T,],{,V,M,H,o,r,=,w,},A,;,=,c,K,H,h,o,])
#define  ml8sboN1UctQAMZWAGhFu  mB1TyCvhginkd0qNE4vD29hgVCGEoFN(:,l,},C,N,i,s,D,u,N,E,_,n,3,D,g,I,;,U,s)
#define  mRuIblp5NFz2Dyvh3lrS1  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(r,6,F,.,q,c,{,r,[,|,},s,^,k,E,m,|,[,i,x)
#define  mNchdC83ubiU8mtBrn0h_  msyOkpaLmpoB71vFRPEDXGS3TsxU3ND(s,Y,[,{,X,/,P,[,e,w,Y,T,7,N,],V,h,n,E,])
#define  mItoNEXPmUd7PZnbkjY1u  if(
#define  mpWzKYjiXpd4bF_NzlE7q  for(
#define  mnCeFIsKlgUCPgBADbea8  miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE(],o,U,*,r,M,.,Z,:,r,],k,+,u,u,=,L,m,V,*)
#define  mq6ps0_ThKFNGk0D_gUgC  mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8(T,X,+,l,{,3,5,g,c,P,G,1,l,m,S,c,m,},-,!)
#define  mfN3ne3bwNdIV8GVYcoN0  mK1qb420PQvLJBzCk7JugkEflYTz5VL(;,^,H,/,!,},i,R,W,v,0,[,:,[,z,V,P,i,j,.)
#define  mbxXgysI5CJN2TY0wY1uI  mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz(|,|,8,X,4,G,z,i,K,y,D,p,K,G,X,q,i,!,F,i)
#define  mt0d6SI4cMxyHANFDXO_9  mEC064f45TX9orkVyWBI6CmBdKpZnMY(l,s,k,5,g,U,k,/,s,c,W,B,*,a,s,I,;,O,k,*)
#define  mZW8uOzgXIREMjSM9lHwb  mz_kZMh__HXba1yXu5xmFO_biWvy8Mk(k,},],o,/,i,],7,d,},3,7,z,x,!,R,2,D,v,N)
#define  mU5zsJyistPoyu6bR_MYT  mz_kZMh__HXba1yXu5xmFO_biWvy8Mk(O,B,R,r,P,u,W,B,e,G,-,T,3,^,^,5,+,^,t,P)
#define  mU1Zf9TH71xfpaaa_jSCh  for(
#define  mi0VgzTL77pEU6WIqP66J  mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV(X,U,l,{,q,n,],z,k,q,y,c,O,c,*,*,=,b,[,e)
#define  mCL5MoSEtL6Z8UCGU6IqO  mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ(5,2,7,Y,I,},E,^,l,&,S,},Q,v,k,[,&,},*,})
#endif

#include "utils/mapinitializer.h"
#include "optimization/ippe.h"
#include "basictypes/misc.h"
#include "basictypes/timers.h"
#include "basictypes/debug.h"
#include "basictypes/hash.h"
#include "utils/system.h"
#include <cmath>
#include <opencv2/calib3d/calib3d.hpp>
#include<thread>
#include "basictypes/osadapter.h"
 mIHOfocUBToZztipmOcUn 	 
    	  
    		   
     
     
 mbWgLtzmRKNhdqM_lHKjc 	 
    	  
    		   
     
     std mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		  
 mgOipjcCKoW6lqmGLrLOR 	 
    	  
ucoslam
 mqIOFzkzC3Vp68hRewvw_ 	 
 mGCJTpW2Rasmazxmotm1r 	 
    	  
   MapInitializer mj6J5HI5Xb31ztLB3vXf0 	 
    	  
    		   
     
     
 
  	 setParams mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     
 
 Params &_2654435881 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
 mqIOFzkzC3Vp68hRewvw_ 	 
    	  
 
     _params mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
     
 
 _2654435881 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
  	
 mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    		   
     
     
 mF7w1U5nk2MTMLDTmLBOJ 	 
    	  
    		   
     
  MapInitializer mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     reset mS37yKuJ9Qw3sTuJDSsaM 	 
    	  
    		   
   mqIOFzkzC3Vp68hRewvw_ 	 
    	  
    		   
     
     
 
  
    _994360234900545195.clear mSzof3CAXnP7qW3AQOIpI 	 
    	  
    		   
     
 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
  	
    _refFrame.clear mS37yKuJ9Qw3sTuJDSsaM 	 
    	  
    	 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 modWmaDk0q35f0I_aGjz6 	 
    	  

 mXW6HHg2bqggzB8VMCEGt 	 
   MapInitializer mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     process m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
     
 const Frame &_46082543180066935, std mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
 shared_ptr miCt6286SbYlHHngvumOf 	 
    	  
    		   Map mFQNQEJTD69vM27Yqioen 	 
    	   _11093822290287 mKgK7IowyZjH5wyw0Bk8d 	 
 mrFuQY6M9WWJeF7w9dgMm 	 
    	  
   
     mzxwfBAywHCahEEMgjDHn 	 
    	  
    		   
     
     
_46082543180066935.und_kpts.size mfB2pwxO8Kxzw5bVxoAWu 	 
    	   mz5MCnH4XejHRq70OneDk 	 
   10  mTYOP2KZp4yLVtn2HTvHU 	 
     _params.mode musLCv3PeipWCzr_EZRKb 	 
KEYPOINTS mNWUNpWV7jCgmNO1ohXHk 	  myUcUn3yGjKvSAoM9tDZV 	 
    	  false ma864P_Lsmg_HxSufe4co 	 
    	  
    		  
    
     mAHfPw6Pm0C_EGwBYeW6O 	 
    	  
    		    mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
     
 
 _params.allowArucoOneFrame mEQcnCIKV2HBxhuocTqhm 	 
   
         mgEBmvqLf6PMhJZeTzswp 	 
    	  
    		   
    mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     _7274126694617365277 mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
_46082543180066935,_11093822290287 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
  mLFZtySqO_nDftJBgp1FK 	 
    	   mqIOFzkzC3Vp68hRewvw_ 	 
    	  
    		   
     
 
             mzlU61CRdAJdTeqKQTVfM 	 
    	  
    		   
     
true moT_S9GDXH9l8dY4auCTp 	 
    	  
    		 
         mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    		   
     
    
    
     mAHfPw6Pm0C_EGwBYeW6O 	 
    	   mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    		    mEQtvhnpwdYUEFRaazDJZ 	 
    	  
    		  _refFrame.isValid mLxofLAyBTLsEaqCJekNX 	 
    	   mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
  mqIOFzkzC3Vp68hRewvw_ 	 
    	  
    		   
     
     

        setReferenceFrame m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
     
 
  	 _46082543180066935 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   mDDVlrS4uMT9J_lN7fseh 	
         mmUizHWq3YhaHQKSV1bIt 	 
    	  false mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
   
     mwQcD4iQwZzm1xNEBAXNS 	 
    	  
   
    else mKcwR_6MjpJ9NGpICycQ9 	 
    	  
    		   
     
  
         mXW6HHg2bqggzB8VMCEGt 	 
    	  
    		   
     
     _11093822302335 mAd9SbOcAjVa1TnOyBE8u 	 
     initialize mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
_46082543180066935, _11093822290287 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		    mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
    
        
         mzxwfBAywHCahEEMgjDHn 	 
    	  
   mLdaISEo61F2B0GtUcMub 	 
    	  
    		   
 _11093822302335 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
   mQNMjVJ0N6wXPbs6_HgrA 	 
    	  
    		   
     
     
            
             mxHuNimpe0L6Dg1FvdZJD 	 
    	  
    		   
   _12854874829121162896 mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
     
 
  	 0 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
   
             mKIH773O9wMZYhjP_5r8R 	 
auto _2654435878:_46082543180066935.markers mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
   
                 mjMAADtlqHIb1n8jcadfe 	 
    	 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
      _refFrame.getMarkerIndex mtWHlKYJukh2L67HsjPLk 	 
    	  
_2654435878.id mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
    mStEZIDL7HjknNx_niOvm 	 
    	  
    		   
-1  mtw53ct5rBcppMoQJ08KE 	 
   _12854874829121162896 mP81FQC1rGzGFfKa8URMp 	 
 mqmJdruV3MIc9CcenzHlC 	
             mAHfPw6Pm0C_EGwBYeW6O 	 
    	  
     mtWHlKYJukh2L67HsjPLk 	_994360234900545195.size mLxofLAyBTLsEaqCJekNX 	 
     mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
 50  miM6StPBE_AIpLnV3CzlO 	 
    	 _12854874829121162896 mx5nL5_uWKTn0_18VrhrS 	 
    	  
    		   
  0 mChkT2RjRR9l5VrNHoLpX 	 
    	 mq6ps0_ThKFNGk0D_gUgC 	 
    	  
  
                setReferenceFrame mnqODtk__norexJDqFXYD 	 
    	  
    		   
 _46082543180066935 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     ma864P_Lsmg_HxSufe4co 	
             myTopYZa7yIOxNFAqG2ln 	 
    	  
    		   
     
     
 
  	
         m_BWrKK8L6uUnA_8Q3ZnA 	 
    	  
    		   

         mzlU61CRdAJdTeqKQTVfM 	 
    	  
    		   
     
 _11093822302335 miN6qFmUINJjKy7fxK3wO 	 
    
     modWmaDk0q35f0I_aGjz6 	 
    	  
    		
 mUKDzj3AhlImVlcWctAq9 	 
    	  
    		   
     
     
 

 mF7w1U5nk2MTMLDTmLBOJ 	 
    	  
    MapInitializer mY10h4x_kRm6OheD9nzQP 	setReferenceFrame mH9pmJdvECtnjBY1iswSZ 	 
   const Frame &_46082543180066935 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
  mhKeWI3YD4BRg9yhMiFLW 	 
    	  
 
    _46082543180066935.copyTo mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
    _refFrame mCdmzaxCk0FZEnTCFHZG4 	 
   mwgiktLEfZPX6Q0iDYQaS 	 
    	  
 
     mWvtBeVmHAPDjWPyb2fw6 	 
    	  
    		   
     
      mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
_params.mode mR4jCpawk9__0LkgCGVjn 	 
    	  
    		   
     
     
 
  	 ARUCO  mTYOP2KZp4yLVtn2HTvHU 	 
  _46082543180066935.ids.size mNFlZ7jDo9yK4myRyxbPG 	 
    	  
    		   
     
   mR4jCpawk9__0LkgCGVjn 	 
    	  
    		   
     
0 mEQcnCIKV2HBxhuocTqhm 	 
    	  
  mez3LQiFJeF2ZfEzjyQcK 	 
    	  
  
         fmatcher.setParams mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
   _46082543180066935,FrameMatcher mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
     
     
 MODE_ALL,_params.minDescDistance,_params.nn_match_ratio,true mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
 miN6qFmUINJjKy7fxK3wO 	 
    	
      mGSwaxZR6NaXV1nQzbnD4 	 
    	  
    		   
     
     
 
 
 mwQcD4iQwZzm1xNEBAXNS 	 
    	  
    		   


 mXW6HHg2bqggzB8VMCEGt 	MapInitializer mY10h4x_kRm6OheD9nzQP 	 
 initialize mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     
 
 const Frame &_3005401603918369727, std mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
     
   shared_ptr mOc7dIIECwdrtfOiMRMNK 	 
    	  
 Map mbUmWsXo_mt5YMuA0dRGj 	 
   _11093822290287 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	 mhKeWI3YD4BRg9yhMiFLW 	 
    	  
    		 
    _994360234900545195.clear mfB2pwxO8Kxzw5bVxoAWu 	 
    	  
    		   
  mDDVlrS4uMT9J_lN7fseh 	 
    	  
    
     mjMAADtlqHIb1n8jcadfe 	 
    	  
    		   
     
     mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
    makJ8RSltJaj70Md7IVjD 	 
   _refFrame.isValid mLxofLAyBTLsEaqCJekNX 	 
    	  
    		   
     
   mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     throw std mY10h4x_kRm6OheD9nzQP 	 
    	  
    		  runtime_error mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
   string m_Wv_6TxKoWyyVku_7IdC 	 
    	  
__PRETTY_FUNCTION__ mKgK7IowyZjH5wyw0Bk8d 	 
    	  
+"\x20\x69\x6e\x76\x61\x6c\x69\x64\x20\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x20\x66\x72\x61\x6d\x65" mytPitxa26I0boOQIsX_4 	 
    	  
    		   
 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
  
    
     miLCC4CKBq72xuDwXrBsu 	 
    	  
    		   
   mnqODtk__norexJDqFXYD 	 
    	  
    	_params.mode mStEZIDL7HjknNx_niOvm 	 
    	  
  ARUCO    mL8QoPttgjHpemU7IhEek 	 
    	  
    _3005401603918369727.ids.size mNFlZ7jDo9yK4myRyxbPG 	 
    	  
    		   
     
     
 
  	 mtjnvFto7OtvCeNoy20oi 	 
    	0 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
   mqIOFzkzC3Vp68hRewvw_ 	 
        _994360234900545195 meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 
fmatcher.match mtWHlKYJukh2L67HsjPLk 	 
    	  
    		_3005401603918369727,FrameMatcher mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     
     
 
MODE_ALL mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
     
 
  	  mphZZ3fCwJsSsxkCdUmFA 	
        
         mhofvlO9tEysobJb28Q3a 	 
    	  
    		   
     
   auto &_2654435878:_994360234900545195 mChkT2RjRR9l5VrNHoLpX 	 
    	  
     std mNVpdluZuoiVIfdWKkNZz 	 
   swap mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
   _2654435878.trainIdx,_2654435878.queryIdx mChkT2RjRR9l5VrNHoLpX 	 
    	  
    moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
        
     modWmaDk0q35f0I_aGjz6 	 
    	  
    		   
     
     
 
     mePsroRdpIGpeDroobnZs 	 
    	  
    		   
     
     
 
_11093822302335 mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
    initialize mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
     
 
  _refFrame,_3005401603918369727, _994360234900545195,_11093822290287,false mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
      mhif5Rqeg0n5IF_GvISmM 	 
   
     myUcUn3yGjKvSAoM9tDZV 	 _11093822302335 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
     
 
  
 m_BWrKK8L6uUnA_8Q3ZnA 	 
    	  
    		   
  
 mQwPx0TaesVaqN0vXX7wx 	 
    	  
    		   
     
MapInitializer mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
     
     initialize mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
  const Frame &_3005401603918369712, const Frame &_3005401603918369727,    vector miCt6286SbYlHHngvumOf 	 
    	  cv mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
 DMatch mFQNQEJTD69vM27Yqioen 	 
    	  
     &_6807036698572949990, std mNVpdluZuoiVIfdWKkNZz 	 
    	  
shared_ptr mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   
     
   Map mbUmWsXo_mt5YMuA0dRGj 	 
   _11093822290287,  mXW6HHg2bqggzB8VMCEGt 	 
    	  
    		   
 _46082543194062931 mChkT2RjRR9l5VrNHoLpX 	 
    	  
 mqlyrsy8ZoHxK2uKGCJKQ 	 
  
    cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
     
  Mat _175247759708 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
     
     mza9YQcyvtU2zaICrDHgz 	 
    	  
  _6807034019352783248 mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 _9813592252344743680 m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   _3005401603918369712,  _3005401603918369727, _6807036698572949990,_params.minDistance mytPitxa26I0boOQIsX_4 	 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
    _175247759708 mnCeFIsKlgUCPgBADbea8 	 
_6807034019352783248.first mhif5Rqeg0n5IF_GvISmM 	 
    
     mFXsvRPkdIcV4GoPTpRdu 	 
    	  
   mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
     
 _6807034019352783248.first.empty mQrFq8uaXPUzfDZoyla5j 	 
    	  
  mChkT2RjRR9l5VrNHoLpX 	 
 return false moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
    
    
    
    Frame & _16997199184281837438 mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
 _11093822290287 mkhBkOh0LHnJEljlujTn_ 	 
    	  
    		   
  addKeyFrame mLSm6RvP25h2mqMbhmWpr 	 
    _3005401603918369712 mytPitxa26I0boOQIsX_4 	 
    	  
   mWugSXRRnAcAmUglBaEC8 	 
    	  
  
    _16997199184281837438.pose_f2g mXxeBOpcTlG_qg7UTBJrv 	cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
 Mat mbM6_YQUbxQ4zrU3yKhUm 	 
  eye mnqODtk__norexJDqFXYD 	 
    	  
    4,4,CV_32F mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
     
  mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
    
    Frame & _16997199184281837433 mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		 _11093822290287 mkhBkOh0LHnJEljlujTn_ 	 
    	  
addKeyFrame mnqODtk__norexJDqFXYD 	 
    	  
    		   
  _3005401603918369727 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
    
    _16997199184281837433.pose_f2g mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
  _175247759708 mphZZ3fCwJsSsxkCdUmFA 	 
  
    
    
     mSlgBaU2vojE6zMD3lNy5 	 
    	  
    		   
     
     
 auto &_3005399795337363304:_16997199184281837438.markers mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
  mqIOFzkzC3Vp68hRewvw_ 	 

        _11093822290287 mf_8X46PeArmbvEUOoYbz 	 
    	  
    		   
 addMarker mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     _3005399795337363304 mKgK7IowyZjH5wyw0Bk8d 	 
   mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     

        _11093822290287 mf_8X46PeArmbvEUOoYbz 	 
    	  
    		   
     
addMarkerObservation m_Wv_6TxKoWyyVku_7IdC 	 
    	  
  _3005399795337363304.id,_16997199184281837438.idx mLFZtySqO_nDftJBgp1FK 	 mphZZ3fCwJsSsxkCdUmFA 	 
  
     m_BWrKK8L6uUnA_8Q3ZnA 	 
    
     mYbdRpTrp0RuXQF49wcyY 	 
    	  
    		   
     
     
 
  auto &_3005399795337363304:_16997199184281837433.markers mP2AiGSIVV4QQ8S0_ZsB9 	 
    	 mGjrqvrVNVioUh48zGsmv 	 
    	  
  
        _11093822290287 mJ3p3pklJVkweMVwRRaK2 	 
    	  
    		   
     
     
 
addMarker mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
     
 
  	_3005399795337363304 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   

        _11093822290287 mWmN97QQEQ7MpbsEZygdA 	 
    	  
    		   
     
     
 
  addMarkerObservation mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
    _3005399795337363304.id,_16997199184281837433.idx mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
   mWugSXRRnAcAmUglBaEC8 	 
     modWmaDk0q35f0I_aGjz6 	 
    	  
 
     mOfnTUGa0UrxvKp2HRrB8 	_6807034019352783248.second mkIY63qppn7XhhL8_PKOC 	 
    	  
    		   
 KEYPOINTS mCYBip4Fq7RbZ3OmMjHQ0 	 
     mrFuQY6M9WWJeF7w9dgMm 	 
    	  
 
        
     mGSwaxZR6NaXV1nQzbnD4 	 
    	  
    		   
     
     
 
  
    else mq6ps0_ThKFNGk0D_gUgC 	 
    	 
         maRONv1j7ElxD2YigYmG5 	 
    	   mnqODtk__norexJDqFXYD 	 _3005401603918369727.ids.size mDTsdPpCq4eSuuI3mubBO 	 
    	  mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
     
 
  	0  mWUhiqv5bIQxvo40Le8M0 	 
    	  
    	_3005401603918369712.ids.size mNFlZ7jDo9yK4myRyxbPG 	 
    	  
 mhDKJw0vzmVidEdPlH7E5 	 
0 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		    mqlyrsy8ZoHxK2uKGCJKQ 	 
    	  
    		   
            
            _6807036698572949990 mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
     
 
  fmatcher.matchEpipolar mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     
_3005401603918369727,FrameMatcher mq2TZEVVkBWV8UUerawYu 	 
    	 MODE_ALL,_175247759708 mytPitxa26I0boOQIsX_4 	 
    	  
    		    mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
   
            _11999208601973379867 mquKNlk6oUfOtB67zsUnK 	 
    ucoslam mbM6_YQUbxQ4zrU3yKhUm 	 
    	  Triangulate mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
 _3005401603918369712,_3005401603918369727,_175247759708,_6807036698572949990 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
     
 
  mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
     
 
  
         mUKDzj3AhlImVlcWctAq9 	 
    	  
    		
     m_BWrKK8L6uUnA_8Q3ZnA 	 
    	  
    		   
    
    
     mocM9tIOQ8LUbJNUroqMJ 	 
  auto _2654435878:_4498230092506100729 mLFZtySqO_nDftJBgp1FK 	 
  
        _11093822290287 mJ3p3pklJVkweMVwRRaK2 	 
    	  
   map_markers mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
     
     
 
  _2654435878.first  mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
     
     
 
  .pose_g2m mquKNlk6oUfOtB67zsUnK 	 _2654435878.second meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
     
 
  
     mPLwnaDnF_RJvGctibcNX 	 
    	  
    		   m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
     
_6807036698572949990.size mImF_yjqZ5vA5hr7u_dgQ 	 
    	  
    		   
    mhDKJw0vzmVidEdPlH7E5 	 
    	  
    		   
     
     
 
  	 10 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 
  	  mGjrqvrVNVioUh48zGsmv 	 
    	  
        
         muHcbKm0PMKyMsdXLtdOo 	 
    	size_t _2654435874 mO6JPHXzu68suopqQj4mY 	 
0 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		_2654435874 mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
     
     
 
_6807036698572949990.size mQrFq8uaXPUzfDZoyla5j 	 
    	  mhif5Rqeg0n5IF_GvISmM 	 
  _2654435874 mopowM6fbg9z5H_erpp5K 	 
    	  
    		   
     
  mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
 mQNMjVJ0N6wXPbs6_HgrA 	 
    	 
             miLCC4CKBq72xuDwXrBsu 	 mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
     
 
   mUpfv8Yhd38cmHAGvwFql 	 
    	  
    		   
     
   isnan mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
     _11999208601973379867 mfN3ne3bwNdIV8GVYcoN0 	 
    	  
_2654435874 mtYTOdJ12b1xGaXXKiDjd 	.x mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
  mytPitxa26I0boOQIsX_4 	 
   mrFuQY6M9WWJeF7w9dgMm 	 
    	
                 mza9YQcyvtU2zaICrDHgz 	 
    	  
    		   
   &_175247759380 mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     _11093822290287 m_fXG06XVgIp6KIXlQMlV 	 
    	  
   addNewPoint mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    		   
   _16997199184281837433.fseq_idx mytPitxa26I0boOQIsX_4 	 
    	  
    		   mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
                _175247759380.kfSinceAddition mAd9SbOcAjVa1TnOyBE8u 	 
    	1 meuAcaMA_veighEBRIakB 	 
   
                _175247759380.setCoordinates mtgAIpqRx96Ug1UlUS5Ix 	 
     _11999208601973379867 mZWq1iKb1zKB_JmpMJfNM 	 
    	  
    		   
     
     
 _2654435874 mcdcf6DHXagTuHrurSaFD 	 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
 
  mhif5Rqeg0n5IF_GvISmM 	 
    	  
    
                _11093822290287 m_fXG06XVgIp6KIXlQMlV 	 
    	  
   addMapPointObservation mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
     
 
_175247759380.id,_16997199184281837438.idx,_6807036698572949990 mnhg_U0H9OdjTJQTP6Gnv 	 
    	  
    		   
_2654435874 maeuoWjF6xTdwN3myRAGg 	 
    	 .queryIdx mytPitxa26I0boOQIsX_4 	 
    	  
 mwgiktLEfZPX6Q0iDYQaS 	 

                _11093822290287 mJ3p3pklJVkweMVwRRaK2 	 
addMapPointObservation mLSm6RvP25h2mqMbhmWpr 	 _175247759380.id,_16997199184281837433.idx,_6807036698572949990 mcHCA7rxsDvkL50CWbJel 	 
    	  
    		   
     
     
 
_2654435874 mXsQ7EtcRLQCoGI0aWHVn 	.trainIdx mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
     
 
  	  moT_S9GDXH9l8dY4auCTp 	 
    	  

             mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    		   
   
         mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    		   
    
      modWmaDk0q35f0I_aGjz6 	 
    	  
    		   
     
 
     mR0oEtHn4mcLNCK3obgTg 	 
    	  
 true ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
  	 
 mwQcD4iQwZzm1xNEBAXNS 	 
    	  

std mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
  pair mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   
     
     
 
cv mq2TZEVVkBWV8UUerawYu 	 
    	Mat,MapInitializer mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   
     
  MODE mbUmWsXo_mt5YMuA0dRGj 	 MapInitializer mbM6_YQUbxQ4zrU3yKhUm 	 
  _9813592252344743680 mGf46XpVsZXTkKG1xBF93 	const Frame &_3005401603918369712, const Frame &_3005401603918369727, vector mLqkqz1oj0n39qRbk3P0d 	 
    	  cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     DMatch mtjnvFto7OtvCeNoy20oi 	 
    	 &_6807036698572949990,  mLm5pMwSjW11Fg7twfBaQ 	 
    	  
_1686524438688096954 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
   mQNMjVJ0N6wXPbs6_HgrA 	 
    	 
     maRONv1j7ElxD2YigYmG5 	 
    	  
    		   
   mtWHlKYJukh2L67HsjPLk 	 
   _3005401603918369712.und_kpts.size mImF_yjqZ5vA5hr7u_dgQ 	 
    	  
    		   
     
     
 
   myLdxSbKnyWYHY1ELQXsL 	 
    	 0  msxbg4uLHX6bSC8xQJJjT 	 
    	  
    		  _params.mode mD2IexDoxblgmPilJikzK 	 
    	  
    		   KEYPOINTS mChkT2RjRR9l5VrNHoLpX 	 
          mXv0PAfzgk2_fV05X5nKZ 	 
    	  
    		   
  mLNsbg8pyRFuUIp_R2v0d 	 
    	  cv mY10h4x_kRm6OheD9nzQP 	 
    	  Mat mLxofLAyBTLsEaqCJekNX 	 
  ,NONE mUKDzj3AhlImVlcWctAq9 	 
     mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 
     mWvtBeVmHAPDjWPyb2fw6 	 
    	  
    		   
     
     
 
  	 mtgAIpqRx96Ug1UlUS5Ix 	 
  _3005401603918369727.und_kpts.size mDTsdPpCq4eSuuI3mubBO 	 
    	  
    		   
 mlmQ7twzbnP41JhsbTjq6 	 
 0  mCL5MoSEtL6Z8UCGU6IqO 	 
    	  
    		   
     
     
 
   _params.mode musLCv3PeipWCzr_EZRKb 	 
    	KEYPOINTS mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
         mmUizHWq3YhaHQKSV1bIt 	 
    	  
    	 mrFuQY6M9WWJeF7w9dgMm 	 
    	  
cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     
   Mat mSzof3CAXnP7qW3AQOIpI 	 
    	  
    		   
     
  ,NONE mGSwaxZR6NaXV1nQzbnD4 	 
    	  
    		   
     
     
 
  	  ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
 
     maRONv1j7ElxD2YigYmG5 	 
    	  
     mxtASYvyLkypbQ3wKMYBi 	 
    	  
 _3005401603918369712.markers.size mQrFq8uaXPUzfDZoyla5j 	 musLCv3PeipWCzr_EZRKb 	 
  0  mWUhiqv5bIQxvo40Le8M0 	 
    	  
 _params.mode mx5nL5_uWKTn0_18VrhrS 	 
    	  ARUCO mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
      mXv0PAfzgk2_fV05X5nKZ 	 
    	  
  mqIOFzkzC3Vp68hRewvw_ 	 
    	  
  cv mNVpdluZuoiVIfdWKkNZz 	 
 Mat mSzof3CAXnP7qW3AQOIpI 	 
    	  
    		   
     
 ,NONE mu1FnQFMDTSwPKm4knbOi 	 
  mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
 
     mFXsvRPkdIcV4GoPTpRdu 	 
    	  
    mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
     
 
  	_3005401603918369727.markers.size mfB2pwxO8Kxzw5bVxoAWu 	 
    	  
    		   
     
     
  mfJt39SVsIcGuR4b5KG3K 	 
    	  
    		   
     
     
 0  mWUhiqv5bIQxvo40Le8M0 	 
    	  
    		   
     _params.mode mVe4dZBBJUVUI35vvA1Ox 	 
    	  
   ARUCO mCdmzaxCk0FZEnTCFHZG4 	      mmUizHWq3YhaHQKSV1bIt 	 
    	  
    		   
     
     
 
  	  mLNsbg8pyRFuUIp_R2v0d 	 
 cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
     
     
Mat mDTsdPpCq4eSuuI3mubBO 	 ,NONE myTopYZa7yIOxNFAqG2ln 	 
    	  
    		   
     
  mphZZ3fCwJsSsxkCdUmFA 	
     mFXsvRPkdIcV4GoPTpRdu 	 
    	  
    		   
     
     
 
 mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    		 _3005401603918369712.und_kpts.size mQRZqQjaaMuE2ei53QVTa 	 
    	  
    	 mOyh0WcAWe4X21Nx7XmIJ 	 
0  mQ7pkbryadK6xP1UwBnlO 	 
    	  _3005401603918369712.markers.size mDTsdPpCq4eSuuI3mubBO 	 
    	  
    		   
     
     
 
 mVe4dZBBJUVUI35vvA1Ox 	0   mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
       mZsqgDOjDIWnGaZiccgxd 	 
    	  
    		   
     
  mqIOFzkzC3Vp68hRewvw_ 	 
    	  
    		   
     
    cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
   Mat mQRZqQjaaMuE2ei53QVTa 	 
    	  
    		   
     
     
 
  	,NONE myTopYZa7yIOxNFAqG2ln 	 
    	  
  meuAcaMA_veighEBRIakB 	 
    	  
    	
     mjMAADtlqHIb1n8jcadfe 	 
   mtWHlKYJukh2L67HsjPLk 	_3005401603918369727.und_kpts.size mLxofLAyBTLsEaqCJekNX 	 
    	  
    mbV1M45gJ90jH8gaxB10u 	 
    	  
    		 0  mAsjWuz0pGT4X3UULs6vr 	 
  _3005401603918369727.markers.size mQRZqQjaaMuE2ei53QVTa 	 
    	  
    	 mD2IexDoxblgmPilJikzK 	0   mCdmzaxCk0FZEnTCFHZG4 	 
       mtQzym6pygKJNEFLY1zwp 	 
    	  
    		   
      mq6ps0_ThKFNGk0D_gUgC 	 
    	  
    		   cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
   Mat mSzof3CAXnP7qW3AQOIpI 	 
    	  
    		  ,NONE mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    		   
   meuAcaMA_veighEBRIakB 	 
    	  
  
     mAHfPw6Pm0C_EGwBYeW6O 	 
    	  
    		   
     
  mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     mgcJaVoCsgmzSh2ja52EC 	 
    	_3005401603918369712.imageParams.isValid mS37yKuJ9Qw3sTuJDSsaM 	 
    	 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
  throw std mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
     
   runtime_error mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
     
 
string mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
 __PRETTY_FUNCTION__ mEQcnCIKV2HBxhuocTqhm 	 
  +"\x4e\x65\x65\x64\x20\x74\x6f\x20\x63\x61\x6c\x6c\x20\x73\x65\x74\x50\x61\x72\x61\x6d\x73\x20\x74\x6f\x20\x73\x65\x74\x20\x74\x68\x65\x20\x63\x61\x6d\x65\x72\x61\x20\x70\x61\x72\x61\x6d\x73\x20\x66\x69\x72\x73\x74" mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		  meuAcaMA_veighEBRIakB 	 
    	  

     mgEBmvqLf6PMhJZeTzswp 	 
    	  
    		   
   mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
  _params.markerSize mKpjSjOyX_RuuYvHw55qX 	 
    	  
    		   
     
     0 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 throw std mnc5AxXzr4BPppbUvP4FG 	 
    	  
runtime_error m_Wv_6TxKoWyyVku_7IdC 	string mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
 __PRETTY_FUNCTION__ mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
     
 
+"\x49\x6e\x76\x61\x6c\x69\x64\x20\x6d\x61\x72\x6b\x65\x72\x20\x73\x69\x7a\x65" mtw53ct5rBcppMoQJ08KE 	 
    	  
    		  mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
  
    
     ms0gVP7KrjDciWyFJ1fmf 	 
    	  
     mtgAIpqRx96Ug1UlUS5Ix 	 _params.mode musLCv3PeipWCzr_EZRKb 	 
    	  BOTH  mUMfEy37Q22XYn_W_z1P0 	 
    	  
    		   
 _params.mode mx5nL5_uWKTn0_18VrhrS 	 
    ARUCO mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     mLNsbg8pyRFuUIp_R2v0d 	 
    	  
    		 
         myAsqbOxXCKbwtKaJsMv8 	 
    	  
    		   
     
  _175247759708 mquKNlk6oUfOtB67zsUnK 	 
    	  
    		  ARUCO_initialize mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     
 
  	_3005401603918369712.markers,_3005401603918369727.markers,_3005401603918369712.imageParams.undistorted mQRZqQjaaMuE2ei53QVTa 	 
    	  
    		   
     
     
 
 ,_params.markerSize,0.02,_params.max_makr_rep_err,_params.minDistance,_4498230092506100729 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
     
 
  	  meuAcaMA_veighEBRIakB 	 
    	  
         maRONv1j7ElxD2YigYmG5 	 
    	  
   mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     
 
   mUpfv8Yhd38cmHAGvwFql 	 
    	  
    		   
     
     
 
_175247759708.empty mfB2pwxO8Kxzw5bVxoAWu 	 
    	  
    		  mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
     
 
  
                 mZsqgDOjDIWnGaZiccgxd 	 
    	  
  mGjrqvrVNVioUh48zGsmv 	 
  _175247759708,ARUCO mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    		   
      mwgiktLEfZPX6Q0iDYQaS 	 
    	 
     mGSwaxZR6NaXV1nQzbnD4 	 
    	  
    		   
     
     

     maRONv1j7ElxD2YigYmG5 	 
    	  
    		  mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
     
 
  _params.mode mkIY63qppn7XhhL8_PKOC 	 
  BOTH  msHWcJRBJJUShzPIX8Ckr 	 
    _params.mode mOyh0WcAWe4X21Nx7XmIJ 	 
    	  
    		   
     
 KEYPOINTS mytPitxa26I0boOQIsX_4 	 
    	  
    	 mKcwR_6MjpJ9NGpICycQ9 	 
    	  
    		   
     
     
 
  
        cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		  Mat _11093821901392,_2654435885 mphZZ3fCwJsSsxkCdUmFA 	 
    	
        vector mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		   
     
  cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
     
     
 
  Point3f mtjnvFto7OtvCeNoy20oi 	 
    	  
    		   
    _11093822296219 mWugSXRRnAcAmUglBaEC8 	 
    	  
 
        vector mXuxUaHxxdF6zEQMdzmh7 	 
bool mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
  _46082576203004608 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
 
 
         mJhQ2aXInyVMFKRs37tY8 	 
    	  
    		   
     
     
 
  _11671783024730682148 mGf46XpVsZXTkKG1xBF93 	 
    	  
    		  _3005401603918369712.imageParams.CameraMatrix,_3005401603918369712.und_kpts,_3005401603918369727.und_kpts,_6807036698572949990,_11093821901392,_2654435885,_11093822296219,_46082576203004608 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
     mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
     
 
  	  mqIOFzkzC3Vp68hRewvw_ 	 
    	  
    		 
            
            cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
     
     
 
  	Mat _11093821901330 mKdGkjFaE0tmrjf5NTlkH 	cv mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
  Mat mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
     
     
 eye mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		 4,4,CV_32F mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     meuAcaMA_veighEBRIakB 	 

            _11093821901392.copyTo mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     
 
 _11093821901330.colRange mtgAIpqRx96Ug1UlUS5Ix 	 0,3 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
     .rowRange mndP4wnd7T2bJPpA9o8xa 	 
    	  
    0,3 mytPitxa26I0boOQIsX_4 	 
    	  
 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
      mqmJdruV3MIc9CcenzHlC 	 
   
            _2654435885 mCd30wtR2_jp19X1QJxGT 	_1686524438688096954 mDDVlrS4uMT9J_lN7fseh 	 
            _2654435885.copyTo mxtASYvyLkypbQ3wKMYBi 	 _11093821901330.rowRange mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
     
 
0,3 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
  .colRange mnqODtk__norexJDqFXYD 	 
    	  
    		3,4 mytPitxa26I0boOQIsX_4 	 
    	 mLFZtySqO_nDftJBgp1FK 	 
    	 meuAcaMA_veighEBRIakB 	
            
             mzlU61CRdAJdTeqKQTVfM 	 
    	  
    	 mez3LQiFJeF2ZfEzjyQcK 	 
    	  
 _11093821901330,KEYPOINTS mUKDzj3AhlImVlcWctAq9 	 
    	  
    		 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
 
         mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    		   
     
     
 
  	 
     mu1FnQFMDTSwPKm4knbOi 	 
    	
     mZsqgDOjDIWnGaZiccgxd 	 
    	  
    		   
   mez3LQiFJeF2ZfEzjyQcK 	 
    	  
    		   
     
     
 
  	cv mY10h4x_kRm6OheD9nzQP 	Mat mfB2pwxO8Kxzw5bVxoAWu 	 
    	  
  ,NONE myTopYZa7yIOxNFAqG2ln 	  mWugSXRRnAcAmUglBaEC8 	 

 mpq02WZd5llRC35g5Crra 	 
    	  
    		   
     
 
MapInitializer mj6J5HI5Xb31ztLB3vXf0 	MapInitializer mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
     
 
  	   mnvuJGwJpM4fXFpwwiBPR 	 
    	  
    		   _46082543171087264,  mR_u0CRiVErFYF52pb6X5 	 
    	  
    		   
     
   _18204643580383888731 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
 mrFuQY6M9WWJeF7w9dgMm 	 
    	  
    		   
  
    _10193178724179165899  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 
   _46082543171087264 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		 
    _994360216124235670  mVybxT27lv2ZINx7C6UqB 	 
    	  
 _46082543171087264*_46082543171087264 mqmJdruV3MIc9CcenzHlC 	 
    
    _3513368080762767352  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		  _18204643580383888731 mwgiktLEfZPX6Q0iDYQaS 	 
  
 mpq02WZd5llRC35g5Crra 	 
    	 
 mePsroRdpIGpeDroobnZs 	 
    	  
   MapInitializer mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   _11671783024730682148 mzrSELvIctMsJ9zj2Nm82 	 
    	const cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     
     
 
 Mat &_1646854292500902885,const std mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
     vector mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   
  cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
  KeyPoint mhDKJw0vzmVidEdPlH7E5 	 
  & _594645163826321276,
                                      const std mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     
  vector mz5MCnH4XejHRq70OneDk 	 
    	  
    cv mlv1HNrEy8nKtkRAz1HIx 	 KeyPoint mhDKJw0vzmVidEdPlH7E5 	 
    	  
    		 &_16987994083097500267,   vector mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		   
  cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		 DMatch mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
    &_5507076421631549640, cv mYQOyfWlcv8BYXSMTquXE 	Mat &_11093821901461, cv mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
 Mat &_11093822381707,
                                      vector mnuDYya_hKIe0F8_gsRLN 	cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
     
     
Point3f mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
 &_706246337618936, vector mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
     
     
 
  	bool mf1IuzucYIRUTpArzsx6l 	 
 &_1883142761634074017 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 

 mqlyrsy8ZoHxK2uKGCJKQ 	 
    	  
    		   
     

     mPLwnaDnF_RJvGctibcNX 	 
    	  
    		   
     
  mGf46XpVsZXTkKG1xBF93 	 
    	  
    _5507076421631549640.size mSzof3CAXnP7qW3AQOIpI 	 
    	  
    		   
     
 mnuDYya_hKIe0F8_gsRLN 	10 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
 return false mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
 
    
    
    
    _8168161081211572021  mO6JPHXzu68suopqQj4mY 	 
    	  
    	 _1646854292500902885.clone mDTsdPpCq4eSuuI3mubBO 	 
    	   mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
   
    _994360233184819249  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 
   _594645163826321276 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		  
    _994360233184819248  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
 _16987994083097500267 ma864P_Lsmg_HxSufe4co 	
    _7917477704619030428.clear mLxofLAyBTLsEaqCJekNX 	 
    	  
    		   
  meuAcaMA_veighEBRIakB 	 
    	  
    		  
    _7917477704619030428.reserve mndP4wnd7T2bJPpA9o8xa 	 
  _994360233184819248.size mS37yKuJ9Qw3sTuJDSsaM 	 
    	  
    		   
      mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
     mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
     
 

     mSlgBaU2vojE6zMD3lNy5 	 
   auto _2654435878:_5507076421631549640 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
 
 
        _7917477704619030428.push_back mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
    make_pair mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    	_2654435878.queryIdx,_2654435878.trainIdx mKgK7IowyZjH5wyw0Bk8d 	 
   mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		 mWugSXRRnAcAmUglBaEC8 	 
 
    const  mR_u0CRiVErFYF52pb6X5 	 
    	  
    		   
     
     
_2654435847  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   _7917477704619030428.size mNFlZ7jDo9yK4myRyxbPG 	  mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
    
    
    vector mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
     
   size_t mLajHmFpSPs_tqjhga4nc 	 
    	  _14217074617584083842 miN6qFmUINJjKy7fxK3wO 	 
    	  
    _14217074617584083842.reserve mnqODtk__norexJDqFXYD 	_2654435847 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		    mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     

    vector mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     
     
 
 size_t mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
     
     
 
  	 _8060054801680167475 miN6qFmUINJjKy7fxK3wO 	 
 
     mKIH773O9wMZYhjP_5r8R 	 
    	int _2654435874 mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    0 mqmJdruV3MIc9CcenzHlC 	 
    	   _2654435874 mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   _2654435847 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
  _2654435874 mz7fxE30os9D4tNXhnqiQ 	 
    	  
    		   
     
     
 
 mNWUNpWV7jCgmNO1ohXHk 	
        _14217074617584083842.push_back mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     
 
 _2654435874 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
     
 
   mphZZ3fCwJsSsxkCdUmFA 	
    
    _10193178724467558310  mRg8w477JE_T_4vTAS6ye 	  vector miCt6286SbYlHHngvumOf 	 
    	  
    		   
     
     
 
  	 vector mz5MCnH4XejHRq70OneDk 	 
    	  
    	size_t mFQNQEJTD69vM27Yqioen 	 
    	  
    		   
     
     
  mhDKJw0vzmVidEdPlH7E5 	 
     mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     
 
  	_3513368080762767352,vector mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   
     
     
 
  	size_t mvXqUis778sIFsZW5vtV5 	 
  mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
8,0 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
  mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
 moT_S9GDXH9l8dY4auCTp 	 
    	  
    	
    
    srand mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     
 
  0 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
  mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     mocM9tIOQ8LUbJNUroqMJ 	 
    	  
    		int _175247760151 mRg8w477JE_T_4vTAS6ye 	0 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     _175247760151 mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
  _3513368080762767352 moT_S9GDXH9l8dY4auCTp 	 
    	   _175247760151 mZAkrlrMBDBZeuyIOXq4K 	 
    	  
    		   
     
      mytPitxa26I0boOQIsX_4 	 
    	  
  
     mrFuQY6M9WWJeF7w9dgMm 	 
    	  
    		   
     
     
 

        _8060054801680167475  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		  _14217074617584083842 mqmJdruV3MIc9CcenzHlC 	 
    	  

        
         muHcbKm0PMKyMsdXLtdOo 	 
    	  
    		   
     
size_t _2654435875 mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
0 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		  _2654435875 mXuxUaHxxdF6zEQMdzmh7 	 
    	 8 mqmJdruV3MIc9CcenzHlC 	 
    _2654435875 mP81FQC1rGzGFfKa8URMp 	 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
     
 
  	
         mq6ps0_ThKFNGk0D_gUgC 	 
    	  
    		   
     
     
 
 
             mwmwv7GVBGSSNquKWLaS7 	 
    	  
    	_46082576082856474  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		  rand mS37yKuJ9Qw3sTuJDSsaM 	 
 % _8060054801680167475.size mDTsdPpCq4eSuuI3mubBO 	 
    	  
    		   
     
 moT_S9GDXH9l8dY4auCTp 	 
 
             membkzbNyMSr1FS0Re8hM 	 
    	  
    		   
     
    _11093822405045  mnCeFIsKlgUCPgBADbea8 	 
    	 _8060054801680167475 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
_46082576082856474 mNvx6y3h4uOynhxSbeSNQ 	 
    	  
    		 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
     
 
  	 
            _10193178724467558310 mZWq1iKb1zKB_JmpMJfNM 	 
    	  
    		   
 _175247760151 mXztGjphv6NPOxrLSUEUq 	 
    	  
    		   
     
 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		   
     
     _2654435875 mtYTOdJ12b1xGaXXKiDjd 	 
    	  
    		   
      mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		   
     
   _11093822405045 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
    
            _8060054801680167475 mcHCA7rxsDvkL50CWbJel 	 
    	  
    		_46082576082856474 mXztGjphv6NPOxrLSUEUq 	 
    	  
      mVybxT27lv2ZINx7C6UqB 	 _8060054801680167475.back mQrFq8uaXPUzfDZoyla5j 	 
    	  
    		   
     
     mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
    
            _8060054801680167475.pop_back mImF_yjqZ5vA5hr7u_dgQ 	 
    	  
    		   
     moT_S9GDXH9l8dY4auCTp 	 
    	  
    		 
         m_BWrKK8L6uUnA_8Q3ZnA 	 
    	  
    		   
     
     
 
 
     myTopYZa7yIOxNFAqG2ln 	 
    	  
  
    
    vector mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   
     
 bool mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
    _14433965424915739325, _14433965424915739327 mqmJdruV3MIc9CcenzHlC 	 
     mYzukuoS5EuAVkLMj3HEJ 	 
    	  
    		   
     
     
 
  _175247761800, _175247761806 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
 
    cv mGwfbPa_SpGojjnG4wAw9 	 
   Mat _2654435841, _2654435839 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
   
    thread _6807155497357734564 mtgAIpqRx96Ug1UlUS5Ix 	&MapInitializer mnc5AxXzr4BPppbUvP4FG 	_5668215658172178667,this,ref mzrSELvIctMsJ9zj2Nm82 	_14433965424915739325 mtw53ct5rBcppMoQJ08KE 	 
    , ref mH9pmJdvECtnjBY1iswSZ 	 
_175247761800 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		, ref mnqODtk__norexJDqFXYD 	 
    	_2654435841 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
   mLFZtySqO_nDftJBgp1FK 	 
    	  
     meuAcaMA_veighEBRIakB 	 
   
    thread _6807155497357734562 mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
  &MapInitializer mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
_11788074806349018216,this,ref mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
     
 
  _14433965424915739327 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
   , ref mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
   _175247761806 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     , ref mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
_2654435839 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
  mtw53ct5rBcppMoQJ08KE 	 
    	  
    		 miN6qFmUINJjKy7fxK3wO 	 
    
    
    _6807155497357734564.join mQrFq8uaXPUzfDZoyla5j 	 
    meuAcaMA_veighEBRIakB 	 
    	  
    		   
 
    _6807155497357734562.join mld7eZtCfa6r4ySUlfIqH 	 
    	  
    		   
     
  miN6qFmUINJjKy7fxK3wO 	 
 
    
     mphegYaJkAj188nKLmOWT 	 
  _175247761736  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
  _175247761800/ mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
     
 
_175247761800+_175247761806 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
    mqmJdruV3MIc9CcenzHlC 	 
    	  
    		 
    
     mSimbUaAH71YIgw46PfYK 	 
    	  
   _3005399805025936106 mO6JPHXzu68suopqQj4mY 	 
    	  
  false miN6qFmUINJjKy7fxK3wO 	 
   
     mOHp6eii0W_CurvEO6nec 	 
    	  
    	_175247761736 mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
     
     
 0.40 mKgK7IowyZjH5wyw0Bk8d 	 
    	 
        _3005399805025936106 mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
   _1187546224459158348 mLSm6RvP25h2mqMbhmWpr 	 
    	  
    _14433965424915739325,_2654435841,_8168161081211572021,_11093821901461,_11093822381707,_706246337618936,_1883142761634074017,1.0,50 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
     
     
  miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     

     mPyT9VjCyKT6B92Ozlr5P 	 
    	  
    		   
  
        _3005399805025936106 mnCeFIsKlgUCPgBADbea8 	 
  _1187546224459158354 mGf46XpVsZXTkKG1xBF93 	 
    	_14433965424915739327,_2654435839,_8168161081211572021,_11093821901461,_11093822381707,_706246337618936,_1883142761634074017,1.0,50 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
   
     mFXsvRPkdIcV4GoPTpRdu 	 
   mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
    _3005399805025936106 mNWUNpWV7jCgmNO1ohXHk 	 
 mrFuQY6M9WWJeF7w9dgMm 	 
    	  
    		   

         mocM9tIOQ8LUbJNUroqMJ 	 
    	  
    		   
 auto &_2654435878:_994360234900545195 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
     
 
  
             mjMAADtlqHIb1n8jcadfe 	 
    	  
    		   
     
     
 
  	 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     mgcJaVoCsgmzSh2ja52EC 	_1883142761634074017 mjYQT6j1wgaGgGYF1qJI3 	 
    _2654435878.queryIdx mXsQ7EtcRLQCoGI0aWHVn 	 
    	  
    		   
     
     
  mP2AiGSIVV4QQ8S0_ZsB9 	
                _2654435878.queryIdx mnCeFIsKlgUCPgBADbea8 	 
    	  
    	_2654435878.trainIdx mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
   -1 mhif5Rqeg0n5IF_GvISmM 	 
 
        remove_unused_matches mGf46XpVsZXTkKG1xBF93 	 
    	  _994360234900545195 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
        _11999208601973379867.reserve mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
  _994360234900545195.size mLxofLAyBTLsEaqCJekNX 	 
    	  
    		 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
  mhif5Rqeg0n5IF_GvISmM 	 
    
         mKIH773O9wMZYhjP_5r8R 	 
    auto &_2654435878:_994360234900545195 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
            _11999208601973379867.push_back mtWHlKYJukh2L67HsjPLk 	 
    _706246337618936 mfN3ne3bwNdIV8GVYcoN0 	 
    	  
    		 _2654435878.queryIdx mtYTOdJ12b1xGaXXKiDjd 	 
    	  
    		   
     
     
 
  mLFZtySqO_nDftJBgp1FK 	 
    	  
     ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
  
     mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    		
     mZsqgDOjDIWnGaZiccgxd 	_3005399805025936106 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
  
 mwQcD4iQwZzm1xNEBAXNS 	 
    	  
   
 mOWYQ3OmlR6NgTKssoAIn 	 MapInitializer mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
  _5668215658172178667 mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
  vector mnuDYya_hKIe0F8_gsRLN 	 
    	  
 bool mhDKJw0vzmVidEdPlH7E5 	 
    	  
    		   
     
     
 
  &_17271253899155467930,  mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
    		   
     
     
 
  &_46082543172245582, cv mY10h4x_kRm6OheD9nzQP 	 
    Mat &_11093822009278 mP2AiGSIVV4QQ8S0_ZsB9 	 
   
 mLNsbg8pyRFuUIp_R2v0d 	
    
    const  mVHJ9I6jPcpbqQB9bqhTz 	 
_2654435847  mnCeFIsKlgUCPgBADbea8 	 
   _7917477704619030428.size mld7eZtCfa6r4ySUlfIqH 	 
    	  
  mqmJdruV3MIc9CcenzHlC 	 
  
    
    vector mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   
     
cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
 Point2f mFQNQEJTD69vM27Yqioen 	 
    	  _706246337605591, _706246337605588 meuAcaMA_veighEBRIakB 	 
    cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
    		   
 Mat _175247761824, _175247761827 mwgiktLEfZPX6Q0iDYQaS 	 
   
    _12337435833092867029 mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
_994360233184819249,_706246337605591, _175247761824 mCdmzaxCk0FZEnTCFHZG4 	 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 
  
    _12337435833092867029 mGf46XpVsZXTkKG1xBF93 	 
    	  
 _994360233184819248,_706246337605588, _175247761827 mEQcnCIKV2HBxhuocTqhm 	 
    mphZZ3fCwJsSsxkCdUmFA 	 
    	 
    cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
     
     
Mat _46082575930330217  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
  _175247761827.inv mNFlZ7jDo9yK4myRyxbPG 	 
    	  
    		 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
    
    _46082543172245582  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		 0.0 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		
    _17271253899155467930  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		   
     
     
 
   vector mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		bool mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
     
 
   mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     _2654435847,false mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
   ma864P_Lsmg_HxSufe4co 	 
   
    
    vector mSoN5o2yDOJ80orgAcweO 	 
    	 cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
 Point2f mFQNQEJTD69vM27Yqioen 	 
    	  
    		   
     
     
 
  	  _46082576183194624 mxtASYvyLkypbQ3wKMYBi 	 
    	  
 8 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
     
 
 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
 
    vector mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
     
   cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    Point2f mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
     
  _46082576183194819 mxtASYvyLkypbQ3wKMYBi 	 
   8 mEQcnCIKV2HBxhuocTqhm 	  mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
  
    cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
    Mat _706246350342703, _706246350346847 moT_S9GDXH9l8dY4auCTp 	 
    	  
    vector mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   
    bool mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    _1200715365640636762 mGf46XpVsZXTkKG1xBF93 	 
    	  
   _2654435847,false mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
 
  mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
  
     mLm5pMwSjW11Fg7twfBaQ 	 
    	  
    		   
     
    _16104291604305712718 mwgiktLEfZPX6Q0iDYQaS 	
    
     mU1Zf9TH71xfpaaa_jSCh 	int _175247760151 meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
 0 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
 _175247760151 mOc7dIIECwdrtfOiMRMNK 	 
   _3513368080762767352 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		 _175247760151 mCoUKvDV8sxZwsxIx5GNE 	 
    	  
    		   
     
     
 
  mytPitxa26I0boOQIsX_4 	
     mKcwR_6MjpJ9NGpICycQ9 	 
    	  
    		   
     
     
 
  
        
         moOskMZCYFVYX67st6FDR 	 
    	  
    		   
     
     
 
  	size_t _2654435875 mYKy6VNQ57atCIXMTSpg8 	 
 0 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
   _2654435875 mSf7M2lLnQTHwMbqH_RRR 	 
  8 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
      _2654435875 mP81FQC1rGzGFfKa8URMp 	 
    	  
    		   
     
  mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
     
 
         mqIOFzkzC3Vp68hRewvw_ 	 
    	  
    		   
  
             mz0GR1i5BQSuWGPDXhIpA 	 
    	  
    _11093822405045  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     _10193178724467558310 mcHCA7rxsDvkL50CWbJel 	 
    	  
    		   
     
 _175247760151 maN8Pf4K4wo4zg3O9vjkx 	 
    	  
   mQAGEgppSBq9HmAWlAxgv 	 
    	 _2654435875 mXsQ7EtcRLQCoGI0aWHVn 	 
    	  
    mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		 
            _46082576183194624 mnhg_U0H9OdjTJQTP6Gnv 	 
    	  
 _2654435875 mcO5gre3n3Zakhk46a5sh 	 
    	  
    		   
     
     
 
    meVN3qpUfWdh0L5zEBZMu 	 
    	  
   _706246337605591 mzcl0385Kw18AGIpYCXsl 	 
    	  
   _7917477704619030428 mfN3ne3bwNdIV8GVYcoN0 	 
    	  
    		   
     
     
 
  _11093822405045 maN8Pf4K4wo4zg3O9vjkx 	 
    .first mV_aYzA2HerHHuuJvxPtT 	 
   mWugSXRRnAcAmUglBaEC8 	
            _46082576183194819 mjYQT6j1wgaGgGYF1qJI3 	 
    	  
    		   
     
     
_2654435875 mV_aYzA2HerHHuuJvxPtT 	 
    	  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		    _706246337605588 mjYQT6j1wgaGgGYF1qJI3 	 
    	  
    		   
     
     
 _7917477704619030428 mnhg_U0H9OdjTJQTP6Gnv 	 
 _11093822405045 mV_aYzA2HerHHuuJvxPtT 	.second mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    	 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     

         myTopYZa7yIOxNFAqG2ln 	 
    	  
    	
        cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
     
 
 Mat _175247762150  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		 _5082483593203424965 m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    	_46082576183194624,_46082576183194819 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
  ma864P_Lsmg_HxSufe4co 	 

        _706246350342703  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 
  _46082575930330217*_175247762150*_175247761824 miN6qFmUINJjKy7fxK3wO 	 

        _706246350346847  mRg8w477JE_T_4vTAS6ye 	 
    	  _706246350342703.inv mQrFq8uaXPUzfDZoyla5j 	 
    	  
   mqmJdruV3MIc9CcenzHlC 	
        _16104291604305712718  mXxeBOpcTlG_qg7UTBJrv 	 
    _17785459191918434301 mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
     
 
  _706246350342703, _706246350346847, _1200715365640636762, _10193178724179165899 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		  mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   

         mItoNEXPmUd7PZnbkjY1u 	 
    	  
    		   
     
     
 
 _16104291604305712718 mvXqUis778sIFsZW5vtV5 	 
    	  
_46082543172245582 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
    
         mqIOFzkzC3Vp68hRewvw_ 	 
    	  
    		   
   
            _11093822009278  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     
 _706246350342703.clone mDTsdPpCq4eSuuI3mubBO 	 
    	   ma864P_Lsmg_HxSufe4co 	 
    	  
    	
            _17271253899155467930  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   _1200715365640636762 meuAcaMA_veighEBRIakB 	 
    	 
            _46082543172245582  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    _16104291604305712718 meuAcaMA_veighEBRIakB 	 
   
         mUKDzj3AhlImVlcWctAq9 	 
    	  
   
     mGSwaxZR6NaXV1nQzbnD4 	 
 mIyo8wONeLU1MQ6fYabD9 	 
    	  
    		   
     
   
 mb9OlwGA1t5M6qh5W_YyX 	 
    	  
    		   
     
     
 
  	 MapInitializer mnc5AxXzr4BPppbUvP4FG 	_11788074806349018216 mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
     vector miCt6286SbYlHHngvumOf 	 
    	  
    		bool mbUmWsXo_mt5YMuA0dRGj 	 
    	  
  &_17271253899155467930,  mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
     
  &_46082543172245582, cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
     
     
Mat &_11093821994570 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
     

 mKcwR_6MjpJ9NGpICycQ9 	 
    	  
    		   
     
     
 
  	 
    
    const  mVHJ9I6jPcpbqQB9bqhTz 	 
    	  
    		   
     
     _2654435847  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
 _17271253899155467930.size mld7eZtCfa6r4ySUlfIqH 	 
   mhif5Rqeg0n5IF_GvISmM 	 
    	  
   
    
    vector mSoN5o2yDOJ80orgAcweO 	 
    	  
    		cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		  Point2f mFQNQEJTD69vM27Yqioen 	 
   _706246337605591, _706246337605588 mDDVlrS4uMT9J_lN7fseh 	 
  
    cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     
     
 
 Mat _175247761824, _175247761827 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
    
    _12337435833092867029 mndP4wnd7T2bJPpA9o8xa 	 
    _994360233184819249,_706246337605591, _175247761824 mChkT2RjRR9l5VrNHoLpX 	 
    	  
 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
    _12337435833092867029 mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
     _994360233184819248,_706246337605588, _175247761827 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
   mWugSXRRnAcAmUglBaEC8 	 
    	  
    cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
 Mat _11093821991670  mAd9SbOcAjVa1TnOyBE8u 	 
    	   _175247761827.t mQrFq8uaXPUzfDZoyla5j 	 
    	  
  mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
    
    
    _46082543172245582  meVN3qpUfWdh0L5zEBZMu 	 
   0.0 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
 
    _17271253899155467930  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
  vector mz5MCnH4XejHRq70OneDk 	 
    	  
    		   
     bool mtjnvFto7OtvCeNoy20oi 	 
    	  
    		   m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
 _2654435847,false mNWUNpWV7jCgmNO1ohXHk 	 
    	  ma864P_Lsmg_HxSufe4co 	 
    	  
    		 
    
    vector mjMH4y_9O_liyFsbzDUxH 	 
    	 cv mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   
     
     
 
  Point2f mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
     
     
 
   _46082576183194624 mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    		   
     
8 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
    mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
    
    vector mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
     
     
 cv mNVpdluZuoiVIfdWKkNZz 	Point2f mvXqUis778sIFsZW5vtV5 	 
    	  
 _46082576183194819 mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
    8 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
      ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
  
    cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
     
     Mat _706246338989182 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
 
    vector mXuxUaHxxdF6zEQMdzmh7 	 
    	  
    		   
bool mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
 _1200715365640636762 mndP4wnd7T2bJPpA9o8xa 	 
    	 _2654435847,false mNWUNpWV7jCgmNO1ohXHk 	 
    	   mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     

     mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
     
     
 
  	 _16104291604305712718 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
   
    
     mKIH773O9wMZYhjP_5r8R 	 
    	  
    		   
     
     
 
  	 int _175247760151 mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    	0 ma864P_Lsmg_HxSufe4co 	 
    	  
    		  _175247760151 mXuxUaHxxdF6zEQMdzmh7 	 
    	  
    		   
     
     
 
  _3513368080762767352 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
   _175247760151 mjYiQ5PDu6c8QsGFAcfyI 	 
    	  
    		   
     
      mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     mKcwR_6MjpJ9NGpICycQ9 	 
    	  
    		   

        
         mU1Zf9TH71xfpaaa_jSCh 	 
    	  
    	int _2654435875 mnCeFIsKlgUCPgBADbea8 	 
 0 mphZZ3fCwJsSsxkCdUmFA 	 
    _2654435875 mz5MCnH4XejHRq70OneDk 	 
    	  
    		 8 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     _2654435875 mP81FQC1rGzGFfKa8URMp 	 
    	  
     mytPitxa26I0boOQIsX_4 	 
    	  
    		   
  
         mhKeWI3YD4BRg9yhMiFLW 	 
    	  
    		  
             mIl8Bz4oYM1DbDYC1fzl4 	 
    	  
    		   _11093822405045  mAd9SbOcAjVa1TnOyBE8u 	 _10193178724467558310 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		   
   _175247760151 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
     mnhg_U0H9OdjTJQTP6Gnv 	 
    	  
    		   
     
  _2654435875 mtYTOdJ12b1xGaXXKiDjd 	 
    	  
    		   
     
     
  mwgiktLEfZPX6Q0iDYQaS 	 
 
            _46082576183194624 mnhg_U0H9OdjTJQTP6Gnv 	_2654435875 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
     
     
 
   mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
      _706246337605591 mfN3ne3bwNdIV8GVYcoN0 	_7917477704619030428 mjYQT6j1wgaGgGYF1qJI3 	 
    	  
   _11093822405045 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
     
     
 
  .first mIVJo0eWCM7NIdVTaOwOV 	 
    moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 

            _46082576183194819 mD_2zWmARS3aJ6y6qfRH_ 	 
    	  
    		   
     
  _2654435875 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    	  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 
  _706246337605588 mP7Vex3pSva4KZPEEVxol 	 
    	  
_7917477704619030428 mQAGEgppSBq9HmAWlAxgv 	 
    	  
    		   
     
_11093822405045 mXsQ7EtcRLQCoGI0aWHVn 	 
    	  
    		   
 .second mcdcf6DHXagTuHrurSaFD 	 
    	 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
    
         mv1ZUEjgm76AgfTPqDyj9 	 
 
        cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     
 Mat _175247761817  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
    _5082483593203429753 mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   _46082576183194624,_46082576183194819 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		  ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
   
        _706246338989182  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
      _11093821991670*_175247761817*_175247761824 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
 
        _16104291604305712718  mO6JPHXzu68suopqQj4mY 	 
    	  
  _9516949822686382330 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		  _706246338989182, _1200715365640636762, _10193178724179165899 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
 moT_S9GDXH9l8dY4auCTp 	 
    	  
 
         mOfnTUGa0UrxvKp2HRrB8 	 
    	  
    		 _16104291604305712718 mFQNQEJTD69vM27Yqioen 	 
    	  
   _46082543172245582 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		  
         mLNsbg8pyRFuUIp_R2v0d 	 
    	  
    		   
  
            _11093821994570  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
  _706246338989182.clone mfB2pwxO8Kxzw5bVxoAWu 	 
    	   moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 
  	 
            _17271253899155467930  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     
 
  	 _1200715365640636762 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
            _46082543172245582  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
      _16104291604305712718 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 
         mwQcD4iQwZzm1xNEBAXNS 	 
    	  
    		   
     
     
 
     mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    	
 mwQcD4iQwZzm1xNEBAXNS 	
cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
  Mat MapInitializer mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
     
_5082483593203424965 mxtASYvyLkypbQ3wKMYBi 	 
    	  
   const vector mz5MCnH4XejHRq70OneDk 	 
    	  
   cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
     
 Point2f mvXqUis778sIFsZW5vtV5 	 
     &_11093821939251, const vector mSf7M2lLnQTHwMbqH_RRR 	 
    	  
   cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
Point2f mf1IuzucYIRUTpArzsx6l 	 
    	  
    		   
    &_11093821939250 mP2AiGSIVV4QQ8S0_ZsB9 	 
 mQNMjVJ0N6wXPbs6_HgrA 	 
    	  
    		   
     
  
    const  mz0GR1i5BQSuWGPDXhIpA 	 
    	  
    		   
     
     
_2654435847  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
     
 
   _11093821939251.size mImF_yjqZ5vA5hr7u_dgQ 	 
    	  
 meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
     
    cv mj6J5HI5Xb31ztLB3vXf0 	 
    	  
    		   
     
     
 
  	 Mat _2654435834 mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   2*_2654435847,9,CV_32F mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
  mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
    
     mpWzKYjiXpd4bF_NzlE7q 	 
    	  
 int _2654435874 meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 
 0 moT_S9GDXH9l8dY4auCTp 	 
     _2654435874 mLqkqz1oj0n39qRbk3P0d 	 
   _2654435847 moT_S9GDXH9l8dY4auCTp 	 
    _2654435874 mz7fxE30os9D4tNXhnqiQ 	 
    	  
    		   
     
    mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    	
     mLNsbg8pyRFuUIp_R2v0d 	 
    	 
        const  mSe8inYVJuJ_SWpL20XSn 	 
    	  
    		   _175247759835  mYKy6VNQ57atCIXMTSpg8 	 _11093821939251 mD_2zWmARS3aJ6y6qfRH_ 	_2654435874 mtYTOdJ12b1xGaXXKiDjd 	 
    	  
    		   
     
.x mqmJdruV3MIc9CcenzHlC 	 
    	  
    		
        const  mnvuJGwJpM4fXFpwwiBPR 	 
    	  _175247760922  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    	 _11093821939251 mjYQT6j1wgaGgGYF1qJI3 	 
    	  
    	_2654435874 mtYTOdJ12b1xGaXXKiDjd 	 
    	  
    		   
     
     
 
  	.y mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
 
        const  mYzukuoS5EuAVkLMj3HEJ 	 
    	  
    		   
     
     
 
 _175247759832  mVybxT27lv2ZINx7C6UqB 	 
 _11093821939250 mzcl0385Kw18AGIpYCXsl 	 
    	  
    		   
     
     
 
  	_2654435874 mXztGjphv6NPOxrLSUEUq 	 
    	  
    		   
    .x ma864P_Lsmg_HxSufe4co 	 
    	  
    		   

        const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  
    		   
     
     
 
 _175247760921  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
  _11093821939250 mjYQT6j1wgaGgGYF1qJI3 	 
_2654435874 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
    .y miN6qFmUINJjKy7fxK3wO 	 
    	
        _2654435834.at miCt6286SbYlHHngvumOf 	 
    	  
    	float mvXqUis778sIFsZW5vtV5 	 
     mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
2*_2654435874,0 mytPitxa26I0boOQIsX_4 	 
    	  
    	  mVybxT27lv2ZINx7C6UqB 	  0.0 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 
  	 
        _2654435834.at mjMH4y_9O_liyFsbzDUxH 	 
    	 float mhDKJw0vzmVidEdPlH7E5 	  mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
  2*_2654435874,1 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
   mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
   0.0 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		
        _2654435834.at mz5MCnH4XejHRq70OneDk 	 
    float mW2ZPvWHsb0kj8UsemkMz 	 
    	  
     m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		2*_2654435874,2 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     
 
   0.0 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
   
        _2654435834.at mnuDYya_hKIe0F8_gsRLN 	 
   float mFQNQEJTD69vM27Yqioen 	 
 mtWHlKYJukh2L67HsjPLk 	 
    	  
2*_2654435874,3 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
   mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
 -_175247759835 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
 
        _2654435834.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
    float mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
     
   mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
  2*_2654435874,4 mChkT2RjRR9l5VrNHoLpX 	 
    	   mAd9SbOcAjVa1TnOyBE8u 	  -_175247760922 mWugSXRRnAcAmUglBaEC8 	 
 
        _2654435834.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
  float mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     
2*_2654435874,5 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
   mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
   -1 ma864P_Lsmg_HxSufe4co 	 
    	  

        _2654435834.at mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   
     
     
 
 float mvXqUis778sIFsZW5vtV5 	 mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
 2*_2654435874,6 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
     
  _175247760921*_175247759835 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
    
        _2654435834.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
     float mRVv11jkqLVq83rwdiZNq 	 
    	  
   m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		 2*_2654435874,7 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
    mRg8w477JE_T_4vTAS6ye 	 
    	  
    		 _175247760921*_175247760922 mWugSXRRnAcAmUglBaEC8 	 
    	  

        _2654435834.at miCt6286SbYlHHngvumOf 	 
    	  
    		   
     
  float mLajHmFpSPs_tqjhga4nc 	 mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
     
 2*_2654435874,8 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
   mYKy6VNQ57atCIXMTSpg8 	 
    	  
     _175247760921 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
        _2654435834.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
  float mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
   mLSm6RvP25h2mqMbhmWpr 	 
    	  
    	2*_2654435874+1,0 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
  mquKNlk6oUfOtB67zsUnK 	 
    	  
  _175247759835 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    
        _2654435834.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
   float mFQNQEJTD69vM27Yqioen 	 
    mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		  2*_2654435874+1,1 mytPitxa26I0boOQIsX_4 	 
      mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     
 
  	 _175247760922 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 
  
        _2654435834.at mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   
     
  float mLajHmFpSPs_tqjhga4nc 	 
    	  
    		   
     
  mH9pmJdvECtnjBY1iswSZ 	 
    	  
2*_2654435874+1,2 mCdmzaxCk0FZEnTCFHZG4 	 
     meVN3qpUfWdh0L5zEBZMu 	 
    	  
  1 miN6qFmUINJjKy7fxK3wO 	 
    	 
        _2654435834.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
     
  float mhDKJw0vzmVidEdPlH7E5 	 
    	  
    		 mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     2*_2654435874+1,3 mEQcnCIKV2HBxhuocTqhm 	 
      mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
  0.0 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
        _2654435834.at mjMH4y_9O_liyFsbzDUxH 	 
 float mbUmWsXo_mt5YMuA0dRGj 	 
     mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   2*_2654435874+1,4 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
   mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
 0.0 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		 
        _2654435834.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     
     
 
  	float ma5XrgW2ATI7PTDDXXfB3 	 
   mtWHlKYJukh2L67HsjPLk 	 
    	 2*_2654435874+1,5 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
 
  	  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     
  0.0 miN6qFmUINJjKy7fxK3wO 	 
    	  
    	
        _2654435834.at mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   
     
     
float mRVv11jkqLVq83rwdiZNq 	 
    mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		  2*_2654435874+1,6 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		    meVN3qpUfWdh0L5zEBZMu 	 
    	   -_175247759832*_175247759835 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
 
        _2654435834.at mSf7M2lLnQTHwMbqH_RRR 	float mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
    m_Wv_6TxKoWyyVku_7IdC 	 
    	  
   2*_2654435874+1,7 mChkT2RjRR9l5VrNHoLpX 	 
    	  
     mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
      -_175247759832*_175247760922 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
     
 
  	 
        _2654435834.at mnuDYya_hKIe0F8_gsRLN 	 
float mf1IuzucYIRUTpArzsx6l 	 
    	  
    		   
  mtWHlKYJukh2L67HsjPLk 	2*_2654435874+1,8 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    meVN3qpUfWdh0L5zEBZMu 	 
    	 -_175247759832 mhif5Rqeg0n5IF_GvISmM 	
     mGSwaxZR6NaXV1nQzbnD4 	 
    	  
    		   
     
     
 
    cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
     
Mat _2654435886,_2654435888,_175247760983 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
   
    cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
  SVDecomp mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		_2654435834,_2654435888,_2654435886,_175247760983,cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     
     
 
 SVD mNVpdluZuoiVIfdWKkNZz 	 
    	  
    		   
     
   MODIFY_A | cv mYQOyfWlcv8BYXSMTquXE 	 
 SVD mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    FULL_UV mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
      mWugSXRRnAcAmUglBaEC8 	 

     mgdJ7Lxk_sORMQaHgbV35 	 
    	  
    		   
     
     _175247760983.row mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		 8 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   .reshape m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
     
 
0, 3 mytPitxa26I0boOQIsX_4 	 
    	  
    		   miN6qFmUINJjKy7fxK3wO 	 
  
 mv1ZUEjgm76AgfTPqDyj9 	
cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
     
 Mat MapInitializer mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
     
     _5082483593203429753 mtWHlKYJukh2L67HsjPLk 	 
    	  const vector mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
     
     
 
  	cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     Point2f mFQNQEJTD69vM27Yqioen 	 
    	  
    		   
   &_11093821939251,const vector mnuDYya_hKIe0F8_gsRLN 	 
    	  
  cv mbM6_YQUbxQ4zrU3yKhUm 	 Point2f mRVv11jkqLVq83rwdiZNq 	 
    	 &_11093821939250 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
     
 
  	
 mqIOFzkzC3Vp68hRewvw_ 	 
    	  
    		   
     
 
    const  mIl8Bz4oYM1DbDYC1fzl4 	 
    _2654435847  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
 _11093821939251.size mQrFq8uaXPUzfDZoyla5j 	 
    	  
    		   
     
     
 
  mWugSXRRnAcAmUglBaEC8 	 
    	  
    	
    cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
     
   Mat _2654435834 mLSm6RvP25h2mqMbhmWpr 	 
    	  
 _2654435847,9,CV_32F mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		    mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
  
     mYbdRpTrp0RuXQF49wcyY 	 
    	  
    		   
int _2654435874 mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     
 
0 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 
  _2654435874 mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		  _2654435847 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
 _2654435874 mMbR8sME8lT9WWeXIiFbW 	 
    	  
    		   
    mCdmzaxCk0FZEnTCFHZG4 	 

     mQNMjVJ0N6wXPbs6_HgrA 	 
    	  
    	
        const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  
    		   
  _175247759835  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
     _11093821939251 mjYQT6j1wgaGgGYF1qJI3 	 
    _2654435874 mNvx6y3h4uOynhxSbeSNQ 	 
    	  
    		   
     
 .x mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
    
        const  mG9tkXdonq5K1a5TTvWdA 	 
    	  
_175247760922  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
 _11093821939251 mcHCA7rxsDvkL50CWbJel 	 
  _2654435874 mV_aYzA2HerHHuuJvxPtT 	 .y meuAcaMA_veighEBRIakB 	 
   
        const  mG9tkXdonq5K1a5TTvWdA 	 
    	  
    		   
     
     
 
  _175247759832  mVybxT27lv2ZINx7C6UqB 	 
    	  
    	 _11093821939250 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
     
     
 _2654435874 maeuoWjF6xTdwN3myRAGg 	 
    	  
    		  .x mWugSXRRnAcAmUglBaEC8 	
        const  mG9tkXdonq5K1a5TTvWdA 	 
    	_175247760921  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
      _11093821939250 mD_2zWmARS3aJ6y6qfRH_ 	_2654435874 maeuoWjF6xTdwN3myRAGg 	 
   .y mhif5Rqeg0n5IF_GvISmM 	 
        _2654435834.at mz5MCnH4XejHRq70OneDk 	 
    	  
  float mf1IuzucYIRUTpArzsx6l 	 
    mzrSELvIctMsJ9zj2Nm82 	_2654435874,0 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
     
 
   mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
  _175247759832*_175247759835 moT_S9GDXH9l8dY4auCTp 	 
    	
        _2654435834.at mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   
     
     
 
  	float mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
     
     
 
 mGf46XpVsZXTkKG1xBF93 	 _2654435874,1 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
     
 
    mO6JPHXzu68suopqQj4mY 	 
    	  
 _175247759832*_175247760922 mwgiktLEfZPX6Q0iDYQaS 	 
        _2654435834.at mLqkqz1oj0n39qRbk3P0d 	 
    	 float mtjnvFto7OtvCeNoy20oi 	 
    	  
    		   
     
     
 
  mzrSELvIctMsJ9zj2Nm82 	 
    	  
   _2654435874,2 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
  _175247759832 mWugSXRRnAcAmUglBaEC8 	 
    	  
    
        _2654435834.at mz5MCnH4XejHRq70OneDk 	 
   float mW2ZPvWHsb0kj8UsemkMz 	 mGf46XpVsZXTkKG1xBF93 	 
  _2654435874,3 mLFZtySqO_nDftJBgp1FK 	  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     _175247760921*_175247759835 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
   
        _2654435834.at mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   
     
     float mhDKJw0vzmVidEdPlH7E5 	 
 mLSm6RvP25h2mqMbhmWpr 	 
    _2654435874,4 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		    mYKy6VNQ57atCIXMTSpg8 	 
   _175247760921*_175247760922 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
 
        _2654435834.at mSf7M2lLnQTHwMbqH_RRR 	float mLajHmFpSPs_tqjhga4nc 	 
    	  
    		   
     
     mtWHlKYJukh2L67HsjPLk 	 
    	  
    		 _2654435874,5 mP2AiGSIVV4QQ8S0_ZsB9 	 
      mAd9SbOcAjVa1TnOyBE8u 	 
    	  
     _175247760921 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   

        _2654435834.at mSoN5o2yDOJ80orgAcweO 	 
    	  float ma5XrgW2ATI7PTDDXXfB3 	 
    	  
    		   
     
  mH9pmJdvECtnjBY1iswSZ 	 
   _2654435874,6 mEQcnCIKV2HBxhuocTqhm 	 
    	  
   mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     _175247759835 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
 
        _2654435834.at mSoN5o2yDOJ80orgAcweO 	 float mf1IuzucYIRUTpArzsx6l 	 
    	  
  mxtASYvyLkypbQ3wKMYBi 	 
    	  
_2654435874,7 mLFZtySqO_nDftJBgp1FK 	 
    	  
  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
  _175247760922 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
     
        _2654435834.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
     
  float mLajHmFpSPs_tqjhga4nc 	 
    	  
    		   
     
      mzrSELvIctMsJ9zj2Nm82 	 
 _2654435874,8 mCdmzaxCk0FZEnTCFHZG4 	 
     mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
     
 
   1 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     mGSwaxZR6NaXV1nQzbnD4 	 
    	 
    cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
    		   
    Mat _2654435886,_2654435888,_175247760983 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
    
    cv mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
     
     
 
  	 SVDecomp mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
   _2654435834,_2654435888,_2654435886,_175247760983,cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
  SVD mlv1HNrEy8nKtkRAz1HIx 	 
MODIFY_A | cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     
     
SVD mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
     
  FULL_UV mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		 mDDVlrS4uMT9J_lN7fseh 	 
    
    cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     
  Mat _706246338936712  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
     
 
 _175247760983.row mnqODtk__norexJDqFXYD 	 
    8 mCdmzaxCk0FZEnTCFHZG4 	 
   .reshape mxtASYvyLkypbQ3wKMYBi 	 
    	  
  0, 3 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
  meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
    cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
     
     
 
  	SVDecomp m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		_706246338936712,_2654435888,_2654435886,_175247760983,cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
SVD mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     
MODIFY_A | cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
 SVD mlv1HNrEy8nKtkRAz1HIx 	 
    	  
  FULL_UV mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
     
 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
  	
    _2654435888.at mz5MCnH4XejHRq70OneDk 	 
    	  
    		   
     
     float mFQNQEJTD69vM27Yqioen 	 
    	  
    		   
     
     
 
  	  mH9pmJdvECtnjBY1iswSZ 	 
    	2 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
     
 
  	 mquKNlk6oUfOtB67zsUnK 	 
0 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
 
  	
     mmUizHWq3YhaHQKSV1bIt 	 
    	  
    		   
     
     
 
  _2654435886*cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		Mat mnc5AxXzr4BPppbUvP4FG 	 diag mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    		   
     
     
 
  	_2654435888 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
    *_175247760983 miN6qFmUINJjKy7fxK3wO 	 
 mIyo8wONeLU1MQ6fYabD9 	 
    	
 mb6bPPxBoRd5eWMKEY_T9 	 
    	  
    		   
     
     
MapInitializer mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   
     
     
 
_17785459191918434301 mH9pmJdvECtnjBY1iswSZ 	const cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
 Mat &_11093822009278, const cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
   Mat &_11093822009342, vector mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		bool mRVv11jkqLVq83rwdiZNq 	 
    &_17271253899155467930,  mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
     
     
 
  _46082543171087264 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 mQNMjVJ0N6wXPbs6_HgrA 	 
    	  
       
    const  mz0GR1i5BQSuWGPDXhIpA 	 
    	  
    		   
_2654435847  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     _7917477704619030428.size mDTsdPpCq4eSuuI3mubBO 	 
    	  
    	 mDDVlrS4uMT9J_lN7fseh 	 
    	 
    const  mG9tkXdonq5K1a5TTvWdA 	 
    	  
    		_11093822398429  mO6JPHXzu68suopqQj4mY 	  _11093822009278.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
     
   float ma5XrgW2ATI7PTDDXXfB3 	 
    	  
    		   
     
     
 
 mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    		   0,0 mLFZtySqO_nDftJBgp1FK 	 
    	  
  ma864P_Lsmg_HxSufe4co 	 
    	  
    const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  
    _11093822398428  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
 _11093822009278.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		float mLajHmFpSPs_tqjhga4nc 	 
     mtgAIpqRx96Ug1UlUS5Ix 	 0,1 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
   mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     

    const  mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
     
     _11093822398403  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
    _11093822009278.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		float mtjnvFto7OtvCeNoy20oi 	 
    	  
   m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
     
 
  0,2 mytPitxa26I0boOQIsX_4 	 
 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    
    const  mphegYaJkAj188nKLmOWT 	 
    	  
   _11093822398364  mKdGkjFaE0tmrjf5NTlkH 	 
     _11093822009278.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		float mFQNQEJTD69vM27Yqioen 	  mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
 1,0 mytPitxa26I0boOQIsX_4 	 
    	  
   mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
   
    const  mphegYaJkAj188nKLmOWT 	 
    	  
  _11093822398365  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		 _11093822009278.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
  float mRVv11jkqLVq83rwdiZNq 	 
     mnqODtk__norexJDqFXYD 	 
1,1 mEQcnCIKV2HBxhuocTqhm 	 
  mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
    const  mG9tkXdonq5K1a5TTvWdA 	_11093822398338  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    _11093822009278.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
float mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
     
     
 
 mxtASYvyLkypbQ3wKMYBi 	 
 1,2 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
   
    const  mIHMqjojFRuV5HLbqdMaZ 	 
    _11093822398298  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
      _11093822009278.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
 float mtjnvFto7OtvCeNoy20oi 	 
    	   mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
     
 
  2,0 mCdmzaxCk0FZEnTCFHZG4 	 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
   
    const  mnvuJGwJpM4fXFpwwiBPR 	 
    	  
    		   _11093822398277  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
 _11093822009278.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
 float mtjnvFto7OtvCeNoy20oi 	 
    	  
    		  mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
   2,1 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
     
  miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
 
    const  mG9tkXdonq5K1a5TTvWdA 	 
  _11093822398276  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
      _11093822009278.at mz5MCnH4XejHRq70OneDk 	 
  float mf1IuzucYIRUTpArzsx6l 	 
    	  
    		 mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
     
 
  2,2 mNWUNpWV7jCgmNO1ohXHk 	 
     meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
     
 
  
    const  mSe8inYVJuJ_SWpL20XSn 	 
    	  
    		   
     
     
 
  _3005401529427071630  meVN3qpUfWdh0L5zEBZMu 	 
    _11093822009342.at mSoN5o2yDOJ80orgAcweO 	 
float mtjnvFto7OtvCeNoy20oi 	 
    	  
   mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
0,0 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
 
    const  mLm5pMwSjW11Fg7twfBaQ 	 
    	  _3005401529421472443  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		   
  _11093822009342.at mz5MCnH4XejHRq70OneDk 	 
    	  
    		   
     float mf1IuzucYIRUTpArzsx6l 	 
    	  
  mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     
 
  	0,1 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		  mqmJdruV3MIc9CcenzHlC 	 
    	  
    		
    const  mnvuJGwJpM4fXFpwwiBPR 	 
    	  
    		   
     
     _3005401529537514599  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		  _11093822009342.at miCt6286SbYlHHngvumOf 	 
    	  
    		   float mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
    mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
     
0,2 mEQcnCIKV2HBxhuocTqhm 	 
    	  
 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
    const  mphegYaJkAj188nKLmOWT 	_3005401529370179020  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
     _11093822009342.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
     
   float mhDKJw0vzmVidEdPlH7E5 	 
    	  
    		  m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
 1,0 mNWUNpWV7jCgmNO1ohXHk 	 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
 
    const  mb6bPPxBoRd5eWMKEY_T9 	 
    	  
    		   
     
    _3005401529369987001  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
 _11093822009342.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		float mhDKJw0vzmVidEdPlH7E5 	 
   mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
 1,1 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
    mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
  
    const  mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
  _3005401529351329903  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
     _11093822009342.at mz5MCnH4XejHRq70OneDk 	 
    	  
  float mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
    mzrSELvIctMsJ9zj2Nm82 	 
    	  
    	1,2 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    	 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    	
    const  mSe8inYVJuJ_SWpL20XSn 	 
_3005401529527259663  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
   _11093822009342.at mXuxUaHxxdF6zEQMdzmh7 	 
 float ma5XrgW2ATI7PTDDXXfB3 	 
    	   mxtASYvyLkypbQ3wKMYBi 	 
2,0 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		    mqmJdruV3MIc9CcenzHlC 	 
    const  mSe8inYVJuJ_SWpL20XSn 	 
    	  
    		  _3005401529502477801  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
   _11093822009342.at miCt6286SbYlHHngvumOf 	 
    	  
float ma5XrgW2ATI7PTDDXXfB3 	 
    	  
    		   
     
     
 
   mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
2,1 mytPitxa26I0boOQIsX_4 	  miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
 
  	 
    const  mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
    		   _3005401529495938372  mAd9SbOcAjVa1TnOyBE8u 	 
     _11093822009342.at mSf7M2lLnQTHwMbqH_RRR 	 
 float mLajHmFpSPs_tqjhga4nc 	 
    	   mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
  2,2 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     

    _17271253899155467930.resize mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
     
 
  	 _2654435847 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
    mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
     
 
  	 
     mG9tkXdonq5K1a5TTvWdA 	 
    	  
    		   
    _46082543172245582  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
     
 
 0 ma864P_Lsmg_HxSufe4co 	 
  
    const  mb6bPPxBoRd5eWMKEY_T9 	 
    	  
    		   
     
 _175247759809  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
      5.991 meuAcaMA_veighEBRIakB 	 
    	  
    		   
    const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  
    		   
     
_9395000106275793626  meVN3qpUfWdh0L5zEBZMu 	 1.0/ mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
     
 
_46082543171087264*_46082543171087264 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
  meuAcaMA_veighEBRIakB 	 

     mocM9tIOQ8LUbJNUroqMJ 	 
    int _2654435874 mquKNlk6oUfOtB67zsUnK 	 
    	  
   0 mphZZ3fCwJsSsxkCdUmFA 	 
     _2654435874 mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     
   _2654435847 mqmJdruV3MIc9CcenzHlC 	 
    	  
    _2654435874 mP81FQC1rGzGFfKa8URMp 	 
    	  
    		   
     
   mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
     
 
  
     mQNMjVJ0N6wXPbs6_HgrA 	 
    	
         mXXe_01CFG5K_yWQao2rc 	 
    	  
    		   
    _11093821971816  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
   true miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
 
  
        const cv mj6J5HI5Xb31ztLB3vXf0 	 
    	  
    		   
     
     
 
  	 KeyPoint &_11093822348761  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		   _994360233184819249 mcHCA7rxsDvkL50CWbJel 	 
    	  
    		   
     
     
_7917477704619030428 mP7Vex3pSva4KZPEEVxol 	 
    	  _2654435874 mXsQ7EtcRLQCoGI0aWHVn 	 
    	  
    		.first mcdcf6DHXagTuHrurSaFD 	 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
 
        const cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
KeyPoint &_11093822348742  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
  _994360233184819248 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		  _7917477704619030428 mjYQT6j1wgaGgGYF1qJI3 	_2654435874 mcdcf6DHXagTuHrurSaFD 	 
    	  
    		   
     
     
 
 .second mXsQ7EtcRLQCoGI0aWHVn 	 
    	  
  mphZZ3fCwJsSsxkCdUmFA 	 
    	  
 
        const  mLm5pMwSjW11Fg7twfBaQ 	 
    	  
    		   
  _175247759835  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
      _11093822348761.pt.x mWugSXRRnAcAmUglBaEC8 	 
    	  
    		 
        const  mphegYaJkAj188nKLmOWT 	 
    	  
    	_175247760922  mKdGkjFaE0tmrjf5NTlkH 	 
    _11093822348761.pt.y mqmJdruV3MIc9CcenzHlC 	 
    	  
    
        const  mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
     
     
_175247759832  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
     _11093822348742.pt.x miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
 
        const  mYzukuoS5EuAVkLMj3HEJ 	 
    	  
    		   _175247760921  mYKy6VNQ57atCIXMTSpg8 	 
    	  
  _11093822348742.pt.y ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
        
        
        const  mG9tkXdonq5K1a5TTvWdA 	 _16937440141356181747  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
     
 
  	  1.0/ mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     
 
_3005401529527259663*_175247759832+_3005401529502477801*_175247760921+_3005401529495938372 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
  moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 
  	 
        const  mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
     
     _46082543236117216  mAd9SbOcAjVa1TnOyBE8u 	  m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
  _3005401529427071630*_175247759832+_3005401529421472443*_175247760921+_3005401529537514599 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
   *_16937440141356181747 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
        const  mb6bPPxBoRd5eWMKEY_T9 	 
    	  
    		   
 _46082576205740220  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 
  	  mndP4wnd7T2bJPpA9o8xa 	 
  _3005401529370179020*_175247759832+_3005401529369987001*_175247760921+_3005401529351329903 mCdmzaxCk0FZEnTCFHZG4 	 *_16937440141356181747 meuAcaMA_veighEBRIakB 	 
   
        const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  
    		   
   _13812273414234552516  mRg8w477JE_T_4vTAS6ye 	 
    	  
   mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     _175247759835-_46082543236117216 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
 * mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
_175247759835-_46082543236117216 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
 + mndP4wnd7T2bJPpA9o8xa 	 
    	 _175247760922-_46082576205740220 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		* mndP4wnd7T2bJPpA9o8xa 	 
    	  _175247760922-_46082576205740220 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
      mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
   
        const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  
    		   
    _14226755087262694000  mAd9SbOcAjVa1TnOyBE8u 	  _13812273414234552516*_9395000106275793626 moT_S9GDXH9l8dY4auCTp 	 
    	  
    
         mOHp6eii0W_CurvEO6nec 	 
    	  
    		   
     
     _14226755087262694000 mFQNQEJTD69vM27Yqioen 	 
    	  
    		   
 _175247759809 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		
            _11093821971816  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
 false mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     

        else
            _46082543172245582  mPR3TvQNUiORj8WMIQT4G 	 
    	   _175247759809 - _14226755087262694000 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
   
        
        
        const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  
    		   
     
     
 
_16937445645353283937  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 
  	  1.0/ mndP4wnd7T2bJPpA9o8xa 	 
    	 _11093822398298*_175247759835+_11093822398277*_175247760922+_11093822398276 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
      mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
   
        const  mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
    		   
     
     
 
  	 _46082543234721512  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
     
  mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     _11093822398429*_175247759835+_11093822398428*_175247760922+_11093822398403 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
 *_16937445645353283937 ma864P_Lsmg_HxSufe4co 	 
        const  mSe8inYVJuJ_SWpL20XSn 	 
    	  
    		   
     
     _46082576210450602  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		  m_Wv_6TxKoWyyVku_7IdC 	 
  _11093822398364*_175247759835+_11093822398365*_175247760922+_11093822398338 mEQcnCIKV2HBxhuocTqhm 	 
    	  
   *_16937445645353283937 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		
        const  mG9tkXdonq5K1a5TTvWdA 	 _13812273414234552517  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
    mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
 _175247759832-_46082543234721512 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    	* mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    _175247759832-_46082543234721512 mNWUNpWV7jCgmNO1ohXHk 	+ mndP4wnd7T2bJPpA9o8xa 	 
    	  
   _175247760921-_46082576210450602 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
  * mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
    _175247760921-_46082576210450602 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
  meuAcaMA_veighEBRIakB 	 
        const  mLm5pMwSjW11Fg7twfBaQ 	 
    	  
    		   
     
 _14226755087262694015  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
 _13812273414234552517*_9395000106275793626 mhif5Rqeg0n5IF_GvISmM 	 
    
         mjN40EFRrBDEp1gJGGIk5 	_14226755087262694015 mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
_175247759809 mytPitxa26I0boOQIsX_4 	 
    	  

            _11093821971816  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
   false ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
 
        else
            _46082543172245582  mBig1dgAg5rUJL0JFLOei 	 
     _175247759809 - _14226755087262694015 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
  
         mJhQ2aXInyVMFKRs37tY8 	 
    	  
    		   
     
    _11093821971816 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		
            _17271253899155467930 mnhg_U0H9OdjTJQTP6Gnv 	 
    	  
    		   
     
     
 
  _2654435874 mXsQ7EtcRLQCoGI0aWHVn 	 
   mquKNlk6oUfOtB67zsUnK 	 
    	  
  true meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
     
 
 
        else
            _17271253899155467930 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		   
     
     
 _2654435874 mIVJo0eWCM7NIdVTaOwOV 	 
     mXxeBOpcTlG_qg7UTBJrv 	 
    	  
 false mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
    
     mwQcD4iQwZzm1xNEBAXNS 	 
    	  
    		   

     mac78ewkKOOFBDPHhKb_r 	 
_46082543172245582 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		  
 mIyo8wONeLU1MQ6fYabD9 	 
    	  
 
 mzPAMkOuis3J5V8ino4fR 	 
    	  MapInitializer mj6J5HI5Xb31ztLB3vXf0 	 
    	  
    		   
     _9516949822686382330 mH9pmJdvECtnjBY1iswSZ 	 
    	  
 const cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
     
    Mat &_11093821994570, vector mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
    bool mhDKJw0vzmVidEdPlH7E5 	 
    	  
    		   &_17271253899155467930,  mphegYaJkAj188nKLmOWT 	 
    	  
    		   
     
     
 
  	 _46082543171087264 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		 
 mLNsbg8pyRFuUIp_R2v0d 	 
    	  
    	
    const  mbwK9Uiu2G1H3wMKMc3_w 	_2654435847  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 
 _7917477704619030428.size mQRZqQjaaMuE2ei53QVTa 	 
     moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 
  
    const  mSe8inYVJuJ_SWpL20XSn 	 
    	  
    		   
  _11093822386651  mYKy6VNQ57atCIXMTSpg8 	 
 _11093821994570.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		float mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
   mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     
 
0,0 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
  mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
    const  mG9tkXdonq5K1a5TTvWdA 	 
    	  
    		   
     
     
 
 _11093822386648  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   _11093821994570.at mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		   
     
     
 
float mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
     
 mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
    0,1 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
 
   mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
    const  mphegYaJkAj188nKLmOWT 	 
    	  
   _11093822386649  mYKy6VNQ57atCIXMTSpg8 	 
   _11093821994570.at mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   
     
     
 
float mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		 mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
    0,2 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
     
 
   mWugSXRRnAcAmUglBaEC8 	 
    const  mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
_11093822386584  mYKy6VNQ57atCIXMTSpg8 	 
    	  _11093821994570.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     
     
 float mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		 mGf46XpVsZXTkKG1xBF93 	 
    	  
    		  1,0 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
 meuAcaMA_veighEBRIakB 	 
 
    const  mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
  _11093822386587  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
     
 
  	  _11093821994570.at mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   
     
     
 float mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     
 
  1,1 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
      meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
 
    const  mIHMqjojFRuV5HLbqdMaZ 	 _11093822386586  meVN3qpUfWdh0L5zEBZMu 	 _11093821994570.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     
     
 
  float mFQNQEJTD69vM27Yqioen 	 
    	  
    		   
    mnqODtk__norexJDqFXYD 	 
    	  
1,2 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
  mqmJdruV3MIc9CcenzHlC 	 
    	  
 
    const  mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
    		   _11093822386521  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 _11093821994570.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
     
    float mFQNQEJTD69vM27Yqioen 	 
    	  
    		   
     
      mnqODtk__norexJDqFXYD 	 
    	  
    		   
  2,0 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
   mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
  	 
    const  mG9tkXdonq5K1a5TTvWdA 	 
    _11093822386522  meVN3qpUfWdh0L5zEBZMu 	 
    	  
   _11093821994570.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
     
 float mhDKJw0vzmVidEdPlH7E5 	 
    	  
    	 mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
2,1 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
 
   miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
 
    const  mLm5pMwSjW11Fg7twfBaQ 	 
    	_11093822386523  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
     
  _11093821994570.at mOc7dIIECwdrtfOiMRMNK 	 
 float mFQNQEJTD69vM27Yqioen 	 
    	  
     m_Wv_6TxKoWyyVku_7IdC 	 
    2,2 mKgK7IowyZjH5wyw0Bk8d 	 
     mwgiktLEfZPX6Q0iDYQaS 	 

    _17271253899155467930.resize mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
_2654435847 mKgK7IowyZjH5wyw0Bk8d 	 
    mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
   
     mSe8inYVJuJ_SWpL20XSn 	 
    _46082543172245582  mRg8w477JE_T_4vTAS6ye 	 
    	  
  0 miN6qFmUINJjKy7fxK3wO 	 
    	  
    	
    const  mYzukuoS5EuAVkLMj3HEJ 	 
    	  
    	_175247759809  meVN3qpUfWdh0L5zEBZMu 	 
    	  3.841 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		 
    const  mb6bPPxBoRd5eWMKEY_T9 	_6807155495820199660  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
   5.991 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
   
    const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  
    		   
 _9395000106275793626  mKdGkjFaE0tmrjf5NTlkH 	 
   1.0/ mtWHlKYJukh2L67HsjPLk 	 
   _46082543171087264*_46082543171087264 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
 
  ma864P_Lsmg_HxSufe4co 	
     muHcbKm0PMKyMsdXLtdOo 	 
    	  
    		 int _2654435874 mVybxT27lv2ZINx7C6UqB 	 
    	  
    		0 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
     
 
  	 _2654435874 mXuxUaHxxdF6zEQMdzmh7 	 
    	  
    		   
     
     _2654435847 mphZZ3fCwJsSsxkCdUmFA 	 
  _2654435874 mZAkrlrMBDBZeuyIOXq4K 	 
    	  
    		    mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		
     mhKeWI3YD4BRg9yhMiFLW 	 
    	  
    		   
     
     
 
 
         mePsroRdpIGpeDroobnZs 	 _11093821971816  mnCeFIsKlgUCPgBADbea8 	 
    true mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
 
        const cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     
KeyPoint &_11093822348761  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		   
     
 _994360233184819249 mnhg_U0H9OdjTJQTP6Gnv 	 
    	  
    		   
     
   _7917477704619030428 mzcl0385Kw18AGIpYCXsl 	 
    	  
 _2654435874 mV_aYzA2HerHHuuJvxPtT 	 
  .first maeuoWjF6xTdwN3myRAGg 	 
    	  mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		
        const cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		 KeyPoint &_11093822348742  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 
  _994360233184819248 mnhg_U0H9OdjTJQTP6Gnv 	 
    	  
   _7917477704619030428 mQAGEgppSBq9HmAWlAxgv 	 
    	  
    		   
     
  _2654435874 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
   .second maeuoWjF6xTdwN3myRAGg 	 
    	  
    		   
     
     
  ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
  
        const  mYzukuoS5EuAVkLMj3HEJ 	 
    	  
    		   
     
     _175247759835  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
    _11093822348761.pt.x meuAcaMA_veighEBRIakB 	 
    	  
   
        const  mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
     
     
 
  _175247760922  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
  _11093822348761.pt.y mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
        const  mb6bPPxBoRd5eWMKEY_T9 	 
    	  
    		  _175247759832  mVybxT27lv2ZINx7C6UqB 	 
    	  
  _11093822348742.pt.x mwgiktLEfZPX6Q0iDYQaS 	 
        const  mSe8inYVJuJ_SWpL20XSn 	 
    	  
    		   
     
  _175247760921  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		 _11093822348742.pt.y ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
        
        
        const  mYzukuoS5EuAVkLMj3HEJ 	 
    	  
   _175247762667  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 
 _11093822386651*_175247759835+_11093822386648*_175247760922+_11093822386649 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
        const  mphegYaJkAj188nKLmOWT 	 
    	  
 _175247762730  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		   _11093822386584*_175247759835+_11093822386587*_175247760922+_11093822386586 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
 
        const  mG9tkXdonq5K1a5TTvWdA 	 
    	  
    _175247762798  mKdGkjFaE0tmrjf5NTlkH 	 
    	  _11093822386521*_175247759835+_11093822386522*_175247760922+_11093822386523 meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
     
 
  	
        const  mLm5pMwSjW11Fg7twfBaQ 	 
    	  
    	_706246333051887  mO6JPHXzu68suopqQj4mY 	 _175247762667*_175247759832+_175247762730*_175247760921+_175247762798 moT_S9GDXH9l8dY4auCTp 	 
  
        const  mLm5pMwSjW11Fg7twfBaQ 	 _13812273414234552516  mRg8w477JE_T_4vTAS6ye 	 
  _706246333051887*_706246333051887/ m_Wv_6TxKoWyyVku_7IdC 	 
    	  _175247762667*_175247762667+_175247762730*_175247762730 mNWUNpWV7jCgmNO1ohXHk 	 
 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		
        const  mnvuJGwJpM4fXFpwwiBPR 	 
    	  
    		   
     
     
 
_14226755087262694000  mVybxT27lv2ZINx7C6UqB 	 
     _13812273414234552516*_9395000106275793626 moT_S9GDXH9l8dY4auCTp 	 
   
         mzxwfBAywHCahEEMgjDHn 	 
    	  
    		   
     
_14226755087262694000 mhDKJw0vzmVidEdPlH7E5 	 
    _175247759809 mKgK7IowyZjH5wyw0Bk8d 	 
 
            _11093821971816  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
   false miN6qFmUINJjKy7fxK3wO 	
        else
            _46082543172245582  mAh9WiJ5Sy1FhI1A81QHM 	 
    	  
    		   
  _6807155495820199660 - _14226755087262694000 mhif5Rqeg0n5IF_GvISmM 	 
    	  
 
        
        
        const  mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
    		   _175247762666  mVybxT27lv2ZINx7C6UqB 	 
   _11093822386651*_175247759832+_11093822386584*_175247760921+_11093822386521 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     

        const  mphegYaJkAj188nKLmOWT 	 
    	  
    		   
     
     
 
  	 _175247762731  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 _11093822386648*_175247759832+_11093822386587*_175247760921+_11093822386522 mDDVlrS4uMT9J_lN7fseh 	 
    	  
   
        const  mSe8inYVJuJ_SWpL20XSn 	 
    	  
 _175247762797  mRg8w477JE_T_4vTAS6ye 	 
    	  
  _11093822386649*_175247759832+_11093822386586*_175247760921+_11093822386523 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
  
        const  mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
    		   
     
     
 
  	_706246333051886  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
     
 _175247762666*_175247759835+_175247762731*_175247760922+_175247762797 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
        const  mb6bPPxBoRd5eWMKEY_T9 	 _13812273414234552517  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 
 _706246333051886*_706246333051886/ mndP4wnd7T2bJPpA9o8xa 	 
    	  _175247762666*_175247762666+_175247762731*_175247762731 mytPitxa26I0boOQIsX_4 	 
    	  mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
 
        const  mYzukuoS5EuAVkLMj3HEJ 	 
   _14226755087262694015  mVybxT27lv2ZINx7C6UqB 	 _13812273414234552517*_9395000106275793626 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 
  	
         mfIVnKehunlKlj05qT5YF 	 
   _14226755087262694015 ma5XrgW2ATI7PTDDXXfB3 	 
    	  
    		_175247759809 mtw53ct5rBcppMoQJ08KE 	 
   
            _11093821971816  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		    false mqmJdruV3MIc9CcenzHlC 	 
    	  
    		 
        else
            _46082543172245582  mBig1dgAg5rUJL0JFLOei 	 
    	  
    		   
     
  _6807155495820199660 - _14226755087262694015 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    
         mfIVnKehunlKlj05qT5YF 	 
    	  
    		   _11093821971816 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
   
            _17271253899155467930 mcHCA7rxsDvkL50CWbJel 	 
_2654435874 maN8Pf4K4wo4zg3O9vjkx 	 
    	  
    		   
     mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
  true mqmJdruV3MIc9CcenzHlC 	 
 
        else
            _17271253899155467930 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		  _2654435874 mtYTOdJ12b1xGaXXKiDjd 	 
     mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
   false miN6qFmUINJjKy7fxK3wO 	 
    	  
     mGSwaxZR6NaXV1nQzbnD4 	 
    	  
    		   
     
     
 

     mZsqgDOjDIWnGaZiccgxd 	 
    _46082543172245582 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
 
 mu1FnQFMDTSwPKm4knbOi 	 
    	  
    		   
     
     

 mOvTSzFoPpLPQmnInV4g_ 	 
    	  
    		   MapInitializer mlv1HNrEy8nKtkRAz1HIx 	 
    	  
   _1187546224459158354 mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     
 
 vector mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		bool mtjnvFto7OtvCeNoy20oi 	 
    &_17271253899155467930, cv mj6J5HI5Xb31ztLB3vXf0 	 
    	 Mat &_11093821994570, cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
 Mat &_2654435844,
                            cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
  Mat &_11093821901461, cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
     
 
  	 Mat &_11093822381707, vector mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
   cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		  Point3f mFQNQEJTD69vM27Yqioen 	  &_706246337618936, vector miCt6286SbYlHHngvumOf 	 
    	  
    		   
     
 bool mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
     
 
 &_1883142761634074017,  mG9tkXdonq5K1a5TTvWdA 	 
    	  
    		   
     
     
 _1686011036669914721,  mz0GR1i5BQSuWGPDXhIpA 	 
    	_3782192360946256634 mEQcnCIKV2HBxhuocTqhm 	 

 mqIOFzkzC3Vp68hRewvw_ 	 
    	
     mR_u0CRiVErFYF52pb6X5 	 
    	  
    		   
     
     
 _2654435847 meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     0 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    	
     mocM9tIOQ8LUbJNUroqMJ 	 
    	  
    		   
     
size_t _2654435874 mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
   0, _706246308776244  mRg8w477JE_T_4vTAS6ye 	 
  _17271253899155467930.size mNFlZ7jDo9yK4myRyxbPG 	 
    	  
    		   
     
     
  miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
   _2654435874 miCt6286SbYlHHngvumOf 	 
    	  
    		   
   _706246308776244 mwgiktLEfZPX6Q0iDYQaS 	 
    	  _2654435874 mjYiQ5PDu6c8QsGFAcfyI 	 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
         mjN40EFRrBDEp1gJGGIk5 	 
    	  
    		   
    _17271253899155467930 mnhg_U0H9OdjTJQTP6Gnv 	 
_2654435874 maeuoWjF6xTdwN3myRAGg 	 
    	  
    	 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
    
            _2654435847 mz7fxE30os9D4tNXhnqiQ 	 
    	  
    		   
   mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
    
    
    cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	 Mat _11093822702715  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     _2654435844.t mS37yKuJ9Qw3sTuJDSsaM 	 
    	 *_11093821994570*_2654435844 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
 
    cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		Mat _175247761703, _175247761702, _2654435885 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   

    
    _11668855431419298303 mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
    _11093822702715,_175247761703,_175247761702,_2654435885 mLFZtySqO_nDftJBgp1FK 	 
    	  
     mDDVlrS4uMT9J_lN7fseh 	 
    	  
      
    cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
 Mat _175247759768 mRg8w477JE_T_4vTAS6ye 	 
 _2654435885 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 
  	
    cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
 Mat _175247759771 mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
   -_2654435885 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
    
    vector miCt6286SbYlHHngvumOf 	 
    	  
    		   
    cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     Point3f mhDKJw0vzmVidEdPlH7E5 	 
    	  
  _46082576181793552, _46082576181793553, _46082576181793554, _46082576181793555 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 
  	
    vector miCt6286SbYlHHngvumOf 	 
    	  
    		 bool mtjnvFto7OtvCeNoy20oi 	 
    	  
    		   
      _10753448257785030707,_10753448257785030706,_10753448257785030709, _10753448257785030708 mphZZ3fCwJsSsxkCdUmFA 	 
    
     mG9tkXdonq5K1a5TTvWdA 	 
    	  
    		_1516225754718738891,_1516225754718738890, _1516225754718738889, _1516225754718738888 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
 
     mDMbTh7oHYwJwnASuTwGV 	 
_3005399802399529536  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
 _993392631849970936 mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
   _175247761703,_175247759768,_994360233184819249,_994360233184819248,_7917477704619030428,_17271253899155467930,_2654435844, _46082576181793552, 4.0*_994360216124235670, _10753448257785030707, _1516225754718738891 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     moT_S9GDXH9l8dY4auCTp 	 
    	  
    		
     mbwK9Uiu2G1H3wMKMc3_w 	 
    	  
  _3005399802399529537  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
 _993392631849970936 m_Wv_6TxKoWyyVku_7IdC 	 
    	  
 _175247761702,_175247759768,_994360233184819249,_994360233184819248,_7917477704619030428,_17271253899155467930,_2654435844, _46082576181793553, 4.0*_994360216124235670, _10753448257785030706, _1516225754718738890 mLFZtySqO_nDftJBgp1FK 	 
    	   meuAcaMA_veighEBRIakB 	 
 
     membkzbNyMSr1FS0Re8hM 	 
    	  
    		   
     
     
 _3005399802399529542  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
    _993392631849970936 mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
   _175247761703,_175247759771,_994360233184819249,_994360233184819248,_7917477704619030428,_17271253899155467930,_2654435844, _46082576181793554, 4.0*_994360216124235670, _10753448257785030709, _1516225754718738889 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
     
 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		
     mDMbTh7oHYwJwnASuTwGV 	 
    	  
    		   
     
    _3005399802399529543  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 _993392631849970936 mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
 _175247761702,_175247759771,_994360233184819249,_994360233184819248,_7917477704619030428,_17271253899155467930,_2654435844, _46082576181793555, 4.0*_994360216124235670, _10753448257785030708, _1516225754718738888 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 
  	 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
    
     mDMbTh7oHYwJwnASuTwGV 	 
    	  
    		 _6807036690970283909  mO6JPHXzu68suopqQj4mY 	 max mndP4wnd7T2bJPpA9o8xa 	 
    	 _3005399802399529536,max mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     
 _3005399802399529537,max mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
  _3005399802399529542,_3005399802399529543 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
    mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
   mKgK7IowyZjH5wyw0Bk8d 	  meuAcaMA_veighEBRIakB 	 
    	  
    		  
    _11093821901461  mYKy6VNQ57atCIXMTSpg8 	 
    	   cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
    		   
     
     
 Mat mQRZqQjaaMuE2ei53QVTa 	 
    	  
    		   
      mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		  
    _11093822381707  mO6JPHXzu68suopqQj4mY 	 
    cv mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   
     
     
 
  	Mat mQRZqQjaaMuE2ei53QVTa 	 
    	  
    mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 
     mxHuNimpe0L6Dg1FvdZJD 	 
    	  
    		   
     
     
 
 _16937194945473087812  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
    max mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     
 
  	static_cast mXuxUaHxxdF6zEQMdzmh7 	 
    int mRVv11jkqLVq83rwdiZNq 	 
   mndP4wnd7T2bJPpA9o8xa 	0.9*_2654435847 mP2AiGSIVV4QQ8S0_ZsB9 	 
,_3782192360946256634 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
      miN6qFmUINJjKy7fxK3wO 	 
  
     mbwK9Uiu2G1H3wMKMc3_w 	 
    	  
    		   
     
     
 
_16937373785260612085  mO6JPHXzu68suopqQj4mY 	 
 0 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
  	
     mItoNEXPmUd7PZnbkjY1u 	 
    	  
    		 _3005399802399529536 mRVv11jkqLVq83rwdiZNq 	 
  0.7*_6807036690970283909 mEQcnCIKV2HBxhuocTqhm 	 
    
        _16937373785260612085 mP81FQC1rGzGFfKa8URMp 	 
    	  
    		   
     
      mqmJdruV3MIc9CcenzHlC 	 
    	  
    		
     mOfnTUGa0UrxvKp2HRrB8 	 
    	  
    		   
     
     _3005399802399529537 ma5XrgW2ATI7PTDDXXfB3 	 
    	  
    		   
     
0.7*_6807036690970283909 mChkT2RjRR9l5VrNHoLpX 	
        _16937373785260612085 mjYiQ5PDu6c8QsGFAcfyI 	 
    	  
    		  mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
     
 

     mrP3ghTVta3Jw7IANk1Xx 	 
    	_3005399802399529542 mFQNQEJTD69vM27Yqioen 	 
    	  
    		   
0.7*_6807036690970283909 mCdmzaxCk0FZEnTCFHZG4 	 
        _16937373785260612085 mopowM6fbg9z5H_erpp5K 	 
    	  
   mphZZ3fCwJsSsxkCdUmFA 	 
 
     mJhQ2aXInyVMFKRs37tY8 	 
    	  
    		 _3005399802399529543 mtjnvFto7OtvCeNoy20oi 	 
    	  
    		   
     
     0.7*_6807036690970283909 mP2AiGSIVV4QQ8S0_ZsB9 	
        _16937373785260612085 mlfjux5PlAl152m6jAFfT 	 
    	  
    		   ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
  	
    
     mzxwfBAywHCahEEMgjDHn 	 
    	  
    		  _6807036690970283909 mXuxUaHxxdF6zEQMdzmh7 	_16937194945473087812  myPAQMpW1LsQon8rXUeSt 	 
    	  
    		   
     
   _16937373785260612085 mFQNQEJTD69vM27Yqioen 	 
    	  
  1 mLFZtySqO_nDftJBgp1FK 	 
    	  
  
     mKcwR_6MjpJ9NGpICycQ9 	
         mmUizHWq3YhaHQKSV1bIt 	 
false miN6qFmUINJjKy7fxK3wO 	 
   
     mu1FnQFMDTSwPKm4knbOi 	 
    	  
    		   
    
    
     mOHp6eii0W_CurvEO6nec 	 
    	  
    		   
     
     
 _6807036690970283909 myLdxSbKnyWYHY1ELQXsL 	 
    	  
    		   
     
    _3005399802399529536 mtw53ct5rBcppMoQJ08KE 	 
 
     mrFuQY6M9WWJeF7w9dgMm 	 
    	  
    		   
     
   
         mjN40EFRrBDEp1gJGGIk5 	 
    	  
    		   
     
 _1516225754718738891 mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
     
  _1686011036669914721 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
         mq6ps0_ThKFNGk0D_gUgC 	 
            _706246337618936  mquKNlk6oUfOtB67zsUnK 	 
  _46082576181793552 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
            _1883142761634074017  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
     _10753448257785030707 mDDVlrS4uMT9J_lN7fseh 	 
    	  
            _175247761703.copyTo mzrSELvIctMsJ9zj2Nm82 	 
    	  _11093821901461 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
      miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
   
            _175247759768.copyTo mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		_11093822381707 mytPitxa26I0boOQIsX_4 	 
   mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   

             my52yXW_6prFRkDuSZDWp 	 
    	  
 true mqmJdruV3MIc9CcenzHlC 	 
    	  
    		 
         modWmaDk0q35f0I_aGjz6 	 
    	  
 
     mwQcD4iQwZzm1xNEBAXNS 	 
else  mOHp6eii0W_CurvEO6nec 	 
    	  
_6807036690970283909 mfJt39SVsIcGuR4b5KG3K 	 
    	  
    		   
 _3005399802399529537 mEQcnCIKV2HBxhuocTqhm 	 
    	  
  
     mez3LQiFJeF2ZfEzjyQcK 	 
    	  
    		   
     
     
 
 
         mjN40EFRrBDEp1gJGGIk5 	 
    _1516225754718738890 mtjnvFto7OtvCeNoy20oi 	 
    	  
_1686011036669914721 mEQcnCIKV2HBxhuocTqhm 	 
    	  

         mq6ps0_ThKFNGk0D_gUgC 	 
    	  
            _706246337618936  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		 _46082576181793553 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
            _1883142761634074017  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     
 
  _10753448257785030706 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    	
            _175247761702.copyTo mndP4wnd7T2bJPpA9o8xa 	_11093821901461 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
      moT_S9GDXH9l8dY4auCTp 	 
    	
            _175247759768.copyTo mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    		_11093822381707 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
   mwgiktLEfZPX6Q0iDYQaS 	 
    	 
             mmUizHWq3YhaHQKSV1bIt 	 
    	  
    		   
     
     
 
  	 true mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		 
         mGSwaxZR6NaXV1nQzbnD4 	 

     mGSwaxZR6NaXV1nQzbnD4 	else  mOHp6eii0W_CurvEO6nec 	 
    	  
    		   
   _6807036690970283909 mD2IexDoxblgmPilJikzK 	 
    	  
 _3005399802399529542 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
     
 
     mGjrqvrVNVioUh48zGsmv 	 
    	  
    	
         mmy_gM6T1hmBPCCyiUjg_ 	 
    	  
    		   
     
_1516225754718738889 mtjnvFto7OtvCeNoy20oi 	 
    	  _1686011036669914721 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
   
         mKcwR_6MjpJ9NGpICycQ9 	 
    	  
    		   
     
     
 
 
            _706246337618936  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
     
  _46082576181793554 mqmJdruV3MIc9CcenzHlC 	
            _1883142761634074017  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
    _10753448257785030709 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
     
 
            _175247761703.copyTo mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
 _11093821901461 mChkT2RjRR9l5VrNHoLpX 	 mDDVlrS4uMT9J_lN7fseh 	 

            _175247759771.copyTo mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
   _11093822381707 mtw53ct5rBcppMoQJ08KE 	 
 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 
 
             mtQzym6pygKJNEFLY1zwp 	 
    	  
    		   
     
     
 
  	 true mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
     
 
  	
         myTopYZa7yIOxNFAqG2ln 	 
    	  
    		   
     
     
 
 
     mpq02WZd5llRC35g5Crra 	 
    	  
    		else  mzxwfBAywHCahEEMgjDHn 	 
    	  
    		   
   _6807036690970283909 mVe4dZBBJUVUI35vvA1Ox 	 
    	  
_3005399802399529543 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
  
     mqIOFzkzC3Vp68hRewvw_ 	 
    	 
         mfIVnKehunlKlj05qT5YF 	 
    	  
    		   
_1516225754718738888 mhDKJw0vzmVidEdPlH7E5 	 
    	  
    		_1686011036669914721 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
     
 

         mGjrqvrVNVioUh48zGsmv 	 
    	  
    		 
            _706246337618936  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
 _46082576181793555 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     

            _1883142761634074017  mO6JPHXzu68suopqQj4mY 	 
    	  _10753448257785030708 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     
 
            _175247761702.copyTo mLSm6RvP25h2mqMbhmWpr 	 
    	  
_11093821901461 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
  ma864P_Lsmg_HxSufe4co 	 
    	  
  
            _175247759771.copyTo mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
     
 
  	 _11093822381707 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
   moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   

             mzlU61CRdAJdTeqKQTVfM 	 
    	  true mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
         mv1ZUEjgm76AgfTPqDyj9 	 
    	  
    		   
     

     mUKDzj3AhlImVlcWctAq9 	 
    	  
    		   
     
     
 
  	
     mzlU61CRdAJdTeqKQTVfM 	 
    	  
    		   
     
     
 
  	false mwgiktLEfZPX6Q0iDYQaS 	 
    	
 mu1FnQFMDTSwPKm4knbOi 	 
    	  
  
 mldqDhxdMVwVsZ_sHFAvZ 	 
    	  
    		   
     
     
 MapInitializer mq2TZEVVkBWV8UUerawYu 	 _1187546224459158348 mnqODtk__norexJDqFXYD 	 
    vector mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     bool ma5XrgW2ATI7PTDDXXfB3 	 
    	  
  &_17271253899155467930, cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
   Mat &_11093822009278, cv mlv1HNrEy8nKtkRAz1HIx 	 
  Mat &_2654435844,
                      cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     
   Mat &_11093821901461, cv mYQOyfWlcv8BYXSMTquXE 	 
    	Mat &_11093822381707, vector mSoN5o2yDOJ80orgAcweO 	cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
  Point3f mLajHmFpSPs_tqjhga4nc 	 
    	  
    		   
     
     
 
  	 &_706246337618936, vector mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
    bool mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
  &_1883142761634074017,  mnvuJGwJpM4fXFpwwiBPR 	 
    	  
    		   
 _1686011036669914721,  mJeLsoxjVQgLOmHuDfdQp 	 
    	  
    		   
     _3782192360946256634 mKgK7IowyZjH5wyw0Bk8d 	 
  
 mGjrqvrVNVioUh48zGsmv 	 
    	  
    		   
     
     
 

     mbwK9Uiu2G1H3wMKMc3_w 	 
    	  
    		   
    _2654435847 mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
    0 mWugSXRRnAcAmUglBaEC8 	 
     muHcbKm0PMKyMsdXLtdOo 	 
    	  
    		   
 size_t _2654435874 meVN3qpUfWdh0L5zEBZMu 	 
    	  
0, _706246308776244  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		    _17271253899155467930.size mld7eZtCfa6r4ySUlfIqH 	  mphZZ3fCwJsSsxkCdUmFA 	 _2654435874 mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
    _706246308776244 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
    _2654435874 mZAkrlrMBDBZeuyIOXq4K 	 
    	  
    		   
     
 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   

         mJhQ2aXInyVMFKRs37tY8 	 
    	  
    		   
 _17271253899155467930 mfFZ_UoVScGXYqYaKarzZ 	 
    _2654435874 mXsQ7EtcRLQCoGI0aWHVn 	 
    	  
    		   
      mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
 
            _2654435847 mjYiQ5PDu6c8QsGFAcfyI 	 
     miN6qFmUINJjKy7fxK3wO 	 
 
    
    
    
    cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     
  Mat _706246308705964  mnCeFIsKlgUCPgBADbea8 	 
    	  
     _2654435844.inv mS37yKuJ9Qw3sTuJDSsaM 	 
    	  
    		   
   mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
 
    cv mYQOyfWlcv8BYXSMTquXE 	 
    	  Mat _2654435834  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		 _706246308705964*_11093822009278*_2654435844 mWugSXRRnAcAmUglBaEC8 	 
    	  
 
    cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
    		   
     
    Mat _2654435854,_2654435888,_175247763071,_2654435855 miN6qFmUINJjKy7fxK3wO 	
    cv mj6J5HI5Xb31ztLB3vXf0 	 
    	  
    		  SVD mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   
     
     
 
 compute mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
   _2654435834,_2654435888,_2654435854,_175247763071,cv mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
     
  SVD mq2TZEVVkBWV8UUerawYu 	 
    	  
   FULL_UV mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
      mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
 
    _2654435855 mRg8w477JE_T_4vTAS6ye 	 
  _175247763071.t mfB2pwxO8Kxzw5bVxoAWu 	 mphZZ3fCwJsSsxkCdUmFA 	 

     mnvuJGwJpM4fXFpwwiBPR 	 
_2654435884  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
  cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    determinant mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
   _2654435854 mChkT2RjRR9l5VrNHoLpX 	 *cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   determinant mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
   _175247763071 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    	 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 

     mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
     
     
 
_175247762860  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
     
 
 _2654435888.at mz5MCnH4XejHRq70OneDk 	 
    	  
    		   
     
   float mtjnvFto7OtvCeNoy20oi 	 
    	  
    		   
  mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    		   
     
     
 
0 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   

     mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
    		   
     
     _175247762863  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 
 _2654435888.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	 float mFQNQEJTD69vM27Yqioen 	 
    	  
     mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     
 
  	 1 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
  miN6qFmUINJjKy7fxK3wO 	 
 
     mnvuJGwJpM4fXFpwwiBPR 	 
    	  
    		   
     
    _175247762862  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
     
 
   _2654435888.at mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		   
     
    float mtjnvFto7OtvCeNoy20oi 	 
    	  
 mH9pmJdvECtnjBY1iswSZ 	 
    	  
  2 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
  mhif5Rqeg0n5IF_GvISmM 	 
    	  
  
     mmy_gM6T1hmBPCCyiUjg_ 	 
    	  
    		   
     
     
 
  	 _175247762860/_175247762863 mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
     
     
 
1.00001  mwmethC8hVoD4rfRzlkZn 	 
    	  
    		   
   _175247762863/_175247762862 miCt6286SbYlHHngvumOf 	 
    	  
    		   
     
     
 1.00001 mCdmzaxCk0FZEnTCFHZG4 	 
   
     mq6ps0_ThKFNGk0D_gUgC 	 
 
         myUcUn3yGjKvSAoM9tDZV 	 
    	  
    		   
     false mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     modWmaDk0q35f0I_aGjz6 	 
    	  
  
    vector mz5MCnH4XejHRq70OneDk 	 
    	  
   cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
 Mat mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
  _175247761017, _175247760983, _175247760989 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
  
    _175247761017.reserve mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		  8 mytPitxa26I0boOQIsX_4 	 
    	  
    		   mWugSXRRnAcAmUglBaEC8 	 
    	  
    _175247760983.reserve mxtASYvyLkypbQ3wKMYBi 	 8 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		  ma864P_Lsmg_HxSufe4co 	 
    	  
  
    _175247760989.reserve mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
   8 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
    
     mSe8inYVJuJ_SWpL20XSn 	 
    	 _706246337333900  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
      sqrt mnqODtk__norexJDqFXYD 	 
    	  
 mH9pmJdvECtnjBY1iswSZ 	 
    	  
_175247762860*_175247762860-_175247762863*_175247762863 mCYBip4Fq7RbZ3OmMjHQ0 	/ mH9pmJdvECtnjBY1iswSZ 	 
  _175247762860*_175247762860-_175247762862*_175247762862 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
     
 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    
     mphegYaJkAj188nKLmOWT 	 
    	  
    		   
     
_706246337333938  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
 sqrt mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
 mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     
 _175247762863*_175247762863-_175247762862*_175247762862 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
 / mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
     
 
 _175247762860*_175247762860-_175247762862*_175247762862 mChkT2RjRR9l5VrNHoLpX 	 
    	   mEQcnCIKV2HBxhuocTqhm 	 
    	   mphZZ3fCwJsSsxkCdUmFA 	 
    	  
     mYzukuoS5EuAVkLMj3HEJ 	 
    	  
 _175247761031 mD_2zWmARS3aJ6y6qfRH_ 	 
    	  
  mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
    meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
      mqlyrsy8ZoHxK2uKGCJKQ 	 
    	  
_706246337333900,_706246337333900,-_706246337333900,-_706246337333900 mwQcD4iQwZzm1xNEBAXNS 	 
    	  mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 
  
     mYzukuoS5EuAVkLMj3HEJ 	 
    	  
  _175247761033 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		   
     
    mcdcf6DHXagTuHrurSaFD 	 
    	  
    		   
     
       mnCeFIsKlgUCPgBADbea8 	 
    	   mLNsbg8pyRFuUIp_R2v0d 	 
    	_706246337333938,-_706246337333938,_706246337333938,-_706246337333938 modWmaDk0q35f0I_aGjz6 	 
    	  
    		   
     
     
 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   

    
     mSe8inYVJuJ_SWpL20XSn 	 
    	  
    	_6864651305897832470  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   sqrt mtWHlKYJukh2L67HsjPLk 	 
    	  
 mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
     
 
 _175247762860*_175247762860-_175247762863*_175247762863 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
   * mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
  _175247762863*_175247762863-_175247762862*_175247762862 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
     
 
/ m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
  mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		 _175247762860+_175247762862 mLFZtySqO_nDftJBgp1FK 	 
  *_175247762863 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
     
 
  	  moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
   
     mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
    		   
     
     
 
 _3005399638337628843  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
    m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
   _175247762863*_175247762863+_175247762860*_175247762862 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
     
 
 / m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    mGf46XpVsZXTkKG1xBF93 	 _175247762860+_175247762862 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
   *_175247762863 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
     
 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
 
     mSe8inYVJuJ_SWpL20XSn 	 
    	  
    		  _3005401602454656653 mfFZ_UoVScGXYqYaKarzZ 	 
    	   mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
     
      mYKy6VNQ57atCIXMTSpg8 	 
      mqIOFzkzC3Vp68hRewvw_ 	 
    	  
    		   
     
_6864651305897832470, -_6864651305897832470, -_6864651305897832470, _6864651305897832470 mu1FnQFMDTSwPKm4knbOi 	 ma864P_Lsmg_HxSufe4co 	 
    	  
 
     mYbdRpTrp0RuXQF49wcyY 	 
    	  
    		   
     
int _2654435874 mKdGkjFaE0tmrjf5NTlkH 	 
    	 0 moT_S9GDXH9l8dY4auCTp 	 _2654435874 mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		   
     
     
 4 mWugSXRRnAcAmUglBaEC8 	 
    	  
  _2654435874 mz7fxE30os9D4tNXhnqiQ 	 
  mP2AiGSIVV4QQ8S0_ZsB9 	 
  
     mKcwR_6MjpJ9NGpICycQ9 	 
   
        cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
  Mat _175247761760 mVybxT27lv2ZINx7C6UqB 	 
    	  
    		  cv mY10h4x_kRm6OheD9nzQP 	 
    	 Mat mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     
     
eye mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     
3,3,CV_32F mEQcnCIKV2HBxhuocTqhm 	 
   mWugSXRRnAcAmUglBaEC8 	
        _175247761760.at mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		   
float mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
    mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
     0,0 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
 mquKNlk6oUfOtB67zsUnK 	 
    	  _3005399638337628843 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		  
        _175247761760.at mXuxUaHxxdF6zEQMdzmh7 	 
    	  
  float mtjnvFto7OtvCeNoy20oi 	 
    	  
    		   
     
     
 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     
 0,2 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 
 mquKNlk6oUfOtB67zsUnK 	 
    	  
 -_3005401602454656653 mfN3ne3bwNdIV8GVYcoN0 	 
    	  
    		 _2654435874 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
     mphZZ3fCwJsSsxkCdUmFA 	 
   
        _175247761760.at mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   
  float mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
  mtWHlKYJukh2L67HsjPLk 	 
    	  
    2,0 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
     mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
    _3005401602454656653 mD_2zWmARS3aJ6y6qfRH_ 	 
    	  
    		   
     
     
 
_2654435874 maN8Pf4K4wo4zg3O9vjkx 	 
    	  
    		   
     
  ma864P_Lsmg_HxSufe4co 	 
        _175247761760.at mjMH4y_9O_liyFsbzDUxH 	 
    	  float mbUmWsXo_mt5YMuA0dRGj 	 
   mndP4wnd7T2bJPpA9o8xa 	 
    	  
2,2 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		 mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
     
_3005399638337628843 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
  
        cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
 Mat _2654435851  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
   _2654435884*_2654435854*_175247761760*_175247763071 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
        _175247761017.push_back mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     
 
 _2654435851 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     moT_S9GDXH9l8dY4auCTp 	 
    	  
 
        cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
     
 Mat _175247759833 m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
 3,1,CV_32F mytPitxa26I0boOQIsX_4 	 
    	  
    	 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 
  	
        _175247759833.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
   float mFQNQEJTD69vM27Yqioen 	 
    	   m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    	0 mCdmzaxCk0FZEnTCFHZG4 	 
     mAd9SbOcAjVa1TnOyBE8u 	 
    	  
_175247761031 mjYQT6j1wgaGgGYF1qJI3 	 
_2654435874 mcdcf6DHXagTuHrurSaFD 	 
    	  
    		   
     
     mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
     
 
  	
        _175247759833.at mz5MCnH4XejHRq70OneDk 	 
    	  
   float mRVv11jkqLVq83rwdiZNq 	 
 mzrSELvIctMsJ9zj2Nm82 	 
 1 mCYBip4Fq7RbZ3OmMjHQ0 	 mAd9SbOcAjVa1TnOyBE8u 	 
 0 mWugSXRRnAcAmUglBaEC8 	 
 
        _175247759833.at mSoN5o2yDOJ80orgAcweO 	 
 float mf1IuzucYIRUTpArzsx6l 	 
  mLSm6RvP25h2mqMbhmWpr 	 
    	 2 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
      mnCeFIsKlgUCPgBADbea8 	 
    	  
    -_175247761033 mjYQT6j1wgaGgGYF1qJI3 	 
    	  
    		   
     
     
 
 _2654435874 mIVJo0eWCM7NIdVTaOwOV 	 
  mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
  	 
        _175247759833 mO6ny4iGIfOhAtLBm6B0y 	 
    	  
    		   
 _175247762860-_175247762862 meuAcaMA_veighEBRIakB 	 
    	  
    
        cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
  Mat _2654435885  mYKy6VNQ57atCIXMTSpg8 	 
 _2654435854*_175247759833 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
 
        _175247760983.push_back mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
     
 
  	 _2654435885/cv mnc5AxXzr4BPppbUvP4FG 	norm mLSm6RvP25h2mqMbhmWpr 	 
    _2654435885 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
     mNWUNpWV7jCgmNO1ohXHk 	 
    	   miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
   
        cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
  Mat _175247759445 mH9pmJdvECtnjBY1iswSZ 	3,1,CV_32F mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
      mqmJdruV3MIc9CcenzHlC 	 
   
        _175247759445.at mXuxUaHxxdF6zEQMdzmh7 	float ma5XrgW2ATI7PTDDXXfB3 	 
 m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
0 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
 mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
 _175247761031 mP7Vex3pSva4KZPEEVxol 	 
    	  
    _2654435874 mNvx6y3h4uOynhxSbeSNQ 	 
    	  
    		   
     
     
 
 mqmJdruV3MIc9CcenzHlC 	
        _175247759445.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
     
     
 float mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
      mtgAIpqRx96Ug1UlUS5Ix 	 1 mLFZtySqO_nDftJBgp1FK 	 
     mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		  0 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
 
        _175247759445.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		 float mf1IuzucYIRUTpArzsx6l 	 
    	  
  mH9pmJdvECtnjBY1iswSZ 	 
 2 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
     
 
  	 _175247761033 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		   
     
     
 
  _2654435874 mcO5gre3n3Zakhk46a5sh 	 mwgiktLEfZPX6Q0iDYQaS 	 
        cv mNVpdluZuoiVIfdWKkNZz 	 Mat _2654435879  mXxeBOpcTlG_qg7UTBJrv 	 
    	   _2654435855*_175247759445 meuAcaMA_veighEBRIakB 	 
    	  
    		   
    
         mbQTs8ycowijFEWatBSew 	 
    	_2654435879.at mLqkqz1oj0n39qRbk3P0d 	 
    	float ma5XrgW2ATI7PTDDXXfB3 	 
    	  
    		    mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
   2 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
   mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
     
     0 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
     
 
  	
            _2654435879 meVN3qpUfWdh0L5zEBZMu 	-_2654435879 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   

        _175247760989.push_back m_Wv_6TxKoWyyVku_7IdC 	 
 _2654435879 mytPitxa26I0boOQIsX_4 	 
    	  
    		 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
     mu1FnQFMDTSwPKm4knbOi 	 
    	  
    		   
     
     
 
 
    
     mYzukuoS5EuAVkLMj3HEJ 	 
    	  
    		   
     
     
_16937291051106099375  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   sqrt mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     
 mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     _175247762860*_175247762860-_175247762863*_175247762863 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
   * mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   _175247762863*_175247762863-_175247762862*_175247762862 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 
 mtw53ct5rBcppMoQJ08KE 	 
    	  
    / mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
   _175247762860-_175247762862 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		*_175247762863 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
    mphZZ3fCwJsSsxkCdUmFA 	 
    	
     mLm5pMwSjW11Fg7twfBaQ 	 
    	  
    	_706246351275978  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
     
 
  	   mtWHlKYJukh2L67HsjPLk 	 
    	  
    		  _175247762860*_175247762862-_175247762863*_175247762863 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
 / mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		    mxtASYvyLkypbQ3wKMYBi 	 
    	  
   _175247762860-_175247762862 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
  *_175247762863 mKgK7IowyZjH5wyw0Bk8d 	 
 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
  
     mIHMqjojFRuV5HLbqdMaZ 	 _706246330201782 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		   
     
     
 
   mXztGjphv6NPOxrLSUEUq 	 
    	  
    		   
     
   mKdGkjFaE0tmrjf5NTlkH 	 
    mQNMjVJ0N6wXPbs6_HgrA 	 
    	  
    		   
  _16937291051106099375, -_16937291051106099375, -_16937291051106099375, _16937291051106099375 mu1FnQFMDTSwPKm4knbOi 	 
    	  mphZZ3fCwJsSsxkCdUmFA 	 
    	  
   
     mKIH773O9wMZYhjP_5r8R 	 
    	int _2654435874 mnCeFIsKlgUCPgBADbea8 	 
 0 mqmJdruV3MIc9CcenzHlC 	  _2654435874 mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
     
  4 meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
     _2654435874 mVntLRk8HoUsKvdPLyHta 	 
    	  
    		  mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
     
 
  
     mGjrqvrVNVioUh48zGsmv 	 
    	 
        cv mYQOyfWlcv8BYXSMTquXE 	 
    	 Mat _175247761760 mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     
 
  cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
  Mat mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		 eye mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
     
 3,3,CV_32F mKgK7IowyZjH5wyw0Bk8d 	 
     mqmJdruV3MIc9CcenzHlC 	
        _175247761760.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
     
     
 
  float mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
     
  m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
    0,0 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
   _706246351275978 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		
        _175247761760.at mz5MCnH4XejHRq70OneDk 	 
    float mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
     
  m_Wv_6TxKoWyyVku_7IdC 	 
    	 0,2 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
     
 
_706246330201782 mQAGEgppSBq9HmAWlAxgv 	 
    	  
    		   
     _2654435874 mcO5gre3n3Zakhk46a5sh 	 
    mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
    
        _175247761760.at mXuxUaHxxdF6zEQMdzmh7 	 
    	  
 float mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
     
     
 
 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
 1,1 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
    mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
-1 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
     
 
 
        _175247761760.at mjMH4y_9O_liyFsbzDUxH 	 
    	  
   float mbUmWsXo_mt5YMuA0dRGj 	 
  mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
    2,0 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
     
  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
     
 
_706246330201782 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
_2654435874 maN8Pf4K4wo4zg3O9vjkx 	 
   ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
        _175247761760.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
  float mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
     
     
 
   mxtASYvyLkypbQ3wKMYBi 	 
    2,2 mtw53ct5rBcppMoQJ08KE 	 
     mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     
-_706246351275978 mphZZ3fCwJsSsxkCdUmFA 	 
  
        cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  Mat _2654435851  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
  _2654435884*_2654435854*_175247761760*_175247763071 ma864P_Lsmg_HxSufe4co 	 
    
        _175247761017.push_back mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     
 _2654435851 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
     
 
 mDDVlrS4uMT9J_lN7fseh 	 
    	
        cv mGwfbPa_SpGojjnG4wAw9 	 
    Mat _175247759833 mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
 3,1,CV_32F mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
   mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		
        _175247759833.at mnuDYya_hKIe0F8_gsRLN 	 
    	 float mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
      mndP4wnd7T2bJPpA9o8xa 	 
 0 mKgK7IowyZjH5wyw0Bk8d 	 mquKNlk6oUfOtB67zsUnK 	 
_175247761031 mfN3ne3bwNdIV8GVYcoN0 	 
    	  
  _2654435874 maN8Pf4K4wo4zg3O9vjkx 	 
  mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
     
        _175247759833.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    float mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
     
     
 
  m_Wv_6TxKoWyyVku_7IdC 	 
    1 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
   mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
0 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
    
        _175247759833.at mXuxUaHxxdF6zEQMdzmh7 	 float mbUmWsXo_mt5YMuA0dRGj 	 
 m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
   2 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   meVN3qpUfWdh0L5zEBZMu 	 
    	  
    _175247761033 mP7Vex3pSva4KZPEEVxol 	 
    	_2654435874 maN8Pf4K4wo4zg3O9vjkx 	 
    	  mhif5Rqeg0n5IF_GvISmM 	 
    	 
        _175247759833 mqCRyvIJKLz8u93spsWKA 	 
    	  
    		  _175247762860+_175247762862 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   

        cv mq2TZEVVkBWV8UUerawYu 	 
    	  
  Mat _2654435885  mYKy6VNQ57atCIXMTSpg8 	 
    	  
 _2654435854*_175247759833 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     

        _175247760983.push_back m_Wv_6TxKoWyyVku_7IdC 	 
  _2654435885/cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     
   norm mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
    _2654435885 mKgK7IowyZjH5wyw0Bk8d 	 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	   ma864P_Lsmg_HxSufe4co 	 
    	  
    		 
        cv mj6J5HI5Xb31ztLB3vXf0 	 
    	  
    		  Mat _175247759445 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     3,1,CV_32F mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
     
 
  mqmJdruV3MIc9CcenzHlC 	 
    	 
        _175247759445.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
float mLajHmFpSPs_tqjhga4nc 	 
    	  
    		    mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
0 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
  mYKy6VNQ57atCIXMTSpg8 	 _175247761031 mjYQT6j1wgaGgGYF1qJI3 	 
    	  
    _2654435874 maeuoWjF6xTdwN3myRAGg 	 
    	  
    		   
     
    mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
  
        _175247759445.at mnuDYya_hKIe0F8_gsRLN 	float mW2ZPvWHsb0kj8UsemkMz 	 
 mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
  1 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     mVybxT27lv2ZINx7C6UqB 	 
    	  
  0 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
 
        _175247759445.at mLqkqz1oj0n39qRbk3P0d 	float mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   mtWHlKYJukh2L67HsjPLk 	 
    	  
    		  2 mtw53ct5rBcppMoQJ08KE 	 mKdGkjFaE0tmrjf5NTlkH 	 _175247761033 mnhg_U0H9OdjTJQTP6Gnv 	_2654435874 mcdcf6DHXagTuHrurSaFD 	 
    	  
    		   
     mWugSXRRnAcAmUglBaEC8 	 
        cv mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		Mat _2654435879  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
     
  _2654435855*_175247759445 ma864P_Lsmg_HxSufe4co 	 
   
         mOfnTUGa0UrxvKp2HRrB8 	 
_2654435879.at miCt6286SbYlHHngvumOf 	 
    	  
    		   
     
     
 
float mRVv11jkqLVq83rwdiZNq 	 
    	  
   mtgAIpqRx96Ug1UlUS5Ix 	 
    	  
    		   
     
     
2 mtw53ct5rBcppMoQJ08KE 	 
    	  
     mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
     
     0 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		
            _2654435879 mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		-_2654435879 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
        _175247760989.push_back mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
_2654435879 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
      mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    	
     m_BWrKK8L6uUnA_8Q3ZnA 	 
    	  
    		
     mxHuNimpe0L6Dg1FvdZJD 	 
    _16940367568810760802  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		    0 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     

     mxHuNimpe0L6Dg1FvdZJD 	 
    	  
    		   
     
     
 
  	 _9505321537286276156  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   0 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
        
     mIl8Bz4oYM1DbDYC1fzl4 	 
   _2570993952652048401  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		   
  -1 mqmJdruV3MIc9CcenzHlC 	 
  
     mphegYaJkAj188nKLmOWT 	 
    	  
  _5965360956970359603  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     -1 miN6qFmUINJjKy7fxK3wO 	 
    	  
    vector mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		  cv mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
     
     
 
  	Point3f mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
     
     
 
  	 _6806984971934296172 miN6qFmUINJjKy7fxK3wO 	
    vector mnuDYya_hKIe0F8_gsRLN 	 
    	  
    bool mf1IuzucYIRUTpArzsx6l 	 
    	  
    		   _13793248373315477956 mwgiktLEfZPX6Q0iDYQaS 	 

    
    
     mYbdRpTrp0RuXQF49wcyY 	 
    	  
    		   
     
     size_t _2654435874 mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
 0 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 
  	  _2654435874 mSoN5o2yDOJ80orgAcweO 	 
    	  
 8 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     _2654435874 mlfjux5PlAl152m6jAFfT 	 
    	  
    		   
   mLFZtySqO_nDftJBgp1FK 	 
    	  

     mGjrqvrVNVioUh48zGsmv 	 
    	  
  
         mnvuJGwJpM4fXFpwwiBPR 	 
    	  
    		   
     
     _1516225754718738707 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
    
        vector mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		 Point3f mhDKJw0vzmVidEdPlH7E5 	 
    	  
    		   
     
     
 
  	 _46082576181793496 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 
  	
        vector mXuxUaHxxdF6zEQMdzmh7 	 bool mtjnvFto7OtvCeNoy20oi 	 
     _10753448257785030763 meuAcaMA_veighEBRIakB 	
         mVHJ9I6jPcpbqQB9bqhTz 	 
    	  
    		   
     
    _46082575790776546  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
 _993392631849970936 mxtASYvyLkypbQ3wKMYBi 	 
  _175247761017 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
 _2654435874 mcO5gre3n3Zakhk46a5sh 	 
    	  
  ,_175247760983 mzcl0385Kw18AGIpYCXsl 	 
    	  
    		   
     
     
 
  	_2654435874 mXsQ7EtcRLQCoGI0aWHVn 	 
    	  ,_994360233184819249,_994360233184819248,_7917477704619030428,_17271253899155467930,_2654435844,_46082576181793496, 4.0*_994360216124235670, _10753448257785030763, _1516225754718738707 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
     
 
  	  meuAcaMA_veighEBRIakB 	 
    	  
    		   
     

         mOfnTUGa0UrxvKp2HRrB8 	 
    	  
    		   
  _46082575790776546 mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
     
 _16940367568810760802 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
  
         mGjrqvrVNVioUh48zGsmv 	 
    	  
    		   
     
    
            _9505321537286276156  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
     
 
  	 _16940367568810760802 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
   
            _16940367568810760802  mKdGkjFaE0tmrjf5NTlkH 	 
 _46082575790776546 mDDVlrS4uMT9J_lN7fseh 	 

            _2570993952652048401  mRg8w477JE_T_4vTAS6ye 	 
    	  
  _2654435874 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		
            _5965360956970359603  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
   _1516225754718738707 meuAcaMA_veighEBRIakB 	 
    	  
    		   
 
            _6806984971934296172  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
  _46082576181793496 mqmJdruV3MIc9CcenzHlC 	 
   
            _13793248373315477956  meVN3qpUfWdh0L5zEBZMu 	  _10753448257785030763 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		 
         mGSwaxZR6NaXV1nQzbnD4 	 
         mzsfWWbrltNhNi_qG2Ose 	 
    	  
    		   
 mjN40EFRrBDEp1gJGGIk5 	 
   _46082575790776546 mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
     
     
 
  	_9505321537286276156 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
  
         mGjrqvrVNVioUh48zGsmv 	 
    	  
    		   
     
 
            _9505321537286276156  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
 _46082575790776546 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
     
 
 
         mwQcD4iQwZzm1xNEBAXNS 	 
    	  
    		   
     
    
     mUKDzj3AhlImVlcWctAq9 	 
    	  

     mfIVnKehunlKlj05qT5YF 	 
    	  
    		   
   _9505321537286276156 mXuxUaHxxdF6zEQMdzmh7 	 
  0.75*_16940367568810760802  mAsjWuz0pGT4X3UULs6vr 	 
    	  
    _5965360956970359603 mdb0HRqlxqtf9slEU7FuY 	 
    	  
    		   
     
     
 
  _1686011036669914721  mWUhiqv5bIQxvo40Le8M0 	 
    _16940367568810760802 mW2ZPvWHsb0kj8UsemkMz 	 
 _3782192360946256634  mTYOP2KZp4yLVtn2HTvHU 	 _16940367568810760802 ma5XrgW2ATI7PTDDXXfB3 	 
    	  
    		   
     
0.9*_2654435847 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		  
     mqIOFzkzC3Vp68hRewvw_ 	
        _175247761017 mfN3ne3bwNdIV8GVYcoN0 	 
    	  
    		   
_2570993952652048401 maeuoWjF6xTdwN3myRAGg 	 
    	  
.copyTo m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
 _11093821901461 mytPitxa26I0boOQIsX_4 	 
    	  
    ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
 
        _175247760983 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
     _2570993952652048401 mcdcf6DHXagTuHrurSaFD 	 
    	  
    		 .copyTo mtWHlKYJukh2L67HsjPLk 	 
    	  
    		_11093822381707 mtw53ct5rBcppMoQJ08KE 	 
     moT_S9GDXH9l8dY4auCTp 	 
    	  
    		
        _706246337618936  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
 _6806984971934296172 mDDVlrS4uMT9J_lN7fseh 	 
    
        _1883142761634074017  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
     
  _13793248373315477956 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
  
         myUcUn3yGjKvSAoM9tDZV 	 
    	  
    		   
     
     
 
true mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     m_BWrKK8L6uUnA_8Q3ZnA 	
     my52yXW_6prFRkDuSZDWp 	 
  false ma864P_Lsmg_HxSufe4co 	 
    	  
 myTopYZa7yIOxNFAqG2ln 	 
    	  
    		   
     
   
 mOWYQ3OmlR6NgTKssoAIn 	 
    	  MapInitializer mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
  _13188689179917490056 mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
     
const cv mnc5AxXzr4BPppbUvP4FG 	 
 KeyPoint &_11093822348761, const cv mj6J5HI5Xb31ztLB3vXf0 	 
KeyPoint &_11093822348742, const cv mq2TZEVVkBWV8UUerawYu 	 
    	  
 Mat &_175247761573, const cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
     
 
  	Mat &_175247761572, cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	Mat &_11093821939030 mEQcnCIKV2HBxhuocTqhm 	 
    	  

 mq6ps0_ThKFNGk0D_gUgC 	 
    	  
    		   
 
    cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
  Mat _2654435834 mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
 4,4,CV_32F mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
    mphZZ3fCwJsSsxkCdUmFA 	 
    _2654435834.row mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
     
 0 mLFZtySqO_nDftJBgp1FK 	 
    mVybxT27lv2ZINx7C6UqB 	  _11093822348761.pt.x*_175247761573.row mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
    2 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
   -_175247761573.row m_Wv_6TxKoWyyVku_7IdC 	0 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
   moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   

    _2654435834.row mLSm6RvP25h2mqMbhmWpr 	 
1 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 
  	  mKdGkjFaE0tmrjf5NTlkH 	 
  _11093822348761.pt.y*_175247761573.row m_Wv_6TxKoWyyVku_7IdC 	 
    	 2 mtw53ct5rBcppMoQJ08KE 	-_175247761573.row mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
  1 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     mqmJdruV3MIc9CcenzHlC 	 
    	  
    		  
    _2654435834.row mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		 2 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     mO6JPHXzu68suopqQj4mY 	 
    	  
  _11093822348742.pt.x*_175247761572.row mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
    2 mEQcnCIKV2HBxhuocTqhm 	 
    	-_175247761572.row m_Wv_6TxKoWyyVku_7IdC 	 
0 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    	 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
  	
    _2654435834.row m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    	3 mLFZtySqO_nDftJBgp1FK 	 
    	  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
  _11093822348742.pt.y*_175247761572.row mxtASYvyLkypbQ3wKMYBi 	 
   2 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
    -_175247761572.row mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
     
 
 1 mP2AiGSIVV4QQ8S0_ZsB9 	 
   miN6qFmUINJjKy7fxK3wO 	 
    	  
 
    cv mWkXRNO1Jxx7qH3BJU2Yy 	Mat _2654435886,_2654435888,_175247760983 mWugSXRRnAcAmUglBaEC8 	 
 
    cv mnc5AxXzr4BPppbUvP4FG 	 
    SVD mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		compute mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
 _2654435834,_2654435888,_2654435886,_175247760983,cv mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   
     
     
 
SVD mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   MODIFY_A| cv mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
     
 SVD mlv1HNrEy8nKtkRAz1HIx 	 
    	 FULL_UV mEQcnCIKV2HBxhuocTqhm 	 mDDVlrS4uMT9J_lN7fseh 	 
   
    _11093821939030  mRg8w477JE_T_4vTAS6ye 	 
    	  
    	 _175247760983.row mH9pmJdvECtnjBY1iswSZ 	 
    3 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
     
 
.t mld7eZtCfa6r4ySUlfIqH 	 
    	  
  mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
 
    _11093821939030  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
     
 
  	 _11093821939030.rowRange mtgAIpqRx96Ug1UlUS5Ix 	 
    	0,3 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
  /_11093821939030.at miCt6286SbYlHHngvumOf 	 float mbUmWsXo_mt5YMuA0dRGj 	 mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
  3 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
   
 mIyo8wONeLU1MQ6fYabD9 	 
    	  
    		   
     
     
 
  
 mF7w1U5nk2MTMLDTmLBOJ 	 
    	  
    		   
     
     
 
  MapInitializer mY10h4x_kRm6OheD9nzQP 	 
 _12337435833092867029 mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
     
 
const vector mLqkqz1oj0n39qRbk3P0d 	 cv mj6J5HI5Xb31ztLB3vXf0 	KeyPoint mtjnvFto7OtvCeNoy20oi 	 
    	  
    		   
     
  &_46082576192198777, vector mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
  cv mj6J5HI5Xb31ztLB3vXf0 	 
    	  Point2f mFQNQEJTD69vM27Yqioen 	 
    	  
    	 &_11959346835625416039, cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
    Mat &_2654435853 mEQcnCIKV2HBxhuocTqhm 	 
    	  
 mq6ps0_ThKFNGk0D_gUgC 	 
    	  
    		  
     mLm5pMwSjW11Fg7twfBaQ 	 
    	  
    		   
     
   _46082575822310300  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
  0 mphZZ3fCwJsSsxkCdUmFA 	 
    	
     mLm5pMwSjW11Fg7twfBaQ 	 
    	  
  _46082575822310301  mO6JPHXzu68suopqQj4mY 	 
    	  
   0 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 
  	 
    const  mxHuNimpe0L6Dg1FvdZJD 	_2654435847  mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   _46082576192198777.size mS37yKuJ9Qw3sTuJDSsaM 	 
  ma864P_Lsmg_HxSufe4co 	 
 
    _11959346835625416039.resize mxtASYvyLkypbQ3wKMYBi 	 
    	  
  _2654435847 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
     
     moT_S9GDXH9l8dY4auCTp 	 
    	  
  
     mYbdRpTrp0RuXQF49wcyY 	 
    	  
    		   
   int _2654435874 mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 
  	 0 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		    _2654435874 mOc7dIIECwdrtfOiMRMNK 	 
    	  
  _2654435847 miN6qFmUINJjKy7fxK3wO 	 
 _2654435874 mopowM6fbg9z5H_erpp5K 	 
    	   mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
   
     mqlyrsy8ZoHxK2uKGCJKQ 	 
    	  
    
        _46082575822310300  mRRxLUZFhIyMm4fVOuYH2 	 
    	  
    		   
     
     
 
  	 _46082576192198777 mP7Vex3pSva4KZPEEVxol 	 
    	 _2654435874 mV_aYzA2HerHHuuJvxPtT 	 
    	  
    		   
     
     
 
.pt.x ma864P_Lsmg_HxSufe4co 	 
    	
        _46082575822310301  mkZfslnsB4E4XCg4ewCkh 	 
    	  
    		    _46082576192198777 mzcl0385Kw18AGIpYCXsl 	 
    	  
    		   
     
    _2654435874 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
     
  .pt.y ma864P_Lsmg_HxSufe4co 	
     mUKDzj3AhlImVlcWctAq9 	 
    	  
    		   
  
    _46082575822310300  mRg8w477JE_T_4vTAS6ye 	 
    	  
 _46082575822310300/_2654435847 meuAcaMA_veighEBRIakB 	 
    	  
    		   
     

    _46082575822310301  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
   _46082575822310301/_2654435847 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
  
     mG9tkXdonq5K1a5TTvWdA 	 
    	  
    		   
     
     _16937206910726371261  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		    0 meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
     mSe8inYVJuJ_SWpL20XSn 	 
    	  
    		   
     
     
 
  	 _16937206910726371262  mRg8w477JE_T_4vTAS6ye 	 
  0 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     

     mpWzKYjiXpd4bF_NzlE7q 	 
    	  
    		   
int _2654435874 mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
     
 
0 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
 _2654435874 mPLxnLLY_ZIq7Cn8Gyj0y 	 
  _2654435847 mDDVlrS4uMT9J_lN7fseh 	 
    	  _2654435874 mz7fxE30os9D4tNXhnqiQ 	 
    	  
    		   
     
     
 
  mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
    
     mez3LQiFJeF2ZfEzjyQcK 	 
    	  
    		   
 
        _11959346835625416039 mnhg_U0H9OdjTJQTP6Gnv 	 
    	  
    		   
     
     
 
 _2654435874 mNvx6y3h4uOynhxSbeSNQ 	 
    	  
    		   
     
 .x  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   _46082576192198777 mD_2zWmARS3aJ6y6qfRH_ 	 
    	  
_2654435874 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
     
 .pt.x - _46082575822310300 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
 
        _11959346835625416039 mnhg_U0H9OdjTJQTP6Gnv 	 
    _2654435874 mcdcf6DHXagTuHrurSaFD 	 
    	  
    		  .y  mRg8w477JE_T_4vTAS6ye 	 
  _46082576192198777 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
     
     
 
_2654435874 mXsQ7EtcRLQCoGI0aWHVn 	 
    	  
    		   
     
 .pt.y - _46082575822310301 mhif5Rqeg0n5IF_GvISmM 	 

        _16937206910726371261  mngvt_AEOnxcjjVOMNH1l 	 
    	  
   fabs mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     _11959346835625416039 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
 _2654435874 maN8Pf4K4wo4zg3O9vjkx 	 
    	  
    	.x mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
     
 
   mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		 
        _16937206910726371262  mV_udCF3k7PmtzngrfHoD 	 
   fabs mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
    _11959346835625416039 mnhg_U0H9OdjTJQTP6Gnv 	 
    	  
 _2654435874 maeuoWjF6xTdwN3myRAGg 	 
    	 .y mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
     
 

     mpq02WZd5llRC35g5Crra 	 
   
    _16937206910726371261  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 
   _16937206910726371261/_2654435847 moT_S9GDXH9l8dY4auCTp 	 
    	  
    
    _16937206910726371262  mYKy6VNQ57atCIXMTSpg8 	 _16937206910726371262/_2654435847 meuAcaMA_veighEBRIakB 	 
    	  
    		
     mSe8inYVJuJ_SWpL20XSn 	 
 _175247759792  mRg8w477JE_T_4vTAS6ye 	 1.0/_16937206910726371261 mWugSXRRnAcAmUglBaEC8 	 
    	 
     mLm5pMwSjW11Fg7twfBaQ 	 
    	_175247759793  mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
      1.0/_16937206910726371262 ma864P_Lsmg_HxSufe4co 	 
    	
     mAnexmimtA4aulnTFqO1Z 	 
    	  
    		   
     
    int _2654435874 mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    	0 meuAcaMA_veighEBRIakB 	 
    	  
  _2654435874 mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
_2654435847 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
 _2654435874 mz7fxE30os9D4tNXhnqiQ 	 mtw53ct5rBcppMoQJ08KE 	 
     mez3LQiFJeF2ZfEzjyQcK 	 
    	  
   
        _11959346835625416039 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
     
_2654435874 mcdcf6DHXagTuHrurSaFD 	.x  mquKNlk6oUfOtB67zsUnK 	 
    	  
   _11959346835625416039 mfFZ_UoVScGXYqYaKarzZ 	 
    	_2654435874 mIVJo0eWCM7NIdVTaOwOV 	 
 .x * _175247759792 meuAcaMA_veighEBRIakB 	 
    	
        _11959346835625416039 mjYQT6j1wgaGgGYF1qJI3 	 
    	_2654435874 maN8Pf4K4wo4zg3O9vjkx 	 
    	  
    		   
  .y  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
     
 
  	 _11959346835625416039 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
     
     
 
  	_2654435874 mXztGjphv6NPOxrLSUEUq 	 
    	  
    		   
     
     
 .y * _175247759793 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     
     
     mUKDzj3AhlImVlcWctAq9 	 
    	  
    		   
  
    _2654435853  mRg8w477JE_T_4vTAS6ye 	 
    	  
   cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
     
 Mat mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    	eye mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		 3,3,CV_32F mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   

    _2654435853.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  float mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
 0,0 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
      meVN3qpUfWdh0L5zEBZMu 	 
 _175247759792 moT_S9GDXH9l8dY4auCTp 	 
  
    _2654435853.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     
     
 float mFQNQEJTD69vM27Yqioen 	 
    	   mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     
 
  1,1 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
    _175247759793 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
    
    _2654435853.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
     
  float mFQNQEJTD69vM27Yqioen 	 mzrSELvIctMsJ9zj2Nm82 	 
    	  
0,2 mytPitxa26I0boOQIsX_4 	 
    	  
  mnCeFIsKlgUCPgBADbea8 	 
    	  
    		  -_46082575822310300*_175247759792 ma864P_Lsmg_HxSufe4co 	 
    	  

    _2654435853.at mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   
     
   float mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
    mzrSELvIctMsJ9zj2Nm82 	 
   1,2 mytPitxa26I0boOQIsX_4 	  mO6JPHXzu68suopqQj4mY 	 
    -_46082575822310301*_175247759793 meuAcaMA_veighEBRIakB 	 
    	  
    		   
     
     
 

 mu1FnQFMDTSwPKm4knbOi 	 
    	  
    		   
     
    
 mbwK9Uiu2G1H3wMKMc3_w 	 
    	MapInitializer mGwfbPa_SpGojjnG4wAw9 	 
    	  
    		   
     
     _993392631849970936 mtgAIpqRx96Ug1UlUS5Ix 	 
    const cv mWkXRNO1Jxx7qH3BJU2Yy 	 
Mat &_2654435851, const cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
     
  Mat &_2654435885, const vector mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   
     
     cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
KeyPoint mFQNQEJTD69vM27Yqioen 	 
   &_3005399810348660273, const vector mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		   
     
     
 
cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
    		   
     
     
 
  	KeyPoint mW2ZPvWHsb0kj8UsemkMz 	 
 &_3005399810348660272,
                       const vector mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		   
     
     
 
  Match mf1IuzucYIRUTpArzsx6l 	 
    	  
    		    &_5507076421631549640, vector mSoN5o2yDOJ80orgAcweO 	 
    	  
    		   
     
 bool mf1IuzucYIRUTpArzsx6l 	 
    &_17271253899155467930,
                       const cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
Mat &_2654435844, vector mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		   
     
     
 
  	cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
Point3f mbUmWsXo_mt5YMuA0dRGj 	 &_706246337618936,  mnvuJGwJpM4fXFpwwiBPR 	 
    	  
    		   
     
    _11093822376282, vector mSoN5o2yDOJ80orgAcweO 	 
    	  
    		 bool mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    	 &_3005399809928654743,  mphegYaJkAj188nKLmOWT 	 
    	  
    		   
     
  &_16937213055926717083 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
     
 
  	 
 mrFuQY6M9WWJeF7w9dgMm 	 
    	  
    		  
    
    const  mG9tkXdonq5K1a5TTvWdA 	 
    	  
_175247759975  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 
 _2654435844.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
float mW2ZPvWHsb0kj8UsemkMz 	  mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
    0,0 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
 ma864P_Lsmg_HxSufe4co 	 
    	  
    		 
    const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  _175247759974  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
     
  _2654435844.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   
     
  float ma5XrgW2ATI7PTDDXXfB3 	 
    	  
    		   
     
     
 
   mLSm6RvP25h2mqMbhmWpr 	 1,1 mLFZtySqO_nDftJBgp1FK 	 
    	  mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 
    const  mIHMqjojFRuV5HLbqdMaZ 	 
    	  
    		   
_175247762852  mYKy6VNQ57atCIXMTSpg8 	 
  _2654435844.at mjMH4y_9O_liyFsbzDUxH 	 
    	  
    		   float mLajHmFpSPs_tqjhga4nc 	 
    	  
     mLSm6RvP25h2mqMbhmWpr 	 
    	  
 0,2 mytPitxa26I0boOQIsX_4 	 
     mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
     
    const  mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  
    		 _175247762853  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
      _2654435844.at mPLxnLLY_ZIq7Cn8Gyj0y 	 
    	  
    		float mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   
     
     
  m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
     
 
1,2 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    	 mwgiktLEfZPX6Q0iDYQaS 	 
 
    _3005399809928654743  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		   
     
    vector mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     
     
bool ma5XrgW2ATI7PTDDXXfB3 	 
    	  
    		   
   mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
     
 
 _3005399810348660273.size mQrFq8uaXPUzfDZoyla5j 	 
    	  
    		 ,false mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
    miN6qFmUINJjKy7fxK3wO 	
    _706246337618936.resize mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
 _3005399810348660273.size mLxofLAyBTLsEaqCJekNX 	 
    	  
    		   
     
   mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     mqmJdruV3MIc9CcenzHlC 	 
    	  
    		  
    vector mSf7M2lLnQTHwMbqH_RRR 	 
    	  
 float mtjnvFto7OtvCeNoy20oi 	 
    	  
    		  _5800553007209659840 mphZZ3fCwJsSsxkCdUmFA 	 
  
    _5800553007209659840.reserve mndP4wnd7T2bJPpA9o8xa 	 
    	  
    		   
     
     _3005399810348660273.size mLxofLAyBTLsEaqCJekNX 	 
    	  
    		  mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
  miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     

    
    cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
     
 
Mat _175247761573 mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
  3,4,CV_32F,cv mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   
Scalar mxtASYvyLkypbQ3wKMYBi 	 0 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
      mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     ma864P_Lsmg_HxSufe4co 	 
    	  
  
    _2654435844.copyTo mGf46XpVsZXTkKG1xBF93 	 
    	  
   _175247761573.rowRange mH9pmJdvECtnjBY1iswSZ 	 
   0,3 mLFZtySqO_nDftJBgp1FK 	 
    	  
    	.colRange mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
   0,3 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
     
 
   mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
     
     mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
    cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
    Mat _175247761508  mnCeFIsKlgUCPgBADbea8 	  cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
    		   
     
     
 
Mat mlv1HNrEy8nKtkRAz1HIx 	zeros mnqODtk__norexJDqFXYD 	 
    	  
3,1,CV_32F mKgK7IowyZjH5wyw0Bk8d 	 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
    
    cv mbM6_YQUbxQ4zrU3yKhUm 	 
    Mat _175247761572 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
  3,4,CV_32F mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
      mhif5Rqeg0n5IF_GvISmM 	 
    	 
    _2654435851.copyTo mnqODtk__norexJDqFXYD 	 
    	  
_175247761572.rowRange mGf46XpVsZXTkKG1xBF93 	0,3 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
     
     
.colRange mtWHlKYJukh2L67HsjPLk 	 
    	  0,3 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
     
  mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 
  	  mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		
    _2654435885.copyTo mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     _175247761572.rowRange m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
 0,3 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
     
     
 
 .col mGf46XpVsZXTkKG1xBF93 	 
    	  
    		 3 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
  ma864P_Lsmg_HxSufe4co 	 
    	  
   
    _175247761572  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
     
 
  	 _2654435844*_175247761572 mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
     
 
  	 
    cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		   
 Mat _175247761509  mYKy6VNQ57atCIXMTSpg8 	 
 -_2654435851.t mS37yKuJ9Qw3sTuJDSsaM 	 
    	  
    		   
     
    *_2654435885 mhif5Rqeg0n5IF_GvISmM 	 
     membkzbNyMSr1FS0Re8hM 	 
    	  
    		   
     
   _46082575790776546 mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
 0 moT_S9GDXH9l8dY4auCTp 	 
    	
     muHcbKm0PMKyMsdXLtdOo 	 size_t _2654435874 meVN3qpUfWdh0L5zEBZMu 	 
    	  
    0, _706246308776244 mVybxT27lv2ZINx7C6UqB 	 
   _5507076421631549640.size mfB2pwxO8Kxzw5bVxoAWu 	 
    	   miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
   _2654435874 mnuDYya_hKIe0F8_gsRLN 	_706246308776244 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 
 _2654435874 mz7fxE30os9D4tNXhnqiQ 	 
    	  
  mtw53ct5rBcppMoQJ08KE 	 
    	  
     mrFuQY6M9WWJeF7w9dgMm 	 
    	  
    		   
   
         mOHp6eii0W_CurvEO6nec 	 
  mo44bndgqstU5qGZyR5R3 	 
    	  
    		   
 _17271253899155467930 mP7Vex3pSva4KZPEEVxol 	 
    	  _2654435874 mV_aYzA2HerHHuuJvxPtT 	  mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
     
 

            continue moT_S9GDXH9l8dY4auCTp 	 
    	  
    
        const cv mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   
     
    KeyPoint &_11093822348761  mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
     
     
 
 _3005399810348660273 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
     
     
 
 _5507076421631549640 mcHCA7rxsDvkL50CWbJel 	 
    	  
    		   
    _2654435874 mXsQ7EtcRLQCoGI0aWHVn 	 .first mXztGjphv6NPOxrLSUEUq 	 
    	  
    		   ma864P_Lsmg_HxSufe4co 	 
    	
        const cv mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
 KeyPoint &_11093822348742  mO6JPHXzu68suopqQj4mY 	 
  _3005399810348660272 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		   
     
     
_5507076421631549640 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
     
     
_2654435874 mXztGjphv6NPOxrLSUEUq 	 
    	  
    		   
     
    .second mXztGjphv6NPOxrLSUEUq 	 
    	  
    		   
     
     
 
  	 miN6qFmUINJjKy7fxK3wO 	 

        cv mbM6_YQUbxQ4zrU3yKhUm 	 
    	  
    		   
     
     
 
  	Mat _46082575776159025 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		 
        _13188689179917490056 m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
    _11093822348761,_11093822348742,_175247761573,_175247761572,_46082575776159025 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    	
         mbQTs8ycowijFEWatBSew 	 
    	  
    		   
      mLdaISEo61F2B0GtUcMub 	isfinite mtgAIpqRx96Ug1UlUS5Ix 	_46082575776159025.at mLqkqz1oj0n39qRbk3P0d 	 
    	  
    	float mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   mtWHlKYJukh2L67HsjPLk 	 
    	  
 0 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
   mKgK7IowyZjH5wyw0Bk8d 	 
     mujD1_l8DTz3zW3wg5fYN 	 
    	   mUpfv8Yhd38cmHAGvwFql 	 
    	  
    		   
     
   isfinite mGf46XpVsZXTkKG1xBF93 	 
    	  
    		_46082575776159025.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
 float mvXqUis778sIFsZW5vtV5 	 
    	  
    		   mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
    1 mNWUNpWV7jCgmNO1ohXHk 	 
    mytPitxa26I0boOQIsX_4 	 
    	   myPAQMpW1LsQon8rXUeSt 	 
    	  
    		   
       mEQtvhnpwdYUEFRaazDJZ 	 
    	  
    		   
     
 isfinite mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
     
 
  	_46082575776159025.at mSf7M2lLnQTHwMbqH_RRR 	float mtjnvFto7OtvCeNoy20oi 	 
    	  
    		   
     
     mtWHlKYJukh2L67HsjPLk 	 
    	2 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
     mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
     
 
  	 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
  
         mGjrqvrVNVioUh48zGsmv 	 
    	
            _3005399809928654743 mcHCA7rxsDvkL50CWbJel 	 
    	  
_5507076421631549640 mQAGEgppSBq9HmAWlAxgv 	 
    	  
    		   
     
     
 _2654435874 mcdcf6DHXagTuHrurSaFD 	 
    	  
    		   
     
    .first mtYTOdJ12b1xGaXXKiDjd 	 
   mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
 false mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
     
            continue meuAcaMA_veighEBRIakB 	 
    	  
  
         myTopYZa7yIOxNFAqG2ln 	
        
        cv mj6J5HI5Xb31ztLB3vXf0 	 
    	  
  Mat _6807036687918592958  mYKy6VNQ57atCIXMTSpg8 	 
    	  
    		   
     
 _46082575776159025 - _175247761508 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     
     
 
  	
         mnvuJGwJpM4fXFpwwiBPR 	 
    	  
 _46082575013947785  meVN3qpUfWdh0L5zEBZMu 	 
   cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
    		norm mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
     
 
  _6807036687918592958 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
   moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     

        cv mj6J5HI5Xb31ztLB3vXf0 	 
    	  
    		   Mat _6807036687918592959  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
     _46082575776159025 - _175247761509 miN6qFmUINJjKy7fxK3wO 	 
    	  
   
         mZ8_hrlTxQvpZ68ZNjaa7 	 
    	  _46082575013947784  mRg8w477JE_T_4vTAS6ye 	 
    	  
    cv mq2TZEVVkBWV8UUerawYu 	 
    	 norm mLSm6RvP25h2mqMbhmWpr 	 
    	_6807036687918592959 mytPitxa26I0boOQIsX_4 	 mphZZ3fCwJsSsxkCdUmFA 	 
  
         mYzukuoS5EuAVkLMj3HEJ 	 
    	  
    		   
     
     
 
  	_6065268260414012491  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
   _6807036687918592958.dot mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		   
     
_6807036687918592959 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
/ mLSm6RvP25h2mqMbhmWpr 	 
  _46082575013947785*_46082575013947784 mEQcnCIKV2HBxhuocTqhm 	 
 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 

        
         mfIVnKehunlKlj05qT5YF 	 _46082575776159025.at mz5MCnH4XejHRq70OneDk 	 
  float mRVv11jkqLVq83rwdiZNq 	 
   mLSm6RvP25h2mqMbhmWpr 	2 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
      mZPkZQMjIRl7FhHYgfU_t 	 
    	  
    		   
     
     
 
  	0  mk7FE4eYNO0y0kGHA79xJ 	 _6065268260414012491 mOc7dIIECwdrtfOiMRMNK 	 
    	  
    		   0.99998 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		
            continue miN6qFmUINJjKy7fxK3wO 	 
    	  

        
        cv mj6J5HI5Xb31ztLB3vXf0 	 
Mat _46082575776159024  mnCeFIsKlgUCPgBADbea8 	 
    	  
     _2654435851*_46082575776159025+_2654435885 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
     
 
  	 
         mOHp6eii0W_CurvEO6nec 	 
    	  
    _46082575776159024.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
     
   float mf1IuzucYIRUTpArzsx6l 	 
    	  
    		   m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
   2 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
 mopuiW_wWLEb7vbueUpbT 	 
    	  
    		   
     
  0  mCL5MoSEtL6Z8UCGU6IqO 	 
    	   _6065268260414012491 mSoN5o2yDOJ80orgAcweO 	 
    	  
0.99998 mtw53ct5rBcppMoQJ08KE 	 
  
            continue mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
  
        
         mzPAMkOuis3J5V8ino4fR 	 
    	  
    		   
 _706246308812856, _706246308812859 meuAcaMA_veighEBRIakB 	 
 
         mIHMqjojFRuV5HLbqdMaZ 	_46082544220862540  meVN3qpUfWdh0L5zEBZMu 	 
     1.0/_46082575776159025.at miCt6286SbYlHHngvumOf 	 
    	  
    		   
     
float mLajHmFpSPs_tqjhga4nc 	 
    	  
    		   
 mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
   2 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
      mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 
 
        _706246308812856  mAd9SbOcAjVa1TnOyBE8u 	 
    	  
    		   
     
     
 _175247759975*_46082575776159025.at mnuDYya_hKIe0F8_gsRLN 	 
    	 float mtjnvFto7OtvCeNoy20oi 	 mLSm6RvP25h2mqMbhmWpr 	0 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     
 
  	 *_46082544220862540+_175247762852 mhif5Rqeg0n5IF_GvISmM 	 
    	  
        _706246308812859  meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     
 _175247759974*_46082575776159025.at miCt6286SbYlHHngvumOf 	 
    	  
    		   
    float mRVv11jkqLVq83rwdiZNq 	 
    	  
    		   mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   
     
     1 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
*_46082544220862540+_175247762853 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 

         mIHMqjojFRuV5HLbqdMaZ 	 
    	  
 _11817497959695576683  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
   mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
     
 
  	_706246308812856-_11093822348761.pt.x mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
     
 
  	* m_Wv_6TxKoWyyVku_7IdC 	 
   _706246308812856-_11093822348761.pt.x mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
    + mtWHlKYJukh2L67HsjPLk 	 
_706246308812859-_11093822348761.pt.y mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
     
     * mGf46XpVsZXTkKG1xBF93 	 
    	  
 _706246308812859-_11093822348761.pt.y mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
  ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
   
         mjN40EFRrBDEp1gJGGIk5 	 
    	  
_11817497959695576683 mf1IuzucYIRUTpArzsx6l 	 
    	  
  _11093822376282 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
    
            continue mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 

        
         mSe8inYVJuJ_SWpL20XSn 	 
    	  
    		   
  _706246308812923, _706246308812920 meuAcaMA_veighEBRIakB 	 
    	  
   
         mnvuJGwJpM4fXFpwwiBPR 	 
_46082544220862543  mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		  1.0/_46082575776159024.at mLqkqz1oj0n39qRbk3P0d 	float mf1IuzucYIRUTpArzsx6l 	 
    	  
    		   
 mnqODtk__norexJDqFXYD 	 
    	  
    		   2 mKgK7IowyZjH5wyw0Bk8d 	 
     miN6qFmUINJjKy7fxK3wO 	 
    	  
        _706246308812923  mRg8w477JE_T_4vTAS6ye 	 
    	 _175247759975*_46082575776159024.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
    float mbUmWsXo_mt5YMuA0dRGj 	 
    	  
    		   
     
    mxtASYvyLkypbQ3wKMYBi 	 
    	  
    	0 mLFZtySqO_nDftJBgp1FK 	*_46082544220862543+_175247762852 moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
 
        _706246308812920  mO6JPHXzu68suopqQj4mY 	 
    	  
    		  _175247759974*_46082575776159024.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     float mFQNQEJTD69vM27Yqioen 	 
    	  
    		  mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
1 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		   
 *_46082544220862543+_175247762853 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
     
 
  
         mnvuJGwJpM4fXFpwwiBPR 	 
    	  
    		_11817497959695576682  mRg8w477JE_T_4vTAS6ye 	 
    	  
  mxtASYvyLkypbQ3wKMYBi 	 _706246308812923-_11093822348742.pt.x mKgK7IowyZjH5wyw0Bk8d 	 
    	  * mtWHlKYJukh2L67HsjPLk 	 
    	  
   _706246308812923-_11093822348742.pt.x mytPitxa26I0boOQIsX_4 	 
    	  
    		   
    + mtWHlKYJukh2L67HsjPLk 	_706246308812920-_11093822348742.pt.y mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     * mnqODtk__norexJDqFXYD 	 
    	  
    		_706246308812920-_11093822348742.pt.y mEQcnCIKV2HBxhuocTqhm 	 
   meuAcaMA_veighEBRIakB 	 
    	  
    		   
         mOHp6eii0W_CurvEO6nec 	 
    	  
    		   
     
_11817497959695576682 mvXqUis778sIFsZW5vtV5 	 
    _11093822376282 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   

            continue meuAcaMA_veighEBRIakB 	 
    	  
  
        _5800553007209659840.push_back m_Wv_6TxKoWyyVku_7IdC 	 
    	  
    		   
     
_6065268260414012491 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
    moT_S9GDXH9l8dY4auCTp 	 
    	  
    		   
     
        _706246337618936 mP7Vex3pSva4KZPEEVxol 	 
    	  
    		   
    _5507076421631549640 mQAGEgppSBq9HmAWlAxgv 	 
_2654435874 mXsQ7EtcRLQCoGI0aWHVn 	 
    	  
    .first mcdcf6DHXagTuHrurSaFD 	 
    	  
    mnCeFIsKlgUCPgBADbea8 	 
    	  
    		  cv mq2TZEVVkBWV8UUerawYu 	 
    	  
 Point3f mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   _46082575776159025.at mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
  float mtjnvFto7OtvCeNoy20oi 	 
    	  mGf46XpVsZXTkKG1xBF93 	 
    	  
  0 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
    ,_46082575776159025.at mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
     
  float ma5XrgW2ATI7PTDDXXfB3 	 
     mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		   1 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
   ,_46082575776159025.at mXuxUaHxxdF6zEQMdzmh7 	 
    	  
    		  float mRVv11jkqLVq83rwdiZNq 	 
 mnqODtk__norexJDqFXYD 	 
    	  
  2 mP2AiGSIVV4QQ8S0_ZsB9 	 
   mytPitxa26I0boOQIsX_4 	 
    	  
    		    mqmJdruV3MIc9CcenzHlC 	 
    	  
    	
        _46082575790776546 mz7fxE30os9D4tNXhnqiQ 	 
    	  
    		    mqmJdruV3MIc9CcenzHlC 	 
    	  
  
         mOHp6eii0W_CurvEO6nec 	 
   _6065268260414012491 mXuxUaHxxdF6zEQMdzmh7 	 
  0.99998 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
     
     
 
  	 
            _3005399809928654743 mZWq1iKb1zKB_JmpMJfNM 	 
    	  
    		   
     
     
 
  	_5507076421631549640 mP7Vex3pSva4KZPEEVxol 	 
    	  
   _2654435874 maeuoWjF6xTdwN3myRAGg 	 
    	  
    		   
     
 .first mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
   mquKNlk6oUfOtB67zsUnK 	 
    	  
true mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		 
     mv1ZUEjgm76AgfTPqDyj9 	 

     mItoNEXPmUd7PZnbkjY1u 	 
    	_46082575790776546 mf1IuzucYIRUTpArzsx6l 	 
  0 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		 
     mQNMjVJ0N6wXPbs6_HgrA 	 
    	 
        sort mH9pmJdvECtnjBY1iswSZ 	 
    	  
    		   
     
 _5800553007209659840.begin mDTsdPpCq4eSuuI3mubBO 	 
    	  
    	,_5800553007209659840.end mLxofLAyBTLsEaqCJekNX 	 
    	  mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     mhif5Rqeg0n5IF_GvISmM 	 
  
        size_t _11093822405045  mAd9SbOcAjVa1TnOyBE8u 	 
 min mnqODtk__norexJDqFXYD 	 50,int mtWHlKYJukh2L67HsjPLk 	 
    	  
   _5800553007209659840.size mld7eZtCfa6r4ySUlfIqH 	 
    	  
   -1 mCdmzaxCk0FZEnTCFHZG4 	 
    	  
    		   
     
     mNWUNpWV7jCgmNO1ohXHk 	 
   meuAcaMA_veighEBRIakB 	 
 
        _16937213055926717083  mXxeBOpcTlG_qg7UTBJrv 	 
    	  
    		   
     
   acos mLSm6RvP25h2mqMbhmWpr 	 
    	  
   _5800553007209659840 mfFZ_UoVScGXYqYaKarzZ 	 
    	  
    		   
     
     
 
  _11093822405045 mtYTOdJ12b1xGaXXKiDjd 	 
    	 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
  *180/CV_PI mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 
  	 
     mu1FnQFMDTSwPKm4knbOi 	 
    
    else
        _16937213055926717083 mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
   0 mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
     

     mtQzym6pygKJNEFLY1zwp 	 
    	  
    		   
     
     
_46082575790776546 mwgiktLEfZPX6Q0iDYQaS 	
 mIyo8wONeLU1MQ6fYabD9 	 
    	  
    		   
   
 mZW8uOzgXIREMjSM9lHwb 	MapInitializer mlv1HNrEy8nKtkRAz1HIx 	 
    _11668855431419298303 mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		 const cv mWkXRNO1Jxx7qH3BJU2Yy 	Mat &_2654435838, cv mj6J5HI5Xb31ztLB3vXf0 	 
    	  
    		   
     
     
 
  	 Mat &_175247761703, cv mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
     
     
Mat &_175247761702, cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
     
     
 
 Mat &_2654435885 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
    		   
     
 
 mez3LQiFJeF2ZfEzjyQcK 	
    cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
    	Mat _2654435886,_2654435888,_175247760983 mphZZ3fCwJsSsxkCdUmFA 	 
    	  
    		   
     
 
    cv mGwfbPa_SpGojjnG4wAw9 	 
    	  
SVD mnc5AxXzr4BPppbUvP4FG 	 
    	  
    		   
     
     
 compute mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
     
 _2654435838,_2654435888,_2654435886,_175247760983 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
      mWugSXRRnAcAmUglBaEC8 	 
    	  
    		   
 
    _2654435886.col mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
     
2 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
     .copyTo mxtASYvyLkypbQ3wKMYBi 	_2654435885 mChkT2RjRR9l5VrNHoLpX 	 
    	  
    		   
   mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     

    _2654435885 meVN3qpUfWdh0L5zEBZMu 	 
    	  
    		   
     
     _2654435885/cv mYQOyfWlcv8BYXSMTquXE 	 
    	  
 norm mzrSELvIctMsJ9zj2Nm82 	 
    	  
    		_2654435885 mytPitxa26I0boOQIsX_4 	 
    	  
    		   
     
   mhif5Rqeg0n5IF_GvISmM 	 
    	  
    		   
    cv mWkXRNO1Jxx7qH3BJU2Yy 	 
    	  
    		   
   Mat _2654435856 mtgAIpqRx96Ug1UlUS5Ix 	3,3,CV_32F,cv mq2TZEVVkBWV8UUerawYu 	 
    	  
    		   Scalar mtWHlKYJukh2L67HsjPLk 	 
    	  
    		   
0 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
 mKgK7IowyZjH5wyw0Bk8d 	 
   mhif5Rqeg0n5IF_GvISmM 	 
    	 
    _2654435856.at mLqkqz1oj0n39qRbk3P0d 	 
  float mRVv11jkqLVq83rwdiZNq 	 
    	  
  mLSm6RvP25h2mqMbhmWpr 	 
    	  
0,1 mEQcnCIKV2HBxhuocTqhm 	 
    	  
    		 mVybxT27lv2ZINx7C6UqB 	 
   -1 miN6qFmUINJjKy7fxK3wO 	 
    	
    _2654435856.at mOc7dIIECwdrtfOiMRMNK 	 
    	  
  float mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
     
     
 
   mLSm6RvP25h2mqMbhmWpr 	 
    	1,0 mP2AiGSIVV4QQ8S0_ZsB9 	 
    	 mquKNlk6oUfOtB67zsUnK 	 
1 ma864P_Lsmg_HxSufe4co 	 
    	
    _2654435856.at mjMH4y_9O_liyFsbzDUxH 	 
 float mf1IuzucYIRUTpArzsx6l 	 
    	  
    		   
     
     
  mGf46XpVsZXTkKG1xBF93 	 
    	  
    		   
     
 2,2 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
 mRg8w477JE_T_4vTAS6ye 	 
    	  
    		   
  1 miN6qFmUINJjKy7fxK3wO 	 
    	  
  
    _175247761703  mVybxT27lv2ZINx7C6UqB 	 
    _2654435886*_2654435856*_175247760983 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     mbQTs8ycowijFEWatBSew 	 
  cv mlv1HNrEy8nKtkRAz1HIx 	 
    	  
    		   
     
determinant m_Wv_6TxKoWyyVku_7IdC 	 
    	  
 _175247761703 mNWUNpWV7jCgmNO1ohXHk 	 
    	  
   mLqkqz1oj0n39qRbk3P0d 	 
    	  
    		   0 mCYBip4Fq7RbZ3OmMjHQ0 	 
    	  
    		   
     
     
 

        _175247761703 mO6JPHXzu68suopqQj4mY 	 
    	  
    		   
     
     
 -_175247761703 meuAcaMA_veighEBRIakB 	 
    
    _175247761702  mVybxT27lv2ZINx7C6UqB 	 
    	  
    		   
     
   _2654435886*_2654435856.t mS37yKuJ9Qw3sTuJDSsaM 	 
    	  
    		   
     
   *_175247760983 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    	
     mOfnTUGa0UrxvKp2HRrB8 	 
    	  
    		  cv mNVpdluZuoiVIfdWKkNZz 	 
    	  
    		   
     
     
determinant mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
     
 
_175247761702 mtw53ct5rBcppMoQJ08KE 	 
    	  
    		   
     
     
 
 mnuDYya_hKIe0F8_gsRLN 	 
    	  
    		   
     
 0 mChkT2RjRR9l5VrNHoLpX 	 

        _175247761702 mXxeBOpcTlG_qg7UTBJrv 	 
   -_175247761702 mqmJdruV3MIc9CcenzHlC 	
 mIyo8wONeLU1MQ6fYabD9 	 

 mePsroRdpIGpeDroobnZs 	MapInitializer mYQOyfWlcv8BYXSMTquXE 	 
    	  
 _7274126694617365277 mtWHlKYJukh2L67HsjPLk 	 
    const Frame &_46082543180066935, std mY10h4x_kRm6OheD9nzQP 	 
    	  
    		   
     
     
 
  shared_ptr mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		   
  Map mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
   _11093822290287 mLFZtySqO_nDftJBgp1FK 	 
    	  
    	 mhKeWI3YD4BRg9yhMiFLW 	 
    	  
    		   
     
     
 


    
     mVHJ9I6jPcpbqQB9bqhTz 	 
    	  
    		   
     
     
 
  	 _18242569162703393014 mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
     
 
  	 0 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     mpWzKYjiXpd4bF_NzlE7q 	 
    	  
    		   
     
     
 size_t _2654435878 mKdGkjFaE0tmrjf5NTlkH 	 
    	  
    		   
     
    0 miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
    _2654435878 mSf7M2lLnQTHwMbqH_RRR 	 
    	  
    		 _46082543180066935.markers.size mQrFq8uaXPUzfDZoyla5j 	 
    	 mwgiktLEfZPX6Q0iDYQaS 	 
    	  
    		   
     
     
 _2654435878 mjYiQ5PDu6c8QsGFAcfyI 	 
     mCdmzaxCk0FZEnTCFHZG4 	  mq6ps0_ThKFNGk0D_gUgC 	 
    
         mWvtBeVmHAPDjWPyb2fw6 	 
    	  
    		   
     
     
 
   mLSm6RvP25h2mqMbhmWpr 	 
    	  
    		   
     
     
 
  _46082543180066935.markers mfN3ne3bwNdIV8GVYcoN0 	 
    	 _2654435878 mV_aYzA2HerHHuuJvxPtT 	 
    	  
    		   .poses.err_ratio mW2ZPvWHsb0kj8UsemkMz 	 
    	  
    		   
 _params.aruco_minerrratio_valid mChkT2RjRR9l5VrNHoLpX 	 
    	  
    
            _18242569162703393014 mMbR8sME8lT9WWeXIiFbW 	 
    	  
   miN6qFmUINJjKy7fxK3wO 	 
    	  
    		   
     
     

     mwQcD4iQwZzm1xNEBAXNS 	 
    	  
    	
     mAHfPw6Pm0C_EGwBYeW6O 	 
    	  
     mnqODtk__norexJDqFXYD 	 
    	  
    		   
     
     
_18242569162703393014 mx5nL5_uWKTn0_18VrhrS 	 
    	  
    		   
     
     
 0 mtw53ct5rBcppMoQJ08KE 	 
    return false mwgiktLEfZPX6Q0iDYQaS 	 
    	  
 
     mMGByMmoaX_KkNHqSQTHW 	 
    	  
    		   
     
     
 
  	&_18139480568557707913 mnCeFIsKlgUCPgBADbea8 	 
    	  
    		   
_11093822290287 mf_8X46PeArmbvEUOoYbz 	 
    	  
    	addKeyFrame mtgAIpqRx96Ug1UlUS5Ix 	_46082543180066935 mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
  mqmJdruV3MIc9CcenzHlC 	 

    _18139480568557707913.pose_f2g mquKNlk6oUfOtB67zsUnK 	 
    	  
    		   
     
     se3 mxtASYvyLkypbQ3wKMYBi 	 
    	  
    		0,0,0,0,0,0 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
      mWugSXRRnAcAmUglBaEC8 	 
    	  

     mocM9tIOQ8LUbJNUroqMJ 	 
    	  
    		   
     
     
 size_t _2654435878 meVN3qpUfWdh0L5zEBZMu 	 
  0 mqmJdruV3MIc9CcenzHlC 	 
    	  
    		  _2654435878 mz5MCnH4XejHRq70OneDk 	 
_46082543180066935.markers.size mld7eZtCfa6r4ySUlfIqH 	 
    	  
 mDDVlrS4uMT9J_lN7fseh 	 
    	  
    		   
     
     
 _2654435878 mVntLRk8HoUsKvdPLyHta 	 mLFZtySqO_nDftJBgp1FK 	 
    	  
    		   
     
     
  mLNsbg8pyRFuUIp_R2v0d 	
         mzuFiYmYPocBurVof4ZlB 	 
    	  
    		   
     
     
 &_1681469518277799077 mKdGkjFaE0tmrjf5NTlkH 	 
    _11093822290287 mJ3p3pklJVkweMVwRRaK2 	 
    	  
    		   
     
     
addMarker mnqODtk__norexJDqFXYD 	 
    	  
    _46082543180066935.markers mjYQT6j1wgaGgGYF1qJI3 	 
    	  
    		 _2654435878 maeuoWjF6xTdwN3myRAGg 	 
    	  
     mKgK7IowyZjH5wyw0Bk8d 	 
    	  
    		   
     
     
 
  	 ma864P_Lsmg_HxSufe4co 	 
    	  
    		   
     
     
 
  
        _11093822290287 mWmN97QQEQ7MpbsEZygdA 	 
    	  
    		   
     
     
addMarkerObservation mGf46XpVsZXTkKG1xBF93 	 
    	  
    	_1681469518277799077.id,_18139480568557707913.idx mKgK7IowyZjH5wyw0Bk8d 	 
    	  
   ma864P_Lsmg_HxSufe4co 	 
    	  
    		 
         mgEBmvqLf6PMhJZeTzswp 	 
    	  
    		   
     
     
 
   mtWHlKYJukh2L67HsjPLk 	 _46082543180066935.markers mjYQT6j1wgaGgGYF1qJI3 	 
    	  
    		   
  _2654435878 mXztGjphv6NPOxrLSUEUq 	 
    	  
    		   
     
  .poses.err_ratio mvXqUis778sIFsZW5vtV5 	 
    	  
    		   
      _params.aruco_minerrratio_valid mP2AiGSIVV4QQ8S0_ZsB9 	 
    	  
    		   
 
            _1681469518277799077.pose_g2m mnCeFIsKlgUCPgBADbea8 	 
_46082543180066935.markers mfN3ne3bwNdIV8GVYcoN0 	 
    	  
    		   
     
     
 
  	 _2654435878 mIVJo0eWCM7NIdVTaOwOV 	 
    	  
    		   
     
    .poses.sols mD_2zWmARS3aJ6y6qfRH_ 	 
    	  
    		   
     0 mtYTOdJ12b1xGaXXKiDjd 	 
    	  
    		   
     
   mhif5Rqeg0n5IF_GvISmM 	 
    	
         mu1FnQFMDTSwPKm4knbOi 	 
    	  
  
     my52yXW_6prFRkDuSZDWp 	 
    	true mqmJdruV3MIc9CcenzHlC 	 
    	  
    		   
     

 mGSwaxZR6NaXV1nQzbnD4 	 
    	  
    		   
     
     
 mUKDzj3AhlImVlcWctAq9 	  

#ifdef _718950611945867080
#undef  mqmJdruV3MIc9CcenzHlC 
#undef  mkhBkOh0LHnJEljlujTn_ 
#undef  mtwSlSoUN8Us4uueBZb5r 
#undef  mpPFZGemitY3WtK0LqptO 
#undef  mcO5gre3n3Zakhk46a5sh 
#undef  meflZrHDLMaKFuzl168fp 
#undef  mVe4dZBBJUVUI35vvA1Ox 
#undef  mz0GR1i5BQSuWGPDXhIpA 
#undef  myTopYZa7yIOxNFAqG2ln 
#undef  mvXqUis778sIFsZW5vtV5 
#undef  m_BWrKK8L6uUnA_8Q3ZnA 
#undef  mV_udCF3k7PmtzngrfHoD 
#undef  mIXC4TbfNyA9iroZWjvHy 
#undef  msHWcJRBJJUShzPIX8Ckr 
#undef mOfY6d1_EZLRjLPZMXd04Tc_aoBGr24
#undef mNzvQMIxD83QZmxmFat_8TjOOs0sOBw
#undef  mAsjWuz0pGT4X3UULs6vr 
#undef  mtMknmknZUrg3jfRWX38C 
#undef  mFixnsamHz1eGE8_ywSna 
#undef  mIHOfocUBToZztipmOcUn 
#undef mmMZzhaChK0tGFiKl4oMqI4fqZ9zq1X
#undef  mDMbTh7oHYwJwnASuTwGV 
#undef  mkTxCKuDIQYUqvBAorH5l 
#undef  mPyT9VjCyKT6B92Ozlr5P 
#undef  mKpjSjOyX_RuuYvHw55qX 
#undef mNKTjjOML4zGQAK5eX2gwJyX7CMJFCU
#undef  my52yXW_6prFRkDuSZDWp 
#undef  mFleY3dggpvYRDtf4yUUV 
#undef  mhyKCMZsa_k2tKqEl6BCa 
#undef  mR_u0CRiVErFYF52pb6X5 
#undef  mfJt39SVsIcGuR4b5KG3K 
#undef mbAucdJagR1sxgrThMHZc82R3MqNgEY
#undef  mx6C3YAnIkYBPU5bOvSyw 
#undef  mZWq1iKb1zKB_JmpMJfNM 
#undef  mhif5Rqeg0n5IF_GvISmM 
#undef  mi6a0nZXIuHlycg3ExbUz 
#undef  mq2TZEVVkBWV8UUerawYu 
#undef  mTYOP2KZp4yLVtn2HTvHU 
#undef  mAu9Y5zlNfizMiA65ddOx 
#undef  mAsdonLhgqbLvHT6VTJkH 
#undef msyOkpaLmpoB71vFRPEDXGS3TsxU3ND
#undef  mQ863o1y97_2idvw_KPx1 
#undef  mXNtru3nMBcsoL3_RErQj 
#undef  mbL_g2PfUt85bakTpPg1R 
#undef mfMyzrLY7_JdFTjRQvPRTasqsO2JRcz
#undef  mgcJaVoCsgmzSh2ja52EC 
#undef  mxXdGSc8aCTz40JVhtF0Y 
#undef  mbQTs8ycowijFEWatBSew 
#undef  mrP3ghTVta3Jw7IANk1Xx 
#undef  mryXUmLImtQ4Is09uHLpb 
#undef  mocM9tIOQ8LUbJNUroqMJ 
#undef  mXW6HHg2bqggzB8VMCEGt 
#undef  mHSyAnBP050sCfoSPHt7a 
#undef  mMbR8sME8lT9WWeXIiFbW 
#undef mKO5ty5XQmDG26qnB24Lo74iN3EoshH
#undef  mXxeBOpcTlG_qg7UTBJrv 
#undef  mKdGkjFaE0tmrjf5NTlkH 
#undef  ms5reMIAMufxQEX8dRrhY 
#undef  moDooq3KNJRmORqK_8bDE 
#undef mKusDK4uQHAyJ66b3FY4lktL2ghiLVn
#undef  mOfnTUGa0UrxvKp2HRrB8 
#undef  meaI9iCS2_3gnLUKc6Yak 
#undef  mQPiihzD3FgYO9MNmiE4a 
#undef  mXv0PAfzgk2_fV05X5nKZ 
#undef  m_fXG06XVgIp6KIXlQMlV 
#undef mTJdKBjvdKVXPqgZTf8l2lhmzgRzcGL
#undef  mpWzKYjiXpd4bF_NzlE7q 
#undef  mAd9SbOcAjVa1TnOyBE8u 
#undef  mKdtFXuYxpaRdh1XF2ScI 
#undef  mCL5MoSEtL6Z8UCGU6IqO 
#undef  mzNoSi168i4jQTDhZUv9r 
#undef  mSoN5o2yDOJ80orgAcweO 
#undef  mArz5bDnWZI31SNSlCPTX 
#undef  mFM21yS1I0T4mkM6cJnPD 
#undef  mnc5AxXzr4BPppbUvP4FG 
#undef  mwQcD4iQwZzm1xNEBAXNS 
#undef  mxtASYvyLkypbQ3wKMYBi 
#undef  membkzbNyMSr1FS0Re8hM 
#undef  mJ3p3pklJVkweMVwRRaK2 
#undef mgu9xJRksosGg0PfqhlZcWowbxdK3sJ
#undef  mP7Vex3pSva4KZPEEVxol 
#undef  msnj4aq_aChIQpU6YEJs8 
#undef mEC064f45TX9orkVyWBI6CmBdKpZnMY
#undef  mf8hNMrC3WcbIRkKFEDuc 
#undef  mKlbe0bqkR9ajbQOJmzIq 
#undef  mV_7GSvceJxBtjDWLlwL0 
#undef  mpJTox1Mh3lDhCzdEmf4s 
#undef  mOc7dIIECwdrtfOiMRMNK 
#undef  mZk6cWFDbU7fs79qEM8t4 
#undef  mDGj7BxopLbE4olBjVRk4 
#undef  miWpYBxFs8qXrbLDM941S 
#undef  mv1ZUEjgm76AgfTPqDyj9 
#undef mrc6OafsMmRoNgURc8cIX2altrg8RgN
#undef  mYql_vxBPLnHDYRIHXMGS 
#undef  mjYQT6j1wgaGgGYF1qJI3 
#undef  mDTsdPpCq4eSuuI3mubBO 
#undef  ml1Pj6tCOcTMWG1SZFLPp 
#undef  moT_S9GDXH9l8dY4auCTp 
#undef  moLgX26ku1R1U80k4xOTV 
#undef  mOvTSzFoPpLPQmnInV4g_ 
#undef  mQQgAMOX3x9JxS731vXKd 
#undef  mIHMqjojFRuV5HLbqdMaZ 
#undef mvk7gdheMYBLwF5lCOI2cuLIhvSqJPq
#undef  mx5nL5_uWKTn0_18VrhrS 
#undef  mBCA3ok9_phX6l7uzs9aJ 
#undef  mSf7M2lLnQTHwMbqH_RRR 
#undef  mshwsV8Ee_IpQ1WAc0POF 
#undef  mVvyvE_Nna2Evm4DBNaV5 
#undef  mACCTlr8Er0mxQltC4dQ0 
#undef  mT_zOZQYvmdAIy7GXPlZb 
#undef  mqCRyvIJKLz8u93spsWKA 
#undef  msI0CyWFIwayfXRkte2ZJ 
#undef  mYGrxb9L4CcPi8a2R5OCG 
#undef mKlveOqq2RLY3Wg46unzUzIx0R2wC1U
#undef  maN8Pf4K4wo4zg3O9vjkx 
#undef  ml_IkdOZ9Pt3ALKcz4v68 
#undef  mOyh0WcAWe4X21Nx7XmIJ 
#undef  mqWF0EGgwKuO0DRAoUW03 
#undef  mQwPx0TaesVaqN0vXX7wx 
#undef  mh7F_7DwYzXEJQ44CDVOd 
#undef  ms0gVP7KrjDciWyFJ1fmf 
#undef  mJhQ2aXInyVMFKRs37tY8 
#undef msUMWQv7u8xmURrwRLbcokDkEqYeTl5
#undef  mfFE0ddNolABP9h_SYzyH 
#undef  mQEno3lW2El1qgRPum1EC 
#undef  msgseMyRZ5n10fxSW8wqN 
#undef  miCt6286SbYlHHngvumOf 
#undef  maRONv1j7ElxD2YigYmG5 
#undef  mWUhiqv5bIQxvo40Le8M0 
#undef  merwIhutcIOF7ljN2eA2_ 
#undef  mnFBsv2XApkzBpu1BZkdw 
#undef mvUEVeg_nu6V36BOOw677d6y3hZbG5b
#undef mbsQOuAaIyDVDes0IfnL0hHETVYxWRQ
#undef  mrs9l0h_Mo3UbkNMCfQiy 
#undef  mZsqgDOjDIWnGaZiccgxd 
#undef mxTwrt5mwiPktiIMmH0IHbKA6yZYqaR
#undef  mEQtvhnpwdYUEFRaazDJZ 
#undef  msEI8Bkam3c1vxA5_uZ2R 
#undef  mb9OlwGA1t5M6qh5W_YyX 
#undef mpZeZTzn4wYzfoQXnRJC_OTWOzF3mnF
#undef  mpCtp5eOfsJOU6bapo3Xc 
#undef  mvZ14eY4CWbHw1nZrMh4K 
#undef  mXztGjphv6NPOxrLSUEUq 
#undef  mdb0HRqlxqtf9slEU7FuY 
#undef mq_7JYOIy8jyNkYTabU7GdNgZ4yBlW2
#undef  mwrHpql8JJqmzOcS2FBew 
#undef  mxHOqWW3q92iGrWvuNPVP 
#undef  mV_aYzA2HerHHuuJvxPtT 
#undef  mbfyrsiw1hut7oFhrLR4h 
#undef  mQR2IKIsMpm9uM8evwN63 
#undef  mJvPeJjOJ1DjORAiUPNiY 
#undef mRSmAbn2b99FbXRTRqJuSKVGlaIDKpp
#undef  mtw53ct5rBcppMoQJ08KE 
#undef  mza9YQcyvtU2zaICrDHgz 
#undef  mtYTOdJ12b1xGaXXKiDjd 
#undef  mbWgLtzmRKNhdqM_lHKjc 
#undef  mqlyrsy8ZoHxK2uKGCJKQ 
#undef  mfScQ3hApi3zApBoaqezo 
#undef  mld7eZtCfa6r4ySUlfIqH 
#undef  mzTNi3ZiobCHTjdPPVBIm 
#undef  mYKy6VNQ57atCIXMTSpg8 
#undef  mgEBmvqLf6PMhJZeTzswp 
#undef  mmO6dSHd4TSKfawJ2UZch 
#undef mNos97cFai48VfpcLamrm0fNKCFG0Wj
#undef  mVybxT27lv2ZINx7C6UqB 
#undef  mi8rQqu9fK9KZquxYE_Kh 
#undef mtCmbCaGnNOI2YAT3N4b_IOgCpovDCG
#undef  mphegYaJkAj188nKLmOWT 
#undef mjvisFhoul0MMt59WOr5FFXi4b1bHZy
#undef  mKSMdIPVpErcpAXiiW7Gg 
#undef  mljTZwlVKlJXnTPRp7Xec 
#undef  mZO_Be8esSeqdwm2_0Lng 
#undef  mqVj0gjCYwYCd1BDHvQ1q 
#undef  mMF7jrIM56XMAOa4i8vzd 
#undef  mStEZIDL7HjknNx_niOvm 
#undef  mSe8inYVJuJ_SWpL20XSn 
#undef  mYQOyfWlcv8BYXSMTquXE 
#undef mDYzbG6wPLXHzU5tc_WwkXrJRKfauPB
#undef  mhIOjOF5DoUXz2tMNMC9n 
#undef  mIVJo0eWCM7NIdVTaOwOV 
#undef  mKSSBCVapqNJ7QOvFb0Yt 
#undef  mZzB8WL5_fhfoUbeFYWG7 
#undef  meuAcaMA_veighEBRIakB 
#undef  mJuvH2jmXjprwO8g0P3rA 
#undef  mnqODtk__norexJDqFXYD 
#undef mylGd2jA2fn4G3Vwsj3CmTOQ5DjHISK
#undef  mZe3iM5Vb4MN7fWcB_j1W 
#undef mbxMVf0KlSx441cquP3eHLECMunVP2y
#undef  mBDwUZiBonmC25VT0hEv4 
#undef  mYzukuoS5EuAVkLMj3HEJ 
#undef  mRVv11jkqLVq83rwdiZNq 
#undef mlIKeZ3J_Dw5QqipSAm8xVbDSitkHUV
#undef  mpPGzOzhK_y49HZQyfcqP 
#undef  mez3LQiFJeF2ZfEzjyQcK 
#undef  mA2LLwYRXyQatmlprTX_9 
#undef  mAPVEhtRJTjorwGCe9mU5 
#undef mMiUD2Ul1JD1P6Zoppp1jEkpADdWuS7
#undef  mukfpAQ_bsXz1SeH22I4U 
#undef  mWA7_mUrsAkTnlALjZRuV 
#undef mHym9HiP3NUvTTAeO5VEF62wtzyaMjv
#undef  mp0NXGdzIniDHoism9Ydg 
#undef  mAbujF4Jyb2_SbxeA809d 
#undef mYAM1GaDeDP9HjbPrnzWuPYvHlPuInX
#undef  mR3SmqlT_RO3LW1rycvQV 
#undef  mVHJ9I6jPcpbqQB9bqhTz 
#undef  mpH0tTqgVVhq1D7p6uzMj 
#undef  mnCeFIsKlgUCPgBADbea8 
#undef  mBL8Jp8oIGaT83VFzqXxj 
#undef  mNVpdluZuoiVIfdWKkNZz 
#undef mILnhO6tUuf0jC8ICzQNM6DVJM5pkU0
#undef mvougtzhY12CATSxbrZyl0r6i4Cofa4
#undef  mFT349C99hkCNr8ceHbv4 
#undef  mZAkrlrMBDBZeuyIOXq4K 
#undef mRZMgXovjhFR5nw_qhKbYjUVvgwbJM9
#undef  mUKDzj3AhlImVlcWctAq9 
#undef  mfLwKGoggK6FTdtr_kyTD 
#undef mJzrSPVBXv8TJT4vG1f6c3s_lOYl3Gh
#undef  mLm5pMwSjW11Fg7twfBaQ 
#undef  mz882g6UmYYikrmJsoTXS 
#undef  mItoNEXPmUd7PZnbkjY1u 
#undef mXnUfHi4JUDWaiElDnJd7IOaC3L1bwV
#undef  mG9tkXdonq5K1a5TTvWdA 
#undef  mAh9WiJ5Sy1FhI1A81QHM 
#undef  mLdaISEo61F2B0GtUcMub 
#undef  m_UN2Z5BV4n1jzIwQbwMV 
#undef  mzrSELvIctMsJ9zj2Nm82 
#undef  mlv1HNrEy8nKtkRAz1HIx 
#undef  mf_8X46PeArmbvEUOoYbz 
#undef  mNFlZ7jDo9yK4myRyxbPG 
#undef mg2QzMMPacyxGXfBawCntPSl5oqpmp5
#undef  mfOBUoRxXGyCKmISP2Fa2 
#undef  mMM9ulKYF5uFvOlxnwc5q 
#undef  mfenr7UkNUGNUiHWpslZu 
#undef  mbp3LAAWzXWaEtyxiLhXe 
#undef muWZMhzpPIxDjLsAstCgwCZyebeHHNx
#undef  mvV2rpmOHfvaeq8PnbRx1 
#undef  mAUvGbDfA6e0dHZcVPTP7 
#undef  mXXe_01CFG5K_yWQao2rc 
#undef  mjNtnGdxnEcYuGDooq0Y8 
#undef  mtWHlKYJukh2L67HsjPLk 
#undef mK1qb420PQvLJBzCk7JugkEflYTz5VL
#undef  mopuiW_wWLEb7vbueUpbT 
#undef  mac78ewkKOOFBDPHhKb_r 
#undef  mW2ZPvWHsb0kj8UsemkMz 
#undef mTM9qfhzCTbvR7qIN1I9pwgIxSb7FCk
#undef moA8BntQZTsihsSQ27K7EkvZBRPk0jb
#undef  mLxofLAyBTLsEaqCJekNX 
#undef  mkIY63qppn7XhhL8_PKOC 
#undef  mLSm6RvP25h2mqMbhmWpr 
#undef mC8KYd1QlFy3_vXmJOYZOqnlaJ3T9Za
#undef  mLajHmFpSPs_tqjhga4nc 
#undef  mt9exA3A_UuFnhbGU1gPP 
#undef  ml8sboN1UctQAMZWAGhFu 
#undef  mwmwv7GVBGSSNquKWLaS7 
#undef mTJ6ikGKdOyqotVinwUufff1YcoPrIm
#undef  mwgiktLEfZPX6Q0iDYQaS 
#undef  mKcwR_6MjpJ9NGpICycQ9 
#undef  mR0oEtHn4mcLNCK3obgTg 
#undef mHcTkjestRdFnwQ5Hsln85FjT6syo35
#undef  mmy_gM6T1hmBPCCyiUjg_ 
#undef  mSWtztx76NMPVmAGQ6Ru1 
#undef  mndP4wnd7T2bJPpA9o8xa 
#undef  m_njCsIoWti438KdZ7A3Z 
#undef  myLdxSbKnyWYHY1ELQXsL 
#undef  mfIVnKehunlKlj05qT5YF 
#undef  mtgAIpqRx96Ug1UlUS5Ix 
#undef  mwJzBxDwaGoS1u6XQA9kF 
#undef  mbSzxLoqs6z5PAzX9GO0Z 
#undef  mQBayHGMRDimm_TNEaW8G 
#undef  mjN40EFRrBDEp1gJGGIk5 
#undef mhLswLfmDECrX8QwFDzJirKypIulTUh
#undef  mKgK7IowyZjH5wyw0Bk8d 
#undef mwKTHRCUCSqozMudYVOa7QRqUCbl_zP
#undef  mUbe03iJbNiK0SFC1qiOB 
#undef  muSK04Vz5d6OwHO_pnE1b 
#undef  mt0d6SI4cMxyHANFDXO_9 
#undef  mfN3ne3bwNdIV8GVYcoN0 
#undef  mQRZqQjaaMuE2ei53QVTa 
#undef mwvcF1MXfdRClJ0VLK9qQvh0XHWjNp9
#undef  ma864P_Lsmg_HxSufe4co 
#undef  mLFZtySqO_nDftJBgp1FK 
#undef  mb9OfiQM2vLz6_E9jAaXk 
#undef  mXuxUaHxxdF6zEQMdzmh7 
#undef  mCmNar4SomM_6aug86_Vb 
#undef  mWvtBeVmHAPDjWPyb2fw6 
#undef  mw43HcDW_E5tpBhzkhy_G 
#undef  mIyo8wONeLU1MQ6fYabD9 
#undef  mZEToL7w1MwaLTuM2AFSG 
#undef  mofMRVdhgYFjonQ3mKSYZ 
#undef  m_PJR0RkW8xQAS0rz0_YK 
#undef  mbxVjFGEIxEw0NUo8d3Ft 
#undef  mnhg_U0H9OdjTJQTP6Gnv 
#undef  mS37yKuJ9Qw3sTuJDSsaM 
#undef  mOWYQ3OmlR6NgTKssoAIn 
#undef mpslIC8fwQoFTrtZHRvhtsXzXfxWxuK
#undef  ma5XrgW2ATI7PTDDXXfB3 
#undef  mX4PFQRsbSrgHD9fsj2hr 
#undef  mzuFiYmYPocBurVof4ZlB 
#undef  mSlgBaU2vojE6zMD3lNy5 
#undef  mMNJKohqyycJPFpj8eRtp 
#undef  mkZfslnsB4E4XCg4ewCkh 
#undef  mWKsKza2Ie1x9Go1Sq7mS 
#undef  mxxVbU1EP8UGUU2GgGm60 
#undef  mZPkZQMjIRl7FhHYgfU_t 
#undef  mciQs2U4tIXfIykF9oghR 
#undef mdofyDBTiTPru6JxshZkHxWJUmSLiNV
#undef  ma8KMC8A12FflwMhZpnUd 
#undef mah_886XMh42ae5MC0NBIjAmdmNpB5O
#undef  mUX1X7i6U9cYagHN1H61j 
#undef  mzjWAM1lG0qtElK8KOav0 
#undef  mFtRWAsbcndIRnjhO0RVS 
#undef  mzlU61CRdAJdTeqKQTVfM 
#undef  mYKdwRjOLAapoggHzBlsK 
#undef  mdjm1pMLcmX1Kj1wCaEmX 
#undef  mapFNo33Cxop8c5ktjxb5 
#undef mw0tTFNN2uiBkW6m_eCbOvAmiyjhG01
#undef  mNWUNpWV7jCgmNO1ohXHk 
#undef mD2B6q2lEYdwFKcmMhJdxre6SeKJBoq
#undef mFoqA8fn_QnUDFhWdz5QVtAXpt5mqS8
#undef  mggAAdTyH7GUYCgj7F_NK 
#undef  mP81FQC1rGzGFfKa8URMp 
#undef  mH4ahGk4rD8pNLHoBY6e2 
#undef  musLCv3PeipWCzr_EZRKb 
#undef  mjzAIU_ADY461Wii_hi3C 
#undef  mfUYGG5ZFjFLLvm0kZRca 
#undef  mJ_Pc1vl4i0gA6lgU2KRM 
#undef  mFWKVMwKmulNbmtAXtoTn 
#undef  mPBfEQ7Kf1tnyv9IMHQj6 
#undef  mbUmWsXo_mt5YMuA0dRGj 
#undef  mo44bndgqstU5qGZyR5R3 
#undef  mD_2zWmARS3aJ6y6qfRH_ 
#undef  mbwK9Uiu2G1H3wMKMc3_w 
#undef mAyGGG8INgjnFvFc2l6llTs1gGqi9lB
#undef  mdJ3TnurRuIyRdl03hB8V 
#undef  mmXDIAsakndWmFnQGgCSu 
#undef  mib_7pBiS70zs53JCmQ5x 
#undef  mVntLRk8HoUsKvdPLyHta 
#undef  ma_VPgWniLwpIMIRHKQfD 
#undef mA3OHxxezsCMuGqzpA46TaTnokRHTnN
#undef  mU5zsJyistPoyu6bR_MYT 
#undef  moOskMZCYFVYX67st6FDR 
#undef  mi5oG5G6C0X1ycoZTANN6 
#undef  msxbg4uLHX6bSC8xQJJjT 
#undef  mQAGEgppSBq9HmAWlAxgv 
#undef  mNvx6y3h4uOynhxSbeSNQ 
#undef  mj_5QCrXM16tofyVPSe_7 
#undef  mIdyHY8qlwLUDCg3LqS5v 
#undef  mAxckUPI4GmHP8aTrzcHa 
#undef  mphZZ3fCwJsSsxkCdUmFA 
#undef mG5Rb3JsAYRcrGrw4hcYesG6GNQ5tfG
#undef  mYbdRpTrp0RuXQF49wcyY 
#undef  mKNmntVBFHhx284hXGzZn 
#undef  meVN3qpUfWdh0L5zEBZMu 
#undef  mD70Qe1PePOYeUYgIlM0w 
#undef mgtZ5dJBcrKDVziMzXjro3bku98O4gb
#undef mvno3k87zj0_PkP7zdmz4bM21CBHWrP
#undef  m_5ZWe7HgnsJrikK7zpT3 
#undef  mz4DQ5hbNxq8mq5ehkJ3z 
#undef  mngvt_AEOnxcjjVOMNH1l 
#undef  maI76rxuvSUx4RnZDyTa7 
#undef  mb6bPPxBoRd5eWMKEY_T9 
#undef mhx94LeC3YnYIrpoBXs0jV7HVdsjMPz
#undef  maNQdhC2dWpIQA8ciaOTX 
#undef  mQrFq8uaXPUzfDZoyla5j 
#undef  mWODfa1Wq6HYaKxqgXepQ 
#undef  maRvasCuGs7On98C_DsEL 
#undef  mU1Zf9TH71xfpaaa_jSCh 
#undef mfsOEnXJzeg7cgShrnQr0Q0jBe6st5c
#undef  mXMumYcHyMLbmbmnsP5dx 
#undef  meTsDOg81kzwueOfX9px1 
#undef  mwBEznB3gGAjfLQyygAgT 
#undef  mm8qj8E03WU6q9hyvKDy6 
#undef  muHcbKm0PMKyMsdXLtdOo 
#undef  mPLxnLLY_ZIq7Cn8Gyj0y 
#undef  mXsQ7EtcRLQCoGI0aWHVn 
#undef  mWugSXRRnAcAmUglBaEC8 
#undef  mEe07V1ftJu0wNxgWSgEq 
#undef  myUcUn3yGjKvSAoM9tDZV 
#undef  mfJo_hbZ8WbXBCxZ9wVKd 
#undef  mldqDhxdMVwVsZ_sHFAvZ 
#undef  mO6JPHXzu68suopqQj4mY 
#undef  mb2GSJSbmLIcm_4mDhxLV 
#undef mp0nlPvzjA9qzFIrgZqXRhtPXNd0OZ2
#undef  mQNMjVJ0N6wXPbs6_HgrA 
#undef  mq4Ny6jmZngTGMX7g7iD1 
#undef  mMGByMmoaX_KkNHqSQTHW 
#undef  mV78weJCJa4teGKdCdEoA 
#undef mvW3cobeX3vVDq_ubzh4pyzuwdGncRh
#undef  m_ooWWGwvxTurt3bC_287 
#undef mB1TyCvhginkd0qNE4vD29hgVCGEoFN
#undef  mpKcSob73WCEc51cTQhSg 
#undef  mPVjKyeU7n_jg2OU2HXfQ 
#undef  mQbejPP8sp38yL10i6lLU 
#undef  mWkXRNO1Jxx7qH3BJU2Yy 
#undef  mytPitxa26I0boOQIsX_4 
#undef  mCAWNJrkI3y_AaJrsGRlW 
#undef  mq6ps0_ThKFNGk0D_gUgC 
#undef  mGf46XpVsZXTkKG1xBF93 
#undef  mQ7bTZ70bEB5QoAHj90Aa 
#undef  mcHCA7rxsDvkL50CWbJel 
#undef  mk7FE4eYNO0y0kGHA79xJ 
#undef  mqu865e0s7mA67B4iCjgP 
#undef  mIl8Bz4oYM1DbDYC1fzl4 
#undef  mCSOCHdFeVug7ftk2QcJo 
#undef miVHYJ8Vd6N94whoCllGiOt6YQ0uPeT
#undef  mqIOFzkzC3Vp68hRewvw_ 
#undef  mpMNmnv_8Ipnl5K2c8t53 
#undef  mA3dIhDvEVZH7lW4Zbecw 
#undef  mXtAOoecuaP5JSrQHSlp_ 
#undef  mTiTcXKry5OzMu4hlwnJS 
#undef mmYm053IHIUwOgVkRp2j8lTQsbQ1UaI
#undef m_rXNZmfTnThCDdJ_TopukrQOKmohWe
#undef  mgdJ7Lxk_sORMQaHgbV35 
#undef mKx4ajHqs6GBljFuwdT6wAu7sadxUn9
#undef  mAnexmimtA4aulnTFqO1Z 
#undef moInb8EUb1T28v2kS0hm90nn8opwJsS
#undef  mz7fxE30os9D4tNXhnqiQ 
#undef mYwuLcIq9myUOfENc2DDVU9l7LLuVz1
#undef miQNjYzQ8mOgcFJ9ae1oXDAaXwH2lZE
#undef  mOd4gqjobBubSaKi0YVJj 
#undef  myPAQMpW1LsQon8rXUeSt 
#undef  me9NNIGFXdOjv9uIRW_aW 
#undef mprX7Ac3on8kVlDq6ckXUxMekQAsyNU
#undef  msr0kpJew1NRIDW5oppw4 
#undef  mAHfPw6Pm0C_EGwBYeW6O 
#undef  mkIWm_FhlZ9edIBwTE7yn 
#undef  mgYmmWcXjc8YDMjtlYbDx 
#undef  mFT7F9gj4qa5FhQk1mDzt 
#undef  mgOipjcCKoW6lqmGLrLOR 
#undef  myIobh19BAR8bbpyIogfI 
#undef  mj3wYj7YGRAZdVAG7FIfy 
#undef  mV0W6FqwcCNK199FQBwm0 
#undef  mgrwD6fMGdqWAX45HkZLm 
#undef  mWmN97QQEQ7MpbsEZygdA 
#undef  mF7w1U5nk2MTMLDTmLBOJ 
#undef  mQ7pkbryadK6xP1UwBnlO 
#undef  mKIxRfN2yPuRgJRs2WPHE 
#undef mh0BZobxwkBGuRlxWnCrgW7GVx58mdk
#undef  mD2zvGK3LMUI_oap4rWrL 
#undef  muLyKcTiM2J66AesQBREm 
#undef mbrVdvAj7XC2J0fXXZo5Ff_d_zcAf5S
#undef  mSimbUaAH71YIgw46PfYK 
#undef mDfUAWVaDgOlsgvvOEu_XWznwHQ7Pca
#undef  memBPTMex4Q8hYIboQnQT 
#undef  mGpUow31Du8x3Q4OKSaKa 
#undef mhJj9vv7zHRSaX5zjnZOdhARUupGDkX
#undef  mj6J5HI5Xb31ztLB3vXf0 
#undef  mmUizHWq3YhaHQKSV1bIt 
#undef  mCd30wtR2_jp19X1QJxGT 
#undef mSvOz6y5G53F8eQeMfXsXe_Zf7JNaYJ
#undef  mGCJTpW2Rasmazxmotm1r 
#undef  mCxGYNCDy2ch3sYaYl3fb 
#undef  mUobXZ2a0lXIXTIB1Ogkn 
#undef  mJeLsoxjVQgLOmHuDfdQp 
#undef  mu9xASZI0703uMAO1dtqL 
#undef  mC_SnzXT8ezjodlfUau06 
#undef  mB5W1EeOMdLoJ0CcZak1O 
#undef  mlmQ7twzbnP41JhsbTjq6 
#undef  mhDKJw0vzmVidEdPlH7E5 
#undef  mi6M6M4HNDsUqGSfB1XIc 
#undef mbju4PISEJDTDKaNvVZgYGWLnjVwWbo
#undef  mzPAMkOuis3J5V8ino4fR 
#undef  mL8QoPttgjHpemU7IhEek 
#undef  mInLkmiaabxECHgr3MIkM 
#undef  meYAl8g8b3EnplE66yiVx 
#undef mkp8stKRIMlPuuD0xBYppAW6VOpbsLN
#undef  mf1IuzucYIRUTpArzsx6l 
#undef  mqLFPLgyLcGCTbIyKt8jl 
#undef  miM6StPBE_AIpLnV3CzlO 
#undef mXppeuRrrEEaoAjvL3jMX6Oazz5QjKM
#undef  mIdX5HNnK2eApSoyx1MkE 
#undef  mjMH4y_9O_liyFsbzDUxH 
#undef mKvRdDZo2hLox_h2MYxX5LpeVSzgWma
#undef  mQKX_ktx1nXQWco3UA2nE 
#undef  mSJc_Piy7BtW2FYVfLCE2 
#undef  mc7E93JDoptfm7EJ6aO4n 
#undef  mDy7_3d5pze2eG0nIg9ix 
#undef  mbV1M45gJ90jH8gaxB10u 
#undef  mGjrqvrVNVioUh48zGsmv 
#undef  mCdmzaxCk0FZEnTCFHZG4 
#undef  mkj34_kJlpIicWyXmacrU 
#undef  mKIH773O9wMZYhjP_5r8R 
#undef mQmGVzwqgnV7i001eN6e236nmDZW95v
#undef  mn6rAhgZU41aDciG8UDL_ 
#undef  mRuIblp5NFz2Dyvh3lrS1 
#undef  mBig1dgAg5rUJL0JFLOei 
#undef  mPR3TvQNUiORj8WMIQT4G 
#undef  mY10h4x_kRm6OheD9nzQP 
#undef  moZyVdyRAH491CbY1hMWz 
#undef  mRRxLUZFhIyMm4fVOuYH2 
#undef  mO2bw_Axd63rwbqolRUPu 
#undef  mfB2pwxO8Kxzw5bVxoAWu 
#undef mS7xVzw_wsMry9asEQCgsviswGgA9nq
#undef mScKEkC7K8_DatwiGYuKYOfLhVwBcK9
#undef  mkFnoQpf8BpdMoafaeZIe 
#undef  mmYLJzF30SGioD2YDpOtL 
#undef  mOHp6eii0W_CurvEO6nec 
#undef  mZ8_hrlTxQvpZ68ZNjaa7 
#undef  mdUhBw02GnqwJFQFHR0Aj 
#undef  mImF_yjqZ5vA5hr7u_dgQ 
#undef  mcdcf6DHXagTuHrurSaFD 
#undef msgTv4_u1nHaORHVm_oxOOIQ9D3qajj
#undef  mDclGqxnFvvxQ1kWAyR8r 
#undef mANHj3UNlwj8dOQU9TN6RfyhSfl8g5q
#undef  mLNsbg8pyRFuUIp_R2v0d 
#undef  mujD1_l8DTz3zW3wg5fYN 
#undef  mquKNlk6oUfOtB67zsUnK 
#undef  mjYiQ5PDu6c8QsGFAcfyI 
#undef  mEQcnCIKV2HBxhuocTqhm 
#undef mC9Rg_hrKSDo6jdQo9M6cwNM7BbUN3a
#undef  miN6qFmUINJjKy7fxK3wO 
#undef  maeuoWjF6xTdwN3myRAGg 
#undef  mtjnvFto7OtvCeNoy20oi 
#undef mpAU_b88yljyed64ipzwG383qMRNQVj
#undef  mtQzym6pygKJNEFLY1zwp 
#undef  mfFZ_UoVScGXYqYaKarzZ 
#undef  mju_8YZHecSoZnHcHOwm_ 
#undef  mCYBip4Fq7RbZ3OmMjHQ0 
#undef  mNchdC83ubiU8mtBrn0h_ 
#undef  mnuDYya_hKIe0F8_gsRLN 
#undef  ml4SDnJsptA_yCjAusDM9 
#undef  mChkT2RjRR9l5VrNHoLpX 
#undef  mGwfbPa_SpGojjnG4wAw9 
#undef  mrtDqSkaL1WZXETHB9Svh 
#undef  mqVmppDUD5hNkQmGwEZry 
#undef mXOrPXBgXdoaCXGCj7TMoxczyaOEdHJ
#undef  mPsuUIJXZuYTqSET0TT7o 
#undef  mkhazAyRqzahyM685eLOG 
#undef mdhsdWD7IF_Kc1tarp6BDqB4rX8bbS6
#undef  mDd_U9RdH9rZoTN8PmWMq 
#undef  mJS4Qs72jwMSgyMWYcv6F 
#undef mYL0i6I6_KPtPQgpSRRcys2con67Xn0
#undef  mGwX4lA9IuJaxQui7nC7N 
#undef  mP2AiGSIVV4QQ8S0_ZsB9 
#undef  mvAgaGyKoH4BoC48YFK63 
#undef  myL9DdBFuEiALUNb3mn2t 
#undef  mo5cpWRx15XJQ70SLrMmm 
#undef  mAoli6wqEt74na8KDOnMK 
#undef  m_Wv_6TxKoWyyVku_7IdC 
#undef  myqUHc37G2xQx4I3C1bCr 
#undef  mu1FnQFMDTSwPKm4knbOi 
#undef  mGGOlXtlBI87lJ879M9yx 
#undef  mrjXaNihMrIYYT87JMzED 
#undef  mFXsvRPkdIcV4GoPTpRdu 
#undef  mFNjhpmy0Os_BH3Fl8BxV 
#undef  mW1YfPv0fvnuVbkd7rV0K 
#undef  mnvuJGwJpM4fXFpwwiBPR 
#undef  moNo50KGrFIfKUbRhy95s 
#undef  mwB12mLv8G3iX6LnT4Rhw 
#undef  mjMAADtlqHIb1n8jcadfe 
#undef mSnf4kZem2pZso_LGVV3R_CgkHBOpFP
#undef  mci_rzwx4lTeXDbxkvvTu 
#undef  mYrH7YycgEGeb9PzTKSZj 
#undef  mePsroRdpIGpeDroobnZs 
#undef  mGm1T69SvbUDPUJ5tLrXQ 
#undef  mD2IexDoxblgmPilJikzK 
#undef mpeQdyxOQpr54ro66Bp1xTaE3_C0DkC
#undef  mGSwaxZR6NaXV1nQzbnD4 
#undef  meDIsVOQtTDSEKWgb941A 
#undef  mccvQmebKAJpv9BLnRwLo 
#undef mPPgU4znrCfTLfKDLeHokGbP5yyOY2Z
#undef  mbM6_YQUbxQ4zrU3yKhUm 
#undef  mKzWb_HAQsjHT1IjQCqvi 
#undef  modWmaDk0q35f0I_aGjz6 
#undef  mz5MCnH4XejHRq70OneDk 
#undef  mSzof3CAXnP7qW3AQOIpI 
#undef  mopowM6fbg9z5H_erpp5K 
#undef  mO6ny4iGIfOhAtLBm6B0y 
#undef  mPLwnaDnF_RJvGctibcNX 
#undef  mUpfv8Yhd38cmHAGvwFql 
#undef  mhofvlO9tEysobJb28Q3a 
#undef  moljDbnYuVvirfHM3EqqS 
#undef  makJ8RSltJaj70Md7IVjD 
#undef mz_kZMh__HXba1yXu5xmFO_biWvy8Mk
#undef  mhKeWI3YD4BRg9yhMiFLW 
#undef  mxcSCDlb7XbZPKnJNBbaH 
#undef  mMsLTeV_j72VETtfXsr12 
#undef mcXbFsHi91PXAO0GHe7xgmGnYlYUzsc
#undef  me3e97eBTPqPoHpy9KTu0 
#undef  mPZ4oMpB_Jx0PipOQdK3t 
#undef  mYwIYOipFoNIGN8Q9eUnM 
#undef  mqWPdZcaA6aPCDQbOr6gt 
#undef  mxHuNimpe0L6Dg1FvdZJD 
#undef  mxo6r3fqiGzgJtyNbGTZn 
#undef  mp9in7T3QCgnCTdKL4aXw 
#undef  mlfjux5PlAl152m6jAFfT 
#undef  mzsfWWbrltNhNi_qG2Ose 
#undef  mQjsSlJW9UmvEe6x181Pi 
#undef  mn6HL5CNQybt13oe9ZhYl 
#undef  mwmethC8hVoD4rfRzlkZn 
#undef  mz6L1o2G5rkHiZfy43kXh 
#undef  mg0u19XS1Czncmr64SvTD 
#undef  myAsqbOxXCKbwtKaJsMv8 
#undef  miLCC4CKBq72xuDwXrBsu 
#undef  mNlAbuGEDdVVtLoRz_nm4 
#undef  mrFuQY6M9WWJeF7w9dgMm 
#undef  mx3grkFeXlIrdbfdNJNZo 
#undef  mKVVCWBIFVlq1endyKGHY 
#undef mTUyCDvBtsi8RSKBBAjzql49EayRD_q
#undef  mMml0453fdyjaI_KtObDJ 
#undef  mMCFdfdRBCPjfnZ7iQ8yM 
#undef  mZW8uOzgXIREMjSM9lHwb 
#undef  mRg8w477JE_T_4vTAS6ye 
#undef  mR4jCpawk9__0LkgCGVjn 
#undef  m_Xwi8J0UrnhRD0LPamUT 
#undef  mi0VgzTL77pEU6WIqP66J 
#undef mJOkUWUm8_EWipYaHUASjNlQGbp6pTx
#undef  mT1nKCMDlQQN9Dk4guxju 
#undef  mUMfEy37Q22XYn_W_z1P0 
#undef  mLC2YVPow7wjlUrUvB8AX 
#undef  mCoUKvDV8sxZwsxIx5GNE 
#undef  mDDVlrS4uMT9J_lN7fseh 
#undef  mK2txgxt9PNqVdV0TBJHE 
#undef  mghBQfJm8DlTKqfpdpPyP 
#undef  mbxXgysI5CJN2TY0wY1uI 
#undef  mpq02WZd5llRC35g5Crra 
#undef  mexePs9v_6qsf8eRrLCKY 
#undef mgi8AfjvsytxAkm429V0ukpBJffTGMh
#undef  mzxwfBAywHCahEEMgjDHn 
#undef  mDZSg7ecZElSJDcf9hgAb 
#undef  mDHKqXl1SW2VQHNLTfQtC 
#undef  mUJVb4YYR215j1UAauZ3C 
#undef  mH9pmJdvECtnjBY1iswSZ 
#undef mUGs3wMURqDOenN3SmrYqNsDscC8sLL
#undef  mzcl0385Kw18AGIpYCXsl 
#undef  mFQNQEJTD69vM27Yqioen 
#undef  mNIEDl3YyO6a_l1lZnIBf 
#undef  mLqkqz1oj0n39qRbk3P0d 
#undef  meUUKeWhLEVhQsl6aqDnD 
#undef  mSJ0fgQDSugOw3EL6AoN1 
#endif
