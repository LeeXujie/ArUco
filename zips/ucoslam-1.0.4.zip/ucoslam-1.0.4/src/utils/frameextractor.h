#ifndef _7843067593709665284
#define  mMxGOgWhjQ2yrZAdqG_Ft  mh1d9DrxpIRxkD8q0yfkhyGnM5yWozy(l,e,4,s,b,5,[,{,-,2,0,n,M,R,G,l,l,6,e,:)
#define  mjKkbwMbQhMiG1aJI2I7x  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(+,},r,Z,*,-,],:,l,g,+,j,=,*,9,{,V,t,],^)
#define  mNSyKlY1OLpxI58STAPVs  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(L,*,{,!,+,{,a,J,/,2,{,K,L,9,6,O,H,+,r,])
#define  mXAH6nmZ3oPLhB459vQkd  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(J,K,=,M,;,L,L,X,!,<,E,_,;,U,Q,-,f,x,2,c)
#define  mzfR8L5gDNAEpcG521TmL  myycSeUNl2UaSztHLUlp4thuB3KFoS7(Y,w,:,U,8,D,^,8,R,w,[,W,N,p,*,w,I,R,;,!)
#define  mlZc9D7DysVVO7aYhs30S  mybqFwvm_stxorYCR11OOdi0P7TM2hb(+,5,3,r,{,3,!,},7,[,E,x,;,v,a,A,/,/,!,_)
#define  mVlb7CtyTEufwYbnJHVtD  mGEt5TRwydpdaNpgZWWwwn96FfNYmss(s,-,[,-,v,:,d,.,c,v,+,/,l,s,.,X,c,D,a,H)
#define  mLrfJgrXQgUiXh5XPhuZN  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(^,I,R,z,S,J,.,+,y,7,Y,u,4,f,y,U,5,[,G,!)
#define  mKpo2Oc83bFa2HDVs7F__  mByy67jxaShsJThnKTR2VBb7mnCF0r6(K,i,^,],+,7,5,:,[,j,],B,},f,y,g,D,{,I,T)
#define  mnP7ecWfR0kMBwxv2YuIf  meLJOI7HgX5w8hFT8ddZEsuYBNcUX5z(s,S,W,Q,+,o,u,:,W,a,+,[,d,e,c,u,r,t,F,t)
#define  msl8SJKeChU5HkW9cPMXu  mtmD3lZYb_Gu_7mEP1aib4ziGDxxfF3(T,c,X,s,L,7,V,+,l,/,z,v,s,R,a,;,.,.,R,*)
#define  mN4axtqxOsqT8LRc1FllK  mGAKlxzN1dfRR0ta1q5M1R5eY13O9ks(i,D,t,W,L,*,a,:,J,e,h,p,r,v,n,o,z,M,[,d)
#define  mc_OdScVk_rhzsDkwoGLb  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(/,/,=,.,b,A,i,S,t,>,u,s,e,U,},4,y,{,},p)
#define  mCu9j2IaTpSbZHK8vHoQJ  mbKIxMRUNbJGkfj6Bw2oy0bjVav__yJ(w,e,},t,E,:,v,],l,l,_,u,o,I,b,d,{,e,C,G)
#define  mlfGf0AIHXuNzxZIYw_rT  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(B,S,=,B,f,/,4,{,x,-,C,0,/,n,Q,!,},q,9,D)
#define  mah7aYn9AUfSf52iv_R03  for(
#define  mmxs_M33hrr5NqohE99r2  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(r,E,=,o,V,Q,c,[,],+,C,P,j,4,;,g,x,4,[,8)
#define  mczNMvNrF_ouK5Kt40KIQ  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(g,{,+,J,1,x,_,:,},b,K,_,3,l,2,+,a,Y,p,4)
#define  mpIqyDA89k7Oc7PxnefkF  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(3,e,^,6,+,-,=,/,^,C,6,_,Z,b,r,{,{,N,y,b)
#define  mntPcsG5ptVB5vQBK66S3  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(G,[,9,],N,;,y,5,-,e,],C,9,F,/,B,y,6,q,~)
#define  mafhFTdbpUPWPVZo43ucJ  mzazozMGwSuJCPqRJMiC41SROUCEk4p(r,e,O,!,*,],+,m,t,n,r,a,x,5,e,u,z,i,W,*)
#define  mIGuKXCX8pOD0SmVQ8644  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(:,P,G,~,e,L,*,F,d,P,M,/,t,],g,.,D,A,*,g)
#define  mjSTkXgp90SW5EUUlQrO3  mLJYxMggwZJzgkXuYmj1acSKRoHly7S(v,{,o,v,J,s,g,x,O,!,+,K,J,l,^,d,i,o,M,U)
#define  mfXm73LYzo3iJe5mBQfnR  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(h,U,7,r,o,P,-,-,t,r,o,!,T,!,.,{,/,3,N,-)
#define  mMMO4HjKC483luztYhrze  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(G,{,L,r,K,q,f,+,r,4,;,i,q,C,/,q,p,P,G,V)
#define  mVU_W1gM3fqsJqBqDEmrx  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(:,O,^,t,/,S,:,.,v,:,2,!,K,],},-,!,c,e,7)
#define  mTAP9LFMWvHZIQHllI2GP  mS8WaEGrZ0Qs0BsDm_JbRzNR0tSonbX(d,],v,l,p,i,K,c,[,+,L,],:,F,A,*,u,-,b,!)
#define  mYIIju_V_WKlC5oMA8MxY  mM0ClKE0ZWTim8NQpdFpNzxzA5eUUSz(-,},*,:,a,w,:,u,W,5,o,},P,Y,:,O,t,l,^,+)
#define  mbfVOgGo7GnP9Eyg_Kjee  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(m,[,*,+,=,m,Z,a,H,{,],*,g,.,],v,F,=,P,e)
#define  mRTZ4ih46U4cY9_VxkuoG  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(i,5,r,Z,e,K,=,D,{,V,!,*,k,;,:,V,u,},i,m)
#define  mhF3fyiak1UoyOhTDFUJK  mb4duUSAe25FggcEEdSRAMuiSNaf28z(.,/,t,I,a,s,K,r,:,i,e,:,v,5,q,l,K,p,},y)
#define  mDm3IKGiPKlQH9eyaT16N  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(v,+,u,k,P,/,F,x,B,G,T,Z,/,.,},-,>,U,p,^)
#define  mSazLeSbqwteKbYykT6Qd  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(!,c,u,q,v,f,k,j,J,U,v,9,W,^,[,>,>,!,{,^)
#define  mpMevd9Uiq3eXEARRq7Y8  mz1XpIzVxf85bp7VSu491XiyWGYK1Le(l,u,N,n,-,u,e,r,V,_,8,R,-,/,!,D,;,Z,r,t)
#define  mYSeUPt6nSBgihquz2hJw  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(w,x,w,H,*,:,-,L,5,F,n,M,:,V,n,w,],P,a,>)
#define  mHYor4xov_KdpFwYZPwUX  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(p,Q,E,/,:,H,a,n,!,t,.,],V,},:,-,-,p,T,{)
#define  mNGDLLEiEdU6l6wR0Iv7H  mlcNbC0Zn5AT6jTwdyMBZHtXhirEZai(R,_,l,s,m,f,:,V,},1,C,4,j,t,t,A,o,2,a,Z)
#define  mziZCqmB_A1HfU2C1dSED  ()
#define  mmw9tM2BJvFkHbj2nRR_0  mnID62rKQcfcp0IEktAfKevYVJgtqKw(d,*,=,9,*,x,L,N,=,A,-,z,},J,T,-,X,8,Z,H)
#define  m_unz1qRkP_i6tzvPIkvP  mV5jWO4jYaq0xrRTL06D0BMuXfgwfyK(w,.,J,j,L,.,o,K,s,;,F,^,P,n,l,u,/,2,9,e)
#define  mSmsDTx6VJgL2Fbqkp0NA  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(d,;,!,5,p,i,/,:,<,_,o,^,6,N,M,O,b,6,B,I)
#define  mR8Wucy41RxWH67A0kGiy  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(Y,k,a,-,r,z,I,9,n,V,F,M,N,W,C,W,9,+,b,+)
#define  mvM0aoGrNshbuWATX6PLZ  mybqFwvm_stxorYCR11OOdi0P7TM2hb(*,S,r,g,t,z,Z,9,m,/,4,R,3,f,;,U,k,b,;,{)
#define  miPSh2aH2dUUzoirsQa9Z  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(D,X,4,W,4,g,<,<,I,m,N,X,F,[,_,:,V,],!,l)
#define  mYZFy6rS4QcR6IyRFGbcp  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(O,C,a,h,/,C,T,-,3,c,g,;,d,m,4,;,+,J,{,O)
#define  mEiWR4KgD5KyJ2JhPctS4  mvxAVRxtyhzivBxjU_QMnENO6FebFla(Q,D,+,y,S,K,i,u,],y,m,b,d,s,f,x,o,/,l,e)
#define  mhJc9R2ePZOC_hcciHuFN  mcpXeRk8MTFTQvkDX6Lc1n1O6vKrbhb(j,_,.,n,u,.,t,{,{,.,B,2,U,t,Y,y,3,.,i,R)
#define  mJafDpoD1sw1HvQdWzAIG  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(2,*,-,},.,g,6,.,A,l,1,+,b,W,.,t,.,<,u,<)
#define  mpM5YkPR3jsHRMGbLXc0d  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(],*,;,{,R,U,],-,!,L,},^,2,4,K,V,m,],^,*)
#define  mSAirV0ERbm_7Dht4Beu6  mzxu0YaCrAAuNBGOMMsRBtO36XjkNwA(;,_,l,x,+,D,s,-,u,r,9,e,t,E,e,:,+,g,7,N)
#define  mzy6bDMyPTDIxNfNPZT05  mryAEIJFXOsqsVKwKQdyUL2Yutgg0sy(Z,y,0,b,},.,e,S,x,Y,[,w,p,z,X,-,n,;,I,2)
#define  mEOu6rTgPmdyQzJqnuPKN  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(r,c,u,e,t,A,=,k,+,y,F,+,_,r,S,8,w,X,:,])
#define  mj06PLvb8y2Xgwtg6u3Nb  myycSeUNl2UaSztHLUlp4thuB3KFoS7(3,H,U,C,t,^,;,A,.,q,H,[,X,s,r,i,t,;,<,^)
#define  maj3we4UWM8nMwoFsjfAv  mmyMbeM1Q1v1YCdwsw4VrXi7h8JuhIw(W,C,r,7,3,O,c,u,t,Q,i,1,G,z,l,[,q,t,.,s)
#define  mUN4KW_X0zOmmnyy87rRY  if(
#define  mqwkIpFXtv88x1mdX5klJ  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(U,T,+,e,r,c,^,W,t,t,3,!,/,c,u,_,P,!,/,:)
#define  mbvbLQyMMpSMPHndA_3NT  mMHTsHydCVKMWjP1DoNGCkuwtso7JNY(y,t,A,7,*,7,o,u,[,E,c,{,w,^,a,V,/,b,D,g)
#define  mJz3HTgXb0t_L3X02Qjox  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(/,{,[,8,R,6,&,&,7,;,*,1,E,6,[,m,/,1,/,K)
#define  mvRm5XV7HRh3vjPj8hxtO  mlcNbC0Zn5AT6jTwdyMBZHtXhirEZai(F,:,a,w,9,f,/,_,V,2,0,o,g,P,e,3,l,q,s,{)
#define  mqeze8eIhcJFwXpE81isv  mAH_0HZSOXSOH5z8WNKkxGtvkzPSa98(z,X,;,B,e,k,z,.,E,.,1,d,r,b,u,z,+,a,.,Q)
#define  mHlSYNykE6Qr6Ws7d8iK4  mXirATZHOeA_kQvjcuZu7hB13N2V0C2(0,n,[,+,a,E,^,:,P,A,Y,M,D,N,D,1,j,i,[,t)
#define  msUXfQEsZvo6MzqnVaJKe  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(L,.,w,M,t,s,Y,3,{,Z,x,;,i,D,w,q,9,n,+,e)
#define  mKxqvwLT5khvqhuX8xq1X  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(X,.,-,S,u,i,},+,},-,D,+,_,^,a,1,s,p,m,H)
#define  mN1KEP0eoeY3oenXrGS5k  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(j,x,-,3,w,},S,},;,a,D,Q,L,V,L,6,r,>,+,>)
#define  mPk7FrFSG0Bt87bT46qih  ()
#define  moiAOZfXpfyLmHfPB4Lon  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(V,1,9,},^,2,=,V,l,4,g,=,Q,:,*,.,s,N,o,[)
#define  mPJhKjWhkbCeyYutfZQVH  mn_4S2ljijVENFuMmLGQR2YToS4cmzK(:,W,c,4,y,7,a,h,r,p,-,w,b,],O,*,u,l,g,i)
#define  mqoWZTT_oZADMO_LPrSNq  mhHn8LxJUItCdbzq4uzcdBKJo1gQrDD(P,r,i,n,Y,!,t,r,G,*,e,^,^,m,0,/,S,/,G,u)
#define  misbKJ09SZIWeoCAWH8B5  mWCDDZXzLUqCb7bkeRuC87IfMDMXzZd([,!,o,u,t,[,n,d,f,a,r,/,r,e,/,/,M,J,s,o)
#define  mAxXgcvITONDKOTGuzG4Q  mO9XTjhg3cZKfnn4amRi5fySmVeY624(d,/,e,[,b,[,-,o,l,0,{,u,_,4,k,W,I,{,r,n)
#define  mwFnwk_57M7ZxnlKE8uak  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(m,X,l,g,f,1,x,n,-,*,u,=,V,s,],Q,H,l,+,3)
#define  mbyLqb1P9w6PQCZ1mI89v  mJYQ2V8runtqekLZKRxtRfrKTXGSosI(t,3,5,.,u,U,e,n,!,y,u,.,M,t,J,i,M,r,0,M)
#define  mZGBokuovpRJ6m1PJGGhs  mnID62rKQcfcp0IEktAfKevYVJgtqKw([,4,|,-,F,8,K,;,|,g,*,5,},p,P,I,d,a,z,r)
#define  mc4FLNVVF3DcD92oc2XM_  mX6PEBA63VRK09B09dUBJ2uazHomUWr(=,Q,^,y,3,*,B,.,P,F,t,n,k,p,W,F,q,z,B,U)
#define  mc4sFptKgz6Blb09hl0bU  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot({,G,u,G,c,!,+,+,f,0,X,!,Z,0,w,H,L,R,v,G)
#define  mBgK95MS0UiLVqEW0L5Qf  mYz34v14gNqWTNOc3JEJeTrSQVXsdkg(A,E,^,!,o,f,8,z,f,a,Q,-,v,!,1,e,l,h,J,t)
#define  mC2U87XNwf9ZFXAKjANTz  )
#define  mxcWhEYxwtVbYdB6RLHuz  for(
#define  mxxIM_AOB03IyZf8fYf6u  )
#define  mBrhLQBFQSLppFvFBNqdE  mh1d9DrxpIRxkD8q0yfkhyGnM5yWozy(+,b,a,o,[,e,d,u,R,3,d,p,z,H,k,o,!,z,l,:)
#define  mdUz9Gyy9f9VvOlZp4e08  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(G,!,x,^,L,O,l,!,;,2,u,*,7,i,E,[,6,],Y,d)
#define  mkgatJfG1B81eCsEcIO1O  mbaw1uaAWdzEvPVvXYvMjSiVD0AOo7b(V,!,a,p,/,q,x,h,v,i,r,:,c,t,6,E,e,/,},])
#define  mzS2pIT1YYp5TGkDOsiKp  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(A,^,d,{,L,R,],e,a,!,U,^,-,V,o,l,h,K,e,g)
#define  mEsRHs2i4HKWq6GruJOUE  ()
#define  mpbpPqTwANraPtSIcXTh9  mX6PEBA63VRK09B09dUBJ2uazHomUWr(:,t,v,F,-,:,.,V,+,d,.,T,d,+,*,{,P,3,o,O)
#define  mQc3jTs74gmlo2nIZhfnn  mnID62rKQcfcp0IEktAfKevYVJgtqKw(N,6,+,7,+,*,u,-,+,g,l,X,D,Y,*,C,N,M,7,V)
#define  mVaNNXCZ48LWCRY3Gz61K  mXirATZHOeA_kQvjcuZu7hB13N2V0C2(:,o,T,*,],A,T,;,*,B,J,6,6,l,3,/,;,f,.,r)
#define  mVs5ACgUB2p31u162MtOo  mcJWcZxVTqBKmmE2VsHWGk4lVlsrNkQ(},a,j,s,b,h,!,l,/,3,s,s,/,l,m,+,G,c,t,^)
#define  mpckBDZDg0lImhP8_RoIV  mX6PEBA63VRK09B09dUBJ2uazHomUWr(&,+,6,},8,&,r,D,C,2,R,[,6,{,V,m,k,{,k,Z)
#define  me6PYmh_pLOff4WWxiOIk  mGEt5TRwydpdaNpgZWWwwn96FfNYmss(a,V,f,/,Y,[,},8,f,H,k,+,l,t,8,+,7,2,o,[)
#define  mOWRlZXbFEaADN9JS2Lan  ()
#define  mcMwSQ4Nrn_S8nH7ffWbh  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL({,B,w,4,d,p,k,W,s,I,r,k,x,!,N,<,=,4,L,])
#define  mNmv9VnLRHqL8v_b0Vl6D  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(E,I,-,W,7,Z,A,e,T,9,t,},d,Y,s,.,V,F,f,<)
#define  mPQowycrYI4w5Ux6AxEWz  if(
#define  mI9x1tVbS1Tc1HJAbYfBt  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(X,Z,E,!,F,{,.,w,r,e,^,4,Y,Z,],i,f,b,7,w)
#define  mb1l8IcWnFnKGpGlxMKRh  mX6PEBA63VRK09B09dUBJ2uazHomUWr(=,Q,/,-,t,<,y,Y,m,b,e,!,z,x,.,.,V,s,],Q)
#define  mSgEajsdKbuaiMSZyOsoS  mPdT36hfVREF2V6Z6l8Vj_KGZsxwYDo(},X,k,.,i,C,O,*,j,t,1,:,t,Q,0,{,.,H,K,n)
#define  mkRm0ZCZboNdxvQrqPcoe  mX6PEBA63VRK09B09dUBJ2uazHomUWr(+,j,d,{,{,+,+,:,w,/,[,[,c,:,q,9,P,.,4,.)
#define  mqEVaWmdpsYX8ECMUICjt  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(.,P,Y,+,v,M,Y,k,_,+,3,=,u,j,B,K,2,},V,6)
#define  mmQhYR0O8dG2ezP0nVrXG  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(7,t,p,c,j,K,},6,{,[,*,E,3,7,p,/,U,U,a,;)
#define  mbl7KuzNNsAeMjukrMWf8  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(],.,l,Q,6,:,N,f,6,1,{,M,6,.,/,A,W,.,H,{)
#define  mzSgA62kh9X60P2ZbU_ZB  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(t,d,-,7,C,C,|,p,Y,-,K,|,5,I,/,f,;,o,v,{)
#define  mpQS0nDsmQlwQ2e3f2bjF  mloG7lVr6x6THUHui9zTrcWvWGWm3wS(t,^,S,p,9,O,*,e,S,4,i,k,L,N,C,W,n,Z,W,x)
#define  mLFYAC7eEE2IToT_uHOvu  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(6,-,P,*,*,x,>,-,i,d,],D,v,8,a,W,e,1,a,4)
#define  mjfJya0RtMs9NMmXRYyED  mz3pinu8xTWy4Xa1YhZ8F7S2xw7PIaA(5,l,e,v,w,:,p,_,I,k,T,Y,r,e,i,-,t,a,v,w)
#define  mg3iysm_kMILavdIUb6iZ  m_yrai7SAyV9XzvSJ0wstMxebZiQ594(!,O,K,:,!,+,-,n,Y,r,e,w,],r,[,t,3,u,},4)
#define  mfEgXFAXdHJMIz0B8yDNl  mM40WYfTE6YxqkAjuzmOeOg1sLtwmNT(o,[,j,l,F,f,l,/,;,a,P,t,6,f,/,Q,u,V,P,*)
#define  mIWB3d9WRT1oBpLh4jTRb  mnID62rKQcfcp0IEktAfKevYVJgtqKw(},},&,c,S,y,:,b,&,t,!,Z,-,s,s,F,U,2,4,4)
#define  mZASZ3pzj43HOXqJe3HjJ  for(
#define  mCDc7XI3__JhdWUPFx8Vc  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(|,/,a,S,D,Q,D,^,+,z,*,2,|,s,{,l,s,8,Z,n)
#define  mNnib6VR7ygORjYjtyQtJ  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(c,.,C,K,r,{,=,*,w,},R,c,g,x,4,^,;,f,n,m)
#define  mXYzN8rNVUQrE9RbuCkk3  mJnEornm9htjmBxV8hRo5mlLdJ2O7mG(e,x,},v,v,i,s,^,x,4,:,b,f,2,G,Z,l,a,E,W)
#define  mtauobhKRCbBYVNU4AA_V  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(S,.,Q,},x,8,0,2,j,7,B,v,v,I,W,x,T,Q,},0)
#define  mI8KmYSg83FC3c5M8hTZv  mloG7lVr6x6THUHui9zTrcWvWGWm3wS(r,w,9,q,P,s,a,P,},/,f,D,1,},],j,o,G,E,y)
#define  mYAqz3yDOwrT6DP43Mbva  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(=,-,n,s,c,c,t,k,;,6,*,^,=,o,.,{,u,x,F,-)
#define  mRUr_etSUlVmt81YhAOZN  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(},z,P,c,M,7,/,^,A,h,q,V,X,.,-,t,e,y,.,^)
#define  mvNovGu6V16d03JNueGOd  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ({,r,L,S,g,A,=,r,Q,;,_,/,-,!,!,U,+,K,[,u)
#define  mwIgCaQNFvoAfd0ysnhOe  mzz5441oXHeL3YKYtSWVPxoD_u2rNpA(o,t,n,t,9,2,-,c,_,Q,s,s,S,:,a,t,3,G,i,u)
#define  mFbAVrlmDm96iXbQBjlbL  mlcNbC0Zn5AT6jTwdyMBZHtXhirEZai(G,a,s,G,h,u,{,Q,!,d,_,j,},c,g,0,i,{,n,v)
#define  mMdGMVINdENVHxHpI3vYw  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(0,},=,!,w,;,l,w,7,!,m,I,e,;,K,7,j,E,N,z)
#define  mp66f6tdTOrQMxZizsMe1  mw_R_htyaKSawpTt_nyN34gwSIKFwim(a,Q,:,r,c,s,s,*,.,!,s,N,L,-,l,P,r,q,5,u)
#define  mF5RlLb6BEJo7uQwtI8Id  mMHTsHydCVKMWjP1DoNGCkuwtso7JNY(^,o,n,M,.,^,l,o,P,K,/,m,2,p,b,^,h,v,N,0)
#define  mVN6PcFPK5Lb3XLxcPcRF  mJnEornm9htjmBxV8hRo5mlLdJ2O7mG(k,Q,N,Q,H,:,a,},4,*,!,u,b,J,Y,^,e,r,m,z)
#define  mM38EeL_dg1sBZmW_8iwh  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(o,Q,:,d,p,+,=,R,0,P,.,A,F,m,q,K,+,V,],5)
#define  mAahCNRhbJ9K7gAbilQcg  mXirATZHOeA_kQvjcuZu7hB13N2V0C2(D,e,.,b,-,y,[,y,1,m,.,[,P,},_,^,+,n,B,w)
#define  mnp6FP5nP7SgmHKCvhR_Q  mByy67jxaShsJThnKTR2VBb7mnCF0r6(-,D,=,m,.,-,v,^,l,5,},],9,z,q,r,e,Z,[,E)
#define  mNS8CwpKqN7XhL3OuE2eA  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(j,],],B,i,{,x,A,:,M,W,9,y,W,-,-,f,f,u,/)
#define  mGeC741PMGs0tF97WkQxi  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(X,g,P,-,^,/,{,h,0,{,2,M,8,z,.,R,:,[,I,w)
#define  mkhR1nFUrAUwQ6kBZttfc  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(b,Z,/,{,<,I,[,Z,P,[,T,*,[,!,f,h,F,=,c,C)
#define  mvcP35u1JA7WGIvMQHL9L  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(G,-,/,X,[,V,-,D,e,],{,-,c,o,.,-,C,W,b,j)
#define  mzRttPsCqlyQ4wnoFrIWY  moA8VghehqaVpoXQAZdpVKczKJ9WCTX(k,T,r,},J,],b,n,;,u,J,},b,a,a,7,j,e,*,8)
#define  mCiLDfbLLxJiEEzJNN26O  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(Q,[,q,D,0,},:,},T,Z,:,:,R,!,k,3,A,v,S,[)
#define  mYLJIFBXE8E1VUYKAJAkM  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(i,;,C,5,x,4,e,:,b,!,s,s,f,R,v,{,v,s,},g)
#define  mkYGGpVld4zcK1H1H28To  (
#define mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(WOALj,QcoQD,x9Dr0,LsQD0,yew6F,E19yL,etTZH,AapFP,_0gUC,nZJGe,NPcAL,_8pYg,Sig3w,u15bU,Fpqb4,r4tmF,zILXp,v2jG4,lyfPX,wowXN)  nZJGe##x9Dr0
#define mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(jBDiA,dyAm7,xq69q,oqHyK,ryE5w,gb67J,AnE_X,QZAij,g5qr3,d1787,p_dB8,T_gfy,IZmBH,asbzj,GdgEl,Lqnu_,qQuW5,w4SVE,oNbZN,sUxuj)  Lqnu_##qQuW5
#define mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(A3lb7,yg5nw,FBIfH,e4554,YzzcF,OtOCU,RDACz,OTGP8,JOegT,BWed6,hanLm,ztT14,Z9xQa,AATcr,LVPz8,I56dS,fJjNL,wTwmt,yrfHT,Ol_ai)  OTGP8##RDACz
#define mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(EOZhM,g4mnU,uPUwZ,Kkm6L,C9Rbz,QYh4D,L97Xy,ti00d,NkIOr,wTn12,jYI0b,qMfBs,fMKkO,O1gZQ,s0zv0,pKXxL,sPU7Z,mKh22,KJ6bt,V1X5x)  EOZhM##fMKkO
#define mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(LXdkE,iyuod,Ovbfk,PX8qQ,U93Wj,Q3KNo,i0Wmn,ZD2Cs,cWJuK,xsuoO,y6guU,yLTy5,UhTBs,ebqGU,xE3s2,XcY8U,AxL1v,J16lB,_6ZwM,pMGAE)  xsuoO##yLTy5
#define mX6PEBA63VRK09B09dUBJ2uazHomUWr(h0ijt,T671X,GdBrY,dqEeW,RrCua,Srima,Gqh8s,pGsY5,jaFIE,M_ccv,Hx10h,YkRIu,wFYNo,rvF3D,VbTPB,iUJbV,c4keN,itrVG,O2YO4,HuKMH)  Srima##h0ijt
#define mnID62rKQcfcp0IEktAfKevYVJgtqKw(Fynb8,MAR6V,_iSOL,XezUC,YzlFU,irXOQ,s4plB,QQ1bp,RNyXr,KaADq,MQUMn,B6zqq,B0aBc,EAkUi,yCBqO,sDOxY,AXJnM,rWAVj,sFwbk,_PnMD)  _iSOL##RNyXr
#define mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(NENxF,rhqwH,zasdU,xngCL,j02ML,jBDr6,TN8sH,hA_Mn,w6G2J,uobF9,qc6QT,eWY_M,KrzRE,ubr9e,TpyM4,qHkNg,uWh8W,xywwO,kHiYR,_9BgW)  j02ML##xywwO
#define mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(tnvDy,kH3C8,xkGsV,K0ugL,KUlxL,McWbq,Hjl2u,iCaE2,L65sl,yQwsO,K6v9i,nhSLl,FjYnw,Mugzm,GtrLl,qOKXW,b6hiR,mb9aO,WGzoD,Sdc2z)  mb9aO##Sdc2z
#define mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(fVoDi,NVUwK,FiDpD,g6Pg3,X7j_t,xSlle,oixac,OixnV,VcFrJ,EDOUD,VCiTw,D14qb,L9L1v,jMSOB,lvy2O,w8Nza,KVLPJ,LO5RO,mXLlu,EZTUa)  D14qb##oixac
#define  mZ49bGbu9rE6BKxffEODb  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(k,Y,Z,o,I,/,t,p,^,-,*,!,[,-,;,J,5,b,P,:)
#define  maOPL_xI9FaWWmxHgmQwE  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(f,n,-,7,Z,Z,<,Z,P,E,c,<,},V,.,C,i,f,s,*)
#define  mScr_8JY4Wl1nM2nHzX1v  mmxqmWLHQtwfQxKy29ier3THb5Vsw35(a,[,h,[,i,v,;,a,T,],S,:,r,N,t,e,8,U,3,p)
#define  mxsc3TsxoTYmFVfeJhB30  mqLrUVJAhaaGHP_VDYSGuQ60Azx5PAj(w,e,n,t,2,G,Y,u,W,5,{,;,r,.,M,u,C,],i,8)
#define  mdDpB6nj7kzPJxMeIpI5M  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(],/,V,V,-,p,N,U,g,6,_,R,+,E,-,q,q,>,X,Q)
#define  mKgLfbnWjJ3pKomnVjtCz  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(:,z,x,4,h,W,k,*,B,m,i,:,:,[,[,Y,p,;,.,N)
#define  mU6DrvKeNIs2fWOr5JPK9  mV5jWO4jYaq0xrRTL06D0BMuXfgwfyK(t,S,B,1,D,B,7,U,g,Q,s,M,C,i,;,Q,-,B,a,n)
#define  mvWPUxuxbWIbPmfk8o8Qp  if(
#define  mpqmTF7ZivMOsnTmsD82Q  m_yrai7SAyV9XzvSJ0wstMxebZiQ594(},I,W,J,7,a,!,e,A,d,o,+,!,l,E,u,0,b,A,0)
#define  mss_Ro6jefLI9lwP9tbbb  mryAEIJFXOsqsVKwKQdyUL2Yutgg0sy(:,U,3,7,8,z,o,+,e,S,d,r,E,S,X,L,f,!,{,X)
#define  mpYp1wggXv3dy9hKrzsZz  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(c,{,2,t,;,H,T,s,0,7,y,],A,b,},s,I,y,/,Z)
#define  mrfHVJw86v0KMYlOEw4NF  mw_R_htyaKSawpTt_nyN34gwSIKFwim(l,P,8,G,f,e,r,T,c,x,s,/,},S,a,2,3,_,b,W)
#define  mAzduthvD_Jv93PFFx9tV  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(C,p,+,y,s,N,U,1,8,+,],^,],H,t,4,a,X,{,j)
#define  mse0lbKf3CsjMx638ZevW  meLJOI7HgX5w8hFT8ddZEsuYBNcUX5z(d,Y,-,x,s,j,b,],V,O,b,A,D,p,l,!,u,e,B,o)
#define  mAZltqLQI2aI_C_9z2COK  mnID62rKQcfcp0IEktAfKevYVJgtqKw(.,e,:,1,h,6,R,m,:,.,g,3,*,9,*,H,Y,t,;,t)
#define  mqdcpMWmlN5IIXLVC9PO2  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(*,d,b,a,j,t,M,K,G,^,_,!,=,y,7,J,G,;,],q)
#define  mdflGO3qRm5JTp7QUuQVo  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(*,Z,5,{,i,o,g,.,=,q,M,{,H,8,-,/,Y,e,;,E)
#define  mKSICpW8vuO3y2MZszOf2  mAH_0HZSOXSOH5z8WNKkxGtvkzPSa98(r,A,E,*,l,e,J,},],r,w,I,a,f,:,t,x,s,E,K)
#define  md0OZEwi4YofGotGtNTdI  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(r,;,q,1,+,],X,[,/,<,B,=,y,u,6,R,x,-,2,])
#define  mRaN47LBoHuQndebyY13f  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(s,5,x,=,-,+,U,N,4,a,P,/,l,l,;,D,8,},-,E)
#define  mmP_PQ_VFHIilWChY46Hv  mEgogoNVf3v8CZpseAB6nJg22S1zZmg([,T,/,u,^,W,q,p,+,g,B,v,z,.,E,D,H,5,E,!)
#define  mJft7epryDvCsSeZ1nymh  mW2I8gprowgNJRZhS9GSa57CM8DUKQY(d,A,r,e,f,],J,t,G,r,.,r,-,^,O,0,o,6,A,[)
#define  mUdsYmKtgGHax_EEA1C3i  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(2,P,},3,<,T,W,9,Z,S,6,4,s,y,^,S,V,<,u,I)
#define  msrhIJTdkmEYhV6_myMXD  mYz34v14gNqWTNOc3JEJeTrSQVXsdkg(;,3,{,*,a,c,X,*,;,s,f,O,L,E,R,G,l,:,},s)
#define  mNyS5gnb2ZgYWBRo4rtYu  mX6PEBA63VRK09B09dUBJ2uazHomUWr(>,V,.,q,^,-,V,2,P,r,L,-,Q,T,R,s,T,e,I,v)
#define  mySIdJB4tJejLndYpQUDP  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(<,Y,U,N,Z,R,u,P,e,b,[,+,<,h,E,+,[,B,J,M)
#define  mH1C295IyUacmxVPN5Tmp  mzazozMGwSuJCPqRJMiC41SROUCEk4p(l,o,0,Q,-,y,N,7,u,e,d,-,e,9,s,b,x,^,{,.)
#define  mXngFVa3kwewf5KlFRpga  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(c,z,_,*,o,5,},x,F,Q,.,U,k,s,[,>,=,r,H,I)
#define  mSdUsC90bhOS5QOrzfHT5  mEgogoNVf3v8CZpseAB6nJg22S1zZmg(^,8,{,i,M,g,J,^,S,{,5,.,9,2,G,+,x,p,2,6)
#define  mS4W7jBK7Pvm0zO29hcFJ  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(5,A,;,.,^,H,Q,Y,!,j,U,~,1,.,b,],+,V,Y,-)
#define  muUJHfiFTwjN0GjwzH8Zd  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(},^,<,2,^,1,m,;,X,<,],{,V,T,8,!,G,B,.,v)
#define  mUZCxQXQmCyvZWbzK09Of  mnID62rKQcfcp0IEktAfKevYVJgtqKw(b,p,!,e,4,U,V,.,=,W,o,1,P,K,w,5,Q,A,C,{)
#define  mbcL5Dc0V55K64qUxo03v  mzxu0YaCrAAuNBGOMMsRBtO36XjkNwA(p,{,o,0,V,!,o,+,j,k,W,b,0,J,l,M,},8,j,Z)
#define  m_SbjIOdih1Gt_BCpBG7_  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(E,I,=,1,l,c,z,+,i,*,D,:,L,3,v,P,g,f,!,s)
#define  mMYIdWbegzKp0WfXd4OfQ  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(c,L,!,*,!,I,K,l,V,8,;,[,},A,7,N,/,=,.,*)
#define  mdfxuir_eER1fhqyzY8uj  mByy67jxaShsJThnKTR2VBb7mnCF0r6(},u,],y,t,x,S,M,*,[,o,A,[,k,s,m,c,;,x,h)
#define  mjWA02rPm7QZvt5TW_FG5  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(T,d,m,i,:,t,u,},P,8,G,T,O,/,},R,W,-,8,-)
#define  mK8s6M73UzXaQY_l03t7m  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(Z,k,k,r,Z,;,N,3,z,2,x,7,r,T,L,+,+,E,o,t)
#define  mFsL2LkgC6E9m26FY8rc4  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(<,:,r,E,:,n,^,:,l,E,B,},=,Z,*,B,V,^,^,r)
#define  mvZzhb1BoYYsM5Y7OSBbt  mcJWcZxVTqBKmmE2VsHWGk4lVlsrNkQ(B,l,r,e,k,-,!,p,V,1,[,s,:,a,H,^,+,f,f,^)
#define  mIYPy6lUjb6rbsa5XzeW3  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(n,.,s,w,9,v,L,.,8,.,v,h,.,!,n,v,T,>,:,=)
#define  mwCAEf9o0eyrlKoJ__khw  for(
#define  mmrPLtXwwwYKO7hwiCAiw  myycSeUNl2UaSztHLUlp4thuB3KFoS7(},U,I,t,o,H,q,R,Q,l,Z,U,U,-,X,z,],a,{,0)
#define  mC2cKdD22nTd9HMBA3roy  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(d,[,O,K,L,I,/,1,],h,m,Q,G,L,M,P,2,],m,y)
#define  mj6DS96SUxFvui6EQtWtu  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(5,/,!,7,Z,;,!,:,{,x,m,x,Y,f,K,u,I,+,G,{)
#define  mnvCKsDZ686eW04ktcmm2  mybqFwvm_stxorYCR11OOdi0P7TM2hb(B,k,J,O,c,*,^,2,I,!,x,F,P,-,G,J,/,2,{,:)
#define  mB0SH1azerGYYDrJ5A23M  mybqFwvm_stxorYCR11OOdi0P7TM2hb(y,/,u,+,J,l,{,.,*,s,E,s,[,X,!,:,+,x,~,B)
#define  mjskGhbPys3znx8ohhpol  mnID62rKQcfcp0IEktAfKevYVJgtqKw(+,+,-,A,9,;,u,x,-,s,B,u,{,b,5,},r,5,V,N)
#define  mJ6iYx79kyQvrGGdug3tL  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(],c,:,R,/,:,W,l,X,{,[,*,z,o,/,/,P,=,3,j)
#define  mLCwp82CRyzunhp6opa1o  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(r,J,^,*,b,0,=,V,p,3,],!,W,D,*,g,A,{,a,Z)
#define  miXGg_BS1GNUOxSZTu1I6  mUlvUgXM19DoWwwVfwIuc3_vLn4ainn(4,m,l,k,o,/,l,!,n,3,u,;,a,_,^,*,a,o,b,U)
#define  mcXpKydk0n62EjiEJXTe3  mukmkAKLvUgWsEw5KanuTTPD3E5YLoh(t,N,A,!,*,Q,F,i,l,u,U,A,p,h,:,c,b,n,8,F)
#define  mFgWDhQLYwtW0poQ18ZdX  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(k,*,R,^,[,9,b,v,l,f,r,/,u,z,I,P,},!,:,s)
#define  mpYoeKMm2usLCbYWeE9KN  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(.,*,s,J,I,f,!,.,+,M,[,*,N,P,I,&,&,H,0,U)
#define  msQAJ7G3bgfXRjghTZhcE  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(U,/,W,I,&,/,n,{,{,t,},:,o,/,K,-,},&,V,7)
#define  mf2DmqhN91_hxYrkrBOoZ  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(y,G,S,7,8,E,H,-,U,-,u,},R,L,},L,H,v,0,4)
#define  mw3udxpQRet78OUq8pUyD  mcJWcZxVTqBKmmE2VsHWGk4lVlsrNkQ(i,o,-,t,:,[,O,R,/,u,3,a,m,l,p,!,:,f,7,:)
#define  mDZnYz5510zFVNkSFh1my  if(
#define  mH3QVan74lKZrUT6pDiCC  mOTZPAjzEI7wD6T3bwxkJiMGsx8uAz5(:,;,P,e,r,^,:,^,t,p,a,Q,.,3,v,0,i,;,},+)
#define  mUCktCR2DmCnhlAo5aA_J  mX6PEBA63VRK09B09dUBJ2uazHomUWr(<,c,[,+,q,<,S,b,8,w,U,Y,b,z,6,1,O,5,],S)
#define  mFbX4V_4RDsCxgsT01jvH  mW2I8gprowgNJRZhS9GSa57CM8DUKQY(p,Z,q,M,n,I,[,O,},S,e,w,1,y,X,k,e,S,{,/)
#define  mbtoRHAe_W6JhuGU83bXu  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(i,2,b,T,{,:,N,d,S,!,o,=,C,v,{,j,M,4,7,M)
#define  mlbyD1tzFC7tNI73Qw25t  for(
#define  mOu8sL_sSsaWDMcd6PkWs  mRfitOutUGZGSjoiLJJkYDKqa4u2CyQ(e,a,6,^,r,i,v,0,9,d,:,},g,8,t,H,:,e,p,N)
#define  mthZBBlRe4mWFqORrz8uk  mcpXeRk8MTFTQvkDX6Lc1n1O6vKrbhb(D,e,o,i,p,A,v,;,7,Z,L,t,!,:,z,r,a,0,r,H)
#define  mMC_Jjv_5DlpMspwpJcsm  mPfnwggwbOzHSfHtQ9LsmiZYVFf4qPW(-,a,{,e,f,t,n,m,a,l,{,h,o,V,6,a,+,t,/,-)
#define  mRroqIukYBuwRbyovvBhh  mX6PEBA63VRK09B09dUBJ2uazHomUWr(=,c,k,6,P,/,.,/,V,v,P,Y,B,W,/,o,E,9,},u)
#define  mIQAg830_BxTPzZ_16rHn  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(t,I,a,{,I,{,O,z,r,;,},X,p,.,W,b,{,t,Z,[)
#define  mTEEPSOfPx2bNT0rQ0Ghu  mUlvUgXM19DoWwwVfwIuc3_vLn4ainn(o,k,V,_,r,h,e,o,l,E,+,X,6,y,a,t,x,u,t,d)
#define  msUEq86XA_r6BY6t6AG9_  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(x,[,m,h,l,],/,X,*,n,p,6,c,s,[,[,!,/,*,=)
#define  mrNnhWbMAL0yJBb53lVUr  mtmD3lZYb_Gu_7mEP1aib4ziGDxxfF3(],f,+,e,-,I,P,g,a,-,a,+,s,n,l,4,G,n,P,[)
#define  mK5CsFBtQZD6cP8kGtt1n  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(I,!,v,o,:,8,:,},T,.,Z,A,q,m,-,W,!,:,m,X)
#define  mLtPirVzbHf2vwwQuKys5  mX6PEBA63VRK09B09dUBJ2uazHomUWr(=,V,9,!,[,=,i,w,^,4,K,q,I,a,!,a,],T,G,t)
#define  ma7exivcDMvVahmow8Wy9  mX6PEBA63VRK09B09dUBJ2uazHomUWr(=,I,f,X,o,>,W,e,7,Y,D,l,],y,-,V,*,2,C,{)
#define  mjKbHOZDpGGwQ4d9RU_Wk  mb4duUSAe25FggcEEdSRAMuiSNaf28z(O,+,2,;,3,o,.,i,t,n,_,F,t,s,!,r,3,u,},Q)
#define  mOv1BXKtkMtwYf8qiTEg7  mLJYxMggwZJzgkXuYmj1acSKRoHly7S(],W,x,t,],n,N,t,5,s,l,L,Q,-,^,e,u,r,S,.)
#define  mwOVOny7gqfvUOC7o9X8Z  mhHn8LxJUItCdbzq4uzcdBKJo1gQrDD(/,s,F,t,U,3,r,c,L,6,t,O,r,c,9,g,c,0,K,u)
#define  mll4jssxb27dgTVvjSKNS  mzz5441oXHeL3YKYtSWVPxoD_u2rNpA(E,:,i,e,j,t,U,!,e,N,Q,[,3,p,[,v,a,7,r,p)
#define  mPvZpvL72V17g0ZY4GnbS  mM0ClKE0ZWTim8NQpdFpNzxzA5eUUSz(-,+,X,*,t,],c,r,C,z,e,K,U,+,G,},u,G,X,-)
#define  mJK4akBnWEmD0mgPq0bTA  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(1,9,U,},7,!,T,d,v,f,j,D,.,q,/,=,=,x,R,x)
#define  mXkUwKFbDa_e3TRiybkYo  mUlvUgXM19DoWwwVfwIuc3_vLn4ainn(2,.,},O,u,6,o,u,i,P,Y,4,W,_,a,K,],t,a,!)
#define  m_dWA7IZyheolQmKBoBhq  mzxu0YaCrAAuNBGOMMsRBtO36XjkNwA(3,.,o,.,/,O,i,K,*,E,!,v,b,J,d,Z,Y,5,6,w)
#define  mtzPVsIpQTEpiRcRoLGBN  myycSeUNl2UaSztHLUlp4thuB3KFoS7(f,K,i,T,b,{,*,;,9,-,*,.,m,0,^,E,7,0,[,!)
#define  mUMmK9fRoAciuN43ywQh3  mWDZMZ1KDAWIS3QvjrEl7eTLzbo2gww(s,3,T,p,n,u,G,_,i,;,3,.,t,y,t,2,s,o,*,{)
#define  mPF42eNUygPTcFvVf9uam  mnID62rKQcfcp0IEktAfKevYVJgtqKw(h,W,i,{,x,+,a,p,f,O,+,M,r,r,6,},P,-,9,p)
#define  mHlPNt3_yhapqGlT6MDlW  mGpNSv6qtjKcDoBHRXx6VGAngwNP9y2(c,},3,+,;,v,u,K,s,I,p,b,F,:,L,.,r,l,:,i)
#define  mDlt10XoSR2fYKK3SFBVJ  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(/,/,>,Q,F,p,^,-,I,>,Z,q,9,.,H,p,y,s,!,o)
#define  mBd07NVm9WkRAYIqSBH4p  mEgogoNVf3v8CZpseAB6nJg22S1zZmg(],+,*,6,r,/,],a,A,X,*,7,Y,p,G,s,;,I,{,^)
#define  mhumxDZMVJ2JSSXoXovag  if(
#define  mj07x5HWiBpHUi6Wui23U  mJYQ2V8runtqekLZKRxtRfrKTXGSosI(N,!,;,!,s,T,e,7,*,D,r,-,0,e,/,B,},l,g,2)
#define  mhhdAKxcs2afanmxNRNTd  mRiIgUIu8k1v3YUzQcHTbtxqqZ5gOhH(5,m,i,},+,a,:,c,!,e,],y,e,;,n,{,U,s,a,p)
#define  mVShjW1LFaDgpJlcElzJ0  mEgogoNVf3v8CZpseAB6nJg22S1zZmg(=,w,S,0,y,5,.,_,d,n,;,m,D,t,N,m,V,g,K,K)
#define  mNAD5qElfnwRO5V3swkF_  mzazozMGwSuJCPqRJMiC41SROUCEk4p(c,t,P,2,U,J,a,a,r,t,s,y,5,I,},u,P,n,c,-)
#define  mRyrz7Lx6P46lCFkVeo2x  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(4,o,;,p,j,f,-,S,],m,J,R,7,n,c,!,^,^,*,])
#define  mvwO48Hx1_ATyLQy0WLcx  myycSeUNl2UaSztHLUlp4thuB3KFoS7(;,l,E,;,j,i,o,d,W,R,7,;,k,h,Q,v,j,/,},b)
#define  mc145dtNd8ENwKU4BbbuH  mMHTsHydCVKMWjP1DoNGCkuwtso7JNY(K,s,8,m,f,.,e,l,p,E,u,H,+,J,e,M,X,6,U,-)
#define  mEhQx298_sPoXh3cUDtAg  mkdrdjrDJb3quxTkzmg_eZhPFf12IC9(*,V,E,!,4,-,x,0,Y,},d,a,c,j,t,O,*,n,A,i)
#define  mTrXDcVbxxIBGIi4oU5w1  mnID62rKQcfcp0IEktAfKevYVJgtqKw([,z,<,/,*,K,D,m,=,{,-,U,/,b,{,1,1,u,6,r)
#define mPjkCHzK5CpuULgO2Y3dNGgy0gjE8B6(J9ro3,XY3wn,ZGtro,dXDu0,h9riH,f5cSs,HpDyk,m3Epu,I5Yr0,Pvi7b,aE58f,LZk_X,hTWBG,VsVjh,_yP_4,BdD4l,HZSjX,IURjf,wqZda,mqEVo)  I5Yr0##J9ro3##m3Epu##aE58f##IURjf##_yP_4##mqEVo##LZk_X##hTWBG
#define me7GHe4ydXod7Tk4XH7TynmwA1BSclJ(Io2_5,RBC73,wl4VJ,phOnd,FLfdX,xIZwI,Yao9i,yAdue,MncSb,P3YUf,TaNnX,DSEEa,bR4jJ,oNXFo,Ve828,xMPT9,jZLLm,YsLKc,_F0dV,KzSs1)  Io2_5##xMPT9##oNXFo##DSEEa##P3YUf##Yao9i##phOnd##Ve828##jZLLm
#define mKjc7UtpIzVI2We_H7nbZibmrjpPJ1h(rR6h3,zfkSH,s_vTH,oEpiA,gLQI6,GWAGD,krrBJ,XF6wi,udbnJ,d26AL,xVi1k,WBl6N,_QJKL,sJeJ5,KpzB_,ssn5u,J7jlC,dQW9j,NRBml,fq5g_)  WBl6N##sJeJ5##KpzB_##udbnJ##xVi1k##fq5g_##rR6h3##zfkSH##krrBJ
#define mfz8ejWk23fL0rXMJ17_iF3tq49PGsB(lQNVt,M9FoS,M6EbC,lklmW,QM_oO,Ok3xF,ZY6RL,CecwF,iQXhB,SgRIS,J1Z2x,K8K3a,dHKCB,Q9yWs,_Ao0R,dOHNQ,dNOTR,S1DRD,rCXxj,fLWuK)  S1DRD##Q9yWs##M6EbC##fLWuK##M9FoS##lklmW##SgRIS##K8K3a##CecwF
#define mmT3Mncp4X0CzSLpgam1C9RV2fdC3j7(cByDt,CuXeF,ultmo,TWFoN,hXT8N,Wxqx9,_6byj,QAbNx,EiudW,zOoBV,RU7iR,msM0q,lKFRg,s3tkf,NNlpZ,QPk85,ZT1iU,CI81l,oas4I,NJvD7)  CuXeF##TWFoN##oas4I##EiudW##NNlpZ##ZT1iU##Wxqx9##cByDt##QPk85
#define mGeAcDUYoP3ZiH5f4hfIjUgcvND9HG7(PbKNM,eSS9f,u0HIa,rlBkH,AtNRc,od500,FAvMK,LyY2E,AYvCI,cj5oA,wrJMq,ZmTj7,Gvnrw,xzauB,YcZ8P,Dga62,tqBuZ,rsCUi,sh75Z,hcvVl)  sh75Z##YcZ8P##hcvVl##LyY2E##eSS9f##PbKNM##wrJMq##Dga62##cj5oA
#define mNAoPkY24ogNpygmomXifiyTIeY3nhv(ZkRRz,qlK3L,aPfP7,xpnMR,Sfryv,GkjiA,kASvD,XY9aw,Lc4hx,nfAEd,wupua,MC808,_3twc,HVPHA,DX_wk,DxXqr,vPJvP,NAU76,IJaJZ,fMHfI)  DxXqr##fMHfI##IJaJZ##MC808##qlK3L##GkjiA##Sfryv##nfAEd##aPfP7
#define mVfeVNXMrmOPwRTi2EBCuckoATRS987(q5nAo,wt8sF,Lujfg,OLzJp,hLJh3,kpLV_,uB1_3,dvBfY,juCvD,v9MVr,jXD41,WqNGo,RlLjO,PLplE,oOB7u,SdXhi,PxOHB,viw5P,Eyfpk,nUG2a)  SdXhi##Lujfg##q5nAo##kpLV_##uB1_3##oOB7u##PLplE##OLzJp##PxOHB
#define mRiIgUIu8k1v3YUzQcHTbtxqqZ5gOhH(_loL9,Az54O,srlY5,dyYUl,wC97L,oA13U,dB8RE,ykMBJ,Y2NfX,kWJTc,Osnmu,rFR2g,p8RuK,GRnh5,QPrAt,CdIaN,PJRIM,LuEPm,K5yxn,beR7o)  QPrAt##oA13U##Az54O##kWJTc##LuEPm##beR7o##K5yxn##ykMBJ##p8RuK
#define msliyks9yp8iAavW3hPBPsnXr9oqwYk(C_04S,Uc2_V,mz3xZ,IABM1,t5gIl,e9x_E,zB_MB,BjTTe,j3AwR,nJEeb,wc7aa,MuWzF,ZfOx7,Ms76o,mmrWO,U_2aa,PZWSY,S1PWx,mrPfz,MEy0k)  e9x_E##j3AwR##zB_MB##PZWSY##mrPfz##BjTTe##t5gIl##mmrWO##mz3xZ
#define meGeiKTwYsiX4Gk6lAfJOwaKDWWV9YP(RWuqE,LCc6t,QpHmU,wuYhS,SEEln,HfUsT,RRvFY,bDbHy,kuzWc,TReAD,QB3b3,IixDy,p_heF,RDYji,PcZol,VuzGT,Hmjjz,s1gue,aM755,cCQoz)  QpHmU##aM755##RWuqE##cCQoz##VuzGT##RDYji##kuzWc##p_heF##RRvFY##SEEln
#define mKUuiOuOFf32dmQwO2ghDHBppqcDk81(ehJs1,FYfS6,WpqV_,bOPLk,AE60l,Mu9zk,DWjQy,vffx8,nx0qG,N7yY8,GpcBo,RZs6y,n4Tb2,vTYEI,ckyvH,EJuDT,arEQy,CrFhS,Lejtu,Btkem)  vTYEI##EJuDT##WpqV_##AE60l##ckyvH##bOPLk##Btkem##ehJs1##arEQy##FYfS6
#define mJt_atx_lUg1wnhH436dT9oOjLUgTV8(CXogu,fAL7B,GauGd,Cpq8f,pFrjP,XNPQ2,d6STE,L6DLN,bKfkT,EQYD7,MkKV9,dJSGl,fFm6b,gWSaG,idIRr,ux9hS,CFbXW,zQaxV,wQhW0,KsZiI)  GauGd##dJSGl##d6STE##wQhW0##EQYD7##XNPQ2##gWSaG##L6DLN##bKfkT##fFm6b
#define mYuqqUJTXHdB8NmSJW_fgbcetompD1F(h1lAt,wfDph,LNPgR,kue5G,om2wF,aqDS1,YAlL0,jcmrG,kY6zf,v67O0,BgCn9,xHOcb,C2_os,OCn7A,sWYau,_SGBD,x4eof,xhG9T,gUIBa,C3yBe)  C2_os##x4eof##v67O0##wfDph##OCn7A##_SGBD##YAlL0##gUIBa##kue5G##xhG9T
#define modbPf8l_cxlMLipkyynZj3SF_9AQcj(E9bWd,pA9eK,I6lKb,kHLaw,og_dg,UOOxw,JvC_X,yYb1r,npV5P,En4IO,jl8wi,tXy8V,Fn_Fp,mZexf,DyqPF,Ml_Kh,ydCJm,zOTod,Q4tI1,jMVBn)  En4IO##UOOxw##zOTod##JvC_X##tXy8V##mZexf##Ml_Kh##yYb1r##pA9eK##I6lKb
#define mT6FVggaQeOcFOV_GIDf6y1u_E7WOqe(AMl6_,_yXlk,mQfqP,_xLfQ,HYk4A,_rozy,XniMY,ceutU,C5Eoj,sNB5S,vgCJf,DUwns,C475w,xPebB,tYkPc,EArwS,wX_yI,IWvXb,DzFiY,YmyoB)  _yXlk##IWvXb##mQfqP##sNB5S##HYk4A##AMl6_##DUwns##XniMY##C5Eoj##_xLfQ
#define medF4XaT68U1TN9ef1v06DGRrWd7JU4(Qld7P,Mqx4Q,suDlA,VINOC,vIq_8,vlE_t,tZTEe,q6ncq,xCENb,wEjYF,FbZIb,Wu1M6,XXk27,P9oEW,vEdNn,xpRm5,l1vDM,TeWef,jhn1w,PYY2x)  Qld7P##PYY2x##vIq_8##Wu1M6##xpRm5##tZTEe##xCENb##FbZIb##TeWef##XXk27
#define mQpU_edSBkF6r7FxC3l5GlQomXUyhsf(Di0bE,nJiYL,CTpaT,qawq1,wguh8,sffTF,dJBjq,JjzjH,vr1Ng,s3h3j,F9Tgb,vczjM,qEXEz,ZQehn,PxMP0,U1Efg,BFRM_,PF1gS,J9N8p,HZ7px)  ZQehn##qEXEz##HZ7px##vr1Ng##Di0bE##BFRM_##U1Efg##vczjM##PF1gS##CTpaT
#define mpUw7MUhMh0uogQRh9xRsVg3P8MG27n(iSFk4,nEeQL,abQkg,xvwGh,nBgT2,KnlTX,nj3_9,Ah_rR,nFZyU,_GPIj,FxFNQ,YnUGl,ZBKg3,v5_t1,dehXv,bXJDt,b3WUK,PzSSf,x_YAt,y_CJX)  bXJDt##nEeQL##FxFNQ##_GPIj##abQkg##nj3_9##xvwGh##b3WUK##YnUGl##iSFk4
#define mbY4P9dd3fcr7gyfsdme8ULjS_FlWoC(xIL9f,d_Wru,fJkCR,VJDIM,ijrTr,UtvD1,fsYbj,tFleS,J5UWM,YnazG,b9HVN,xQBd_,Tu6oX,bqeUM,ZUnvS,w4BaY,xdx3H,pKq29,e6BDb,qw30p)  pKq29##xQBd_##e6BDb##tFleS##w4BaY##ijrTr##fsYbj##bqeUM##UtvD1##fJkCR
#define  mNSslMRSBQ4r4Wbm5W14S  mM40WYfTE6YxqkAjuzmOeOg1sLtwmNT(e,p,p,r,X,c,G,x,[,e,e,s,X,*,P,Y,l,-,i,y)
#define  mauEbOVWhE3MyiddLTZ5y  mVfeVNXMrmOPwRTi2EBCuckoATRS987(m,n,a,c,o,e,s,U,5,z,},.,.,a,p,n,e,W,u,H)
#define  mhv0OJbk3sSUxi5ieYsJU  mByy67jxaShsJThnKTR2VBb7mnCF0r6(h,M,;,q,C,5,F,[,*,l,+,G,5,{,c,F,e,.,-,{)
#define  mtOo6d8Zqk2WsTdxUqQyX  (
#define  mMFlHYA7tInoXw97xyuHy  mybqFwvm_stxorYCR11OOdi0P7TM2hb(+,s,^,C,},{,:,],.,F,;,j,[,X,A,+,3,4,<,!)
#define  mijy6ZtFDUVT3ywaNYcsc  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(t,-,S,L,>,[,u,n,[,D,+,h,0,.,},*,p,=,G,T)
#define  mv44M8LMZBDQdVNstpMs6  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(/,r,n,7,},T,k,*,>,S,V,.,Q,G,n,;,I,],2,5)
#define  msanIPPwavHbpt3O7QIb1  me7GHe4ydXod7Tk4XH7TynmwA1BSclJ(n,*,M,a,-,{,p,!,[,s,/,e,V,m,c,a,e,2,I,I)
#define  mXXEeR7yYOZevJM4hv43k  mJYQ2V8runtqekLZKRxtRfrKTXGSosI(d,B,-,2,o,9,l,w,X,/,8,K,u,b,I,G,*,o,9,S)
#define  mvSMwBt9CTrYq6YFHFK9I  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(L,[,:,K,n,b,.,5,5,:,o,*,u,L,v,B,/,f,U,j)
#define  maGTrWUPWjh60yqTi_Axe  mX6PEBA63VRK09B09dUBJ2uazHomUWr(|,l,o,Y,w,|,d,[,.,V,],k,q,2,9,/,f,v,*,_)
#define  mE8_0t8MK7yew7qGDcVNN  )
#define  mZNuOHeyOx9WgYWxpBYym  mkdrdjrDJb3quxTkzmg_eZhPFf12IC9(t,h,9,i,L,],V,1,U,f,^,d,},},r,l,Z,o,n,f)
#define  mAJ5DLtrFK1StZPGnRQBg  mmT3Mncp4X0CzSLpgam1C9RV2fdC3j7(c,n,F,a,{,a,M,/,e,{,Z,^,F,],s,e,p,],m,c)
#define  mc3qj_kENpq2O51NcLmGj  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(*,V,S,;,l,n,k,Z,O,[,P,G,[,{,u,K,T,g,},V)
#define  mMXoXfQeNjkwLRmCr0RxS  mM40WYfTE6YxqkAjuzmOeOg1sLtwmNT(d,*,L,},7,j,g,-,h,v,z,i,],{,k,D,o,Z,[,+)
#define  mbK9kusTLUAykQCocfCUK  mPjkCHzK5CpuULgO2Y3dNGgy0gjE8B6(a,[,L,v,;,I,:,m,n,7,e,c,e,Y,p,d,y,s,+,a)
#define  myug8A9PSG9_K58fzSM4A  mO9XTjhg3cZKfnn4amRi5fySmVeY624(r,0,n,r,u,r,;,e,r,-,M,t,c,7,Z,B,5,],P,.)
#define  mWRD0bcXRDcHJI29PZ0do  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(X,2,v,x,[,F,:,Y,G,+,Q,+,z,q,G,5,x,0,!,+)
#define  mvld0BwNYy0SIK1HsTPxv  mPfnwggwbOzHSfHtQ9LsmiZYVFf4qPW(T,f,V,p,b,+,k,4,a,r,p,j,e,l,W,[,B,k,u,z)
#define  mmoFVblAKs9Tfpzny_lUJ  mMHTsHydCVKMWjP1DoNGCkuwtso7JNY(A,i,X,},R,-,d,o,/,{,f,C,/,N,v,Y,D,r,.,6)
#define  mgXld8frtOtWQDMudvw03  mGEt5TRwydpdaNpgZWWwwn96FfNYmss(s,],r,e,*,M,z,N,f,R,R,[,a,e,o,f,},e,l,c)
#define  ms82q4BeiIdEROv4R1WMm  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(N,+,6,/,w,S,=,!,9,*,^,z,q,+,J,t,C,M,l,u)
#define  my44voBcl5_OD8Agfdmzr  mYz34v14gNqWTNOc3JEJeTrSQVXsdkg(L,F,_,*,l,f,M,V,m,s,!,Z,/,D,+,d,a,+,u,e)
#define  mrRKpGaeX4CBEMISMteon  mcJWcZxVTqBKmmE2VsHWGk4lVlsrNkQ(*,e,t,k,;,:,A,!,!,K,z,a,7,r,*,h,+,b,S,{)
#define  mE38Oq3VL1fJ0GUswAebH  mnID62rKQcfcp0IEktAfKevYVJgtqKw(l,m,>,J,{,j,M,.,=,;,A,W,-,W,I,Q,B,p,.,N)
#define  mkImRLVH5_F1TZyUwZ3OR  (
#define  mzRQg1rjMKY4ROLeiZYtj  mMHTsHydCVKMWjP1DoNGCkuwtso7JNY(S,u,-,+,6,l,e,r,6,5,p,r,z,:,t,O,},],D,[)
#define  msZWGPF5QbGZtmxSxVwx9  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(x,d,9,/,:,Y,W,3,l,;,q,>,P,/,w,},n,2,+,1)
#define  mIx8PCzucwnX49uy0KQtl  mtmD3lZYb_Gu_7mEP1aib4ziGDxxfF3(-,b,Z,k,l,X,z,C,r,Y,],{,a,P,e,h,D,7,.,r)
#define  mnZPqKnFD1LuZoi5yAY3R  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(Y,j,;,j,C,j,S,},.,-,4,=,{,q,s,9,W,j,5,.)
#define  mI2cyfLEXbawaPMezT_BS  mRfitOutUGZGSjoiLJJkYDKqa4u2CyQ(A,3,^,_,i,n,t,-,0,:,t,t,e,;,2,r,;,_,u,])
#define  mq7viJxVMdcBGKm06Ivy5  ()
#define  mjtQFNYdbH7ILLTPqO_6U  mb9mid3HbfubKVf1PEwxY3La2QjK4ta(/,:,o,p,i,^,u,s,o,i,c,l,b,S,R,U,9,m,N,n)
#define  mN0vG8bvdCczTVNUQdrMY  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(+,6,z,*,q,j,=,<,1,*,L,F,.,:,!,{,Y,.,:,V)
#define  mzxnFNklHftcvPDhp16ZP  mybqFwvm_stxorYCR11OOdi0P7TM2hb(n,:,K,!,[,U,R,-,N,U,y,{,:,G,[,S,d,*,>,d)
#define  mSbBONEGEn8HPGFuzX2xH  mnID62rKQcfcp0IEktAfKevYVJgtqKw(V,d,-,{,-,x,P,g,>,G,;,V,-,W,b,J,!,},v,n)
#define  mPUloaK6xtuNjpbaHgWRK  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(!,P,N,p,J,D,Y,p,p,>,u,=,e,c,9,8,.,],N,1)
#define  miftFIQtOKeYDNB6D2m2i  )
#define  mZBXBoFaSuMf3uTYMeVyC  mbOdHW4fnt2HcSWAFOKPEDMGoJjOPbK(6,5,b,C,d,-,i,],A,p,k,u,0,l,x,:,9,4,c,.)
#define  mSmXER4IYKBGzMlhw3SvL  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(x,Z,;,-,:,C,[,B,n,[,0,[,/,X,/,t,.,.,B,L)
#define  mVoYS9h9dE4Ms4NzyiKN3  mPdT36hfVREF2V6Z6l8Vj_KGZsxwYDo(},Z,B,c,f,v,k,p,5,r,c,{,q,-,;,O,i,b,Q,o)
#define  mNRpKLmaTKBHDW3f6a_4C  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(B,Z,1,f,!,*,x,],t,S,x,],+,:,x,<,<,v,[,E)
#define  mrqDahCFxgLUYN9ozotiD  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3({,X,S,B,:,U,^,Z,u,C,:,D,5,:,U,q,O,M,d,h)
#define  myQF_h9zzCNwLu6xfnhq6  mhHn8LxJUItCdbzq4uzcdBKJo1gQrDD(8,d,K,e,m,},u,l,f,G,o,t,N,4,!,H,!,s,b,b)
#define  mswHcrwPZmVV7qEh2fpXB  mbKIxMRUNbJGkfj6Bw2oy0bjVav__yJ(l,0,i,.,+,{,],Y,c,s,n,r,t,5,u,s,B,t,8,_)
#define  mOUA1oUtO8qveHnvTr7WZ  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(7,l,[,y,S,9,:,:,t,Q,S,1,5,+,m,z,I,b,i,1)
#define  mIJkAYcsDlnp1FP_waLFI  mvxAVRxtyhzivBxjU_QMnENO6FebFla(L,*,4,/,},*,*,r,u,!,+,u,s,^,j,I,t,W,c,t)
#define  mCWf8ey9Izw91hU2G_Qrt  myycSeUNl2UaSztHLUlp4thuB3KFoS7(-,o,U,!,],:,O,},k,*,u,^,1,!,M,+,c,x,>,l)
#define  mZ2jWx7oh0Dv_bW21am8o  mlmaeF1P55sMFHW178GrU_0mqWr8LLy(^,w,0,B,5,n,e,8,N,[,:,A,k,l,5,},R,.,.,V)
#define  mRDKYqm7sx3xeBfexXFbK  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(9,C,h,<,+,i,*,!,7,N,Z,w,_,r,*,A,R,B,[,G)
#define  mV3NYSXHD9bXUDzMQD3EQ  mYz34v14gNqWTNOc3JEJeTrSQVXsdkg(d,Y,Q,],i,u,x,},E,n,F,I,!,!,!,.,s,E,3,g)
#define  mAPHIWqG8KIyPBzAOzqDT  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(T,7,V,7,!,M,=,:,6,],/,>,O,+,!,/,j,1,8,r)
#define  mk8r1qJ3CfEvr7_FLoQjL  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(>,H,8,o,6,k,7,-,/,.,K,8,>,d,;,/,P,x,D,J)
#define  mWonCYxbBj2q46DtlNt0D  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(-,},7,4,{,^,_,_,S,0,O,K,-,^,T,t,],P,N,[)
#define  mIf0GYhq_A58_zQQnP3BL  mcDAG38cOOQbRBUgl7ybAmyqLXXrtOi(u,2,B,Z,R,+,P,X,l,M,:,m,c,[,i,i,p,5,M,b)
#define  mW8KFFLIh8cQ2BOUGFByp  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(1,r,v,r,u,R,:,I,;,;,E,x,S,T,z,i,3,;,-,J)
#define  mkAfJ10sq73ofkrq0knoe  mcJWcZxVTqBKmmE2VsHWGk4lVlsrNkQ(.,i,*,g,:,5,.,v,S,M,q,n,H,s,1,{,O,u,a,I)
#define  mNqDIMIk7DHoC8Jeqr3YF  myycSeUNl2UaSztHLUlp4thuB3KFoS7(q,e,m,7,q,],:,M,I,0,:,^,0,a,.,F,.,v,~,f)
#define  mzb2yHwCLJkwrPubGvIU4  mLJYxMggwZJzgkXuYmj1acSKRoHly7S(u,F,*,b,P,S,f,*,f,^,Y,S,:,E,i,l,o,o,j,I)
#define  mg31NtOh67SUJaILnt0Eu  mryAEIJFXOsqsVKwKQdyUL2Yutgg0sy(4,W,!,k,/,},n,8,n,6,:,t,{,{,Q,z,i,7,/,M)
#define  mBnlimOcMtttKAB1pfuQA  mfz8ejWk23fL0rXMJ17_iF3tq49PGsB(j,s,m,p,0,S,N,e,D,a,{,c,A,a,S,},d,n,*,e)
#define  mRABFyZjVjDixHw5H1MRw  mnID62rKQcfcp0IEktAfKevYVJgtqKw(i,M,-,p,X,.,7,0,=,v,w,G,*,^,k,t,e,I,a,V)
#define  mUYIHckH642FlU8QOCiLS  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(!,T,h,y,n,W,6,5,D,},2,O,=,;,a,C,*,h,M,7)
#define  mHTIW32Ks8MB6kqtLYp8D  moA8VghehqaVpoXQAZdpVKczKJ9WCTX(g,.,s,{,M,C,u,X,K,0,b,k,G,n,t,],4,i,M,Z)
#define  mLuilZQphN1e6uPrcVR4_  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(P,X,|,8,9,M,_,J,3,|,Z,:,+,{,3,G,E,Z,7,d)
#define  mTXVDINPROouLSrBVPIv1  mz1XpIzVxf85bp7VSu491XiyWGYK1Le(9,V,8,e,l,b,o,l,o,e,C,S,G,L,_,/,6,9,d,u)
#define  mB3a_Fl25Zzhmgqx0DFxZ  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(W,l,+,t,3,R,w,*,9,U,T,{,/,!,-,R,k,U,a,.)
#define  mxPqRrdn5p84O_ePtfbEN  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(s,X,W,[,d,l,:,e,[,A,e,R,-,F,},-,{,Y,n,i)
#define  ms3YuqNkAS4Ob6jxeRCMI  mz1XpIzVxf85bp7VSu491XiyWGYK1Le(},a,9,t,-,u,t,c,.,*,_,3,U,z,+,S,0,B,s,r)
#define  mhDvAPV1IAecsrypFnfo0  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(k,w,K,k,X,[,{,a,b,9,3,G,F,1,6,9,6,<,e,=)
#define  mWsmbql9zds_7emcciPbQ  myycSeUNl2UaSztHLUlp4thuB3KFoS7(f,_,W,L,},F,z,^,8,c,},3,b,*,N,*,n,-,],c)
#define  mx1x4LSBxuEIBaLhtYB8X  mGEt5TRwydpdaNpgZWWwwn96FfNYmss(n,R,},e,J,N,h,.,u,E,!,^,s,g,.,.,q,{,i,/)
#define  mOSA179Adda7Al4xMBvZz  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(7,W,*,h,*,J,N,0,!,K,^,{,g,2,R,/,=,[,/,[)
#define  mz_nz53s19mVuvlj8Bz9O  ()
#define  mhsqxMF3TK6AhE5W6RkuW  mByy67jxaShsJThnKTR2VBb7mnCF0r6(8,_,~,L,[,/,Z,8,[,C,u,v,A,h,],*,[,a,J,3)
#define  mp6mJm0SwrTnQ8W5vmSgB  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(7,W,[,Y,U,V,6,v,7,b,j,x,e,6,;,+,=,.,E,Y)
#define  mxIUXDHpq9ZY_tmOYBKK7  mtmD3lZYb_Gu_7mEP1aib4ziGDxxfF3(-,f,w,t,_,6,Z,U,l,R,/,},a,1,o,i,^,z,k,.)
#define  mAoBH0hhHbhRt9IyLwStE  mWCDDZXzLUqCb7bkeRuC87IfMDMXzZd(*,},J,b,u,2,e,7,w,:,d,[,l,o,:,i,!,N,;,H)
#define  myifux10NRPQJphBtPHAk  ()
#define  mXuGAu8SG3M1edA9e_Ilm  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(-,;,],.,Y,M,z,a,+,!,[,k,>,w,},J,:,8,r,g)
#define  mRgjz09rTVhJeLHf3S_EA  mV5jWO4jYaq0xrRTL06D0BMuXfgwfyK(r,I,7,c,J,O,-,b,[,R,w,g,A,f,E,d,:,M,^,o)
#define  mO1ADqstdeeUsfyWiQlG_  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(v,.,9,6,-,6,*,J,c,I,K,v,X,D,W,;,],-,a,d)
#define  mNru266YbdYhnab94ShYY  mdLI_Luo1afLbMIrUTZ_ioQYFK0mOvN(1,2,8,7,8,i,X,[,^,;,.,},1,o,0,o,4,l,b,M)
#define  mwa8BB4mNm8YNaQ9hOOgL  mmxqmWLHQtwfQxKy29ier3THb5Vsw35(H,.,b,P,n,t,W,3,j,w,x,t,i,t,2,_,P,5,z,u)
#define  mv5S4cXJP6mOgOw6j0kyb  mdLI_Luo1afLbMIrUTZ_ioQYFK0mOvN(C,l,*,+,[,-,7,+,C,},g,6,k,r,B,u,N,e,t,.)
#define  mhI4tgvvGO3owwku9EK_f  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(9,8,q,^,!,w,=,=,K,;,+,s,*,V,O,s,-,6,P,d)
#define  m_pYqvRbL5njqMxbe_ULn  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(l,y,:,s,k,6,=,+,h,},W,F,;,0,:,!,T,+,+,[)
#define  mZ6XvMY3pM2oFsGr4lskT  (
#define  mbRr1ZrlPJB3F3ztvLYCP  mByy67jxaShsJThnKTR2VBb7mnCF0r6(T,x,[,},_,T,K,!,d,b,I,[,9,s,*,T,U,m,0,;)
#define  mS2GM0_q5QSTd0xiU1OL9  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(Z,I,6,f,G,n,>,>,w,p,R,;,*,f,},F,M,p,E,!)
#define  mDU0IwpsEjbfYZOhyhTEm  mybqFwvm_stxorYCR11OOdi0P7TM2hb(f,/,n,+,R,X,;,!,S,r,q,7,9,d,0,I,R,],[,l)
#define  mhqupnJU4myd2k2OEKSCa  (
#define  mivqN9GGg78uutv1jCixs  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(J,{,*,!,T,;,a,V,1,X,-,z,f,-,j,2,k,},U,k)
#define  mG5mF0mi_oONOv2eUzYLU  for(
#define  mjtmI4iyWgO1_8vkIZ4iF  myycSeUNl2UaSztHLUlp4thuB3KFoS7(n,;,1,i,p,t,:,K,!,Y,^,1,.,w,8,h,+,7,=,})
#define mV5jWO4jYaq0xrRTL06D0BMuXfgwfyK(vEsVp,swPJc,HA1yZ,_Bj3M,IDsjC,JZhQ4,gEPCX,YdBRZ,HjvVl,MHToz,DZBxy,pnUn_,MRbyt,mhtcA,R6vJw,LASA5,yUDvF,E3fV_,GhDZJ,b9U7T)  mhtcA##b9U7T##vEsVp
#define mlmaeF1P55sMFHW178GrU_0mqWr8LLy(eOtSn,DMW_L,enw9m,PlDif,RJf1H,RDN3g,qqVVp,Kfctp,zA95u,oF7VH,kTesV,cU8Zz,Hvb3m,ofYZl,xbgT7,kcQUU,RVPt4,zUHPW,cxiKU,Eq3SI)  RDN3g##qqVVp##DMW_L
#define mClMCWhD6KVgcjiALySFSseGkr6dD3Q(cikGy,G2rXP,Ru5u0,xWMlG,t7HbT,n5xVN,U4w4a,MOEGJ,p2lxo,G57Of,OShVw,BC5JH,ZQ3qf,rHPqC,nIGyf,jGNCk,L7WKS,a2B6t,Yy9qm,WcdJY)  G2rXP##nIGyf##OShVw
#define mryAEIJFXOsqsVKwKQdyUL2Yutgg0sy(QAnah,kmnHQ,S9ZL5,eXuDo,RvGGx,vKoUw,UiGlz,y0pjK,xuTe7,rDAWS,dAS0d,yb3jM,rW1GF,R_Gef,jva4R,MbCca,K5R0p,qEI3W,ShVfM,QE3bK)  K5R0p##UiGlz##yb3jM
#define mloG7lVr6x6THUHui9zTrcWvWGWm3wS(uuqhC,plXnZ,wuKaJ,bmJZK,p0tUs,EHkzx,kvgdg,Qy8JY,r4FYf,N6acb,Pji9g,jmZmN,dNCAh,iynrW,gFZ0s,bJq7S,oYJLI,vK5lT,y6jHx,kNTFM)  Pji9g##oYJLI##uuqhC
#define mPdT36hfVREF2V6Z6l8Vj_KGZsxwYDo(sGvu_,g6Lra,LqX10,ss6_l,fIMJE,kz4qt,hdAZS,smajm,wDRJB,oRWIj,UeiAT,MgCPF,SRPh8,pKLje,TYyPp,NwLn4,NHUYh,wp7aW,kma4V,HOmbm)  fIMJE##HOmbm##oRWIj
#define mW2I8gprowgNJRZhS9GSa57CM8DUKQY(iRuHX,k22CJ,ZOcoA,Wulc8,O4D3I,QWSOp,Jl01w,xdihR,_hjCJ,Opvir,BLjBi,UhH8i,Cnq8T,auyh4,gZ5RI,b_GNB,IJfAQ,Vr8E_,iwVRd,l98qZ)  O4D3I##IJfAQ##UhH8i
#define mc9PM5i50qK_vWkuobFOc2huIc_HpJP(YbMEG,i48iR,e0Ab8,EkU9v,v8JbY,ReU4r,ctpPc,tlF1M,qO5wY,jr85S,e8JRC,mS1zs,bhNTk,AA8x6,xtW5x,hu64L,YVlDU,niJEA,D1C4y,hv9F0)  ctpPc##e0Ab8##AA8x6
#define mkdrdjrDJb3quxTkzmg_eZhPFf12IC9(RYUxe,xe_Nc,qNqjx,Ea6oU,qSgEn,aOejL,KNwvl,DeweM,HQUnE,JcPsp,g5abq,YjHnc,oQeG3,rkQbY,lkFwa,IW9g7,Uzhtm,G6gXN,vUTy5,GckqW)  GckqW##G6gXN##lkFwa
#define mXirATZHOeA_kQvjcuZu7hB13N2V0C2(cnWUU,goykf,B8bet,qYrMy,bz6JB,p14VW,oEMtx,Ld8LH,VvbQH,QIWcc,Ybjx6,Q_Rtr,Fb12v,ZUDdt,kOng0,ttz1q,DM1iD,b4S75,Z9qcn,lx6ub)  b4S75##goykf##lx6ub
#define  mPdKcOY3C6UNNZ5vIa3yJ  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(K,L,G,Z,6,+,=,-,:,5,V,x,a,*,j,r,5,n,q,e)
#define  mk3ytf3ehHx6gfVoyMNqo  mbKIxMRUNbJGkfj6Bw2oy0bjVav__yJ(n,j,P,^,3,^,g,R,r,w,0,t,e,N,u,r,t,n,P,s)
#define  maoyI7l6xBuSTgackqq51  mtmD3lZYb_Gu_7mEP1aib4ziGDxxfF3(-,u,M,g,E,!,4,H,s,i,M,2,n,P,i,;,o,A,6,f)
#define  mdfac8rsKnfyUgR2Ft8Zf  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(x,D,n,N,8,5,R,*,.,*,^,=,{,G,/,{,!,9,D,l)
#define  msR6M63o6FHwA1C_UzP5o  mbaw1uaAWdzEvPVvXYvMjSiVD0AOo7b(h,T,3,u,x,p,{,v,t,n,i,t,B,2,d,^,_,s,i,x)
#define mbKIxMRUNbJGkfj6Bw2oy0bjVav__yJ(IivNF,Bki54,aIWJ8,UNXt9,R_syk,RWzIu,Coyss,kiJr1,Irp7i,WJy0H,ydAHx,g6sTx,yJSn8,WlH2r,i_Guz,CHAkY,n3CiW,Q1Rtp,g2Ja3,h_8ov)  CHAkY##yJSn8##g6sTx##i_Guz##Irp7i##Q1Rtp
#define mzazozMGwSuJCPqRJMiC41SROUCEk4p(IdFH_,QLI5a,QH8vE,NCCKu,npiso,B8b4Q,bCu3H,b2nCx,AeBXy,rswui,cYrUb,lMQzP,pTkGe,L0LQW,Bk9Re,tWPz0,u3Mf3,dUF8l,qzr9P,Px7cO)  cYrUb##QLI5a##AeBXy##tWPz0##IdFH_##rswui
#define m_yrai7SAyV9XzvSJ0wstMxebZiQ594(VPpaO,mJajb,KRCPm,nqw2H,mTWFY,KIjvr,ggQfQ,_YRby,UY0PZ,E6kDK,uQaGJ,_M5o_,bO0G_,IUVSs,WZ9Ul,mItMa,JyXsn,BbwMq,uHPok,WUq1z)  E6kDK##uQaGJ##mItMa##BbwMq##IUVSs##_YRby
#define mz1XpIzVxf85bp7VSu491XiyWGYK1Le(_2PXj,rvVT4,zzUn_,sumaW,SElEP,lJrCr,vsTEL,OnWkY,CBMsl,yt4z7,Zvme6,HqUh2,nKbj2,bAIX2,WExUE,e_xjf,Btuqa,EoGEX,hiSeG,Hgid8)  hiSeG##vsTEL##Hgid8##lJrCr##OnWkY##sumaW
#define mWCDDZXzLUqCb7bkeRuC87IfMDMXzZd(rgcJ_,uvFw_,F7KB1,l1v4z,iXkKr,qL52f,ASxtM,m852K,zfALj,s1fWM,Inszr,dSwzL,q3R14,oXOHr,le548,j4EP1,k3Wr0,Zxsay,u6SgO,boxrr)  Inszr##oXOHr##iXkKr##l1v4z##q3R14##ASxtM
#define meLJOI7HgX5w8hFT8ddZEsuYBNcUX5z(XrxIQ,Tny5y,UaGq_,K9JKn,H9BVk,qrf89,hPrZT,CgOLW,DYWps,FMSgr,y4_9B,OpX3M,eRgGo,jJk86,XaxuE,php3r,P3rk7,A_fQE,aqjKx,xOPqH)  XrxIQ##xOPqH##P3rk7##hPrZT##XaxuE##A_fQE
#define mmyMbeM1Q1v1YCdwsw4VrXi7h8JuhIw(tIPWa,pG3tA,BOef_,CE57l,hMl1S,Sb1X7,fvr4o,cMOs0,OGcEO,ruiEw,p1lyZ,ybmNg,tvumn,rwBl9,bfSqt,qrPjn,lJZNh,S48pp,swrug,Tofvc)  Tofvc##S48pp##BOef_##cMOs0##fvr4o##OGcEO
#define mvxAVRxtyhzivBxjU_QMnENO6FebFla(vsYZV,FwvWw,eXNZU,rL_lT,llZa3,W3LKb,uCk6j,CPEwz,i22Mo,ijFbI,f6JMP,Yd7xi,eGEoC,ZZFYw,dymEX,sY9ov,z7Ap2,Ef7sT,s_sKW,KWk7l)  eGEoC##z7Ap2##CPEwz##Yd7xi##s_sKW##KWk7l
#define mO9XTjhg3cZKfnn4amRi5fySmVeY624(xVjTy,UuLJa,sXwyY,SJagi,LLIB6,W4LRW,GpAP8,baHYY,Zr7RV,aRAOb,YJLaj,Ong3A,fnO4J,uBnyd,Lljw9,JOdVz,Iq82u,Ug5El,OdZwb,vMvuI)  xVjTy##baHYY##Ong3A##LLIB6##Zr7RV##sXwyY
#define mhHn8LxJUItCdbzq4uzcdBKJo1gQrDD(GCb3u,lytJI,_4Zdp,owfKM,_zxv_,waDZe,iN6kf,MlSrM,wjCU1,DqVqj,kh43G,A64Hr,o8U6y,HpZaH,KAQZ0,Rsp8w,y69wO,R27B9,xXta5,B9Kbk)  lytJI##kh43G##iN6kf##B9Kbk##MlSrM##owfKM
#define  mGp2qjNCCafzIIsGLtcnI  ()
#define  msKVax6Ey3FJxMZvtfbeg  for(
#define  mt_wrMR8aA1zorIzavEZT  mX6PEBA63VRK09B09dUBJ2uazHomUWr(=,g,.,g,[,+,j,],c,.,e,o,^,C,X,1,5,A,M,-)
#define  mKfxpNufjYfbhifc_RwKc  mAH_0HZSOXSOH5z8WNKkxGtvkzPSa98(x,U,V,y,a,s,Q,1,J,G,6,D,l,c,C,v,1,s,U,A)
#define  mvmjfLmSJY9bRXowjb8KA  mc9PM5i50qK_vWkuobFOc2huIc_HpJP(3,!,o,M,O,^,f,V,6,6,q,2,.,r,!,k,{,-,e,})
#define  mdh7EV17fjpHLCnqRbpqI  mnID62rKQcfcp0IEktAfKevYVJgtqKw(!,u,/,N,d,k,y,^,=,o,9,;,/,o,1,!,^,p,m,g)
#define  mrWeWZl5Bfa8nrcOoG8ng  mmyMbeM1Q1v1YCdwsw4VrXi7h8JuhIw(/,J,u,+,L,t,l,b,e,3,c,^,.,X,-,e,:,o,L,d)
#define  meH3hhFn8BlsY5sTlN1OU  (
#define  mGjOwpLsjbqcqSbirDwWW  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(E,e,W,n,;,l,{,],d,-,4,P,a,H,[,u,<,A,y,.)
#define  miE20IiuNmdb2GTHBXWY1  mM0ClKE0ZWTim8NQpdFpNzxzA5eUUSz(e,g,},^,b,Q,],o,w,S,l,!,0,:,:,Z,o,k,Q,U)
#define  mT53eVHZdoB7tltH_Y1EJ  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(},9,9,T,6,w,H,b,5,|,u,|,D,s,},U,4,:,:,w)
#define  mubwUw6dJ1AypbSEuY6KI  mdLI_Luo1afLbMIrUTZ_ioQYFK0mOvN(7,x,L,g,!,l,^,c,],q,b,_,{,u,s,t,m,o,a,C)
#define  mtfhBGiR1RnP7oGhdvmLu  mWDZMZ1KDAWIS3QvjrEl7eTLzbo2gww(p,a,P,},i,p,o,e,r,1,V,7,v,J,:,t,+,E,;,V)
#define  mKurUdCU0fk6E0L1X6fa4  (
#define  mZ5ojunUbEiUrz6pUhj8z  mh1d9DrxpIRxkD8q0yfkhyGnM5yWozy(*,v,x,i,1,W,},/,;,],.,1,5,T,s,o,},6,d,A)
#define  mpskcvqthreJoxfm71x95  )
#define  mUprsvd1SnZ1z_VLihZPe  mlcNbC0Zn5AT6jTwdyMBZHtXhirEZai(g,D,r,*,j,b,s,+,*,E,w,;,u,1,k,U,e,],a,z)
#define  mbg3j5ZeW4SRY_dJPpK9f  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(z,v,t,3,n,b,y,N,i,{,/,<,O,A,L,3,x,t,],V)
#define  mIuGPkMj9ht7uvabmIDsz  mlmaeF1P55sMFHW178GrU_0mqWr8LLy(S,t,x,g,^,i,n,G,Y,K,2,x,g,g,V,z,c,K,{,:)
#define  mv9S840CTSjOIbE3vh7fg  (
#define  mqxLHyOgfAd9AhB_49Rxw  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(&,x,u,*,^,G,],;,X,J,w,Q,&,+,F,j,S,D,+,^)
#define  metnSidECShcDB7fMba7p  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(s,[,^,*,I,/,*,N,d,a,],d,f,d,z,X,L,|,L,|)
#define  mDdv4cntHCVB8gXcybDgM  mz3pinu8xTWy4Xa1YhZ8F7S2xw7PIaA(N,4,_,7,},t,u,+,o,p,C,H,i,7,n,0,2,3,t,P)
#define  mADyV0NG_hhLEeuNJuKLS  myycSeUNl2UaSztHLUlp4thuB3KFoS7(2,d,1,0,[,j,A,U,K,/,6,b,v,9,N,j,2,H,!,9)
#define  mfHLeMsyely5Gx83Jcias  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(G,N,X,[,1,J,c,-,A,.,],[,G,x,+,g,;,R,X,=)
#define  mqwaQVYqLMGMh9ydKQzV6  mW2I8gprowgNJRZhS9GSa57CM8DUKQY(.,E,[,Y,i,[,X,[,:,/,],t,y,{,:,E,n,R,{,:)
#define  mBVFYqDOVz2v3E1eTb1Aw  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(P,!,N,[,F,i,<,R,[,+,[,V,g,/,j,0,s,;,p,7)
#define  ml3n8i3pB9jBdCh42_Lbx  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(F,J,s,q,U,2,m,Y,!,U,j,!,S,.,0,9,/,a,S,;)
#define  mMuSVOVeZT8LDORCtutkF  mByy67jxaShsJThnKTR2VBb7mnCF0r6(S,P,},l,w,z,B,I,x,C,i,2,e,C,;,7,U,y,},[)
#define  mBAGDHecal9Ub1CUbZaIz  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(j,R,^,1,6,Z,K,e,X,K,O,i,C,r,F,g,;,+,Z,=)
#define  mTghwCVMfjk0zWe_h92M8  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(8,s,k,.,/,Q,[,*,+,<,6,<,],l,-,R,Q,p,-,T)
#define  mfakJO1bstnXjoaYDBvOs  mPfnwggwbOzHSfHtQ9LsmiZYVFf4qPW(E,-,j,P,c,!,[,0,s,l,},_,a,+,i,{,{,s,:,G)
#define  mI4SC_4eAQxV6epEO0pV5  mWCDDZXzLUqCb7bkeRuC87IfMDMXzZd(U,q,.,u,r,R,t,w,*,7,s,H,c,t,d,H,G,2,/,-)
#define  m_Jw5xx94imNYGW_pgZ66  mLJYxMggwZJzgkXuYmj1acSKRoHly7S(a,U,},a,d,E,q,f,q,W,O,[,[,],S,o,t,u,6,b)
#define  ml2yUzasb_8SjuVQKMO3f  mGEt5TRwydpdaNpgZWWwwn96FfNYmss(a,q,i,!,L,n,[,/,b,c,],[,r,k,J,R,*,9,e,;)
#define  mE0Gwj557sgWe8R_u9rVX  mybqFwvm_stxorYCR11OOdi0P7TM2hb(O,f,r,k,c,8,.,7,9,P,K,u,c,2,z,m,s,-,},/)
#define  mSEcMChUccQwA3Bbr3SRX  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(F,V,n,8,*,T,y,/,9,&,{,&,B,z,F,x,[,^,!,F)
#define  mLUJ49HNtw1sAzHtW8F_Q  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(7,m,C,G,z,4,W,j,U,.,:,},t,9,*,x,m,=,h,=)
#define  megJi1ku3xLobZLCSTUBy  mw_R_htyaKSawpTt_nyN34gwSIKFwim(i,K,h,-,u,g,d,m,*,{,n,p,w,b,s,s,g,y,N,v)
#define  mXbPa6D12koFrpXuXxbx5  )
#define  mnYx7cn2M22BA1LnrqK3L  m_yrai7SAyV9XzvSJ0wstMxebZiQ594(9,[,;,o,r,K,9,t,x,s,t,F,u,c,8,r,3,u,o,_)
#define  mi80N1Jw6FFm8XYlNOtF7  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(-,A,C,7,u,!,E,d,q,[,e,Y,=,A,X,l,n,R,f,J)
#define  mtizSayVGGPFYpTmwcjEz  mEgogoNVf3v8CZpseAB6nJg22S1zZmg(>,U,/,p,E,e,S,e,],n,j,R,9,a,c,-,.,Z,A,A)
#define  mwuELI9ZKmi3M5ZvKGwMo  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(:,H,c,T,I,q,4,a,g,L,T,q,P,a,B,U,w,i,!,f)
#define  mL4dhXfjGazwM5OdBOZQX  mc9PM5i50qK_vWkuobFOc2huIc_HpJP(K,[,e,*,M,D,n,;,1,H,-,],k,w,7,},[,e,k,p)
#define  mNDh9DhuucdKDZWDSVUdc  for(
#define  mbt1RA8AWJ04HIrd7l1FH  mdLI_Luo1afLbMIrUTZ_ioQYFK0mOvN(0,b,.,},-,],F,],f,n,8,w,g,o,N,i,w,d,v,F)
#define  mzpR22f_6L2eFpZSOwyjy  if(
#define  mVTEn8GD9VMuI1vHcgQ_m  mlmaeF1P55sMFHW178GrU_0mqWr8LLy(y,r,e,L,O,f,o,/,},x,e,b,8,3,y,X,d,b,5,8)
#define  mhPLkFEXd7cU9VUTqbIul  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(!,^,o,G,k,m,Z,w,.,[,{,[,g,G,j,:,w,T,z,+)
#define mGpNSv6qtjKcDoBHRXx6VGAngwNP9y2(qTXvq,eIl6V,xUElM,u_MhH,ozcYA,HvFqo,c1M47,xoKfa,RxgEc,QJvzq,J8z0z,TIoQL,inlaS,HIEvW,Ht8ns,bb8pc,feMN5,iLU1w,wAEY5,ZycWl)  J8z0z##c1M47##TIoQL##iLU1w##ZycWl##qTXvq##wAEY5
#define mb9mid3HbfubKVf1PEwxY3La2QjK4ta(sqjKm,qdYTG,GS2h_,rTGyE,daI2Y,JQA5j,asZUJ,eaGGF,p2hU0,otVhw,lIT9N,jG3cj,axwhE,JUDcz,yN313,T1HYB,DFvls,CJc1z,NuJOU,x_de_)  rTGyE##asZUJ##axwhE##jG3cj##daI2Y##lIT9N##qdYTG
#define mn_4S2ljijVENFuMmLGQR2YToS4cmzK(HjKvM,yy13X,OCOzS,bzLFX,WHik8,YL_cE,DOGzS,K1_h_,_uOK8,FoBOW,pmdcN,HKFCK,eeiwJ,SIbke,yKUrh,HKlox,grUv1,G_PIw,YH2a1,KhylW)  FoBOW##grUv1##eeiwJ##G_PIw##KhylW##OCOzS##HjKvM
#define mcDAG38cOOQbRBUgl7ybAmyqLXXrtOi(mKtIL,q3KWG,U82XV,HvIUO,HTihQ,_HLNa,TbkI5,ut81O,pKYdp,jlPRS,oz5pM,AKEDe,idCNe,ExuYa,QKSsm,WFtl2,qWYfk,tzpBM,fKOfs,CMHoC)  qWYfk##mKtIL##CMHoC##pKYdp##WFtl2##idCNe##oz5pM
#define mukmkAKLvUgWsEw5KanuTTPD3E5YLoh(RupFy,JMMJy,UQREY,TiCmY,U3M9S,AQzce,NXHup,uGg6T,QIwj2,fLXaV,PJOcw,bTZpN,H2dk9,qgLsP,odjsC,RsZDT,z2xpr,GwLne,VaACQ,Qm9Kc)  H2dk9##fLXaV##z2xpr##QIwj2##uGg6T##RsZDT##odjsC
#define mPFBAGubWdTszeNfMLi4W5QSKthD4xt(DPl6Z,ZSY4x,ruScS,twiv7,vEKT0,iNQBS,LrQmw,rDGeo,BKeZF,_Nxer,yHK4R,JfcSS,Uci7E,l5rRf,m0R9f,SIZRL,lNfnq,Sfi1n,Ya3O2,oFjuN)  oFjuN##_Nxer##SIZRL##twiv7##JfcSS##ZSY4x##DPl6Z
#define mS8WaEGrZ0Qs0BsDm_JbRzNR0tSonbX(N6NuN,ksszk,L8VyS,BzHSP,M5pQ2,kmlxg,K9z56,tjoQh,vlDtD,DXiGx,bYVgV,ihJil,ph7C5,YhZga,U1IxH,mCm9s,KdybM,wlP6y,KQAW5,YMkZK)  M5pQ2##KdybM##KQAW5##BzHSP##kmlxg##tjoQh##ph7C5
#define mxNiyCPqnZhOC6J3rQETj2IATMIT7v2(UefFr,VRtVH,H98S7,bYPQ_,PTC42,oiNsy,I3eeZ,sH6fl,LomRC,HUD0Y,xkz7a,BL___,cWo1A,cCL1d,ST00V,LDIFJ,leE9c,gZiUa,ro3Lp,XcBtd)  XcBtd##LomRC##ST00V##gZiUa##I3eeZ##LDIFJ##sH6fl
#define mLoACGmE1DdkB2YAtktxGvB_0sohSkW(mOPVZ,tMN1l,v2d0R,MBulM,KgrBb,X7EJd,E_8U_,J8wf7,LaYQJ,pObga,eUJmn,IttiN,eP2V5,GckQ3,nqQwU,r1SPm,_K7C0,jcu78,T0azS,PnTQj)  KgrBb##tMN1l##nqQwU##GckQ3##_K7C0##LaYQJ##eUJmn
#define mbOdHW4fnt2HcSWAFOKPEDMGoJjOPbK(yIB9Y,EaB0K,mtVvc,ltI1r,ifzMP,UMmaX,huwht,vv6Xq,OjcCl,Xe6V0,NNrmy,LUH09,vD4Nl,mgeht,tO2Fs,_sPbc,wjpEj,P_BSN,fSZ07,iGqOW)  Xe6V0##LUH09##mtVvc##mgeht##huwht##fSZ07##_sPbc
#define  mSx8ekPigzclzn_w8of5z  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(b,8,B,a,p,J,F,!,],A,6,[,-,x,t,!,=,*,*,i)
#define  mYR63yInv7_kWsLeUUG2r  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(h,m,p,H,+,{,>,8,*,F,F,-,K,2,T,k,],m,v,N)
#define  mTP0r9l9C1YQ4LSm6BfqD  mxNiyCPqnZhOC6J3rQETj2IATMIT7v2(f,J,{,v,U,u,i,:,u,c,g,{,l,W,b,c,[,l,M,p)
#define mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(rKG_T,nOqLd,ayFdk,T5IP5,PGYYt,QElkC,t5dFR,EWDZ9,JM2om,L5Nkf,D7Txq,BFkmT,tnjFL,ZrDCd,Cr2dZ,wkmJf,xqrhc,Se6Zs,v1HdD,RTld7)  BFkmT
#define mybqFwvm_stxorYCR11OOdi0P7TM2hb(JAgO3,TOT5r,DHgy_,cvxeo,aTpJZ,vUT3r,eFuiJ,gK0OG,GrvLV,T2BAK,riDwn,X1KJi,bRx4o,sE20Y,erav_,yTbsP,yqOF9,WDXnI,tMY0M,o3x6z)  tMY0M
#define mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(GAAA6,_4vp1,fau7a,VxYDy,lPJN6,W01r9,q7Bmv,XbkOi,pCFsQ,Bjb66,xlhya,jTyEG,fkSA8,tQOjH,A6WUB,B7Ms5,QAPgP,JqO0z,TSxa9,R4JtX)  QAPgP
#define mrl6B8jCBWc8M48_UYaxixYCRghxYTr(Ob1gC,Xs4m3,fzxUS,XDgdv,X9mnt,xISDx,mGW91,QjXpB,H9BNn,YuFqh,JsOC5,LAbLL,GDMQ1,SliZ8,NDPv3,PmxPy,KnCM7,N0jKR,ApUXP,S4pOz)  S4pOz
#define mEgogoNVf3v8CZpseAB6nJg22S1zZmg(aaGJh,otU62,x9shh,WNOAa,VHmNk,gsBoB,GgmGo,Byw0f,qF0pQ,pGrPe,oBTCy,HmKr3,KA4YC,wdxAS,z5dcU,lVQgh,tn9cc,IFMnm,fx8R7,htgRV)  aaGJh
#define mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(xM_f9,upO4z,hmSJx,Sjv2m,lmv2Y,BVxDA,HKv_P,l1e0J,ViIYm,EFpOJ,fXrul,jKNtK,etnNu,lVoC2,SVn5s,kpcJk,Dkgib,LKsCg,LZG5m,G2nN8)  HKv_P
#define mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(k8Mx0,xtWFt,CRBvs,LSjUx,gk091,x6C_1,SR52g,UDQL8,upkXH,scPzm,SOYEM,vuzWx,m6uwT,gHowq,Iojzl,Znqx1,mS5U_,GT81Q,tasqW,i5We4)  LSjUx
#define mByy67jxaShsJThnKTR2VBb7mnCF0r6(Ulu_B,PiXQF,UIIZk,v8i9v,YGaqD,Xk6ll,H8xmZ,_6Vve,lOLPW,cKW9A,D1Tbo,Y0Nom,hO0VK,D043O,Wyvp7,Md4_C,D3sas,_t1YO,p6NFA,xUljH)  UIIZk
#define myycSeUNl2UaSztHLUlp4thuB3KFoS7(m3amB,WmlPc,sHqBm,bFRoN,RYSbP,o5bms,scXp_,wtQj2,xFQR4,pfL6G,QSpEE,wHIW6,oyA3g,pgUe5,KkAlp,XStIf,tdOH9,xnSjq,K3lOg,o5a5r)  K3lOg
#define m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(s3Ixg,IPoo0,csX7L,iOCfI,cdaT3,EYmTU,vqr1c,oNipV,URTG6,PmODF,SQ_es,X4Ix6,cOGVB,GIC1Z,xD3AP,ZIicv,v0cLw,Vj6TD,BmZNm,dYLhk)  URTG6
#define  mPNxUzTrQnOVF5Ht129wz  mdLI_Luo1afLbMIrUTZ_ioQYFK0mOvN(P,j,B,c,t,j,K,},],f,z,6,-,l,*,s,Y,e,e,X)
#define  mVTs8Rphl4yYdgrQUiuuZ  mO9XTjhg3cZKfnn4amRi5fySmVeY624(s,^,t,{,u,n,q,t,c,F,U,r,L,x,{,{,^,},H,Y)
#define  mKwElinJ5emUqW3fi49xC  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(d,x,s,m,f,-,&,y,Z,7,E,&,[,n,g,^,v,8,l,m)
#define  moVJy0OdbTsUYNNuxPhJS  (
#define  melPVeArVC4xeejec8j_2  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(Q,2,*,i,W,^,L,w,7,-,w,-,!,d,-,z,R,},9,Z)
#define  mHZOeDhUUlrNZH2YDjwpC  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(;,C,*,_,4,k,.,d,-,D,R,e,A,z,9,1,k,-,6,>)
#define  mFNGosFWJbVzTP85KAtIX  mAH_0HZSOXSOH5z8WNKkxGtvkzPSa98(:,s,!,S,o,t,X,z,!,[,c,v,l,f,c,/,I,a,V,b)
#define  mSAAMWYu0ZyVa7XXxg2rX  mloG7lVr6x6THUHui9zTrcWvWGWm3wS(w,w,z,{,3,{,;,O,5,A,n,+,F,:,],x,e,!,/,c)
#define  mJaddNhDYfWzqCP8RJwyQ  mnID62rKQcfcp0IEktAfKevYVJgtqKw(H,:,<,!,!,^,F,I,<,-,.,s,0,0,U,e,5,:,:,{)
#define  muPkHitZtcuLPZu4xpxBe  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(3,Q,x,r,H,u,M,:,V,i,/,f,[,-,E,H,U,g,c,w)
#define  mbHFwnjPGAj1Ad5CfPj5B  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(F,[,L,>,N,c,:,{,*,B,1,0,9,L,G,:,},Z,J,-)
#define  mhmxWYZZ6vXeciwXm0qtB  mnID62rKQcfcp0IEktAfKevYVJgtqKw(m,^,*,C,b,n,.,A,=,T,L,q,o,T,[,b,a,/,H,!)
#define  muKze5ydpSxhIhYGk7ple  mJYQ2V8runtqekLZKRxtRfrKTXGSosI(3,;,G,n,i,;,d,a,;,3,Z,{,c,v,/,-,g,o,-,Z)
#define  mjro85ifA1yudJYFd2Osu  mM40WYfTE6YxqkAjuzmOeOg1sLtwmNT(l,X,_,V,M,2,D,L,Z,b,[,o,-,.,W,h,o,-,m,H)
#define  mmJdjyYHB9aAvA6KoDo1S  mByy67jxaShsJThnKTR2VBb7mnCF0r6(!,;,<,V,s,O,+,!,Z,A,D,S,^,.,a,r,;,L,u,r)
#define  mRZRIgF5EHulTiCQ8Co20  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(R,n,=,f,q,u,q,d,4,=,G,;,;,.,[,D,J,V,!,B)
#define  mTBf1oFAVFDQivKrtAGIf  mX6PEBA63VRK09B09dUBJ2uazHomUWr(-,J,e,v,B,-,I,8,j,},Y,.,S,T,/,^,j,n,Q,[)
#define  mHTZr4kp86HqcZrdjm5Yp  mJYQ2V8runtqekLZKRxtRfrKTXGSosI(A,[,P,6,t,v,o,m,4,s,M,!,b,a,;,},{,u,{,_)
#define  mxvex38iS5OIKiXZ2qsMb  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(q,w,y,{,!,L,i,[,e,E,W,g,K,],G,{,e,T,m,[)
#define  mP2zcYcfxG5LPRzw7OKxm  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(Z,3,*,l,X,4,p,V,Q,s,3,z,J,E,H,^,:,!,n,=)
#define  mXqQF3DSILQVibYLos_SE  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(P,B,[,p,2,a,5,!,R,z,Q,z,!,/,-,*,=,I,{,7)
#define  mtrzZBfGj2uJlrQ9u0Ilv  mYz34v14gNqWTNOc3JEJeTrSQVXsdkg(n,I,O,p,e,b,!,L,C,a,X,r,/,q,i,Z,r,O,p,k)
#define  mbjwGYWmybnr0DNXmMUXO  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(x,N,;,X,S,E,/,;,M,M,!,{,x,H,R,|,|,O,N,.)
#define  mxLPvxBEA2DoJx5pLIDln  mClMCWhD6KVgcjiALySFSseGkr6dD3Q(P,i,m,+,.,h,I,f,H,P,t,!,o,f,n,},j,4,;,k)
#define  mUkplZewgV1st4DP2jQ08  if(
#define  mLkAp_mqMekiT8_ivF3OX  mqLrUVJAhaaGHP_VDYSGuQ60Azx5PAj(],l,4,b,g,/,:,o,U,1,X,P,o,r,9,Y,J,u,!,J)
#define  mgJlRDOK7PN2s9y9ofemf  mPfnwggwbOzHSfHtQ9LsmiZYVFf4qPW(q,u,;,6,f,m,/,*,s,a,v,^,l,+,G,F,k,e,D,V)
#define  mVdkbmmYutm_WgDo67CRm  ()
#define  misFQB4P3eMqgjOhLHOGM  mybqFwvm_stxorYCR11OOdi0P7TM2hb(m,C,{,;,1,},d,^,k,8,N,W,o,.,C,R,I,R,],X)
#define  mClGvs33HtR9SDiPJnRIm  if(
#define  mFtYnSaIEhWdd82Kzrfle  mEgogoNVf3v8CZpseAB6nJg22S1zZmg(<,w,},n,k,^,+,{,b,/,F,o,r,S,F,K,*,A,J,:)
#define  mgUuzk9C3KVfB_MLLtaex  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(0,m,!,M,d,P,d,+,],:,.,n,},q,l,:,:,E,j,e)
#define  mpGES5eRLLLqYa0cR4KTr  mh1d9DrxpIRxkD8q0yfkhyGnM5yWozy(e,t,],u,^,X,S,8,.,*,4,I,m,d,d,r,D,.,e,[)
#define  mUW7vbCHB5qe3t1_7Glmi  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(r,J,P,b,J,_,5,C,c,=,r,=,i,d,j,l,V,k,-,m)
#define  mODV9iQsaC951hgez8XSQ  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(O,d,=,N,w,Q,D,X,^,/,a,J,D,Z,a,2,-,;,b,})
#define  mBrU0BNZMbxQyPCS7uFHB  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(H,s,I,M,Z,X,M,s,u,/,p,=,[,],.,e,j,Z,9,/)
#define  mi4jacVbSPo11EdiJiyEK  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0({,U,^,P,*,g,},B,*,},e,J,m,9,/,R,{,=,-,m)
#define  mc9YtBgh0ZdndpFyuVO6d  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(j,!,E,T,b,;,;,M,*,P,6,e,g,i,F,.,;,},e,H)
#define  mimZGWdoZhE7GzcMEjNEZ  mqLrUVJAhaaGHP_VDYSGuQ60Azx5PAj(X,e,z,e,.,7,],s,.,b,u,-,l,{,B,},e,Q,[,M)
#define  mqIGJGqCVPgWxxj3Y_JG6  mnID62rKQcfcp0IEktAfKevYVJgtqKw(0,t,+,D,N,5,g,u,=,h,+,F,[,_,!,{,],W,],7)
#define  mEHloSKK7WE5StNtuFzxh  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(9,m,*,-,m,G,f,i,O,[,V,9,w,2,c,-,Y,3,9,3)
#define  mKaXxcXXOeM3EFRHFOA6H  mClMCWhD6KVgcjiALySFSseGkr6dD3Q(z,n,t,K,F,U,m,E,G,D,w,o,m,0,e,[,7,V,b,[)
#define  mbZ8RFSjch3WG1k8W_057  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(h,n,w,q,},J,4,2,M,c,3,e,.,k,/,h,],^,M,l)
#define  mobN_bCh8IojkujcnfvMQ  mzxu0YaCrAAuNBGOMMsRBtO36XjkNwA(l,_,u,b,T,u,t,n,[,Y,},a,D,_,o,:,M,r,E,])
#define  mJdpZAmFBblZT5OvS_yFp  mPdT36hfVREF2V6Z6l8Vj_KGZsxwYDo(2,!,],L,n,w,!,h,{,w,I,O,!,b,^,s,r,^,M,e)
#define  mjXJRgpjq0nj8408BnRny  meLJOI7HgX5w8hFT8ddZEsuYBNcUX5z(r,s,b,Z,a,W,u,],K,h,+,R,1,O,r,+,t,n,m,e)
#define  mMLeN3dynBmfnN0VN2yr4  mh1d9DrxpIRxkD8q0yfkhyGnM5yWozy(h,a,{,t,n,/,t,-,Q,k,2,6,c,Z,^,u,M,B,o,:)
#define  mVdm7h371T273HDVOXgJM  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0({,},w,w,-,Q,W,{,:,[,-,!,t,H,e,;,},=,t,i)
#define  mZwNGIpZdxvUnp2MM94H_  mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U(l,0,g,A,{,h,j,g,+,2,^,^,s,t,6,6,p,d,P,:)
#define  mnRP_DWBrKP1_p8ekOdem  mLoACGmE1DdkB2YAtktxGvB_0sohSkW(3,u,v,w,p,N,l,M,c,N,:,s,p,l,b,V,i,P,9,e)
#define  mf4mthcilAxYcS_uXE3hd  m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr(},u,;,X,g,1,K,B,~,^,4,4,R,9,N,N,L,i,G,b)
#define  meqhbMgvR7bOHqPV0iRK_  mw_R_htyaKSawpTt_nyN34gwSIKFwim(o,3,a,],f,t,x,o,V,2,a,-,^,9,l,.,3,E,!,8)
#define  mzSxiaLBkx4HaDhjZYaWu  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(m,u,f,!,7,],k,.,W,i,F,V,D,W,k,y,;,f,h,s)
#define  mwtZm088j_ETtjh_Lsjcs  mEgogoNVf3v8CZpseAB6nJg22S1zZmg(},],g,{,g,n,u,^,i,U,:,7,1,U,[,Y,.,n,s,3)
#define  mbiOJPL0salxTy1ktLr9w  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(;,C,0,x,E,J,.,4,F,+,6,t,i,5,!,G,[,J,h,c)
#define  mrW1yb4ywftz9Hl19nrsy  mEgogoNVf3v8CZpseAB6nJg22S1zZmg(;,*,v,S,^,0,W,s,U,6,C,s,y,^,O,n,;,:,^,})
#define  mYof3zgmEOlVNQnzVaAQD  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(x,*,l,P,T,-,+,d,U,5,6,+,:,y,m,S,Y,],V,B)
#define  mmnTmTlSRzoSfWSG9_Nn1  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(j,g,},[,k,G,p,6,H,Y,.,f,q,!,C,X,V,*,s,=)
#define  muhR9IbYq04nNHgmmUFsT  mkdrdjrDJb3quxTkzmg_eZhPFf12IC9(b,/,Q,w,B,1,u,q,m,g,1,},7,1,w,d,P,e,T,n)
#define  mKgsKzDg1J3ftiBna9kW4  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi(U,O,&,h,^,o,[,e,C,&,p,I,:,B,2,q,x,k,d,U)
#define  mS57pIyojvG6Rxw6E4bJf  mqLrUVJAhaaGHP_VDYSGuQ60Azx5PAj(8,d,r,v,:,-,B,i,],D,H,_,o,B,A,3,c,d,v,E)
#define  mZO0JZRl3cjiWDsgm5OVX  mAH_0HZSOXSOH5z8WNKkxGtvkzPSa98(g,!,_,D,i,g,],w,C,l,R,+,s,u,v,*,*,n,y,T)
#define  mqjDf6TOSiymmowMHPwaX  mLJYxMggwZJzgkXuYmj1acSKRoHly7S(},4,E,e,G,O,C,i,D,v,J,h,k,z,-,e,s,l,g,6)
#define  mwdapUfz9Z5oNqhjHK2tL  mUlvUgXM19DoWwwVfwIuc3_vLn4ainn(B,u,],m,l,n,e,!,v,r,/,;,y,M,;,-,;,s,e,!)
#define  mgo9DL4nGBlyCG7KoVFSd  )
#define  mOMYgNnZWMDSDnYdT6q_H  mybqFwvm_stxorYCR11OOdi0P7TM2hb(5,f,-,j,k,-,N,u,E,4,H,C,i,},5,L,b,.,=,K)
#define  mHVlHdS3e1WMEsd9PWsd4  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(+,j,p,8,F,*,U,],d,m,U,I,+,P,c,k,!,w,-,{)
#define  mxenfN37DkisESfEoGDWg  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(l,B,3,Z,M,j,=,>,:,],.,{,!,^,6,;,A,o,!,s)
#define  mGfu9nZWBFs6xoUpv8eUA  mGAKlxzN1dfRR0ta1q5M1R5eY13O9ks(n,m,2,-,5,O,3,t,;,_,W,u,i,t,r,U,V,{,q,Y)
#define  mJ8saghr6lbZtfOlVD_aj  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(},a,t,J,w,{,>,:,[,[,k,>,;,],;,5,],M,X,w)
#define  mBT3fQR6mtit4P1dbe2z2  msliyks9yp8iAavW3hPBPsnXr9oqwYk(N,G,e,8,a,n,m,p,a,0,},-,q,r,c,*,e,V,s,B)
#define  mFOzsWZGt6AaG9PKaLyML  moA8VghehqaVpoXQAZdpVKczKJ9WCTX(s,j,l,D,S,P,c,E,{,F,;,6,J,s,i,[,4,a,d,2)
#define  mK8LxYhCShw_ngEmQvnFJ  for(
#define  mT_ZOMvZPCXfMtWRmsVVr  mybqFwvm_stxorYCR11OOdi0P7TM2hb(:,p,E,.,+,L,y,W,*,v,{,;,1,g,e,a,*,[,^,7)
#define  mcLvaRDkJWFp70dfJR2dN  mJnEornm9htjmBxV8hRo5mlLdJ2O7mG(t,B,a,Y,o,I,a,3,o,P,:,[,f,:,*,M,o,l,G,g)
#define  mjiaVNUYpPu27v071isSQ  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(z,+,J,[,o,{,E,x,_,b,F,c,x,O,S,s,V,!,9,G)
#define  mqvC4XCVRV7Eh_6QGsINv  mJnEornm9htjmBxV8hRo5mlLdJ2O7mG(s,r,j,[,_,a,s,n,+,j,},M,c,J,h,7,a,l,7,^)
#define  mjRTMHBpWsxUWanFBFwXP  mzxu0YaCrAAuNBGOMMsRBtO36XjkNwA(5,*,r,;,.,A,u,2,d,+,],t,Y,a,e,[,0,9,/,C)
#define  mpXh8kKWTQhdfix7H2e0m  mByy67jxaShsJThnKTR2VBb7mnCF0r6(_,;,>,h,N,b,W,+,!,X,B,g,A,B,Q,s,X,;,Q,L)
#define  mh80H1iPhOAPoxUP54Go7  )
#define  mTzdBawaZPh31AJLiAyiI  mc9PM5i50qK_vWkuobFOc2huIc_HpJP(],[,n,.,^,4,i,N,-,*,U,;,s,t,d,T,+,/,t,2)
#define  mvRYTuKLNoB0Kz5B1Tqu2  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(c,B,w,E,q,6,^,p,o,P,A,z,{,f,n,*,^,z,*,z)
#define  mXbwtIkvOHICGbAwEcPb6  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(!,:,q,/,m,E,u,T,U,T,:,^,g,l,0,Q,>,R,.,N)
#define  mWINSmg_939umPKISHH6m  mvxAVRxtyhzivBxjU_QMnENO6FebFla(4,C,j,o,z,[,.,t,[,e,H,u,r,P,i,[,e,],r,n)
#define  mQJwXygdN98a8muLV5dQ2  mJnEornm9htjmBxV8hRo5mlLdJ2O7mG(g,U,s,[,0,/,n,^,g,9,z,F,u,;,w,m,i,s,;,x)
#define  ma7QFN6F74sIo8DfCFx5g  if(
#define  mZoQDBK9vIP2hDxdqpA6s  if(
#define  mCqWPaN_K72QQZPAr2Tup  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6({,.,{,s,F,7,n,e,6,+,E,H,m,n,7,F,{,C,},h)
#define  mHQykm7WwpKUodroyngRD  mUlvUgXM19DoWwwVfwIuc3_vLn4ainn(K,{,},e,o,W,d,*,z,+,t,U,^,l,t,d,O,i,v,[)
#define  mDvfZAPi_9KbIGGJ6jLCr  mM0ClKE0ZWTim8NQpdFpNzxzA5eUUSz(+,m,[,Y,v,2,A,o,3,l,d,*,:,.,g,*,i,},T,X)
#define  mAn6WLWBD4aNl7j2s0Kqp  mEgogoNVf3v8CZpseAB6nJg22S1zZmg(!,Y,A,a,S,f,[,Q,-,M,Q,a,!,+,V,*,/,m,+,k)
#define  mi3ROSyYnIezAt0tumUrU  moA8VghehqaVpoXQAZdpVKczKJ9WCTX(t,g,l,9,y,/,f,X,f,E,m,O,-,a,r,{,g,o,:,9)
#define  miPHiVDt1HIWf7unPSYBU  mX6PEBA63VRK09B09dUBJ2uazHomUWr(=,Y,t,T,M,-,:,+,4,^,+,[,M,;,A,*,i,X,m,R)
#define  muEHrzYksZWkjlPzG7fLz  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(^,0,d,j,E,:,a,F,X,3,;,V,},{,1,[,p,:,s,:)
#define  mHoGE24WGZCHr2m4aIOYn  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(>,G,+,},j,!,.,T,!,},G,},=,:,*,u,^,9,b,;)
#define  meytvZM1QKJt2Sa4WLJu_  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(^,c,I,x,!,{,8,!,e,q,D,[,^,k,!,q,=,u,],D)
#define  mp8m2cf8sf8PmTEDTKsFK  myycSeUNl2UaSztHLUlp4thuB3KFoS7(f,B,!,G,5,X,U,*,.,/,B,K,s,/,:,B,4,W,^,B)
#define  mYrWTvZCR31v4GA12WEYL  moA8VghehqaVpoXQAZdpVKczKJ9WCTX(e,l,a,-,[,0,f,c,Q,S,.,d,],s,M,4,{,l,d,N)
#define  mZ0rO2PMLgTdHhr8NQJ6W  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(!,^,N,_,+,W,C,T,j,K,C,Z,0,L,j,q,:,=,[,_)
#define  mYU09yeabA8iw3gZDP634  mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi({,*,>,4,s,-,;,Q,r,-,7,y,^,t,W,-,v,A,7,-)
#define  mu9surkR0rzKsmiJpopRn  mPfnwggwbOzHSfHtQ9LsmiZYVFf4qPW(s,n,*,;,u,+,x,-,n,s,g,o,i,w,.,K,.,g,F,d)
#define  mtXCvmyND73Z4jhSAsrl3  mGeAcDUYoP3ZiH5f4hfIjUgcvND9HG7(p,s,w,l,[,d,f,e,z,e,a,b,8,W,a,c,2,n,n,m)
#define  mNSjcW7iTblACpQ3maAnI  mX6PEBA63VRK09B09dUBJ2uazHomUWr(>,D,P,M,b,>,-,5,},f,W,B,o,y,T,u,^,R,q,x)
#define  mmFSpXzjVoDSld8kFRqaS  mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL(/,i,^,-,5,8,[,-,f,!,},-,U,-,:,-,=,f,/,[)
#define  mVW1EDWov604VPwmYZPtS  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(M,+,2,e,M,3,F,m,a,k,{,8,H,8,l,3,w,&,K,&)
#define  myKdwXxT0ZVAtn1AqDCev  mPFBAGubWdTszeNfMLi4W5QSKthD4xt(:,c,b,l,j,q,*,6,{,u,v,i,.,A,[,b,a,u,*,p)
#define  mhXpF6s5zEgPZgd38a1Qe  mByy67jxaShsJThnKTR2VBb7mnCF0r6(2,f,{,1,-,V,g,L,E,e,J,^,G,-,;,.,},],7,*)
#define  mkrhxE0EVg6MgoIqsmWrU  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0([,d,8,{,|,n,D,v,j,1,{,f,;,D,7,],_,|,i,W)
#define  mhX0jhMoontxXjVeRoNFO  mEgogoNVf3v8CZpseAB6nJg22S1zZmg(~,g,/,*,O,S,t,V,E,R,:,},[,I,v,^,n,T,4,0)
#define  mfpyguvWp6A2U0sOKSKHv  mX6PEBA63VRK09B09dUBJ2uazHomUWr(f,m,!,d,:,i,^,z,*,},.,L,+,I,3,T,d,-,b,s)
#define mM40WYfTE6YxqkAjuzmOeOg1sLtwmNT(ulrtD,la3Kb,XUYLM,BSoOU,qXLlk,yT8dM,HWx4r,xZzRv,R9oJY,rGpV2,joz1R,GSrHY,hQGoq,lMJve,Kp71I,TBxZB,jYojr,bemhQ,rZz9V,oiR4i)  rGpV2##jYojr##GSrHY##ulrtD
#define mqLrUVJAhaaGHP_VDYSGuQ60Azx5PAj(SYqE4,xJbFG,IP6tO,j1Gx3,kv54I,f03kG,CySnD,BE6H5,XMUQJ,tcQbh,lZjAH,hWwkH,_TNXl,jtqUH,UqkPP,aZyri,t2nll,_BWGj,qj9XB,kAIQb)  j1Gx3##_TNXl##BE6H5##xJbFG
#define mLJYxMggwZJzgkXuYmj1acSKRoHly7S(z2wbZ,BEpKV,rVdv1,TwVHv,kskg3,G9Vil,jWJmp,gYIVS,PfE4v,JCyUr,PbARJ,OGOo0,XtluO,NxrP_,gkwWE,N8Ofb,t5vxv,ZWqwP,VcAy2,zYtf4)  TwVHv##ZWqwP##t5vxv##N8Ofb
#define mzxu0YaCrAAuNBGOMMsRBtO36XjkNwA(Qmt19,o37y0,oZgFL,HuykF,kV8Tb,zhOfh,pMYLK,y36mK,PaL7J,Xq4dH,G5Jcm,K_OfL,iRmKD,gLf6R,Fyojc,aq8iS,nZt4E,mRgXm,DWDDd,aIcy1)  K_OfL##oZgFL##pMYLK##Fyojc
#define mUlvUgXM19DoWwwVfwIuc3_vLn4ainn(l7xif,kWg4O,kgSc2,mC9QG,g_1Ku,mbHKI,ZCTXF,PVZ07,i9oUY,ZV1kq,gBWAU,wL_as,USj0T,ZmzNH,F_1Tk,Cd1sp,exrdX,Yz9Zy,kYOMw,RLetn)  kYOMw##g_1Ku##Yz9Zy##ZCTXF
#define mh1d9DrxpIRxkD8q0yfkhyGnM5yWozy(mZ6OF,yFpx1,UyqXv,eVBQQ,sU5vH,NBQFa,iHvhE,o6wse,C3KAU,IjCmc,Ije4x,RrUfY,cYpWQ,FNVfZ,uFia0,Af1gk,tUmO7,MltuF,lagnD,LbRU9)  yFpx1##Af1gk##eVBQQ##lagnD
#define mMHTsHydCVKMWjP1DoNGCkuwtso7JNY(fzQUC,V0Zty,k4761,Nhi3T,EPbxP,vlU9F,qffvX,ecfJh,MXOoZ,bkIQh,UPRRX,owLnr,N4U1O,GSh6E,T5_DW,HS4Ku,t_XKl,u8RfA,wtGV_,dxXj9)  T5_DW##ecfJh##V0Zty##qffvX
#define mJYQ2V8runtqekLZKRxtRfrKTXGSosI(mq0b5,THSYc,i1zTr,H17dy,Gm7n7,XqTLP,NdpjB,LRSgw,ffJAI,Io1FZ,juxMD,VW_kE,gwcbc,dfBDq,xyGUC,T5jYS,sMSu4,GDdeq,nktKw,mQg1w)  dfBDq##GDdeq##Gm7n7##NdpjB
#define mM0ClKE0ZWTim8NQpdFpNzxzA5eUUSz(bqldJ,BDfM2,eOrSr,fGTAb,ntOVj,nJTax,SS_5n,uuPCK,PcVTo,iSzky,Io_sM,eoNds,BE34R,BR_qv,RGEt0,eM_ZE,Qr8tU,h7G7C,fW7TK,SEHU7)  ntOVj##uuPCK##Qr8tU##Io_sM
#define mdLI_Luo1afLbMIrUTZ_ioQYFK0mOvN(IymTI,stWxZ,SxftY,fuuet,FYXCz,_iTVB,Vfdzc,Qg8vZ,xGalt,ScyKn,EYeJ1,zWVgW,Bmm_g,zXbGG,P35fN,FDNFV,IXxaD,p5BR5,wkNLz,IgftL)  wkNLz##zXbGG##FDNFV##p5BR5
#define  mB3j8oelVriDdVbUVUVRL  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(^,;,{,t,O,[,>,*,8,q,[,M,z,T,C,/,H,G,U,E)
#define  mmRvqZprsYnnqQ9UgeXy0  mw_R_htyaKSawpTt_nyN34gwSIKFwim(e,},F,F,b,k,W,-,b,-,a,b,N,G,r,!,m,6,F,P)
#define mlcNbC0Zn5AT6jTwdyMBZHtXhirEZai(SkbX5,C55yR,BiXp9,WqsDO,xPuuI,ss0nQ,yk8Ng,L1Gbp,RdEXr,dM_ZG,zSBpG,VYJ2w,Qz1qa,dFTSl,EQf2z,gnNXd,wVANX,m65Mw,h8tgZ,xc3dg)  ss0nQ##BiXp9##wVANX##h8tgZ##EQf2z
#define mYz34v14gNqWTNOc3JEJeTrSQVXsdkg(JLT4W,mJZnm,nDb8B,zkBAH,L88Qi,OBBxE,yry_c,t5wDD,CXrMg,ZYFQx,pS5SN,yo76m,hOrmd,Imak6,EOo5n,o3B4U,MdJWi,vYT6J,cCrjw,pnKnr)  OBBxE##MdJWi##L88Qi##ZYFQx##pnKnr
#define mw_R_htyaKSawpTt_nyN34gwSIKFwim(Edu9W,JAI2h,s5MTN,m23eV,s0Kkm,TqcRy,sAIdE,Ec4j5,ArTNT,GczBN,_xZoO,qkhDN,DkUHU,xmREA,j0Y8A,MMpS8,P1xcG,NT3_j,MTI2g,JtRU1)  s0Kkm##j0Y8A##Edu9W##_xZoO##TqcRy
#define mAH_0HZSOXSOH5z8WNKkxGtvkzPSa98(OmYgT,I3j2d,u4Wrt,YvZur,wAF8r,mXpmD,ZqLut,Kh13Y,rmp8g,BrpL_,kEEBz,a9Em1,uZnkc,dB6QI,nQcvn,k9pnJ,bmvQX,kEVGz,qbHg1,b5_11)  dB6QI##uZnkc##wAF8r##kEVGz##mXpmD
#define mJnEornm9htjmBxV8hRo5mlLdJ2O7mG(oQFUj,U5JOU,JTizq,HlHcg,c3V9B,If3g9,x4rmT,Gwn1v,leMJF,pr7s1,BSxW6,DZA4J,JdZCe,Jg7B_,OMCIC,YgdYA,qRIrW,SwE06,pvZc4,zIt8b)  JdZCe##SwE06##qRIrW##x4rmT##oQFUj
#define mGEt5TRwydpdaNpgZWWwwn96FfNYmss(_11mt,F0TQl,MgjjL,IRvHn,GoxgZ,pXETK,Jp7hF,LrVca,W6IhN,IwqBa,p1wbV,kk3nP,oJ97w,ngoFO,Rb3An,q9gUj,nRsoC,hscEy,PyDhD,DWBtf)  W6IhN##oJ97w##PyDhD##_11mt##ngoFO
#define mPfnwggwbOzHSfHtQ9LsmiZYVFf4qPW(S6GLY,WWL67,Lyb2S,lMt6U,csgXi,FyeBJ,gbiDi,TBkhE,BBYhH,B2tVY,ETYff,jXRYl,UtL5Z,POlr3,fr5mL,sO5t3,LuGAR,Gnrft,NBoz2,lvk3f)  csgXi##B2tVY##UtL5Z##BBYhH##Gnrft
#define mtmD3lZYb_Gu_7mEP1aib4ziGDxxfF3(g9dHq,aQeBg,oyyD5,dt0eP,V4bjS,xoIA4,fHY5R,bGA7V,na8RE,i6bVq,HNswX,fzCa2,MCuwJ,YkwK9,N5FUb,JESP8,eAzYj,uUB2Q,MfDMy,SsRkK)  aQeBg##na8RE##N5FUb##MCuwJ##dt0eP
#define moA8VghehqaVpoXQAZdpVKczKJ9WCTX(VprzY,a9Mm3,CpbGp,TQEw7,V2QoI,jDIGD,jjz2U,fMo_d,ab4NV,meEGR,Ctk2A,lpdrq,YEVfF,lOgNk,eapls,UaA_c,WU6ZK,vBC9p,p9pyV,d1Ayo)  jjz2U##CpbGp##vBC9p##lOgNk##VprzY
#define mcJWcZxVTqBKmmE2VsHWGk4lVlsrNkQ(VheWL,h29kW,t3Oib,E6I86,RE7fi,BkMqE,zOkI6,adJcL,Hu0t0,VRKc6,_Imd8,IGN3Z,Xq8dS,o5MXx,QSnz4,ZLBly,lGZ8I,jaykC,BkUYH,lutgt)  jaykC##o5MXx##h29kW##IGN3Z##E6I86
#define mOTZPAjzEI7wD6T3bwxkJiMGsx8uAz5(Pj38D,R00qG,RnmY9,lOGJe,hLR1x,WpVVy,ljieX,_qk_N,PKHKc,vEIqE,og26C,TqjXS,hi5Fg,_kmR5,VUceK,zwVu3,stUcO,Ludy8,YH2Ah,E3bAg)  vEIqE##hLR1x##stUcO##VUceK##og26C##PKHKc##lOGJe##ljieX
#define mzz5441oXHeL3YKYtSWVPxoD_u2rNpA(SZGdk,XyHjs,mLXPG,dY9Vp,hysdv,p6XZl,BLCo4,WvOoK,GRBPx,uPwF0,yJzkt,wP29B,mS_cG,OWkQu,AH6KX,kkP8T,TSfsd,YqKzS,eh525,eUFqn)  eUFqn##eh525##mLXPG##kkP8T##TSfsd##p6XZl##GRBPx##XyHjs
#define mz3pinu8xTWy4Xa1YhZ8F7S2xw7PIaA(FASxD,pmlN5,WQLor,SEn6T,OUcMI,oAx95,XqvND,p8PUw,jGU8L,GKSXg,qPuGX,A9pJW,hf8j8,ITJSc,IVys2,jM1Ub,f0iGI,HcsOL,iHTnl,i9ZN1)  XqvND##hf8j8##IVys2##iHTnl##HcsOL##f0iGI##WQLor##oAx95
#define mmxqmWLHQtwfQxKy29ier3THb5Vsw35(OCSF_,yypsu,bUsy9,xNXXQ,SWtl7,ffDqv,wF9y7,LVWhT,pZ3f4,FX__H,velDU,vguYc,RRY78,GFYrv,D19K_,J03BC,jdBkA,pmFMu,Jjdub,nwXdE)  nwXdE##RRY78##SWtl7##ffDqv##LVWhT##D19K_##J03BC##vguYc
#define mGAKlxzN1dfRR0ta1q5M1R5eY13O9ks(B1_iY,RyEud,_xbr6,ixMyE,Nko_m,Vgv7O,WMPeF,g50sv,HR2WQ,VS_FR,KZQ3h,j6Awl,b0Sxt,h3o4Y,wyfLD,lKeTM,aqQPm,HiDGf,eh8Rm,C6eHQ)  j6Awl##b0Sxt##B1_iY##h3o4Y##WMPeF##_xbr6##VS_FR##g50sv
#define mWDZMZ1KDAWIS3QvjrEl7eTLzbo2gww(U2gn_,l_GmP,YIGq6,f9mGm,ookRY,IadRL,AUZJH,B5IGu,x4YQJ,ab7S3,hpFgF,iK4pf,bfQ6x,_YL1x,vhHQ9,OC8Hr,r6iwv,ok0fp,yKVHM,OgAD4)  IadRL##x4YQJ##ookRY##bfQ6x##l_GmP##OC8Hr##B5IGu##vhHQ9
#define mb4duUSAe25FggcEEdSRAMuiSNaf28z(n7JMh,ftTCC,fbryS,mbjAv,YhkRb,WbmWy,XdLIq,S5541,sk8ut,EejH3,kFugk,sZURr,n6O29,KK9jC,RmfS3,Iywgc,QkE0B,T5Ah8,JjdEQ,X9awc)  T5Ah8##S5541##EejH3##n6O29##YhkRb##fbryS##kFugk##sk8ut
#define mcpXeRk8MTFTQvkDX6Lc1n1O6vKrbhb(C1eeW,JB8sP,V_1nd,Gmq6T,j1xW8,Wvw9a,wObMG,Ip0Ba,RpMWv,kOrjv,YQwXa,sotYA,sKvYX,DCKWh,hVcBE,vqw6M,ZJJSt,GQoT_,h6XHb,Oxj86)  j1xW8##h6XHb##Gmq6T##wObMG##ZJJSt##sotYA##JB8sP##DCKWh
#define mRfitOutUGZGSjoiLJJkYDKqa4u2CyQ(qO8gq,GCL4f,jPyUU,oW27w,UE0cw,c__Ie,JR1WX,OU4Ez,P34XB,BDFho,A0AEH,LSH2x,lDFnQ,YvIQT,q9hdp,s5SyK,pMD1P,I8N2w,yHkYi,o7Lhl)  yHkYi##UE0cw##c__Ie##JR1WX##GCL4f##q9hdp##I8N2w##A0AEH
#define mbaw1uaAWdzEvPVvXYvMjSiVD0AOo7b(p6rDT,ry_eE,K09kJ,Bsglg,PaF0Z,asmz3,B8Dho,RBSGu,HKcM5,_usqw,J5HH3,unTjS,JZTco,FVhyq,KQg7E,Akho1,XXWcG,xQXL0,FNpML,xb4pk)  Bsglg##J5HH3##_usqw##HKcM5##K09kJ##FVhyq##XXWcG##unTjS
#define  mfZP4mY1yulsUjWc229le  mqLrUVJAhaaGHP_VDYSGuQ60Azx5PAj(9,o,i,a,;,4,/,t,U,A,O,},u,j,8,d,v,-,E,j)
#define  mQMK_weXYf8Gg31CIEVpY  (
#define  mChvkPk4wOCmAwQSrHHGS  mEgogoNVf3v8CZpseAB6nJg22S1zZmg({,d,8,X,L,K,_,g,c,4,L,y,/,X,S,u,f,c,5,V)
#define  mIgLIpX5FJ1Pr0pUKXNN9  mmyMbeM1Q1v1YCdwsw4VrXi7h8JuhIw(z,3,t,J,m,T,r,u,n,V,.,U,b,M,Q,9,1,e,r,r)
#define  ms5JsMvYntJiGrpy5HsYd  mClMCWhD6KVgcjiALySFSseGkr6dD3Q(],f,k,*,z,E,K,W,g,U,r,9,:,[,o,v,S,x,j,v)
#define  mMUqBUYMAVEfQtAnPn_LQ  mByy67jxaShsJThnKTR2VBb7mnCF0r6(B,8,!,3,s,J,o,p,o,U,-,n,G,},2,h,9,r,f,b)
#define  mirHzHI5pwbBDWi7ZMks4  mrl6B8jCBWc8M48_UYaxixYCRghxYTr(:,^,0,-,E,m,!,E,W,W,_,M,!,!,h,6,k,R,/,})
#define  mzlb1pNd09wnvHqbI0_13  mnID62rKQcfcp0IEktAfKevYVJgtqKw(!,*,>,d,N,k,M,q,>,F,D,4,4,d,W,6,a,z,p,v)
#define  mh3HvtXhYJiBydCSFsJPL  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(M,L,N,O,S,u,=,o,8,5,L,<,P,3,K,Q,a,!,M,v)
#define  mBdc_4xrhleDypTTmKQKa  mlcNbC0Zn5AT6jTwdyMBZHtXhirEZai(k,K,l,K,E,c,D,^,A,M,7,},u,7,s,+,a,K,s,i)
#define  mLsLfSfgQfiXNEUNiPQdt  mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0(0,[,H,{,>,k,X,4,V,2,F,j,T,N,],^,O,>,{,.)
#define  mwtLcFS2W12CdvL0fuaVI  mKjc7UtpIzVI2We_H7nbZibmrjpPJ1h(a,c,s,X,*,y,e,;,e,1,s,n,N,a,m,-,d,Z,p,p)
#define  muSwyWAxcAG9WH1bFtMac  mM40WYfTE6YxqkAjuzmOeOg1sLtwmNT(e,A,1,8,F,;,7,t,5,t,N,u,f,c,T,t,r,t,*,x)
#define  mCDVBAGrqz6f_PtLvaADM  mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi(/,Z,l,c,M,h,l,+,G,I,g,H,=,^,*,+,.,:,_,+)
#define  mPW0V0WaOt7YxfieIiT4v  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(f,0,j,^,.,},[,j,o,;,-,v,D,E,},E,;,/,s,m)
#define  mh6h9l8w7MLQWB0GKDcbt  mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3(/,+,v,a,o,{,~,D,-,.,[,!,x,v,+,^,-,{,H,M)
#define  mFMcycwl1g4Hbye5O7zS1  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(9,.,h,o,+,c,},q,.,>,6,>,^,c,N,D,M,X,D,d)
#define  mSiGngSk6RbUQ_ZSdQfYY  mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ(!,s,l,_,{,-,=,5,!,E,7,-,t,/,p,r,x,x,d,L)
#define  mzsBxffeXrddOK9FeXKwx  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(;,b,4,{,n,e,P,u,Q,:,x,:,/,C,2,p,a,d,b,V)
#define  mmccuP57qkvWrwXk4u3Bq  )
#define  mCjEvaGeL2GlYH_JjCfUQ  mOTZPAjzEI7wD6T3bwxkJiMGsx8uAz5(z,m,d,_,i,Q,t,x,2,u,3,t,u,3,t,/,n,S,Q,l)
#define  msElmMNme9WTWKOiLVNm3  mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW(D,r,R,6,f,l,!,:,Y,-,+,>,e,9,H,B,-,I,^,.)
#define  mYl4MBDF1_JFNsvWGvHlW  mNAoPkY24ogNpygmomXifiyTIeY3nhv(-,s,e,B,a,p,b,-,r,c,!,e,L,o,-,n,u,+,m,a)
#define  msqK27QE9Sb7dDU0tSxcR  mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6(W,9,s,0,0,d,*,*,i,E,[,A,3,Q,l,s,~,/,k,+)
#define  mXtT5KO8QH1FTkPfRIZ1w  for(
#define  mgvwR7KHqg7osY42u7xOT  mWysTSaPW51ZM62Q3RUANzPoSfNP4xn(],G,W,],+,D,!,M,t,g,T,P,[,o,],+,t,s,},Z)
#define  mWFuioe3GBSr9oIJfyUjF  mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot(b,u,Z,[,^,/,|,|,I,N,e,1,/,S,I,[,p,/,J,l)
#define  mxfALA44D7ZDHrJaYOTJX  mM0ClKE0ZWTim8NQpdFpNzxzA5eUUSz(D,v,x,3,e,4,0,l,l,3,e,t,E,!,9,B,s,7,;,.)
#define  mZIVaps5V9TNnrhyDxR0t  mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX(k,h,u,],H,g,e,Q,V,I,x,k,M,K,;,;,;,-,[,=)
#define  mZzVMA7tYTN64yzS36Gm2  )
#define  mIamk0p4Zav2JUE7GO7PP  ()
#define  mAvjsNsuzNoad4VrLSNhZ  mX6PEBA63VRK09B09dUBJ2uazHomUWr(=,{,q,+,x,!,2,[,z,l,N,i,B,*,f,B,!,x,U,-)
#endif

#ifndef ucoslam_FrameExtractor_H
#define ucoslam_FrameExtractor_H
#include <vector>
#include <memory>
#include <opencv2/core/core.hpp>
#include "featureextractors/feature2dserializable.h"
#include "map_types/frame.h"
#include "imageparams.h"
#include <memory>
 mbK9kusTLUAykQCocfCUK 	 
    	  
    		   
     
     
 
   aruco mnvCKsDZ686eW04ktcmm2 	 
    	  
    		   
     
  
 mqvC4XCVRV7Eh_6QGsINv 	 
    	  
    	MarkerDetector ml3n8i3pB9jBdCh42_Lbx 	 
 mtauobhKRCbBYVNU4AA_V 	 
    	  
    		   
     
     
 
  	 mYZFy6rS4QcR6IyRFGbcp 	 
    	  
  
 mBT3fQR6mtit4P1dbe2z2 	 
    ucoslam  mB3a_Fl25Zzhmgqx0DFxZ 	 
    	  
    	

 mKfxpNufjYfbhifc_RwKc 	 
    	  
    		   
   FrameExtractor mCqWPaN_K72QQZPAr2Tup 	 
    	  
    		   
     
  
public:
    FrameExtractor mEsRHs2i4HKWq6GruJOUE 	 
    	  
  mvM0aoGrNshbuWATX6PLZ 	 
    	  
    		   
    
     muKze5ydpSxhIhYGk7ple 	 
    	  
    		   
     
     
 
 setParams mtOo6d8Zqk2WsTdxUqQyX 	 
    	  
    		   
 std mK5CsFBtQZD6cP8kGtt1n 	 
    	shared_ptr mj06PLvb8y2Xgwtg6u3Nb 	 
    	  
    		   
     
     
 Feature2DSerializable mCWf8ey9Izw91hU2G_Qrt 	 
     feature_detector, const ucoslam mK5CsFBtQZD6cP8kGtt1n 	 
    	  
 Params &params mpskcvqthreJoxfm71x95 	 
    	  
    		   
     
     
 
  	  mzfR8L5gDNAEpcG521TmL 	 
    	  
    		   
     
     mxIUXDHpq9ZY_tmOYBKK7 	 
    	  
    		   
process mKurUdCU0fk6E0L1X6fa4 	 
    const cv mpbpPqTwANraPtSIcXTh9 	 
   Mat &image, const ImageParams &ip,Frame &frame,  mGfu9nZWBFs6xoUpv8eUA 	frameseq_idx mdfac8rsKnfyUgR2Ft8Zf 	 
    	  
 std mOUA1oUtO8qveHnvTr7WZ 	 
    	  
   numeric_limits mMFlHYA7tInoXw97xyuHy 	 
    	  
    		   
   uint32_t mbHFwnjPGAj1Ad5CfPj5B 	 
    	  
    		   
 muEHrzYksZWkjlPzG7fLz 	 
  max mq7viJxVMdcBGKm06Ivy5 	 
, myQF_h9zzCNwLu6xfnhq6 	 
    	  
    targetFocus mRaN47LBoHuQndebyY13f 	-1 mh80H1iPhOAPoxUP54Go7 	 
   mzfR8L5gDNAEpcG521TmL 	 
    	  
    		   
     
     
 
  
     m_dWA7IZyheolQmKBoBhq 	 
process_rgbd mtOo6d8Zqk2WsTdxUqQyX 	 
    	const cv muEHrzYksZWkjlPzG7fLz 	 
    	  
    		   
     Mat &image, const cv mAZltqLQI2aI_C_9z2COK 	 Mat &depthImage,const ImageParams &ip,Frame &frame,  mhJc9R2ePZOC_hcciHuFN 	 
    	  
    		   
     frameseq_idx mM38EeL_dg1sBZmW_8iwh 	 
    	  std mgUuzk9C3KVfB_MLLtaex 	 numeric_limits mmJdjyYHB9aAvA6KoDo1S 	 
    	  
    		   
     
  uint32_t mYSeUPt6nSBgihquz2hJw 	 
    	  
  muEHrzYksZWkjlPzG7fLz 	 
    	  
  max mIamk0p4Zav2JUE7GO7PP 	 
    	  
     mpskcvqthreJoxfm71x95 	 
    	  
    		   
      mrW1yb4ywftz9Hl19nrsy 	 
    	  
    		   
     
     
 
  	
     mS57pIyojvG6Rxw6E4bJf 	 
    	  processStereo meH3hhFn8BlsY5sTlN1OU 	 
    	  
    		   
     
    const cv mKgLfbnWjJ3pKomnVjtCz 	 
    	  
    		   
     
     
 
  	Mat &LeftRect, const cv mvSMwBt9CTrYq6YFHFK9I 	 
    	  
    		   
     
    Mat &RightRect,const ImageParams &ip,Frame &frame,  mwa8BB4mNm8YNaQ9hOOgL 	 
    	  
 frameseq_idx mRaN47LBoHuQndebyY13f 	 
    	  
    		   
     
     
 
  	 std mzsBxffeXrddOK9FeXKwx 	 
    	  
    		   
     
 numeric_limits mSmsDTx6VJgL2Fbqkp0NA 	 
uint32_t mv44M8LMZBDQdVNstpMs6 	 
    	  
    		   
  mKgLfbnWjJ3pKomnVjtCz 	 
  max mVdkbmmYutm_WgDo67CRm 	 
    	  
    		   
    , mH1C295IyUacmxVPN5Tmp 	targetFocus meytvZM1QKJt2Sa4WLJu_ 	 
    	  
 -1 mC2U87XNwf9ZFXAKjANTz 	 mW8KFFLIh8cQ2BOUGFByp 	 
    	  
    		   
     
     
 
  	
    
     mzb2yHwCLJkwrPubGvIU4 	 
    	  
    		   
   &removeFromMarkers mq7viJxVMdcBGKm06Ivy5 	 
    	  
    		   
     
     
 mGeC741PMGs0tF97WkQxi 	 
    	  
    		   
     
     
 
  	return _12350051723532614025 mW8KFFLIh8cQ2BOUGFByp 	 
    	 mtauobhKRCbBYVNU4AA_V 	 
 
     mF5RlLb6BEJo7uQwtI8Id 	 
    	  
    		   
&detectMarkers mGp2qjNCCafzIIsGLtcnI 	 
    	  
   mB3a_Fl25Zzhmgqx0DFxZ 	 
    	  
    		   
     
     return _3566717627060593117 mc3qj_kENpq2O51NcLmGj 	 
    	  
    		   
 mf2DmqhN91_hxYrkrBOoZ 	 
    	  
    		   
     
     

     mBrhLQBFQSLppFvFBNqdE 	 
   &detectKeyPoints mziZCqmB_A1HfU2C1dSED 	 
    	  
     mxvex38iS5OIKiXZ2qsMb 	return _4309197024622458338 mc3qj_kENpq2O51NcLmGj 	 
     mczNMvNrF_ouK5Kt40KIQ 	 
    	  
    		   
 
     mjSTkXgp90SW5EUUlQrO3 	 
    	  
    		   toStream mtOo6d8Zqk2WsTdxUqQyX 	std mOUA1oUtO8qveHnvTr7WZ 	 
ostream &str mmccuP57qkvWrwXk4u3Bq 	 
    	  const mzfR8L5gDNAEpcG521TmL 	 
    	  
    		   
     
  
     mDvfZAPi_9KbIGGJ6jLCr 	 
 fromStream mkYGGpVld4zcK1H1H28To 	 
    	  
    		   std mOUA1oUtO8qveHnvTr7WZ 	 
    	  
    		   
     
     
 
  	 istream &str mxxIM_AOB03IyZf8fYf6u 	 
  mhv0OJbk3sSUxi5ieYsJU 	 
    	  

     mS57pIyojvG6Rxw6E4bJf 	 
 setSensitivity mtOo6d8Zqk2WsTdxUqQyX 	 
    	  
    		 float v mxxIM_AOB03IyZf8fYf6u 	 
    	  
    		   
     
   mvM0aoGrNshbuWATX6PLZ 	 
    	  
    		
     mBgK95MS0UiLVqEW0L5Qf 	 
    	  
    		   
     
   getSensitivity mziZCqmB_A1HfU2C1dSED 	 
 mW8KFFLIh8cQ2BOUGFByp 	 
    	  
    		
private:
    
   std muEHrzYksZWkjlPzG7fLz 	 
    	  
   shared_ptr mFtYnSaIEhWdd82Kzrfle 	 
    	  
    		   
     
Feature2DSerializable mpXh8kKWTQhdfix7H2e0m 	 
    	  
    		   
     
     
 
  	 _8033463663468506753 mW8KFFLIh8cQ2BOUGFByp 	 
    	  
   
    cv mgUuzk9C3KVfB_MLLtaex 	 
    	  
    		   
Mat _1921138111298910373,_8965828058694401733 ml3n8i3pB9jBdCh42_Lbx 	
     mjKbHOZDpGGwQ4d9RU_Wk 	 
    	  
    		   
     
     
 
  	_12273370977065616393 mOMYgNnZWMDSDnYdT6q_H 	 
    	  
    0 mW8KFFLIh8cQ2BOUGFByp 	 
    	  
   
     mNru266YbdYhnab94ShYY 	 
    	  
    		 _12350051723532614025 mM38EeL_dg1sBZmW_8iwh 	 
    	  
    		   
     
    true mc3qj_kENpq2O51NcLmGj 	 
    	  
    		   
     
     
 
  	
     mjro85ifA1yudJYFd2Osu 	 
    	  
    		   
     
     
 
  	 _3566717627060593117 mnp6FP5nP7SgmHKCvhR_Q 	 
    	  
    		true ml3n8i3pB9jBdCh42_Lbx 	 
    	  
    		   
     
 
     miXGg_BS1GNUOxSZTu1I6 	 
    	  
    		   
     
     
_4309197024622458338 meytvZM1QKJt2Sa4WLJu_ 	 
    	  
  true mvM0aoGrNshbuWATX6PLZ 	 
    	
    Feature2DSerializable mvSMwBt9CTrYq6YFHFK9I 	 FeatParams _10675870925382111478 mPW0V0WaOt7YxfieIiT4v 	 
    	  
    		   
   
    std mzsBxffeXrddOK9FeXKwx 	 
    	  
    		   
     
     
 
 shared_ptr mSmsDTx6VJgL2Fbqkp0NA 	 
aruco mK5CsFBtQZD6cP8kGtt1n 	 MarkerDetector mtizSayVGGPFYpTmwcjEz 	 
    	  
    		   
     
    _8000946946827829134 mc3qj_kENpq2O51NcLmGj 	 
    	  
    		   
     mBgK95MS0UiLVqEW0L5Qf 	 
    	  
    		   
     
     _12693418215446769236 mfHLeMsyely5Gx83Jcias 	 
    	 0  mYZFy6rS4QcR6IyRFGbcp 	 
 
     mi3ROSyYnIezAt0tumUrU 	 
    	  _13206983270957238750 mOMYgNnZWMDSDnYdT6q_H 	 
0 mzfR8L5gDNAEpcG521TmL 	 
    	
    ucoslam mK5CsFBtQZD6cP8kGtt1n 	Params _13116459431724108758 ml3n8i3pB9jBdCh42_Lbx 	 
    	  
    		   
    
 mczNMvNrF_ouK5Kt40KIQ 	 
    ml3n8i3pB9jBdCh42_Lbx 	 
    	  
    		   
   
 mFgWDhQLYwtW0poQ18ZdX 	 
    	  
    		   
     
     
 
  	 
#endif

#ifdef _7843067593709665284
#undef  mDm3IKGiPKlQH9eyaT16N 
#undef  mrNnhWbMAL0yJBb53lVUr 
#undef  mkRm0ZCZboNdxvQrqPcoe 
#undef  mYR63yInv7_kWsLeUUG2r 
#undef  mZBXBoFaSuMf3uTYMeVyC 
#undef  mpYoeKMm2usLCbYWeE9KN 
#undef  mdflGO3qRm5JTp7QUuQVo 
#undef  ms3YuqNkAS4Ob6jxeRCMI 
#undef  mS57pIyojvG6Rxw6E4bJf 
#undef  mjSTkXgp90SW5EUUlQrO3 
#undef  mhJc9R2ePZOC_hcciHuFN 
#undef  mWsmbql9zds_7emcciPbQ 
#undef  mbl7KuzNNsAeMjukrMWf8 
#undef  mmw9tM2BJvFkHbj2nRR_0 
#undef  mTEEPSOfPx2bNT0rQ0Ghu 
#undef  mxPqRrdn5p84O_ePtfbEN 
#undef mGpNSv6qtjKcDoBHRXx6VGAngwNP9y2
#undef  mKaXxcXXOeM3EFRHFOA6H 
#undef  mlfGf0AIHXuNzxZIYw_rT 
#undef  mJafDpoD1sw1HvQdWzAIG 
#undef  mbK9kusTLUAykQCocfCUK 
#undef  mvSMwBt9CTrYq6YFHFK9I 
#undef mb9mid3HbfubKVf1PEwxY3La2QjK4ta
#undef  mScr_8JY4Wl1nM2nHzX1v 
#undef mloG7lVr6x6THUHui9zTrcWvWGWm3wS
#undef  mwCAEf9o0eyrlKoJ__khw 
#undef  mf2DmqhN91_hxYrkrBOoZ 
#undef  metnSidECShcDB7fMba7p 
#undef  msUEq86XA_r6BY6t6AG9_ 
#undef  mp6mJm0SwrTnQ8W5vmSgB 
#undef  msqK27QE9Sb7dDU0tSxcR 
#undef  mv9S840CTSjOIbE3vh7fg 
#undef  mivqN9GGg78uutv1jCixs 
#undef  mDdv4cntHCVB8gXcybDgM 
#undef  mI8KmYSg83FC3c5M8hTZv 
#undef  mnRP_DWBrKP1_p8ekOdem 
#undef meLJOI7HgX5w8hFT8ddZEsuYBNcUX5z
#undef  mjXJRgpjq0nj8408BnRny 
#undef  mpM5YkPR3jsHRMGbLXc0d 
#undef  mUZCxQXQmCyvZWbzK09Of 
#undef  mB3j8oelVriDdVbUVUVRL 
#undef  mNSjcW7iTblACpQ3maAnI 
#undef  mdDpB6nj7kzPJxMeIpI5M 
#undef  mGp2qjNCCafzIIsGLtcnI 
#undef  muPkHitZtcuLPZu4xpxBe 
#undef  mJ6iYx79kyQvrGGdug3tL 
#undef  mWFuioe3GBSr9oIJfyUjF 
#undef  mdfxuir_eER1fhqyzY8uj 
#undef  mh6h9l8w7MLQWB0GKDcbt 
#undef  mOWRlZXbFEaADN9JS2Lan 
#undef  mxfALA44D7ZDHrJaYOTJX 
#undef  mJz3HTgXb0t_L3X02Qjox 
#undef  meytvZM1QKJt2Sa4WLJu_ 
#undef mu6wrrBUuxs0bJY5MQHkcEpVktnZnJ3
#undef  mAvjsNsuzNoad4VrLSNhZ 
#undef  mCDVBAGrqz6f_PtLvaADM 
#undef  mrfHVJw86v0KMYlOEw4NF 
#undef mKjc7UtpIzVI2We_H7nbZibmrjpPJ1h
#undef  mi80N1Jw6FFm8XYlNOtF7 
#undef  mWRD0bcXRDcHJI29PZ0do 
#undef  mPk7FrFSG0Bt87bT46qih 
#undef  mBT3fQR6mtit4P1dbe2z2 
#undef  mXYzN8rNVUQrE9RbuCkk3 
#undef  mIJkAYcsDlnp1FP_waLFI 
#undef  mIf0GYhq_A58_zQQnP3BL 
#undef mqLrUVJAhaaGHP_VDYSGuQ60Azx5PAj
#undef  mauEbOVWhE3MyiddLTZ5y 
#undef  mj6DS96SUxFvui6EQtWtu 
#undef mhHn8LxJUItCdbzq4uzcdBKJo1gQrDD
#undef  mHlPNt3_yhapqGlT6MDlW 
#undef  mUYIHckH642FlU8QOCiLS 
#undef me7GHe4ydXod7Tk4XH7TynmwA1BSclJ
#undef  mjKbHOZDpGGwQ4d9RU_Wk 
#undef  mrqDahCFxgLUYN9ozotiD 
#undef  mO1ADqstdeeUsfyWiQlG_ 
#undef  mfZP4mY1yulsUjWc229le 
#undef  mDZnYz5510zFVNkSFh1my 
#undef  myug8A9PSG9_K58fzSM4A 
#undef  mwtZm088j_ETtjh_Lsjcs 
#undef mWysTSaPW51ZM62Q3RUANzPoSfNP4xn
#undef  ml3n8i3pB9jBdCh42_Lbx 
#undef  mFbAVrlmDm96iXbQBjlbL 
#undef  mKgsKzDg1J3ftiBna9kW4 
#undef  mxvex38iS5OIKiXZ2qsMb 
#undef mlcNbC0Zn5AT6jTwdyMBZHtXhirEZai
#undef  mCWf8ey9Izw91hU2G_Qrt 
#undef  mobN_bCh8IojkujcnfvMQ 
#undef  mbHFwnjPGAj1Ad5CfPj5B 
#undef  mVShjW1LFaDgpJlcElzJ0 
#undef  mpGES5eRLLLqYa0cR4KTr 
#undef  mI9x1tVbS1Tc1HJAbYfBt 
#undef  mbfVOgGo7GnP9Eyg_Kjee 
#undef  mzsBxffeXrddOK9FeXKwx 
#undef  mAzduthvD_Jv93PFFx9tV 
#undef  mcLvaRDkJWFp70dfJR2dN 
#undef  mK5CsFBtQZD6cP8kGtt1n 
#undef  mzxnFNklHftcvPDhp16ZP 
#undef  mIgLIpX5FJ1Pr0pUKXNN9 
#undef  mkAfJ10sq73ofkrq0knoe 
#undef  misFQB4P3eMqgjOhLHOGM 
#undef  mbcL5Dc0V55K64qUxo03v 
#undef  m_unz1qRkP_i6tzvPIkvP 
#undef  mTzdBawaZPh31AJLiAyiI 
#undef mGeAcDUYoP3ZiH5f4hfIjUgcvND9HG7
#undef  mV3NYSXHD9bXUDzMQD3EQ 
#undef  mg3iysm_kMILavdIUb6iZ 
#undef  mbiOJPL0salxTy1ktLr9w 
#undef  mpqmTF7ZivMOsnTmsD82Q 
#undef  mVlb7CtyTEufwYbnJHVtD 
#undef  muUJHfiFTwjN0GjwzH8Zd 
#undef  msl8SJKeChU5HkW9cPMXu 
#undef  mzS2pIT1YYp5TGkDOsiKp 
#undef mMgbTsV3MGfUZxQdzhMdxw6t3uhqm4U
#undef  mT_ZOMvZPCXfMtWRmsVVr 
#undef  mRgjz09rTVhJeLHf3S_EA 
#undef  mDvfZAPi_9KbIGGJ6jLCr 
#undef  mbvbLQyMMpSMPHndA_3NT 
#undef mnID62rKQcfcp0IEktAfKevYVJgtqKw
#undef  mAn6WLWBD4aNl7j2s0Kqp 
#undef  mYof3zgmEOlVNQnzVaAQD 
#undef  mIuGPkMj9ht7uvabmIDsz 
#undef  mbZ8RFSjch3WG1k8W_057 
#undef  mziZCqmB_A1HfU2C1dSED 
#undef  ml2yUzasb_8SjuVQKMO3f 
#undef  mTXVDINPROouLSrBVPIv1 
#undef  muhR9IbYq04nNHgmmUFsT 
#undef  mFbX4V_4RDsCxgsT01jvH 
#undef  mOUA1oUtO8qveHnvTr7WZ 
#undef  mAxXgcvITONDKOTGuzG4Q 
#undef  mN4axtqxOsqT8LRc1FllK 
#undef  mC2U87XNwf9ZFXAKjANTz 
#undef  mPNxUzTrQnOVF5Ht129wz 
#undef  mfXm73LYzo3iJe5mBQfnR 
#undef  mqwaQVYqLMGMh9ydKQzV6 
#undef  mZIVaps5V9TNnrhyDxR0t 
#undef  mYrWTvZCR31v4GA12WEYL 
#undef  mirHzHI5pwbBDWi7ZMks4 
#undef mzazozMGwSuJCPqRJMiC41SROUCEk4p
#undef  mp66f6tdTOrQMxZizsMe1 
#undef  mtfhBGiR1RnP7oGhdvmLu 
#undef  msElmMNme9WTWKOiLVNm3 
#undef  mwIgCaQNFvoAfd0ysnhOe 
#undef meGeiKTwYsiX4Gk6lAfJOwaKDWWV9YP
#undef  mE0Gwj557sgWe8R_u9rVX 
#undef  mXbwtIkvOHICGbAwEcPb6 
#undef  mzSxiaLBkx4HaDhjZYaWu 
#undef  mH3QVan74lKZrUT6pDiCC 
#undef  mIWB3d9WRT1oBpLh4jTRb 
#undef  mW8KFFLIh8cQ2BOUGFByp 
#undef  mmQhYR0O8dG2ezP0nVrXG 
#undef  msZWGPF5QbGZtmxSxVwx9 
#undef  mCu9j2IaTpSbZHK8vHoQJ 
#undef  meqhbMgvR7bOHqPV0iRK_ 
#undef  mRTZ4ih46U4cY9_VxkuoG 
#undef  mLkAp_mqMekiT8_ivF3OX 
#undef  mBVFYqDOVz2v3E1eTb1Aw 
#undef  mll4jssxb27dgTVvjSKNS 
#undef  mSmsDTx6VJgL2Fbqkp0NA 
#undef  mmccuP57qkvWrwXk4u3Bq 
#undef  mIx8PCzucwnX49uy0KQtl 
#undef  mSAirV0ERbm_7Dht4Beu6 
#undef  mpskcvqthreJoxfm71x95 
#undef  mQJwXygdN98a8muLV5dQ2 
#undef mM0ClKE0ZWTim8NQpdFpNzxzA5eUUSz
#undef  mXuGAu8SG3M1edA9e_Ilm 
#undef  mdfac8rsKnfyUgR2Ft8Zf 
#undef  mxIUXDHpq9ZY_tmOYBKK7 
#undef  melPVeArVC4xeejec8j_2 
#undef  mRZRIgF5EHulTiCQ8Co20 
#undef  mSbBONEGEn8HPGFuzX2xH 
#undef  msR6M63o6FHwA1C_UzP5o 
#undef modbPf8l_cxlMLipkyynZj3SF_9AQcj
#undef mPjkCHzK5CpuULgO2Y3dNGgy0gjE8B6
#undef  mqxLHyOgfAd9AhB_49Rxw 
#undef mzxu0YaCrAAuNBGOMMsRBtO36XjkNwA
#undef  moVJy0OdbTsUYNNuxPhJS 
#undef  mqoWZTT_oZADMO_LPrSNq 
#undef  mNnib6VR7ygORjYjtyQtJ 
#undef  mp8m2cf8sf8PmTEDTKsFK 
#undef mfz8ejWk23fL0rXMJ17_iF3tq49PGsB
#undef mMHTsHydCVKMWjP1DoNGCkuwtso7JNY
#undef mgkty5C9Y91HsiFOB7vZntq_u_t0ZIL
#undef  mVdm7h371T273HDVOXgJM 
#undef mvxAVRxtyhzivBxjU_QMnENO6FebFla
#undef  mjWA02rPm7QZvt5TW_FG5 
#undef  mZGBokuovpRJ6m1PJGGhs 
#undef  mzRQg1rjMKY4ROLeiZYtj 
#undef mGAKlxzN1dfRR0ta1q5M1R5eY13O9ks
#undef m_yrai7SAyV9XzvSJ0wstMxebZiQ594
#undef  mzfR8L5gDNAEpcG521TmL 
#undef  mMMO4HjKC483luztYhrze 
#undef myycSeUNl2UaSztHLUlp4thuB3KFoS7
#undef  misbKJ09SZIWeoCAWH8B5 
#undef  mDlt10XoSR2fYKK3SFBVJ 
#undef  mHYor4xov_KdpFwYZPwUX 
#undef  mKxqvwLT5khvqhuX8xq1X 
#undef  my44voBcl5_OD8Agfdmzr 
#undef  mUCktCR2DmCnhlAo5aA_J 
#undef  mwa8BB4mNm8YNaQ9hOOgL 
#undef  mT53eVHZdoB7tltH_Y1EJ 
#undef mryAEIJFXOsqsVKwKQdyUL2Yutgg0sy
#undef  myKdwXxT0ZVAtn1AqDCev 
#undef  mK8LxYhCShw_ngEmQvnFJ 
#undef  mNmv9VnLRHqL8v_b0Vl6D 
#undef  mSx8ekPigzclzn_w8of5z 
#undef  mqjDf6TOSiymmowMHPwaX 
#undef  miftFIQtOKeYDNB6D2m2i 
#undef  mx1x4LSBxuEIBaLhtYB8X 
#undef  mi3ROSyYnIezAt0tumUrU 
#undef mb4duUSAe25FggcEEdSRAMuiSNaf28z
#undef mTTN40WmnSHBRIhV8_oD_NcWm0dC7zi
#undef  mcXpKydk0n62EjiEJXTe3 
#undef  mSAAMWYu0ZyVa7XXxg2rX 
#undef  mpYp1wggXv3dy9hKrzsZz 
#undef  mUprsvd1SnZ1z_VLihZPe 
#undef  mS4W7jBK7Pvm0zO29hcFJ 
#undef  m_SbjIOdih1Gt_BCpBG7_ 
#undef  mJK4akBnWEmD0mgPq0bTA 
#undef  mVaNNXCZ48LWCRY3Gz61K 
#undef  mYZFy6rS4QcR6IyRFGbcp 
#undef  mNDh9DhuucdKDZWDSVUdc 
#undef  mfHLeMsyely5Gx83Jcias 
#undef  mmP_PQ_VFHIilWChY46Hv 
#undef  mjRTMHBpWsxUWanFBFwXP 
#undef  mJdpZAmFBblZT5OvS_yFp 
#undef  mzb2yHwCLJkwrPubGvIU4 
#undef  mUdsYmKtgGHax_EEA1C3i 
#undef mLoACGmE1DdkB2YAtktxGvB_0sohSkW
#undef  mxxIM_AOB03IyZf8fYf6u 
#undef  mk8r1qJ3CfEvr7_FLoQjL 
#undef  mvM0aoGrNshbuWATX6PLZ 
#undef  mFOzsWZGt6AaG9PKaLyML 
#undef mW2I8gprowgNJRZhS9GSa57CM8DUKQY
#undef  msrhIJTdkmEYhV6_myMXD 
#undef  mKpo2Oc83bFa2HDVs7F__ 
#undef mNAoPkY24ogNpygmomXifiyTIeY3nhv
#undef  mAJ5DLtrFK1StZPGnRQBg 
#undef  mv5S4cXJP6mOgOw6j0kyb 
#undef  mC2cKdD22nTd9HMBA3roy 
#undef  m_pYqvRbL5njqMxbe_ULn 
#undef mS8WaEGrZ0Qs0BsDm_JbRzNR0tSonbX
#undef  mS2GM0_q5QSTd0xiU1OL9 
#undef mcJWcZxVTqBKmmE2VsHWGk4lVlsrNkQ
#undef  mbjwGYWmybnr0DNXmMUXO 
#undef  ma7exivcDMvVahmow8Wy9 
#undef  mOMYgNnZWMDSDnYdT6q_H 
#undef  m_Jw5xx94imNYGW_pgZ66 
#undef  mcMwSQ4Nrn_S8nH7ffWbh 
#undef  mdh7EV17fjpHLCnqRbpqI 
#undef mybqFwvm_stxorYCR11OOdi0P7TM2hb
#undef  mADyV0NG_hhLEeuNJuKLS 
#undef mLJYxMggwZJzgkXuYmj1acSKRoHly7S
#undef  mXkUwKFbDa_e3TRiybkYo 
#undef mdLI_Luo1afLbMIrUTZ_ioQYFK0mOvN
#undef  mRroqIukYBuwRbyovvBhh 
#undef  mB3a_Fl25Zzhmgqx0DFxZ 
#undef mYz34v14gNqWTNOc3JEJeTrSQVXsdkg
#undef  mHlSYNykE6Qr6Ws7d8iK4 
#undef m_ZVXJdDtztbhtyhYtdmrbc8T7f2nbr
#undef  mZASZ3pzj43HOXqJe3HjJ 
#undef  mlbyD1tzFC7tNI73Qw25t 
#undef mw_R_htyaKSawpTt_nyN34gwSIKFwim
#undef  mTrXDcVbxxIBGIi4oU5w1 
#undef  mHZOeDhUUlrNZH2YDjwpC 
#undef  mPW0V0WaOt7YxfieIiT4v 
#undef  mnvCKsDZ686eW04ktcmm2 
#undef  mMXoXfQeNjkwLRmCr0RxS 
#undef  mqvC4XCVRV7Eh_6QGsINv 
#undef  mnP7ecWfR0kMBwxv2YuIf 
#undef  mc_OdScVk_rhzsDkwoGLb 
#undef  mE8_0t8MK7yew7qGDcVNN 
#undef  mRUr_etSUlVmt81YhAOZN 
#undef  mChvkPk4wOCmAwQSrHHGS 
#undef  mvWPUxuxbWIbPmfk8o8Qp 
#undef  mPdKcOY3C6UNNZ5vIa3yJ 
#undef mcDAG38cOOQbRBUgl7ybAmyqLXXrtOi
#undef mPdT36hfVREF2V6Z6l8Vj_KGZsxwYDo
#undef  mjKkbwMbQhMiG1aJI2I7x 
#undef  mrRKpGaeX4CBEMISMteon 
#undef  mtOo6d8Zqk2WsTdxUqQyX 
#undef  mc9YtBgh0ZdndpFyuVO6d 
#undef  mKfxpNufjYfbhifc_RwKc 
#undef mcpXeRk8MTFTQvkDX6Lc1n1O6vKrbhb
#undef  mUMmK9fRoAciuN43ywQh3 
#undef  mMC_Jjv_5DlpMspwpJcsm 
#undef mWDZMZ1KDAWIS3QvjrEl7eTLzbo2gww
#undef  mHTIW32Ks8MB6kqtLYp8D 
#undef  mz_nz53s19mVuvlj8Bz9O 
#undef  mVdkbmmYutm_WgDo67CRm 
#undef  miE20IiuNmdb2GTHBXWY1 
#undef  mxcWhEYxwtVbYdB6RLHuz 
#undef mPFBAGubWdTszeNfMLi4W5QSKthD4xt
#undef  mwOVOny7gqfvUOC7o9X8Z 
#undef  mdUz9Gyy9f9VvOlZp4e08 
#undef  mZ0rO2PMLgTdHhr8NQJ6W 
#undef  mVTEn8GD9VMuI1vHcgQ_m 
#undef  mZwNGIpZdxvUnp2MM94H_ 
#undef  mLuilZQphN1e6uPrcVR4_ 
#undef  mYLJIFBXE8E1VUYKAJAkM 
#undef  mu9surkR0rzKsmiJpopRn 
#undef mz1XpIzVxf85bp7VSu491XiyWGYK1Le
#undef  mL4dhXfjGazwM5OdBOZQX 
#undef  mtizSayVGGPFYpTmwcjEz 
#undef  mbtoRHAe_W6JhuGU83bXu 
#undef  mEHloSKK7WE5StNtuFzxh 
#undef mT6FVggaQeOcFOV_GIDf6y1u_E7WOqe
#undef  mNS8CwpKqN7XhL3OuE2eA 
#undef moA8VghehqaVpoXQAZdpVKczKJ9WCTX
#undef  mimZGWdoZhE7GzcMEjNEZ 
#undef  mwFnwk_57M7ZxnlKE8uak 
#undef  mvRYTuKLNoB0Kz5B1Tqu2 
#undef  mySIdJB4tJejLndYpQUDP 
#undef mVfeVNXMrmOPwRTi2EBCuckoATRS987
#undef  miXGg_BS1GNUOxSZTu1I6 
#undef  mK8s6M73UzXaQY_l03t7m 
#undef  mswHcrwPZmVV7qEh2fpXB 
#undef  mBgK95MS0UiLVqEW0L5Qf 
#undef  ma7QFN6F74sIo8DfCFx5g 
#undef mbKIxMRUNbJGkfj6Bw2oy0bjVav__yJ
#undef  mtXCvmyND73Z4jhSAsrl3 
#undef mrl6B8jCBWc8M48_UYaxixYCRghxYTr
#undef  mMuSVOVeZT8LDORCtutkF 
#undef mRiIgUIu8k1v3YUzQcHTbtxqqZ5gOhH
#undef  ms5JsMvYntJiGrpy5HsYd 
#undef mQpU_edSBkF6r7FxC3l5GlQomXUyhsf
#undef  mqwkIpFXtv88x1mdX5klJ 
#undef  mthZBBlRe4mWFqORrz8uk 
#undef  mf4mthcilAxYcS_uXE3hd 
#undef  mczNMvNrF_ouK5Kt40KIQ 
#undef mJnEornm9htjmBxV8hRo5mlLdJ2O7mG
#undef  mTP0r9l9C1YQ4LSm6BfqD 
#undef  mnp6FP5nP7SgmHKCvhR_Q 
#undef  mHVlHdS3e1WMEsd9PWsd4 
#undef  mmrPLtXwwwYKO7hwiCAiw 
#undef  mPF42eNUygPTcFvVf9uam 
#undef  mCDc7XI3__JhdWUPFx8Vc 
#undef  mv44M8LMZBDQdVNstpMs6 
#undef  mvmjfLmSJY9bRXowjb8KA 
#undef  mR8Wucy41RxWH67A0kGiy 
#undef  mTAP9LFMWvHZIQHllI2GP 
#undef  maGTrWUPWjh60yqTi_Axe 
#undef  mNSyKlY1OLpxI58STAPVs 
#undef msliyks9yp8iAavW3hPBPsnXr9oqwYk
#undef  mb1l8IcWnFnKGpGlxMKRh 
#undef  mDU0IwpsEjbfYZOhyhTEm 
#undef  mJ8saghr6lbZtfOlVD_aj 
#undef  mhumxDZMVJ2JSSXoXovag 
#undef  mjtmI4iyWgO1_8vkIZ4iF 
#undef  mfEgXFAXdHJMIz0B8yDNl 
#undef  mLFYAC7eEE2IToT_uHOvu 
#undef  mM38EeL_dg1sBZmW_8iwh 
#undef  mEiWR4KgD5KyJ2JhPctS4 
#undef mpUw7MUhMh0uogQRh9xRsVg3P8MG27n
#undef  mCjEvaGeL2GlYH_JjCfUQ 
#undef  mh80H1iPhOAPoxUP54Go7 
#undef  mc4sFptKgz6Blb09hl0bU 
#undef  mSEcMChUccQwA3Bbr3SRX 
#undef  mKSICpW8vuO3y2MZszOf2 
#undef mYuqqUJTXHdB8NmSJW_fgbcetompD1F
#undef  mHoGE24WGZCHr2m4aIOYn 
#undef  mF5RlLb6BEJo7uQwtI8Id 
#undef  mxsc3TsxoTYmFVfeJhB30 
#undef  mGjOwpLsjbqcqSbirDwWW 
#undef  me6PYmh_pLOff4WWxiOIk 
#undef  mI2cyfLEXbawaPMezT_BS 
#undef  mLsLfSfgQfiXNEUNiPQdt 
#undef  mOv1BXKtkMtwYf8qiTEg7 
#undef mWpNOhtVjOagwdHnEqz_pZBvkkiCxZi
#undef  mN0vG8bvdCczTVNUQdrMY 
#undef  msUXfQEsZvo6MzqnVaJKe 
#undef  mRABFyZjVjDixHw5H1MRw 
#undef  mvRm5XV7HRh3vjPj8hxtO 
#undef  mjro85ifA1yudJYFd2Osu 
#undef mGEt5TRwydpdaNpgZWWwwn96FfNYmss
#undef mEgogoNVf3v8CZpseAB6nJg22S1zZmg
#undef  mj07x5HWiBpHUi6Wui23U 
#undef  mhPLkFEXd7cU9VUTqbIul 
#undef mKUuiOuOFf32dmQwO2ghDHBppqcDk81
#undef  mU6DrvKeNIs2fWOr5JPK9 
#undef mClMCWhD6KVgcjiALySFSseGkr6dD3Q
#undef  mwuELI9ZKmi3M5ZvKGwMo 
#undef  mMLeN3dynBmfnN0VN2yr4 
#undef  mhX0jhMoontxXjVeRoNFO 
#undef  mxenfN37DkisESfEoGDWg 
#undef  mClGvs33HtR9SDiPJnRIm 
#undef  mKurUdCU0fk6E0L1X6fa4 
#undef  mVs5ACgUB2p31u162MtOo 
#undef  mbyLqb1P9w6PQCZ1mI89v 
#undef  mfakJO1bstnXjoaYDBvOs 
#undef  mBAGDHecal9Ub1CUbZaIz 
#undef  mgUuzk9C3KVfB_MLLtaex 
#undef  mkImRLVH5_F1TZyUwZ3OR 
#undef mX6PEBA63VRK09B09dUBJ2uazHomUWr
#undef  mXbPa6D12koFrpXuXxbx5 
#undef  mZ6XvMY3pM2oFsGr4lskT 
#undef  mvld0BwNYy0SIK1HsTPxv 
#undef  mRyrz7Lx6P46lCFkVeo2x 
#undef mV5jWO4jYaq0xrRTL06D0BMuXfgwfyK
#undef  mxLPvxBEA2DoJx5pLIDln 
#undef  mMYIdWbegzKp0WfXd4OfQ 
#undef  mpMevd9Uiq3eXEARRq7Y8 
#undef  mah7aYn9AUfSf52iv_R03 
#undef  mCiLDfbLLxJiEEzJNN26O 
#undef  mbt1RA8AWJ04HIrd7l1FH 
#undef  mODV9iQsaC951hgez8XSQ 
#undef  mIYPy6lUjb6rbsa5XzeW3 
#undef mXirATZHOeA_kQvjcuZu7hB13N2V0C2
#undef  mpIqyDA89k7Oc7PxnefkF 
#undef  mMdGMVINdENVHxHpI3vYw 
#undef  mPUloaK6xtuNjpbaHgWRK 
#undef mKlAyAVgLfKqs6dMZmVFVAaLL_8VJt0
#undef  mLtPirVzbHf2vwwQuKys5 
#undef mbOdHW4fnt2HcSWAFOKPEDMGoJjOPbK
#undef  moiAOZfXpfyLmHfPB4Lon 
#undef mWCDDZXzLUqCb7bkeRuC87IfMDMXzZd
#undef  mc3qj_kENpq2O51NcLmGj 
#undef  mvcP35u1JA7WGIvMQHL9L 
#undef  mmnTmTlSRzoSfWSG9_Nn1 
#undef  mqEVaWmdpsYX8ECMUICjt 
#undef  mkgatJfG1B81eCsEcIO1O 
#undef  mgXld8frtOtWQDMudvw03 
#undef  mnYx7cn2M22BA1LnrqK3L 
#undef  mvwO48Hx1_ATyLQy0WLcx 
#undef  mSiGngSk6RbUQ_ZSdQfYY 
#undef  mUkplZewgV1st4DP2jQ08 
#undef  mhF3fyiak1UoyOhTDFUJK 
#undef  mNqDIMIk7DHoC8Jeqr3YF 
#undef  mkYGGpVld4zcK1H1H28To 
#undef  mrW1yb4ywftz9Hl19nrsy 
#undef  mhmxWYZZ6vXeciwXm0qtB 
#undef  miPSh2aH2dUUzoirsQa9Z 
#undef  muKze5ydpSxhIhYGk7ple 
#undef  mtrzZBfGj2uJlrQ9u0Ilv 
#undef  muSwyWAxcAG9WH1bFtMac 
#undef  mZ2jWx7oh0Dv_bW21am8o 
#undef mVyqcBYrp8uoV9PDjWTItmZxUG5q5mX
#undef  mMxGOgWhjQ2yrZAdqG_Ft 
#undef  mYSeUPt6nSBgihquz2hJw 
#undef  mt_wrMR8aA1zorIzavEZT 
#undef  mYU09yeabA8iw3gZDP634 
#undef  mhv0OJbk3sSUxi5ieYsJU 
#undef  mpbpPqTwANraPtSIcXTh9 
#undef  mBdc_4xrhleDypTTmKQKa 
#undef  mIGuKXCX8pOD0SmVQ8644 
#undef  mqeze8eIhcJFwXpE81isv 
#undef  mFNGosFWJbVzTP85KAtIX 
#undef  mMUqBUYMAVEfQtAnPn_LQ 
#undef  mKgLfbnWjJ3pKomnVjtCz 
#undef  mFtYnSaIEhWdd82Kzrfle 
#undef mbY4P9dd3fcr7gyfsdme8ULjS_FlWoC
#undef medF4XaT68U1TN9ef1v06DGRrWd7JU4
#undef  mSgEajsdKbuaiMSZyOsoS 
#undef mO9XTjhg3cZKfnn4amRi5fySmVeY624
#undef  mXtT5KO8QH1FTkPfRIZ1w 
#undef  mq7viJxVMdcBGKm06Ivy5 
#undef mByy67jxaShsJThnKTR2VBb7mnCF0r6
#undef  mSmXER4IYKBGzMlhw3SvL 
#undef  mZNuOHeyOx9WgYWxpBYym 
#undef  mRDKYqm7sx3xeBfexXFbK 
#undef mXf19ZXf6z7ippaosPLCcMuCiWtSAzZ
#undef  mBrhLQBFQSLppFvFBNqdE 
#undef  mhDvAPV1IAecsrypFnfo0 
#undef  mgvwR7KHqg7osY42u7xOT 
#undef  mqdcpMWmlN5IIXLVC9PO2 
#undef  mXngFVa3kwewf5KlFRpga 
#undef  muEHrzYksZWkjlPzG7fLz 
#undef  mijy6ZtFDUVT3ywaNYcsc 
#undef  mQMK_weXYf8Gg31CIEVpY 
#undef mJt_atx_lUg1wnhH436dT9oOjLUgTV8
#undef  mPvZpvL72V17g0ZY4GnbS 
#undef  mc145dtNd8ENwKU4BbbuH 
#undef  mTBf1oFAVFDQivKrtAGIf 
#undef  mBd07NVm9WkRAYIqSBH4p 
#undef  mmxs_M33hrr5NqohE99r2 
#undef  mNAD5qElfnwRO5V3swkF_ 
#undef  mhsqxMF3TK6AhE5W6RkuW 
#undef  mjiaVNUYpPu27v071isSQ 
#undef  mCqWPaN_K72QQZPAr2Tup 
#undef  mNru266YbdYhnab94ShYY 
#undef  mmRvqZprsYnnqQ9UgeXy0 
#undef  mJaddNhDYfWzqCP8RJwyQ 
#undef  miPHiVDt1HIWf7unPSYBU 
#undef  mw3udxpQRet78OUq8pUyD 
#undef  mYAqz3yDOwrT6DP43Mbva 
#undef mmyMbeM1Q1v1YCdwsw4VrXi7h8JuhIw
#undef  mZ49bGbu9rE6BKxffEODb 
#undef  mKwElinJ5emUqW3fi49xC 
#undef mc9PM5i50qK_vWkuobFOc2huIc_HpJP
#undef  mjfJya0RtMs9NMmXRYyED 
#undef mAH_0HZSOXSOH5z8WNKkxGtvkzPSa98
#undef  mHQykm7WwpKUodroyngRD 
#undef  mmoFVblAKs9Tfpzny_lUJ 
#undef  mRaN47LBoHuQndebyY13f 
#undef  mSdUsC90bhOS5QOrzfHT5 
#undef  mi4jacVbSPo11EdiJiyEK 
#undef  mGfu9nZWBFs6xoUpv8eUA 
#undef  mzy6bDMyPTDIxNfNPZT05 
#undef  mG5mF0mi_oONOv2eUzYLU 
#undef  mYIIju_V_WKlC5oMA8MxY 
#undef  mUW7vbCHB5qe3t1_7Glmi 
#undef mM40WYfTE6YxqkAjuzmOeOg1sLtwmNT
#undef  mXXEeR7yYOZevJM4hv43k 
#undef  myQF_h9zzCNwLu6xfnhq6 
#undef  mmJdjyYHB9aAvA6KoDo1S 
#undef mkdrdjrDJb3quxTkzmg_eZhPFf12IC9
#undef  mEsRHs2i4HKWq6GruJOUE 
#undef mnTfGdsdgAUDewuGlVwVlnfj0VD5gj6
#undef mh1d9DrxpIRxkD8q0yfkhyGnM5yWozy
#undef  mqIGJGqCVPgWxxj3Y_JG6 
#undef  mNSslMRSBQ4r4Wbm5W14S 
#undef  mE38Oq3VL1fJ0GUswAebH 
#undef  mlZc9D7DysVVO7aYhs30S 
#undef mUlvUgXM19DoWwwVfwIuc3_vLn4ainn
#undef  mjtQFNYdbH7ILLTPqO_6U 
#undef  mAahCNRhbJ9K7gAbilQcg 
#undef mtmD3lZYb_Gu_7mEP1aib4ziGDxxfF3
#undef  mYl4MBDF1_JFNsvWGvHlW 
#undef  mUN4KW_X0zOmmnyy87rRY 
#undef  mP2zcYcfxG5LPRzw7OKxm 
#undef  mOSA179Adda7Al4xMBvZz 
#undef  mNGDLLEiEdU6l6wR0Iv7H 
#undef  mjskGhbPys3znx8ohhpol 
#undef  mAPHIWqG8KIyPBzAOzqDT 
#undef  ms82q4BeiIdEROv4R1WMm 
#undef  mgJlRDOK7PN2s9y9ofemf 
#undef  mB0SH1azerGYYDrJ5A23M 
#undef  mLCwp82CRyzunhp6opa1o 
#undef  myifux10NRPQJphBtPHAk 
#undef mJYQ2V8runtqekLZKRxtRfrKTXGSosI
#undef  mFsL2LkgC6E9m26FY8rc4 
#undef mbaw1uaAWdzEvPVvXYvMjSiVD0AOo7b
#undef  msanIPPwavHbpt3O7QIb1 
#undef  mJft7epryDvCsSeZ1nymh 
#undef  mZoQDBK9vIP2hDxdqpA6s 
#undef  mss_Ro6jefLI9lwP9tbbb 
#undef  mntPcsG5ptVB5vQBK66S3 
#undef  mmFSpXzjVoDSld8kFRqaS 
#undef  mH1C295IyUacmxVPN5Tmp 
#undef mCWd4y7Gi6rQEzxSB89DC7_bSVqDyot
#undef mmxqmWLHQtwfQxKy29ier3THb5Vsw35
#undef  mafhFTdbpUPWPVZo43ucJ 
#undef  mVoYS9h9dE4Ms4NzyiKN3 
#undef  mzRttPsCqlyQ4wnoFrIWY 
#undef  mI4SC_4eAQxV6epEO0pV5 
#undef  mZO0JZRl3cjiWDsgm5OVX 
#undef  mubwUw6dJ1AypbSEuY6KI 
#undef  mLUJ49HNtw1sAzHtW8F_Q 
#undef  mvNovGu6V16d03JNueGOd 
#undef mmT3Mncp4X0CzSLpgam1C9RV2fdC3j7
#undef  mhXpF6s5zEgPZgd38a1Qe 
#undef  msKVax6Ey3FJxMZvtfbeg 
#undef  mMFlHYA7tInoXw97xyuHy 
#undef  mgo9DL4nGBlyCG7KoVFSd 
#undef  mNRpKLmaTKBHDW3f6a_4C 
#undef mz3pinu8xTWy4Xa1YhZ8F7S2xw7PIaA
#undef  mQc3jTs74gmlo2nIZhfnn 
#undef  mAZltqLQI2aI_C_9z2COK 
#undef  mBnlimOcMtttKAB1pfuQA 
#undef  mhI4tgvvGO3owwku9EK_f 
#undef  mAoBH0hhHbhRt9IyLwStE 
#undef  mzlb1pNd09wnvHqbI0_13 
#undef mzz5441oXHeL3YKYtSWVPxoD_u2rNpA
#undef  mIamk0p4Zav2JUE7GO7PP 
#undef  maOPL_xI9FaWWmxHgmQwE 
#undef mAVZSsbaCqlS5L7zVvNeHg9gt6K78kW
#undef  md0OZEwi4YofGotGtNTdI 
#undef  mnZPqKnFD1LuZoi5yAY3R 
#undef  mkhR1nFUrAUwQ6kBZttfc 
#undef mukmkAKLvUgWsEw5KanuTTPD3E5YLoh
#undef  mVN6PcFPK5Lb3XLxcPcRF 
#undef  mVTs8Rphl4yYdgrQUiuuZ 
#undef  mVW1EDWov604VPwmYZPtS 
#undef  mhqupnJU4myd2k2OEKSCa 
#undef  mg31NtOh67SUJaILnt0Eu 
#undef  mEhQx298_sPoXh3cUDtAg 
#undef  mWINSmg_939umPKISHH6m 
#undef  mj06PLvb8y2Xgwtg6u3Nb 
#undef mn_4S2ljijVENFuMmLGQR2YToS4cmzK
#undef  mNyS5gnb2ZgYWBRo4rtYu 
#undef  mVU_W1gM3fqsJqBqDEmrx 
#undef  mSazLeSbqwteKbYykT6Qd 
#undef  mtauobhKRCbBYVNU4AA_V 
#undef  mBrU0BNZMbxQyPCS7uFHB 
#undef  mhhdAKxcs2afanmxNRNTd 
#undef  mZ5ojunUbEiUrz6pUhj8z 
#undef  mzpR22f_6L2eFpZSOwyjy 
#undef  mse0lbKf3CsjMx638ZevW 
#undef  mtzPVsIpQTEpiRcRoLGBN 
#undef mxNiyCPqnZhOC6J3rQETj2IATMIT7v2
#undef  maoyI7l6xBuSTgackqq51 
#undef  mzSgA62kh9X60P2ZbU_ZB 
#undef  mc4FLNVVF3DcD92oc2XM_ 
#undef  mFMcycwl1g4Hbye5O7zS1 
#undef  mXqQF3DSILQVibYLos_SE 
#undef  meH3hhFn8BlsY5sTlN1OU 
#undef  mPQowycrYI4w5Ux6AxEWz 
#undef  mkrhxE0EVg6MgoIqsmWrU 
#undef  mpQS0nDsmQlwQ2e3f2bjF 
#undef  mwtLcFS2W12CdvL0fuaVI 
#undef  mpckBDZDg0lImhP8_RoIV 
#undef  msQAJ7G3bgfXRjghTZhcE 
#undef  mpXh8kKWTQhdfix7H2e0m 
#undef  mOu8sL_sSsaWDMcd6PkWs 
#undef  mwdapUfz9Z5oNqhjHK2tL 
#undef  mXAH6nmZ3oPLhB459vQkd 
#undef  mPJhKjWhkbCeyYutfZQVH 
#undef  m_dWA7IZyheolQmKBoBhq 
#undef  mvZzhb1BoYYsM5Y7OSBbt 
#undef mPfnwggwbOzHSfHtQ9LsmiZYVFf4qPW
#undef  maj3we4UWM8nMwoFsjfAv 
#undef  mEOu6rTgPmdyQzJqnuPKN 
#undef  mZzVMA7tYTN64yzS36Gm2 
#undef  mHTZr4kp86HqcZrdjm5Yp 
#undef  mfpyguvWp6A2U0sOKSKHv 
#undef mlmaeF1P55sMFHW178GrU_0mqWr8LLy
#undef  mIQAg830_BxTPzZ_16rHn 
#undef  mk3ytf3ehHx6gfVoyMNqo 
#undef  mFgWDhQLYwtW0poQ18ZdX 
#undef  mbRr1ZrlPJB3F3ztvLYCP 
#undef  mWonCYxbBj2q46DtlNt0D 
#undef  mTghwCVMfjk0zWe_h92M8 
#undef  mbg3j5ZeW4SRY_dJPpK9f 
#undef  mN1KEP0eoeY3oenXrGS5k 
#undef mOTZPAjzEI7wD6T3bwxkJiMGsx8uAz5
#undef  mLrfJgrXQgUiXh5XPhuZN 
#undef mRfitOutUGZGSjoiLJJkYDKqa4u2CyQ
#undef  mrWeWZl5Bfa8nrcOoG8ng 
#undef  mGeC741PMGs0tF97WkQxi 
#undef  megJi1ku3xLobZLCSTUBy 
#undef  mh3HvtXhYJiBydCSFsJPL 
#endif
