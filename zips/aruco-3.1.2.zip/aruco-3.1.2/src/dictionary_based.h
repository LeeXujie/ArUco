#ifndef _6580636470966009790
#define  mzrwOkaVNQ12qikoacOtS  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(z,L,-,F,*,*,d,3,Q,F,U,c,K,m,<,},],Y,g,-)
#define  mLq0l_9mYawwF56GLqBiO  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(e,5,;,J,J,V,:,[,+,p,O,7,j,;,m,O,t,},;,.)
#define  mNrsNMyOlNPO0p0HXQMMP  miuYLrMna9tTpfuHozSxZXljtr8IWGY(l,-,H,},},:,i,>,*,u,v,I,-,2,Q,*,],A,G,T)
#define  mrWabZl6Yqxhh9lJh_vp9  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(E,],[,C,-,l,e,B,/,^,],],P,v,i,p,R,8,[,B)
#define  m_TFPk3Phi8ZX86zM0rxV  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(I,5,;,k,;,F,f,T,z,:,},:,{,F,O,4,O,],O,u)
#define  mX2uK3ci5pcPqQSvs4amk  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(M,_,6,],m,O,7,S,O,+,[,_,J,K,7,G,0,k,j,V)
#define  mJZTaq8b9U6IHm6Fo0zfj  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(6,:,j,.,:,W,*,M,K,B,!,K,M,5,!,U,/,9,:,G)
#define  mpmCfg6OTFu9ueV1Jvoij  mUsuCEIFvRP_D44KPaQY47o4ispy8Vj(k,j,f,+,i,/,4,^,5,n,o,t,{,4,;,h,-,v,9,b)
#define  mnW6ZFYawWAWMCKpMfvE2  mahSq6rrq2neTeBW0KH49DPaFsniYhL(:,k,W,n,i,J,I,!,x,p,f,Z,!,y,_,W,.,2,I,1)
#define  mTvuqEbq8QyE7GGDRvvUi  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(i,s,R,Z,W,!,[,],1,9,!,W,[,4,},.,g,5,W,r)
#define  m_Tae7Y9Y2VD1QQBLzq4Y  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(q,i,o,1,Y,p,A,n,[,5,5,>,{,w,R,3,1,D,],])
#define  mEn6ezpXymeCgJNVz3lrW  mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df(8,x,Z,8,q,!,d,t,u,+,3,e,0,9,n,r,U,g,s,r)
#define  mGQ4ZN1hA5s9kbimw7Qwy  miuYLrMna9tTpfuHozSxZXljtr8IWGY(E,|,5,F,r,G,h,|,C,.,;,/,E,1,M,.,-,y,9,b)
#define  mARbu_1sRtfpk1suZIE5h  mQk_FiTqfT2quOMiM0cIKgE508p48JO(4,1,m,=,_,A,/,:,c,Z,;,f,y,{,F,o,e,L,+,l)
#define  mpwGO7r6CJmc7pyzxPS0W  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(Y,V,+,2,g,e,J,!,O,A,z,J,g,u,+,F,M,+,f,U)
#define  mGHOYAWjopscrujOCjpSi  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(E,H,8,},p,n,l,o,/,b,-,S,^,{,6,F,o,.,c,;)
#define  mYg2fb_0h62GR73b_cpn9  miuYLrMna9tTpfuHozSxZXljtr8IWGY(/,<,!,X,+,C,G,=,*,^,!,x,},D,S,/,c,s,],p)
#define  mi6HZqmh8GILM6LjanUt5  ()
#define mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(mgw0B,g3c8T,r3SnZ,fE5q5,hz6ib,e1x82,DaAlj,a8hNv,XCWP3,rXZaD,CSBoZ,Chn6S,kNePl,l7m8X,G_LJY,aP0cD,A7IfE,sx7pM,J0z8A,AuVJB)  kNePl##CSBoZ
#define miuYLrMna9tTpfuHozSxZXljtr8IWGY(PuL4N,wmcgM,yYyC_,DYsKr,n2Vit,Fmyxs,L37nk,rhzou,foYA8,cMRr4,Hg5vb,Sl_LW,pLQo9,dS8Ke,f_eDs,jpMdi,xvkYG,a3ais,FeBAz,tjp5v)  wmcgM##rhzou
#define mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(aQQmF,xpwOI,iD1rA,CkzXS,Qb8ut,oJ5B3,GcAs0,E5idv,wjb5G,bec4W,VHnoT,qPRJF,ZtXSW,yb9tf,Nb1We,xMolA,bGd0a,VKlyl,K4pYx,lt5vN)  E5idv##xpwOI
#define muUdW3fqjYEcWW8jBykcma1JP8mjRxV(veOup,IqzeF,L_8Ns,IOKLa,dvT_I,sCW27,OwBfa,MVQpr,JAeaW,dq7Eo,qSedT,f9g9n,tRlzG,RWlt6,es5D6,yELGq,Hoxiz,rV9hT,Niv3b,ahuQt)  IqzeF##Niv3b
#define muyLCpzNWkiG62Rh8y6QK2T12sisiZy(fzku2,clxwN,jWAdS,lFUGX,QHbpC,Aa4jS,m9r25,cWif7,aMN0b,o0ATq,VmzcT,vZaYa,M48Ti,EFczG,L8C2d,nClNq,pXlO5,opR9G,psO_r,PjnKk)  o0ATq##vZaYa
#define mUbpV4lfDef5exLGNpWAnT12YiDu_kX(Xu20j,gFl5U,XxZFv,sEg5E,CyZgX,gJPQI,KgKAk,NrmZ4,Pjvtp,Co57S,IrvzF,HftOo,aoSzL,WYEYP,Q_ql5,Ef8Ge,pi2K6,AKdMH,rxX6T,y8v_u)  aoSzL##gFl5U
#define mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(Y85fC,QOTyT,WpNIc,MNNUR,lfmAP,JZRZD,rY1qX,aQIIi,WAHWf,XqMB0,CUIx1,DO0ZD,vAyLR,RcrX6,KWKXj,pDpY8,MhE2G,QKZXe,rub2P,fcFs7)  JZRZD##MNNUR
#define mahSq6rrq2neTeBW0KH49DPaFsniYhL(gwCpP,eR9Tc,BDNPj,ECE8f,yj2_r,kKpi8,esfQJ,zkUV7,WLO2V,D2lT2,AYwAF,sWv0w,S2xkW,jKOIO,onv6E,jbVem,L8Fa9,IPDk9,k539P,olDwq)  yj2_r##AYwAF
#define mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(U2OB7,iwHoa,HkFS5,IFjuo,KZiKH,hd4en,Nq6Ac,P3QCV,M_kUu,Qg680,TGyGw,wpZXy,buEf4,poitI,VjIVs,S3XpJ,ykG8F,MU6Z7,bH008,FX0v3)  VjIVs##MU6Z7
#define mQk_FiTqfT2quOMiM0cIKgE508p48JO(relEo,PWBSI,NwAcI,txND0,IoPEv,ybfoq,PF0wi,BNCJ_,jhSyv,JFExU,YXkeJ,r3o8_,G6qcP,p1WZ_,QVfES,NPf64,rB0SI,Xg5oJ,NQV9y,xyzEA)  PF0wi##txND0
#define  mhdOIl9dw0JQwDi0Ir2lO  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(9,a,!,z,b,L,m,n,P,<,.,<,P,j,*,+,8,z,S,R)
#define  mS3cOaukxo2FRb5RvHVc4  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(R,*,:,=,^,=,q,e,!,Y,J,6,N,Z,7,j,_,8,Z,b)
#define  mBbED78xkAlNEldBsfZoY  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(v,>,!,*,F,u,],M,{,N,X,8,-,1,7,B,/,s,l,!)
#define  mmDRiATwYsXZG1Jku9FPg  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(-,],c,],p,v,d,i,y,v,],.,X,M,v,Y,o,^,6,c)
#define  mPBi7A48_1c_87b1U_Eoa  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(.,:,E,1,!,f,m,v,_,G,.,;,:,_,Q,c,h,H,W,6)
#define  mhOJP7GTKtZVREYuK8qsM  mahSq6rrq2neTeBW0KH49DPaFsniYhL(h,T,z,k,>,^,!,g,*,L,>,S,],8,;,Z,U,l,o,Y)
#define  mzuL30IhryR3NJMszS89h  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(Y,K,P,+,:,9,!,[,-,{,&,y,&,y,V,W,-,4,a,i)
#define  mUCUowYS5Zgxsf8jGgVp5  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(^,+,1,F,[,0,l,x,6,g,],Q,R,/,R,O,R,S,=,3)
#define  mBx7lmwJEgh_boAo7hHD4  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(.,=,-,},H,n,N,{,f,-,d,/,/,:,F,T,M,;,},Z)
#define  mxODpvgncxHDxAXg0nTxi  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(^,k,J,U,},t,3,Y,!,.,P,u,g,;,+,0,+,=,-,M)
#define  mPwyvAQ1wHSSp7FJdoENV  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(^,+,X,P,e,O,},d,3,*,],6,+,f,r,U,+,v,X,Y)
#define  ma9kV7iftDKaJMwPMmic6  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(a,3,:,Y,f,B,g,=,W,4,},.,{,Y,{,;,},*,a,H)
#define  mJFezRZdF9Yll4E2ofN_f  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(:,m,-,T,T,Y,+,d,i,O,6,o,B,F,l,b,P,g,{,o)
#define  mBY9q0vKK0__eH5VQs9_L  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(b,o,;,],q,8,1,~,/,H,-,P,X,/,I,U,j,z,d,-)
#define  mjtgzOH8_fFDjnCUIvpJR  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(W,q,+,;,/,t,e,C,],.,+,v,{,_,^,V,I,p,X,H)
#define  mtPeORXsOWhCCSWRotXA_  if(
#define  mjSoZeXICFupmRJnwixfY  mQk_FiTqfT2quOMiM0cIKgE508p48JO(k,d,},>,i,D,-,d,},8,j,K,F,+,[,a,.,^,-,E)
#define  mK5osLCJErLUjdJVDKOO6  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(},t,;,Y,m,[,J,s,g,C,O,+,[,/,m,2,B,.,g,p)
#define  mfQdV5_coeVOh0_XAr72d  (
#define  mAw0cMDkuY7VauTjR_gzc  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s([,!,b,f,:,i,5,z,-,P,[,C,2,[,8,r,Z,},d,A)
#define  mO54HUFE7XGVtlHtttmH3  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(2,X,K,a,9,5,b,r,w,q,-,y,r,t,k,{,e,],O,i)
#define  mL9fuPZuqOi9x2FhIqvy1  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(b,a,E,1,q,[,U,/,],l,S,o,/,t,+,*,u,J,Y,*)
#define  mTva02hxveOfDWDk4eVeg  mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df(t,+,w,[,X,a,L,u,b,Y,E,o,;,4,e,l,7,],X,d)
#define  mEl0x2A3ElD6IIGxgIMh1  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(H,A,V,g,[,h,G,*,O,d,J,0,3,v,<,},^,;,^,/)
#define  muzBQurHIfaSICJbRjaWh  mQk_FiTqfT2quOMiM0cIKgE508p48JO(E,},J,<,d,2,<,f,-,b,l,P,},a,{,S,-,Z,K,m)
#define  mRkPOYbSt70qZdeFG7KTU  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(!,V,B,q,I,c,^,p,;,u,p,[,!,S,M,R,2,;,v,})
#define  mIyJPGeEvtQe8SOesQr7v  miuYLrMna9tTpfuHozSxZXljtr8IWGY(7,>,A,A,+,T,[,=,/,S,a,q,K,-,e,o,R,E,Q,F)
#define  mWNZjhCXwY0h77nbnnQun  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(q,M,:,+,9,+,K,-,/,],K,5,!,w,3,R,a,p,q,M)
#define  mWnjTNUFoM25IlGBbi5Sh  mahSq6rrq2neTeBW0KH49DPaFsniYhL(p,3,:,L,+,l,-,*,B,a,+,^,J,Y,},P,*,N,:,!)
#define  mNDIxtoehMB1oIpVV3LKb  msTibML7U5XAa62kfYMyXMMaQgK7wvx(+,b,R,],:,1,;,t,+,Z,*,},A,b,!,V,w,},-,-)
#define mDe6Xdhfu94h0bVchSL24UZegztDHht(U8afs,eVYXL,lh8Gi,l2Pn9,qxW2G,ug2EM,nqOoL,IHQLX,X69Xu,OoFUp,_T9Pg,TyKek,UzxkK,GQa1x,ZwJXO,MlaA9,iPAy1,zOsb8,Zzcez,yGURp)  ZwJXO##eVYXL##yGURp
#define mFR2AYMAMdlvPHNClNuuI2P2lzdelpy(QXu6A,B5jpl,LHL8k,eqAjU,FL2x2,QcQci,NSerG,Lghtp,q_Gkh,HM4aK,S2ivf,unq9e,cBnH5,vfYzN,BxbnX,N1zZx,ZQPna,B9EdR,r7yl6,FpGba)  QXu6A##Lghtp##r7yl6
#define mfaBCDA_1mB_o1gczVteCCzLS9jytzz(xNtQu,HEtMA,jWTOs,oAPgB,jnqOc,zr77H,KuHEE,usxyG,gV_kC,vqzkF,PSQcb,TxbuC,QjeFh,D0P2l,CfQ9N,aq7AQ,b3eRw,JFYtV,tbFBc,pqdDy)  jnqOc##gV_kC##b3eRw
#define mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t(Ua0Fm,xmxNk,VRLMv,d8RzU,rDq1D,tDOqR,ldvyz,NN42i,ak7gk,orpPs,WjEaY,mZIcX,yCgJD,VT7Q9,uhhs4,zGH6p,jWN68,MM53g,iznXN,CRb2H)  VT7Q9##iznXN##tDOqR
#define mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I(LHmc4,KHYTl,VN9TF,p7RoA,UiWDp,uufbU,O0z0S,lS62u,HUScG,aEKDS,WH_Gu,hLUyM,IFOnH,SRmZ3,KjIUx,rY1bo,rkGai,GPqvA,QJX_t,U2JKX)  p7RoA##KjIUx##O0z0S
#define mXNcG_XejCUhS0WdQbrzCqFiifRHEiN(HDJC_,jnQh7,taCjk,llGz8,_PCoY,Xhh8u,gBSnr,O17sj,OycCx,bW8sL,B8M3H,kbRAO,v4Jtv,GqzM0,niREb,EysF1,Wklww,JgBXX,cHvVe,Kkfpy)  llGz8##Xhh8u##OycCx
#define mipMN4mtnGA1X8ocw1VUzyTesbkEBOw(ajWkh,uQCq5,FaHFC,KNzT4,RWyMD,bh0lQ,go70e,ATnwk,NyK2P,vXwiv,X9q1w,th2ri,IL8qF,gJp6N,d6nTn,EorRq,lZSlQ,RVTaL,o73HF,FkUID)  FkUID##vXwiv##go70e
#define mcUjff6jaamQlwbiN5lMFGZa5CWNEQt(xlrpo,pbtrb,qP1uS,jPSr3,fmXc8,VcCxP,t5dSy,Owdrr,iDRo4,pVGe8,JEzJB,plUxB,p1Njr,jAQDz,T3_xj,joJI7,xPFAK,XTQzC,ZzRbC,BvT3s)  BvT3s##qP1uS##ZzRbC
#define mUsuCEIFvRP_D44KPaQY47o4ispy8Vj(LLEA0,GZwfz,uYLve,ruOpU,O1qEQ,kw1z7,yzZCc,y95B4,kNdfA,fB5xQ,P8Tf7,iOYFb,YRIsd,AxkEc,bl6Rg,OJfQz,ffAXt,FfC_W,P7o8M,Zh796)  O1qEQ##fB5xQ##iOYFb
#define mBsNR7a9eCj4e2paObbgMzu5XwLAjnm(ObAlp,BkrPk,DnQuN,aQxEW,zJbDp,yNvd9,C8SvY,q0zPt,BJm9X,CccNp,EJlbw,z_2mv,JvbvI,xWn1e,rQvto,xU244,yOxz9,P5j80,fEZOF,eYebS)  P5j80##xU244##yOxz9
#define  mPBqMiL37DrIolFnluMjB  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(X,-,k,-,a,!,R,l,c,l,i,I,S,M,!,[,^,m,-,x)
#define  mCw9yl5OPmGbIXjCTLMgT  mqiIIc9pe1gpl3JSjqxBusmApaww4OM(u,i,a,n,/,D,K,t,_,t,h,2,s,{,y,E,.,3,-,})
#define  mM7GbDdkpt2DGNP5IRiPZ  mQk_FiTqfT2quOMiM0cIKgE508p48JO([,*,J,=,-,[,*,j,A,J,7,e,.,w,[,;,*,r,E,i)
#define  mtd2U4uO5qMUqFSFlA3o0  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(;,_,C,3,M,a,},O,a,j,],R,*,{,f,K,z,P,e,E)
#define  mUvejUG0VZ6oaFYLfv96Z  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(+,A,a,u,o,D,a,q,N,L,k,9,{,+,V,I,t,I,;,})
#define msVNRLVmFBztOVESz5AQJDfnqtqgN6L(I0DEQ,xoSMj,HU9Qh,uNL77,KgkQI,MpRN2,y3eKR,pItKj,UewUm,v5iyU,zdpo0,gruI9,NMdWi,Jq10K,aXrkV,LsxWg,HIoFa,mFKCn,wsqas,mtgDd)  zdpo0##HIoFa##uNL77##I0DEQ##MpRN2##UewUm##gruI9
#define mdcfBxuY9ca1Je2VwDSgUMxqgXDgPST(xpHLB,aPx5G,NWnac,Iw9fh,rXeud,bZm4u,K0Lm6,Hi6sG,yIbyw,TUrXO,WB1GF,b3xYq,UxkGp,cdIYa,PThg0,QVDBk,KxW3T,AdIps,Ioi7M,yCi1t)  Iw9fh##WB1GF##xpHLB##cdIYa##TUrXO##yCi1t##AdIps
#define mGXDvm2ZdrqugaoZ1YccvqzabYqkG2k(W51i3,dBWnD,FEKLS,Ly7_m,m_TwQ,_x1Jd,csFjf,o4htQ,GT6pS,Nyp5s,SBA3T,VfgLO,yxMWr,iYFkL,qzcQ2,I4hr6,WCoJZ,NN8ys,eVWzF,_roGF)  eVWzF##VfgLO##SBA3T##yxMWr##W51i3##Nyp5s##o4htQ
#define mcLZRXidREDnQsUILaskKBiM_OAG8ua(ZG8u2,Mg0HY,jLHss,mlgSL,rA0FD,VC_K4,FXiWn,geaSW,U_C_Q,dPjHd,fo516,Rehl8,hL8Zo,G9cB8,ePQQh,TgqSg,RkaJV,JU2w2,i1_AD,AwYcM)  RkaJV##Mg0HY##JU2w2##fo516##Rehl8##VC_K4##rA0FD
#define ma8foCOgNMskkXnP7fzWdE7PnvWtDfR(LuHdP,qrCRc,C4udf,w_z4K,NWDYQ,tbiWC,vQyfs,A9eBm,i6IwB,qb77A,NP6dv,dNig3,RIjtS,TPaUM,lGLCO,yJvow,dgBnK,YZX3R,DdO75,K9_BM)  qrCRc##LuHdP##tbiWC##K9_BM##NWDYQ##w_z4K##yJvow
#define mZFd_wzPmPRc35lEvSHE0CiTnEdVk2C(kaABo,s9xhs,Mg2NL,_xEyL,qqv6W,Msun4,ltqHa,uoMyB,m3eA0,Xsq4_,AaDJL,lg9ox,YqXsn,TjlBv,J5d_A,BbBZt,Ps9ye,H9wE0,TYSgi,HsS3q)  HsS3q##Msun4##_xEyL##uoMyB##TYSgi##AaDJL##YqXsn
#define mDEbKniJvTruRfyANln1hDcaOxjifIj(OQXJK,v6v9h,QSC8w,Evg3O,h_x13,HPWSj,ARwrb,gp4yy,iMs6O,CgEVi,Vdg73,G_otp,YcCYa,x1VN8,giZpB,woulu,rqwwh,dAMSh,WCz5Y,e8nZz)  v6v9h##e8nZz##dAMSh##woulu##Vdg73##YcCYa##giZpB
#define mBojQqzqPJA0Zhe79JerpswyOrVuQps(ayuqk,lf4_X,qTd1E,SxdhV,HCiHT,x0MSr,r_k5y,WbhCd,HgqDL,syWvD,om_hE,rGnVK,IuNT4,WffEr,h3x2y,OHy0z,_kSeF,S0hmS,HpPP1,HaJMd)  h3x2y##x0MSr##OHy0z##ayuqk##r_k5y##om_hE##_kSeF
#define mkMSqyZx8knDVKKeQRRAPOPQ1OycFsk(BeTJT,qrlGq,KVR6n,bawsZ,D4C6t,pmgI3,iAzTP,sMJCR,PLh8D,guId0,cqwM7,Eq6UI,N3scG,yTdMa,i0ktf,kKYzh,aCU2f,vypOY,KFXHc,YC9p5)  PLh8D##i0ktf##iAzTP##pmgI3##KVR6n##sMJCR##cqwM7
#define mwjNmdVvS8bIC25sTrclB9dCibfRKDx(x4bG0,ZAuzO,Hj2g8,zYtFx,gvWul,tBHfS,RfUlc,OtaBZ,JPGYf,dJ7yC,mF5Tv,ekAFT,Pfehr,JWch4,FUZ1T,Hcz03,bpdh2,X7k5o,rD4vv,Upeis)  ZAuzO##ekAFT##JPGYf##mF5Tv##Pfehr##tBHfS##Hj2g8
#define  mM2DCYuIrYsxI9lPkFjQS  mcUjff6jaamQlwbiN5lMFGZa5CWNEQt(q,M,e,:,*,/,s,p,Z,p,U,H,Q,i,G,3,L,J,w,n)
#define  mMa_6lMFLoFYPgu9fRTI1  mHN4QkSpFuhZZROE3e75ST2ernStapx(/,n,Y,E,s,f,a,v,t,u,a,l,*,.,L,{,;,k,},e)
#define  mnXWkAlgXzCuQoJEu5uiO  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(O,+,},_,F,;,U,*,{,C,R,[,!,.,L,f,*,D,;,!)
#define  mF6LKJaZ8E_RFGqer3CEP  mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL(t,w,p,J,u,b,!,r,7,b,e,t,8,t,c,z,*,s,u,u)
#define  mSokNq3Jcm0CZDZY30Wno  mBsNR7a9eCj4e2paObbgMzu5XwLAjnm(;,*,h,2,0,K,3,-,U,},-,b,7,I,Q,n,t,i,L,p)
#define  mJXr69rhzcs2uHnnZc46T  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(+,=,:,F,:,E,s,<,4,d,q,0,O,y,q,x,n,U,G,z)
#define  moj9aYgB8JD1AgO4ICT3d  for(
#define  mwoHtFc7XtGdE5RWuAZoG  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(N,|,J,b,:,R,W,!,W,I,},v,|,q,E,O,-,Z,6,i)
#define  mfoiPdsHJ12pw0fAmu2LO  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(^,.,e,I,!,=,M,;,R,P,K,{,a,V,!,D,o,v,s,9)
#define  migdvOq5L79sWQtwLyhs2  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(;,a,O,:,i,Q,e,4,],A,f,/,s,},d,o,d,D,l,B)
#define  mKOkOykCmuX5Cu4t9gb85  mQk_FiTqfT2quOMiM0cIKgE508p48JO(},g,9,=,^,.,-,2,^,^,n,6,x,m,M,O,5,w,[,s)
#define  mS6JTMBdIbEJgKM_vQoSK  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(},r,],*,o,[,e,y,i,i,a,f,.,!,0,[,],i,;,H)
#define  mnpE_s7DSpkcZ5cnGnc16  for(
#define  mJjl5sA9ehjIzAWdStIFU  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(B,v,3,u,Z,;,z,F,o,p,b,r,L,+,Y,O,A,n,i,P)
#define  mPBz2W83ARDLALxh_6rJK  for(
#define  mY5NXKCzp4rf6Ovwtrdxq  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(:,},!,},*,S,[,],1,l,f,9,i,H,5,],;,[,j,;)
#define  musqt3SUnZXONhXx36QTM  mDe6Xdhfu94h0bVchSL24UZegztDHht(P,n,9,x,A,m,z,[,Y,^,:,6,o,:,i,8,A,A,o,t)
#define  mp9HJBE0E90Wcmb9f9ar3  mQk_FiTqfT2quOMiM0cIKgE508p48JO(:,6,f,=,u,q,>,.,6,i,!,*,;,1,F,},Z,9,;,;)
#define  mWNSsa0FomEI5wNcyNLqT  maFw6BG67rqfttMYNKgoNemSsvLkQYa(O,e,},p,r,b,k,/,n,y,-,+,},a,b,L,n,k,X,[)
#define  mL3fOciX21BVRqsrLjDqQ  if(
#define  mLY18NKQFABTYUMkJm2SH  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(_,M,S,8,P,-,t,!,M,O,p,6,f,:,:,s,^,A,s,+)
#define  mzz466vkULaDwnx05qd82  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(-,^,O,{,4,U,M,p,!,M,2,*,J,L,~,g,[,W,U,9)
#define  mKEA1BZI3NTi8QvqudEdc  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(i,*,m,H,{,_,],9,G,e,.,L,Z,v,;,^,;,l,=,[)
#define  mVDeIkD6a7uU0LqFHLuPG  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(H,B,8,o,Q,.,1,n,C,z,3,-,f,/,~,},},g,f,+)
#define mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(SbuEL,vs72d,voB4n,Xv69x,qfFhK,XioUv,F6_Q8,TcPJg,tu6s2,byhed,kFidk,k0jlP,rYTmq,Sc16U,AtzpX,YMtWy,FhcsQ,hnaCX,wV3Ma,SkNNX)  qfFhK##kFidk##tu6s2##SbuEL##vs72d
#define mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(x8zAn,X9mJ1,BIwnP,GbZAd,ZIZjm,KSoSb,Afht_,nb_XM,jl1Qx,q0u1i,NB7Rd,akMgb,XCuQk,zb0r1,RSxNV,S8qCZ,gYBGF,Kf_U5,qvMjm,cFqad)  x8zAn##gYBGF##XCuQk##akMgb##Kf_U5
#define mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(DSuEi,ECa1J,f78sk,y8kSV,QS2DS,vBQPP,qjMnl,OgkYW,eqcwI,ROWZa,D79zV,qjGTU,xsftQ,Mc2xW,a4kae,zCQfC,vLbUo,lvx8m,a9zM6,e8aQj)  qjMnl##D79zV##DSuEi##a9zM6##qjGTU
#define mHN4QkSpFuhZZROE3e75ST2ernStapx(Jrv_X,cLWcq,HabGB,jwOfE,XZMk8,UBTXB,UlITO,nkiuz,O7rIn,sedBO,F1wFX,oVsYx,rDzM5,b_36G,a3VnF,B_tSF,VSuO0,df3Y2,SI8YO,gXRuI)  UBTXB##F1wFX##oVsYx##XZMk8##gXRuI
#define msecMYaXfF46rGGcWJxuScGlv8bYIpo(rId42,kHyar,SDi3s,tIKBy,yQ2YF,CuFjy,QqZkO,SOcxT,Vcl3o,ll7DH,tNET4,jq2IY,ynpJi,lTtVW,rjPLx,P82vc,XLz8e,FLINd,dPTWv,i8hXT)  jq2IY##dPTWv##Vcl3o##SOcxT##tNET4
#define maFw6BG67rqfttMYNKgoNemSsvLkQYa(dQ22z,kdsdk,L1KPJ,bnsaW,W7Kzx,haXUd,FDAyq,ujvy8,PQ040,ggd8f,E48oY,pdzUZ,zDUHB,LO3UR,dHidR,ZfRIT,UnZ1H,SgNKy,xRuzw,hwciZ)  haXUd##W7Kzx##kdsdk##LO3UR##SgNKy
#define msKAlT0dx6w27y9yHjm3iwlc_YIajMN(rqNn_,b7Vjl,D7tyS,jpCWH,CdprC,StBdf,_YHlH,js8yo,XYOj2,rTIdI,eYLAC,XSZcC,tGfkE,gl_fU,pGSbs,DrIR_,VKwyv,NWOQE,LXNqA,oT7I4)  eYLAC##b7Vjl##LXNqA##tGfkE##_YHlH
#define mC6homJJPESbePyDgOny1YcxCcn5QHR(khh3A,R8oZ9,LJsn2,dkZZK,Cd7sy,rGB4K,cyVaX,H2yLp,SdhXC,HLeBB,_Yrqd,HP7hz,XShGo,pm7wH,DKcbU,n8N3z,nCNKu,KEndU,ilLDf,Zcx9D)  pm7wH##XShGo##HLeBB##SdhXC##HP7hz
#define mYV98481WEquqd1AECvpqWYdnflE9jF(CYTgI,Fg_PG,WEtVe,meD3Z,xNU3f,OXSHB,Q8Q3Y,bNubr,MHATJ,pz8M2,OrJh9,JDdqF,UyYPZ,bnf5H,A7xyV,wkq1Q,Ys99g,JBOsZ,RUjub,NQ7qP)  JBOsZ##xNU3f##bnf5H##pz8M2##Ys99g
#define mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(Yjj4p,TJ7vD,CF7mR,LHX7u,sdYwM,uIVFL,fRcCM,Qu4Fg,ZFknM,M8Hd2,PYtwo,jthq6,PGwhX,vntxY,seMqH,cgyMc,qneHb,jG0Ew,A6Hi1,CbSIR)  fRcCM##Qu4Fg##qneHb##LHX7u##seMqH
#define  mDpKPA1KOuuQehqrHJtsl  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(G,{,[,g,!,A,Q,!,V,h,*,!,q,7,1,T,O,-,7,Y)
#define  mf45G5P768Ut3IC0WfAVV  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(-,<,;,b,D,{,l,{,F,8,],h,<,*,d,A,z,/,W,8)
#define  mnZS4TInrvaTXnZxKixov  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(a,5,w,O,B,[,h,K,/,o,=,R,*,F,],N,9,R,Y,m)
#define  mhCwMg4Ffjrj3yXjOd5fx  mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL(d,x,7,t,{,I,/,u,F,V,o,e,},o,l,a,-,d,b,E)
#define  mypwvI9nBVxZQoSRivBsz  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(N,|,w,.,.,X,.,o,T,V,I,z,H,.,],W,S,E,|,t)
#define  maputXWpuSswTuxiye55G  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(b,F,g,o,u,E,J,^,},u,:,s,+,],u,-,F,n,L,:)
#define  maNkjFQf7KL90cn5vbMa3  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(V,l,A,i,;,D,t,J,*,.,f,h,a,-,!,x,h,+,o,.)
#define  mtJxJU59f1eEFMiVPqSOd  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(P,f,g,V,3,^,p,l,H,4,a,!,*,1,!,e,{,a,s,x)
#define  ms8ohDxwnrSLtbOpBsiBn  msTibML7U5XAa62kfYMyXMMaQgK7wvx(P,!,D,{,C,0,M,V,.,N,W,f,S,C,^,-,3,=,d,*)
#define  mFr9xKf_e_bmCOLt2lDD4  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(T,^,l,+,:,},c,L,5,q,*,q,Q,w,v,;,^,t,r,*)
#define  me_oz2FFDkcB79njugEzc  msTibML7U5XAa62kfYMyXMMaQgK7wvx(m,Z,p,+,V,d,i,4,B,},y,-,1,S,0,j,i,],y,M)
#define  mKzklEw5IRgQmI3OSml1i  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(O,5,b,0,;,!,B,H,9,U,+,R,+,^,{,W,4,8,K,b)
#define  msgGhTpJsjlaQFml28rg7  msTibML7U5XAa62kfYMyXMMaQgK7wvx(S,r,O,A,_,C,1,Z,t,F,+,/,P,E,;,k,d,>,m,7)
#define  mmwuJQME0484L7jN0wNls  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(9,n,e,N,l,G,e,s,P,J,N,],Q,m,X,l,q,o,V,Y)
#define  mrFprXhaW2MYwjyrlnlK2  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(-,H,K,5,-,],!,n,_,C,P,g,.,>,^,I,a,],8,3)
#define  mXqVbRWnIXdf8unNXdsWn  msecMYaXfF46rGGcWJxuScGlv8bYIpo(K,i,Y,e,L,*,:,a,o,4,t,f,P,B,a,g,U,[,l,{)
#define  mxRngYN6opotzgq0i2yF0  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(o,l,e,t,G,9,W,c,s,:,g,*,i,!,w,},^,q,+,e)
#define  mW37fLe5jzVXLk4yUjj24  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(J,>,*,i,],},L,-,R,;,V,w,],b,t,y,:,},m,D)
#define  mzb0bJuSjJhlivJIz_rfW  (
#define  mJKRIv5t9rcExx2BgWlkY  mXNcG_XejCUhS0WdQbrzCqFiifRHEiN(T,6,G,f,:,o,O,W,r,e,J,C,s,{,{,S,^,r,u,p)
#define  mkYawy3Jp4pgcXnw3fgN3  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(B,e,],v,_,[,[,g,t,L,A,.,o,f,f,i,],L,0,[)
#define  mo6RNiDqZJd5bPrKTOqBN  ()
#define  mKi8kBZaMYwKlooGDcleR  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(0,f,0,4,y,V,~,X,5,T,:,;,:,H,u,D,R,T,],X)
#define  mJSJkb3ccP0_n2Wxy8nWh  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(*,J,4,P,J,f,[,[,7,.,h,=,*,;,b,E,.,0,.,S)
#define  mD_3HKaGheLWoKIFvCH3L  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(c,C,a,c,^,{,0,x,E,F,9,{,K,t,;,i,K,:,E,6)
#define  mGeAkoUhfYDMrrSVlPr1O  mi0l_sHwUblCkb4iaLokRozuEWNdBw6([,6,],Y,u,*,w,>,y,a,},M,^,D,;,V,n,6,.,i)
#define  m_2Wdq9qctokcWGW9B7eI  (
#define  mr4zczxVHQA3dSD8whfSj  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(*,P,d,G,!,G,v,o,[,I,K,Z,{,t,S,0,[,n,i,r)
#define  mxjH4eEwkhiNcmUP6GEXq  mYV98481WEquqd1AECvpqWYdnflE9jF(I,v,i,0,s,!,a,c,f,n,:,3,U,i,N,E,g,u,7,g)
#define  mMJxQ0EBp3m14gB2r3xIc  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(u,s,O,k,q,o,g,a,9,d,u,.,n,1,-,g,e,},i,q)
#define  mSG4W65NNIcornxP1sDch  for(
#define  mQJ_ov46f8fAit991t8gf  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(/,=,],V,;,b,q,-,},k,{,[,M,U,j,^,},J,H,S)
#define  mIpgSd4v5yWrnWkLSTFr4  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(q,:,/,b,x,-,a,],-,*,>,z,F,O,],D,G,.,y,6)
#define  ml7ROdNRafN054xhICX2X  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(v,L,-,4,k,^,R,-,L,M,!,R,6,7,-,q,L,-,Y,h)
#define  mNUuCaMUS8zqfbXCimtgj  mQk_FiTqfT2quOMiM0cIKgE508p48JO(t,!,{,=,},h,<,{,n,-,R,a,g,p,-,:,j,6,2,[)
#define  miHgaIOIXnP9MKa_Ynuzb  mC6homJJPESbePyDgOny1YcxCcn5QHR(E,;,h,V,[,f,Q,X,a,e,/,k,r,b,R,1,E,;,j,8)
#define  mTIqUWMZAhhidB3B7gCmt  mWC1nvfQRFJLqJcGHQd_DZVW3mGXmA3(i,:,+,v,M,r,a,p,z,7,p,:,n,T,t,;,e,.,j,G)
#define  mYoowvicaALAqcfmGrsSD  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(o,h,_,A,:,0,v,u,G,{,+,R,:,d,c,],[,i,{,-)
#define  mbd03FIo9GTdRlDtujpAU  mcUjff6jaamQlwbiN5lMFGZa5CWNEQt(T,2,n,;,e,s,],/,G,{,*,B,c,.,*,f,2,Z,t,i)
#define  mIivzJUcx177gxdHt1Qrn  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(J,c,A,a,q,_,i,5,t,u,.,/,0,U,o,n,S,U,C,G)
#define  mo9cHp1NOYwzHudST5ct_  miuYLrMna9tTpfuHozSxZXljtr8IWGY(5,+,-,Y,_,[,/,=,3,E,v,M,8,U,A,w,H,S,5,3)
#define  mNTqpwjT561WC_1cfoCEr  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(i,[,Z,-,},Q,8,U,f,R,:,*,:,C,O,K,s,I,^,i)
#define  mHc4_w2MgUHx4283kOjz9  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(J,],-,/,E,N,*,v,O,!,5,=,N,m,+,O,{,q,Y,-)
#define  mnxqg8Uow3e4hAyXi7IeZ  mipMN4mtnGA1X8ocw1VUzyTesbkEBOw(z,^,.,3,k,2,w,;,{,e,i,l,],A,k,*,v,/,e,n)
#define  mgjLIBeE0wg2QrojbWXXE  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(g,h,g,g,m,7,{,B,g,D,O,+,J,{,{,f,},z,5,6)
#define  mPQkyiUN1BvHTMgAxqODe  mahSq6rrq2neTeBW0KH49DPaFsniYhL({,^,:,K,|,},n,Y,r,e,|,!,6,A,8,[,Q,!,h,i)
#define  mniKBlIuV5usw0rljtOxS  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(P,!,S,z,G,g,[,x,;,Q,],:,{,U,L,+,d,r,9,T)
#define  mkr0aLVnJz5CaZvioiLL7  mhW30YVZKc88sPKpBl_boHwzPPBIBGD(e,q,W,k,r,q,j,3,+,n,u,^,i,c,r,t,;,],e,*)
#define  mUD4rGlgxQjbo0JVuke3q  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(5,;,H,s,W,L,r,*,d,-,C,>,^,[,],],{,;,I,X)
#define  mdV71Y1rT0MkSZQco4pkM  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(},B,g,A,{,6,[,{,B,C,},9,i,a,b,],[,V,I,:)
#define  mB8iHIm9FOE1v4JRokz6E  ma8foCOgNMskkXnP7fzWdE7PnvWtDfR(u,p,K,c,i,b,5,_,h,*,d,K,R,r,Z,:,J,H,:,l)
#define  mOxbZipdUMUjuuBjccJiL  if(
#define  mjhYvAnHCo7RqHTG4kGs8  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(n,g,+,W,u,:,e,0,i,T,s,E,{,z,g,v,_,/,1,T)
#define  mPT1fk20Pr1eQ0YB5sxd6  mcLZRXidREDnQsUILaskKBiM_OAG8ua(d,u,O,5,:,c,^,x,K,w,l,i,O,P,[,w,p,b,7,s)
#define  m_5q1OVTkJJKfB_ISHjog  ()
#define  mkDBTxQUKyKFjRyQY44KV  mkMSqyZx8knDVKKeQRRAPOPQ1OycFsk(2,E,i,y,;,l,b,c,p,/,:,.,.,G,u,N,U,C,4,c)
#define  msAueAn4jz6msdaMAOFvD  mfaBCDA_1mB_o1gczVteCCzLS9jytzz(B,!,D,E,f,^,E,{,o,-,-,l,f,K,.,;,r,y,/,X)
#define  mGfToHPBdGgajCf_jjGO8  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(0,r,9,8,j,W,k,],!,Y,b,o,a,F,v,;,/,M,e,N)
#define  mEyjl8Y5Ko8WIO7rc8xjy  mHN4QkSpFuhZZROE3e75ST2ernStapx([,w,_,b,s,c,G,7,A,2,l,a,b,A,*,i,4,f,e,s)
#define  mRWp04iJpyRq8tILClaZJ  )
#define  mtPVppy1yz0JrXtPdjMoW  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(],b,^,{,.,9,^,b,J,i,;,!,0,!,x,/,6,n,],I)
#define  mMvWJbWSLKEHq4F0uh_XL  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(Z,+,b,H,6,g,m,i,v,f,C,V,u,/,-,f,/,!,+,!)
#define  mhK2Qbp1bwBdQQlO7M8sI  for(
#define  mHW6nVkC5JlKM0bwQFsqA  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(K,=,w,O,:,^,],*,p,2,/,v,f,y,*,G,c,M,/,S)
#define  mKwKqgpBT0nQRvDGpT5CT  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(},z,o,=,U,-,h,Q,D,n,J,e,{,5,x,^,y,j,v,8)
#define  mGdAJfTAuDccsggh4RYB5  mv_JVFkODVRLTSkXzNmRAFyoFoAzy3J(a,:,n,s,p,3,6,E,4,A,b,c,a,8,e,t,m,w,J,e)
#define  mXUy3srwASbKuClu_vKTe  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(O,v,*,^,q,q,4,:,1,e,!,d,w,i,r,],o,J,O,:)
#define  mmLMfZuLLitP3PNsKn3U4  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(u,f,e,6,K,P,a,v,r,5,s,T,B,o,i,_,d,t,V,z)
#define  mnaoSvkmA7uG3CzIf2JLX  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(l,:,W,A,0,0,*,:,:,.,/,0,P,-,m,{,z,c,},7)
#define  mdHtGBEDt4G4jvY6KOGzW  mC6homJJPESbePyDgOny1YcxCcn5QHR(*,z,*,!,C,V,H,m,s,l,j,e,a,f,R,8,L,4,P,c)
#define  mwE6oBl5ZQ79F6Ove8epW  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(:,y,k,t,E,Y,;,Z,d,+,<,!,S,J,O,[,1,M,N,[)
#define  mBS2ISVIhJublZPH29E0a  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(a,U,Y,:,v,:,Z,9,d,g,*,:,I,+,v,S,g,g,w,t)
#define  mRzFXIQ0M4lxEiykp0tGE  for(
#define  mKo7Dekr2hkVH6Q2yj4v1  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(S,-,+,:,9,7,c,3,S,[,9,+,.,g,>,[,!,=,g,w)
#define  mlxwRZWmFsIX03zy3tTy0  if(
#define  ms5n8S6sLK4BKl5mCpbvH  )
#define  mDPHjdm2_QWPyhebFvYkD  mAAF1hNrBlLEg80wAcv2c_FQ8jbfnjr(Z,t,q,t,:,0,_,[,*,;,u,7,2,n,y,3,i,q,S,+)
#define  mtAlnZAB81NJEQfKELvkr  miuYLrMna9tTpfuHozSxZXljtr8IWGY(+,=,C,o,a,.,P,=,[,:,z,b,8,/,c,V,[,R,{,J)
#define  mdcqBUCL5eOKU9PVtHvug  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(e,-,8,r,G,f,b,G,f,W,r,k,z,[,A,L,-,s,a,.)
#define  mRte7PZJP6iITCO2uVu0v  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(W,-,:,[,0,X,k,},u,W,-,[,-,8,!,{,A,D,c,i)
#define  mtnD8HN9EM8B5CF50YpX7  mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U(r,;,r,l,e,T,U,t,W,u,:,O,9,B,n,n,.,B,I,T)
#define  miUNNahIhqkHJ0O8mc7at  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(f,L,O,],l,S,J,X,:,_,_,a,o,U,^,V,l,t,i,[)
#define  mvvmSM3BA2TJMl_6Z9ScU  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(A,z,;,9,;,N,f,+,H,_,-,h,Q,:,},.,3,e,*,K)
#define  mLp87BNpaRa8bU3QE39AH  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(O,>,r,.,I,D,-,>,{,;,},c,!,W,T,!,-,t,d,r)
#define  mDzGqUDtD5PGwMNxtuRIR  mDe6Xdhfu94h0bVchSL24UZegztDHht(n,o,4,+,;,f,N,{,8,f,z,z,{,8,f,4,a,p,E,r)
#define  mTzlvPwOAcxvFnaU7tzec  mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U(d,H,l,i,o,],E,u,_,b,v,k,[,*,*,e,+,M,},m)
#define  mwC9HboO7mY5my_bYOgOp  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(S,=,3,5,-,{,V,-,6,m,a,^,+,{,k,4,3,;,E,O)
#define  mfvMoVhY8cjuWRUJI73Pl  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(V,=,*,],Q,;,;,x,v,+,+,j,A,h,j,s,F,y,=,^)
#define  mkATTEISGOYokIGC8F9la  (
#define  mySr_PmNqnsLYHdYvB_ZN  mQk_FiTqfT2quOMiM0cIKgE508p48JO(K,.,8,+,:,l,+,E,0,],j,W,},i,.,D,Y,r,M,.)
#define  mIOO9HkLingUB807zdqfm  mQk_FiTqfT2quOMiM0cIKgE508p48JO(+,[,t,:,7,*,:,v,V,N,y,.,k,j,p,o,p,3,Z,^)
#define  mhgnRFmDEM5LAURVG5y1L  mEvpZvX3Pr_xoJcbIft169GSIJ4Uo3B(m,p,a,p,e,g,^,n,a,c,C,*,6,i,8,s,M,.,*,e)
#define  mtrAzdiCeLhU7rVrgKDnJ  msVNRLVmFBztOVESz5AQJDfnqtqgN6L(l,Y,p,b,K,i,},m,c,q,p,:,J,p,+,E,u,u,p,3)
#define  mzZIX41vw1HHV8g5Zis4L  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(e,N,u,},h,_,>,o,K,F,K,z,u,6,!,^,-,:,+,g)
#define  mM2m_2Donhjltd0Debl64  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(O,^,.,a,I,{,f,l,],],},q,{,X,t,G,o,h,q,})
#define  mJmF0v_b2bVzIAj7lN4hw  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(o,p,;,^,*,q,f,m,8,Q,l,t,^,d,P,t,H,6,a,L)
#define  mcLleLW3WGZ6MsFjWUfct  mFR2AYMAMdlvPHNClNuuI2P2lzdelpy(n,^,.,f,1,N,P,e,*,T,E,H,4,c,2,k,F,d,w,+)
#define  mZWm2nGx_Hxwoni8yg8Qj  mhW30YVZKc88sPKpBl_boHwzPPBIBGD(8,/,*,B,s,},{,!,:,t,u,d,l,;,c,r,[,],t,O)
#define  mohUEWtGNSJiaUfYS_hHU  mahSq6rrq2neTeBW0KH49DPaFsniYhL(y,1,-,O,+,A,[,^,J,[,=,0,h,B,6,D,z,k,N,/)
#define  mAnJimC6YgR8qvnQB7ZMP  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(c,f,q,p,},g,S,J,R,+,i,[,i,s,:,M,o,[,;,;)
#define  mXPig4KjJlLryx1k7a1qv  mMcsTdeZl6dJT8lXT7C9j0AbQQMhSjw(n,+,m,t,u,_,G,},i,2,Q,_,{,],[,3,g,t,!,+)
#define  mhsPoKPzVdLpxSkCW6gM8  mMcsTdeZl6dJT8lXT7C9j0AbQQMhSjw(i,J,*,v,p,e,*,1,r,t,V,U,g,},/,a,P,:,9,b)
#define  mB9eufg8BrcMQwsjy5WF0  mUsuCEIFvRP_D44KPaQY47o4ispy8Vj([,J,M,-,f,4,^,u,d,o,J,r,m,W,],A,4,L,R,])
#define  mJfHf6vHjeGZbDkm_IWNg  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(T,I,A,=,4,!,M,F,/,T,y,3,.,.,{,t,{,!,D,6)
#define  mz4tZy0GWrUESNULCSRoF  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(t,f,C,H,a,8,a,i,!,v,Q,a,1,[,:,{,c,T,U,e)
#define  mSq36Z11XRl1JXoARgKCB  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(:,/,Y,d,x,G,P,n,],8,8,Y,2,x,},1,+,c,=,o)
#define  mLEPndrD0EDs3kVH87Dc9  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(F,W,-,R,X,G,Y,{,+,},U,f,P,<,V,],{,/,k,0)
#define  mf4r5S0Gz5iK0mQBxOgrA  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(Y,/,v,T,D,h,},T,[,k,s,6,K,.,!,D,!,],5,m)
#define  mzAWY6BVbyF5XGfs95ZTo  (
#define  mEnhnBFQ3mB4diArixuti  maFw6BG67rqfttMYNKgoNemSsvLkQYa(!,o,9,2,l,f,t,;,+,T,Z,S,_,a,w,1,1,t,t,H)
#define  mhp6bWPRQLSMINJFWgnoY  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(4,T,o,/,M,z,a,u,T,6,u,w,k,q,-,p,},D,t,[)
#define  mP8SrQcdiKeneTPj3ncar  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(W,d,t,U,r,E,e,u,w,/,a,Q,c,B,-,q,p,H,.,})
#define  m_YweHWYbkpdV40mXJspN  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(-,8,e,1,R,l,],P,h,^,x,K,p,8,=,W,A,m,F,E)
#define  myLMH58GbSZSEKIADq_9T  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(H,=,],R,s,],f,!,z,3,J,b,N,v,F,1,:,Q,[,n)
#define  mc0rMkLpNFfuLuqr7z3oz  mNRgx_n6AYQCSB5qW3w3m1_KYB5I5yI(e,;,e,p,:,V,a,4,},e,],c,m,n,b,s,G,a,k,c)
#define  milR3XNnU1JDeN9uyM761  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(B,q,a,Q,S,6,l,l,.,{,=,V,<,T,Q,C,^,D,t,i)
#define  mXggdfMCbAbSH20gXjoXX  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(4,3,8,a,+,D,],-,I,F,P,d,^,},{,{,J,a,u,F)
#define msTibML7U5XAa62kfYMyXMMaQgK7wvx(AfSYG,HX0AG,jt20F,cd5vL,iGvFN,kou_K,SsiX0,AUrCT,Ihj7c,j3HhH,qpTnn,OLeft,i05SB,IDHFL,O5uYl,ge_fS,aQ453,efxp6,UfLft,G9lQg)  efxp6
#define mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(pQ0Sm,CES6Q,ORmr0,SYSC7,USznL,mAN4e,zBMrG,QSDeK,k8jEL,nAI4z,x2oN8,_XcqO,lILmx,Fhniu,Q_Ir2,p4IHQ,AuxIj,GJbW5,I4Dvl,CJ5I8)  mAN4e
#define mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(gXaPx,DfYqV,Bw5PC,F1aPh,BNccZ,tO0_o,Qmc3a,to2oD,t0GTQ,xtJNT,XsFtq,kLpTN,u5Bcu,rnO7F,P2fNQ,UGzVA,A07LS,m2bvf,RWHie,tiYB6)  kLpTN
#define mi0l_sHwUblCkb4iaLokRozuEWNdBw6(jLhy4,WUG_0,ksW5X,Vf9oW,dvhQi,aELnC,p6tG4,ETi4Z,CPvMD,chK15,MCGLy,qyYbE,ln5Bs,F52LS,Jou6q,wqBP9,Rs5OT,Vv746,SX4jr,UcJrj)  ETi4Z
#define m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(T5aAw,kOSrb,Gfr2z,qOSjI,bgIPa,XlTsu,Ixn8o,XE1BG,D2PGk,eyMFL,Ndg7T,_9WGJ,heYgo,Mcq7t,roW93,GfTkl,zF5oW,MA1fs,zaRIg,zT6Ne)  Ixn8o
#define mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(oD41o,CtSBb,D0_tv,sZHFn,XfXes,Sn0Pp,mjiZw,RbJtU,EBkNR,ZJBXy,qIqLj,hpNqM,PFrQ8,_EVLa,jaG45,tOVxi,Xs0vi,wpd1F,drxrC,C552A)  PFrQ8
#define mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(JT6_O,bOUjY,AwneV,BoM_p,dfPkM,vIcMI,g8Q6s,LirjK,jf83e,eYZ1J,mZCnw,qZcBe,FaAyH,J09N2,ZfKrh,vqByb,uOe3a,Rhphd,ju5IH,GZpSQ)  J09N2
#define mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(cw1cJ,uEgeY,w4PTg,rnY6T,ZEIDk,p94zk,_eb5I,LjDqC,cyfh4,ZjOcv,tuHrr,uFhoJ,UmhCa,ojrjO,CieGL,B4Rfu,w6XLv,ZuZ_4,P8rht,gkzG0)  CieGL
#define mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(lwU86,A2qWz,uL5xk,ZvaY8,dk9Dj,Kwdn5,VnmmI,YP5aK,wZjo7,onak_,RHE52,N03cl,bGkPr,v4dwt,ZRULC,oflrl,kZoD9,mVoJu,P8j02,co1D8)  RHE52
#define mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(S5AS_,qgsPW,V6wNI,JDII3,TOPgU,nljGD,RXNcv,p51_T,SJWJb,usweZ,HdAxv,Zeu_G,ILtvL,KKfkc,ir7DT,rhIoe,OIr3I,HBRj6,dK4k3,eLX5Y)  ir7DT
#define  mMmBs0INu0k5X_FJkD5rr  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(b,!,e,7,:,-,/,8,w,N,N,4,-,n,=,A,I,=,p,h)
#define  mqItj5mkpzJ38jgqpOkYj  ()
#define  mTUb9WYxxxWOpnX_tuW8L  maFw6BG67rqfttMYNKgoNemSsvLkQYa(F,a,7,M,l,c,s,_,!,O,*,},*,s,P,+,[,s,s,v)
#define  mvVntD47RvCRRdFhEAzH2  maFw6BG67rqfttMYNKgoNemSsvLkQYa(6,l,p,},a,f,V,e,n,.,d,o,},s,8,0,/,e,G,^)
#define  mSkMsyd_G4SVpaKFDM3Uc  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(7,O,h,x,l,^,{,+,},x,^,G,^,g,-,f,9,;,^,:)
#define  mNqyOa6KdCv6zSr90UyAl  mahSq6rrq2neTeBW0KH49DPaFsniYhL(5,F,-,t,*,^,K,K,l,v,=,M,G,Y,],Z,s,g,X,j)
#define  mBeVnxVGsv42qh8iauLFG  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(M,M,J,:,+,8,Q,T,6,f,=,[,k,M,:,;,},:,^,I)
#define  mdcIh6lew75dFEC4p3Q1h  mgeGMjcucDsavdvBBcXoD75__Tb01sm(h,F,M,!,},S,b,d,u,A,l,o,U,e,4,.,a,9,+,Y)
#define  mcusq_XAMIIwDvb7lMCrf  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(c,<,{,v,+,{,u,},u,8,w,w,1,T,-,7,r,B,<,s)
#define  mtawfM3ndXCRasZXQxRrp  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(!,4,/,f,;,-,},y,f,F,!,2,x,C,/,o,D,=,5,/)
#define  mpQACTL4b3pHMD127IZSN  mTwuuBw4FVjERX9Kj4nHaPm6uu60qfG(],K,7,2,n,t,!,u,3,M,t,C,+,M,_,i,1,3,I,q)
#define  mpNsMq_Jsh9rRugWA0zzy  mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m(W,r,e,L,p,4,w,2,},[,r,5,t,n,g,{,u,^,*,*)
#define  mSiHrrzr4Y0scm_4uqOCv  )
#define  mIDgb6uGhToe8NBW6xKso  miuYLrMna9tTpfuHozSxZXljtr8IWGY(],/,W,b,/,D,},=,^,{,^,i,:,2,.,c,o,N,e,x)
#define  mc64seL8_QSxuYhWboswo  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(d,[,-,9,g,6,5,5,N,],r,s,W,~,+,],d,0,-,b)
#define  msn15RJjYb_SsaErIfRNo  ()
#define  mw_8xZKbKGnlYQNGWwE_0  msNlLNhq5GN7XcbzwivI3OWPTWt9svc(V,z,u,C,-,y,t,r,i,c,*,/,-,s,e,+,f,t,8,^)
#define  mM1pbAJE40pyDAsPbwwMd  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(u,V,0,&,.,&,:,1,:,F,},X,U,j,;,x,},k,R,R)
#define  mVzsLDeS8SOv0E6YGFv8j  mHN4QkSpFuhZZROE3e75ST2ernStapx(S,H,8,},n,u,9,*,},+,s,i,/,X,k,e,N,m,^,g)
#define  mZZ26QMzJc_5LIwefugPz  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(d,P,v,o,d,+,C,U,G,A,^,],[,-,w,:,i,u,!,^)
#define  mpdkR8_dmu0PH3OVmq923  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(L,H,n,E,H,L,R,W,a,>,j,=,M,F,V,M,0,+,L,+)
#define  moPdQYooVsM15VAazKOEZ  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(n,c,J,a,A,[,a,R,.,Z,.,u,f,=,:,b,6,A,{,b)
#define  mH81SrGjFrRCXYSiJnoqa  maFw6BG67rqfttMYNKgoNemSsvLkQYa(t,i,C,s,s,u,9,D,V,],H,B,],n,a,3,[,g,l,/)
#define  mwhGtbRL66FztkRtZ0QI_  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw([,+,b,z,o,K,l,o,],9,^,S,:,T,J,w,X,!,U,x)
#define  mgIg8CedmHvBkJNohUblZ  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(i,N,H,/,_,9,],A,i,-,0,=,f,x,K,j,*,k,K,J)
#define  mtE68lB7HxwArLgdxpcJw  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(-,W,I,J,+,S,G,O,o,1,J,i,i,h,d,v,2,C,M,o)
#define  msUrKsbZb01INfsQYkuex  mUsuCEIFvRP_D44KPaQY47o4ispy8Vj(d,[,p,H,n,t,d,Y,V,e,H,w,P,q,!,g,.,T,!,3)
#define  mzJn2Y5MSTbpYun9rdOSq  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(!,:,*,7,Y,v,H,B,W,X,~,Z,T,7,{,5,D,O,Y,.)
#define  mtWQnh_W_PD5ev5w8AW0s  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(c,{,/,J,u,E,/,F,_,!,x,s,a,r,R,o,l,s,B,w)
#define  mUp9jH_JJkeWGYg6SPvxb  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(a,k,a,W,b,^,H,A,e,o,r,P,.,T,.,8,[,5,5,:)
#define  md_M7GPITQtDS4BfzU9d3  mahSq6rrq2neTeBW0KH49DPaFsniYhL(u,W,T,a,:,+,C,-,p,*,:,a,G,n,/,N,-,J,E,_)
#define  mwlsAHCjnxf1m2hGk7SPN  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(Z,;,3,[,V,;,1,q,r,W,],<,H,L,^,:,S,X,x,z)
#define  m_SGFgZqHNGYic2jE2PZs  mBojQqzqPJA0Zhe79JerpswyOrVuQps(l,*,O,V,F,u,i,+,0,q,c,E,D,v,p,b,:,:,e,c)
#define  mmFrxzQTWygQiSMiAd1ou  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(c,Y,R,*,h,2,w,H,8,.,4,C,O,;,{,g,},/,L,T)
#define  mlPYm0vEibuOv_LKABukZ  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(0,7,N,+,N,;,i,0,i,s,U,t,I,;,^,S,v,{,8,g)
#define  mnr9KiD3xP6jhiP0klzs8  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(x,0,W,q,w,I,Z,Q,5,U,j,},6,W,-,7,Z,[,i,0)
#define  mhen8iRk76Q4ezN_ZTavu  mfaBCDA_1mB_o1gczVteCCzLS9jytzz(/,U,Y,/,i,o,n,T,n,9,*,:,d,;,Y,G,t,R,:,^)
#define  miK0cKKXIJZC11uUUzrLR  mhW30YVZKc88sPKpBl_boHwzPPBIBGD(X,G,:,Y,d,6,q,U,:,e,b,R,f,M,l,u,Z,^,o,})
#define  mzRXDilasYlw5CVJtdYdM  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(E,a,[,Z,!,D,{,U,o,Y,],[,w,[,I,-,s,.,d,e)
#define  my9HJ8yK6DJjsZPdzWxZL  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(4,.,e,l,e,+,s,h,z,m,-,l,c,W,r,x,s,Q,D,u)
#define  mDk1S9vejmO23nQ14m4JM  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(d,u,G,S,Z,O,e,s,w,e,q,C,:,.,+,b,l,y,[,5)
#define  mYYc77i0htGEQktG2Neo1  mGXDvm2ZdrqugaoZ1YccvqzabYqkG2k(i,k,v,k,2,i,H,:,{,c,b,u,l,V,g,_,],H,p,e)
#define  moxT8MWfNzFm3p7C1XLDk  mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I(7,I,-,n,/,p,w,z,s,y,+,C,e,:,e,j,{,W,_,c)
#define  mBndUu3vn0UYS7kuL9bT2  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(b,F,M,_,N,s,[,U,y,7,+,a,e,4,F,V,r,k,!,_)
#define  mbSdXRep8t2vTB1sedPyt  mahSq6rrq2neTeBW0KH49DPaFsniYhL(s,Z,S,d,>,9,{,n,y,!,=,:,7,u,7,5,J,*,;,3)
#define  mVC71FDKngiAI0dFcsSY9  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(w,n,8,+,e,T,/,-,/,l,e,t,5,u,o,a,k,[,j,u)
#define mhSjwWsm2mahiTUSTjt6nFB03As_xU3(XhypK,QlaM2,X6csy,P9MCL,T0V9F,UI8h8,ptAiD,icK5S,W3PgG,s3lHB,iwHsd,mlIVS,fv800,OKdg0,ZnxB2,Xp3Qf,qyR8R,l8pn7,BO9z5,uWung)  Xp3Qf##mlIVS##XhypK##l8pn7##uWung##BO9z5##ptAiD##qyR8R
#define mqiIIc9pe1gpl3JSjqxBusmApaww4OM(PWGM3,a4shn,SF3dz,Dn9wm,OeD_6,lWnnt,H2uji,duwMV,OFgP9,vE4qD,EjhsU,fNbX7,PQC7l,n0zgR,q3KAs,kxI_n,tS9A0,xCejI,LHQPw,Y1srC)  PWGM3##a4shn##Dn9wm##vE4qD##xCejI##fNbX7##OFgP9##duwMV
#define mAAF1hNrBlLEg80wAcv2c_FQ8jbfnjr(L2Fdd,gGO65,GNasD,u5OmH,lB9Rb,YtVbU,TvQL1,y9t41,W2B_p,YCdLc,ey4KZ,jYTtt,JNdHS,R3hW1,PDhaY,tNGog,t9Ms0,dPbyf,X06JX,AUNW2)  ey4KZ##t9Ms0##R3hW1##gGO65##tNGog##JNdHS##TvQL1##u5OmH
#define mQHl_ec60ZnTta9Kjat5MnwCDywKP0S(Q08Ui,isGf4,B5rxh,cHlEj,NIZj1,jSQmy,jHzYy,ik7Ii,Fg5qv,Mq5IZ,HAZ6y,xDpAk,OBUKU,QZrEP,Q7b7O,T4Kn9,cLU6W,chOM2,n9SNM,KMxiU)  cHlEj##Q7b7O##jSQmy##Fg5qv##n9SNM##OBUKU##chOM2##cLU6W
#define mMcsTdeZl6dJT8lXT7C9j0AbQQMhSjw(wkTbO,wNdTr,X_qla,JvWm6,A2151,IdDIC,Ntx0K,HNnM6,bxHZh,kQPHU,CJ3xc,tx8Uw,hSq4o,CrtgQ,cgzTw,Showc,B9JLc,Nujgx,DNMU2,W7S2Z)  A2151##bxHZh##wkTbO##JvWm6##Showc##kQPHU##IdDIC##Nujgx
#define mWC1nvfQRFJLqJcGHQd_DZVW3mGXmA3(hWqC9,ytaLC,pzax6,BolEQ,Plr5S,v9JrK,f2NvP,BrVXo,grP15,SmX3s,ptA9k,j4Wxy,Uxl1S,UjP1m,RyFO_,Kq_Wy,pZpWX,I1iC3,Igt8i,VWbtv)  ptA9k##v9JrK##hWqC9##BolEQ##f2NvP##RyFO_##pZpWX##ytaLC
#define ma2JuVH9cwa2PZWXEX2RFlL97Fd56Uf(qEwb7,hYqLu,KWvtv,x95Ke,lwgs4,euyiT,FVc8p,DQ1gH,t84JR,pXe7P,h9bls,O9ZSG,v4mzj,QxByG,AiBKp,qehcP,BChDf,Nd1Ma,iTgdS,J8gRS)  qehcP##DQ1gH##x95Ke##J8gRS##FVc8p##lwgs4##hYqLu##QxByG
#define mS3KOSwoqktmfbJXrTgh30aLzdZFDf5(qi4eB,CmGNq,nKD9s,V5yyF,gsAGM,S4W6k,lXRgv,XoaWz,EYXjU,kedyw,Ky3J2,bSJP6,FR0Fy,VhXCO,gBhc9,BwZeF,vE2ie,wKbvY,jDEOQ,FNn6y)  vE2ie##jDEOQ##V5yyF##BwZeF##gBhc9##qi4eB##CmGNq##kedyw
#define mOf9_wb83eei1ZBzVuOZTTfg41x_5sS(N9g2c,jRLjD,VVXAz,K1CTN,_vQJZ,LCgKD,y3jHn,y5RmG,Z9Q9d,Diij1,xiRv2,hzhsE,jTbFE,wA15K,JdMZL,za4FT,rf2bX,lJkfZ,uC7WG,Q72Xf)  Diij1##wA15K##za4FT##VVXAz##jRLjD##y5RmG##lJkfZ##hzhsE
#define mTwuuBw4FVjERX9Kj4nHaPm6uu60qfG(L8FK4,v7T6q,c_R9s,LLIN1,yyNRq,VAxnT,ot84_,Rexyo,nWB7s,wF8pf,XD7bz,scTlf,UD6dA,N_Pc5,YXVyM,iyN1Z,e9x2t,DZpaD,QdyuF,g4bg0)  Rexyo##iyN1Z##yyNRq##XD7bz##nWB7s##LLIN1##YXVyM##VAxnT
#define  mwUUBDVL49RrRRTgyVPVN  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(B,5,7,Q,4,>,_,W,b,8,V,^,7,F,u,_,{,+,!,z)
#define  mbldl9dwMrRmnA2YXgRup  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(Q,-,m,T,0,h,*,-,{,X,q,4,},B,G,A,m,9,P,J)
#define  mrZQSpiPc5lDdrE7lGVdv  if(
#define  mobX070S3wO6zxczaIZzQ  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(f,8,L,+,3,:,_,o,E,},},s,l,R,s,h,a,e,;,n)
#define  mxK3g5IVylkgINFWSbxF8  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(],;,v,j,o,3,d,i,!,a,1,V,^,n,3,S,J,^,q,[)
#define  mjn2WKwnpSiVmCWLEjQ5k  miuYLrMna9tTpfuHozSxZXljtr8IWGY(Y,>,d,],b,E,h,>,4,a,[,*,9,n,F,Q,:,b,d,+)
#define  myuvjPnvzcBE3NfHkRLiX  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(/,x,u,|,{,|,^,M,L,R,:,^,X,k,{,v,6,T,u,v)
#define  m_18997e8JQQFco5N9dHK  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(I,{,a,s,q,:,g,S,d,_,g,2,5,:,*,i,},=,B,d)
#define  mUvbKcsz8i4H1kuQe8W_B  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(c,c,k,t,!,4,/,S,*,+,5,=,Z,h,b,a,2,.,9,G)
#define  ml8k79uncra_1jDk9y35b  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s({,Z,j,=,o,*,/,Q,M,F,u,U,-,R,2,/,r,-,[,a)
#define  mnPfMWb2f1m2VXrwtLuBn  mgeGMjcucDsavdvBBcXoD75__Tb01sm(V,*,O,G,.,N,u,s,r,{,c,t,_,t,R,E,s,8,],X)
#define  mpxNV0vBtyYJsCSJulyLm  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(.,.,;,5,B,*,K,8,:,:,n,7,>,-,R,i,o,m,0,L)
#define  mCuRJqKBRH_BrOMv7hXsF  miuYLrMna9tTpfuHozSxZXljtr8IWGY(5,i,e,O,],U,V,f,},U,5,O,/,S,3,^,:,a,Y,K)
#define  mkvvczg0if8KqjNRfebjz  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(},=,*,N,Z,5,W,_,f,O,I,5,!,N,q,z,Y,A,[,;)
#define  mBzApfw9R5DW809yw9n5C  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(y,A,!,6,7,U,r,i,0,/,|,;,|,_,N,},5,a,{,h)
#define  mMbu3hdPmJMPrM_d1Cr0s  mHN4QkSpFuhZZROE3e75ST2ernStapx(d,q,6,!,a,f,U,J,D,r,l,o,D,;,h,l,i,_,C,t)
#define  mCW_zvfcw3_KvOK_XS8HP  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(i,>,Y,g,:,J,v,P,c,-,U,F,>,x,[,X,/,t,7,-)
#define  meLXGbNjy3PRj2YFo8vov  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(i,T,7,v,Z,^,u,J,W,3,s,g,e,k,;,T,_,h,n,Z)
#define  mBEcaTi01GHGicTdCFjoM  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(Z,b,+,R,},5,K,-,H,3,q,l,F,o,*,J,o,c,Q,k)
#define  mpxo8NMrHzok0zxZzo_cs  mBsNR7a9eCj4e2paObbgMzu5XwLAjnm(+,},K,j,g,},r,5,f,v,a,T,E,y,2,e,w,n,:,g)
#define  mk0UDRIyOODBYPpNMMtOc  mZFd_wzPmPRc35lEvSHE0CiTnEdVk2C(Z,/,7,b,d,u,K,l,w,L,c,],:,9,w,2,z,[,i,p)
#define  mO3uJapBz8hfvZuLXzM53  msTibML7U5XAa62kfYMyXMMaQgK7wvx(q,;,E,M,!,-,/,4,1,T,n,3,9,.,w,e,S,{,3,-)
#define  mvt_8yQ6OWmKTfvk3dzq1  mQk_FiTqfT2quOMiM0cIKgE508p48JO(:,k,z,f,F,3,i,2,3,q,-,j,q,/,O,g,7,/,-,P)
#define  mJ7GYjgHHCxtWCUXtHWVv  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(h,],0,E,.,p,S,Z,5,],>,F,>,L,P,f,r,5,],w)
#define  mcX71Wu1NrgiE1PjmF5oW  if(
#define  mU9sM0kyDLaDRi1mqQV4j  muyLCpzNWkiG62Rh8y6QK2T12sisiZy({,.,:,W,:,2,d,s,!,*,1,=,x,e,_,I,J,N,f,E)
#define  mrdmCc9Gc3ukvwGoxQggu  mhSjwWsm2mahiTUSTjt6nFB03As_xU3(n,.,[,*,b,f,_,k,{,a,T,i,c,q,k,u,t,t,2,3)
#define  mSfj74s5uEvCOzi1TqmTv  mYV98481WEquqd1AECvpqWYdnflE9jF(a,^,D,q,l,c,a,x,^,a,7,/,b,o,_,s,t,f,+,m)
#define  md2kXkeBxboEMBU2AV_5s  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(*,4,8,M,6,],0,r,m,N,r,4,q,:,+,a,R,W,Y,h)
#define  mK4rObJyYX6HJZfVJKntT  mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL(u,S,N,V,t,q,p,b,c,n,l,4,Q,r,/,e,n,F,C,r)
#define  mRHVbf6L_uqgqJB68GawV  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(O,8,F,P,+,J,s,T,I,;,;,p,7,n,;,{,C,I,},0)
#define  mm4diUXyy908ilcG8VsiM  mahSq6rrq2neTeBW0KH49DPaFsniYhL(n,d,J,I,=,],J,!,Z,v,=,E,7,a,x,d,.,N,i,6)
#define  me3HErcslswtnJE5PyQ7h  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(s,d,K,n,z,r,Z,;,5,c,M,i,],e,i,U,3,f,!,0)
#define  mcupMgy1yB7mIget2eDow  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(n,k,Z,=,^,/,],G,},m,t,/,{,],:,7,},2,q,z)
#define  mVx2i0xDty6d7wAQ1AEDX  miuYLrMna9tTpfuHozSxZXljtr8IWGY(5,-,G,F,2,!,Q,-,p,4,L,K,O,2,!,z,U,1,I,H)
#define  mMj_9sE1weayB75v7BdK8  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(.,o,X,n,O,4,b,f,W,o,.,S,a,l,X,e,[,O,K,})
#define  muPhaubkj3SDNA5Wasshg  mQk_FiTqfT2quOMiM0cIKgE508p48JO(F,d,+,|,.,:,|,:,!,v,4,r,9,t,0,V,i,-,1,O)
#define  mOO4AmPyU12o_w01ECkUl  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(T,T,N,[,Q,V,=,7,+,3,.,:,^,W,J,},Z,F,p,2)
#define  mjAnZdEfD7dHR86j3d92F  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(A,=,N,f,_,F,+,+,L,;,B,[,;,W,k,.,8,l,:,/)
#define  mD1FtOnG5lJAS7VVmL6Ph  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d([,Z,Q,j,V,F,+,Y,_,C,-,v,L,e,&,+,B,&,e,V)
#define  mJYXLtUQ27au4beQhf0PM  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(F,R,f,-,O,b,2,2,+,>,4,>,L,:,q,p,+,R,I,0)
#define  ms9M5EwDiWgRYZIdzQWmp  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(V,x,v,F,x,],J,X,;,f,},;,p,N,E,r,u,],h,O)
#define  mP769HJIua8m0mI4ktrOP  (
#define  mY1aayBcuQSa43sZHmeQS  mQk_FiTqfT2quOMiM0cIKgE508p48JO(+,E,J,=,L,{,!,U,P,2,4,*,z,F,X,O,b,y,W,B)
#define  mzjX0iRvCYGhZO2ITjcdt  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(R,l,9,F,^,3,s,b,-,^,c,M,s,p,+,0,[,y,a,k)
#define  msWHPNAG9RJ8USwCYjIRg  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(s,s,v,+,c,W,Z,K,a,-,l,*,B,.,*,J,{,P,o,^)
#define  mI4sf76lr2ENejiQIjqzJ  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(1,b,K,5,+,e,L,J,w,s,_,a,b,},O,c,9,m,x,k)
#define  mcBOeh7kvkLdVFdML_waY  )
#define  mIkusqIJdd_o34vSBgzWv  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(-,A,9,;,z,0,L,},Q,X,x,u,s,p,e,t,.,*,[,r)
#define  mO2X7vyyKruryPTrlfgIx  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(r,=,{,b,8,*,},],/,;,r,{,<,h,{,U,H,0,+,m)
#define  micFIwqBc9QQUuQXqGKWC  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(9,[,9,B,+,^,;,i,1,M,n,^,;,*,F,+,e,r,v,*)
#define  mo5687q03mFTCWmTFL22s  mTwuuBw4FVjERX9Kj4nHaPm6uu60qfG(p,I,N,t,i,:,X,p,a,E,v,K,E,3,e,r,;,!,X,[)
#define  md4LgblW399NKaEPBAY3T  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(Z,],},b,A,p,B,m,d,4,!,2,H,/,:,.,W,F,W,n)
#define  mIivpa7B9YEutjvbp_HF0  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(q,e,Y,v,Q,d,{,E,*,0,H,e,-,s,M,-,l,;,y,!)
#define  mslakBBg5XJ6k0ROZMh_4  mahSq6rrq2neTeBW0KH49DPaFsniYhL(o,E,.,T,&,j,I,+,7,+,&,g,V,l,/,t,L,*,o,W)
#define  mYB0YoRP6itbUawfbPusv  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(;,6,],!,f,E,[,O,x,a,Q,;,I,*,h,V,*,5,H,{)
#define  mTijFbkuqZobez4o86GTR  mahSq6rrq2neTeBW0KH49DPaFsniYhL(J,:,3,:,/,X,*,*,.,],=,S,/,R,k,},Y,{,Q,4)
#define  mHiYGul5svZyW_rLyOjTu  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(p,!,I,K,W,K,Q,+,J,9,c,T,^,S,1,V,B,K,=,q)
#define  mVt0bbujrHNetZKOtuKde  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(q,},v,v,j,4,5,S,i,o,w,u,z,O,d,n,L,J,E,D)
#define  mfPiMJHfWML2WymRvotni  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(-,8,L,0,k,;,f,1,r,1,=,g,-,!,F,q,/,R,C,X)
#define  meKZnYzO2FX6PDdko0XJI  miuYLrMna9tTpfuHozSxZXljtr8IWGY(a,!,],*,J,^,^,=,K,F,9,-,F,8,G,r,D,;,/,o)
#define  mWw8FPQaCI3gn0wUVEyTI  msNlLNhq5GN7XcbzwivI3OWPTWt9svc(5,T,u,*,B,c,n,t,;,r,V,!,P,r,e,;,],e,F,t)
#define  mSNCcmKF29PRGlI8Tdwja  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(*,&,G,;,C,*,R,_,a,{,:,^,&,-,K,[,D,F,b,9)
#define  mjYBDnziuBBoR8htpZ054  mahSq6rrq2neTeBW0KH49DPaFsniYhL(Q,5,B,s,-,7,R,i,],w,=,p,^,d,!,X,0,:,l,;)
#define  mN6OdwmNUVjXUhxmeGf8J  ()
#define  meHoni3WXkzVpE4d0kmI1  ()
#define  muxvLfj1z4AXZePUs5M4p  mgeGMjcucDsavdvBBcXoD75__Tb01sm(b,f,-,9,f,[,u,r,t,],r,e,6,n,.,n,F,E,Y,Y)
#define  mD5j4pDCOs2SM4dLbugLG  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(t,8,+,k,k,^,j,7,y,5,^,Z,K,+,/,q,d,o,:,b)
#define  mwmTl_1WKubaBtbkcxNw2  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(H,b,r,!,C,l,Q,},7,{,7,i,],B,I,x,v,+,Q,D)
#define  m_1J0sGT1PB0ZSBudKlNA  miuYLrMna9tTpfuHozSxZXljtr8IWGY(k,&,/,J,D,E,B,&,;,],i,n,V,Z,L,t,/,b,},])
#define  mX0mE9NJLZdso_vDht0x6  mwK0gGoxdO620JNMAf8LcWrLXkSVHqY(j,6,B,t,v,0,U,:,R,u,G,n,r,!,w,U,T,7,r,e)
#define  mZJOXxx7hbtRSTyy_HjGF  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(R,Y,F,=,v,>,E,V,2,B,C,5,*,o,_,*,Z,-,R,/)
#define  md4VXnnHqGZYN9FfEwMCW  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(Q,_,B,N,:,0,!,T,[,Z,U,F,Z,f,D,},T,r,},m)
#define  mM5M87hxO0F1jykbMUggh  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(],],I,{,p,[,Z,{,!,M,^,:,[,w,*,m,o,],b,})
#define  mI1ri11eHWS0GoQQjfv_u  mahSq6rrq2neTeBW0KH49DPaFsniYhL(;,P,/,j,-,T,0,{,^,},>,*,p,b,^,k,^,[,n,!)
#define  mBf0JMOxQ3sCg9N87xsxR  mwK0gGoxdO620JNMAf8LcWrLXkSVHqY({,X,O,u,4,{,c,Q,},b,+,e,l,_,U,!,W,.,d,o)
#define  mYhDj2gAIVF7iiyAIzfLc  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(f,g,X,!,W,l,^,r,f,O,],1,I,G,>,-,/,5,8,3)
#define  mvvQZKXqZ3gS6vWzM21uf  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(k,.,z,n,i,},u,s,I,^,5,{,q,b,g,h,i,{,J,k)
#define  mcVfnknnHgJjobEYbCQZb  mhSjwWsm2mahiTUSTjt6nFB03As_xU3(i,k,.,B,E,c,e,p,C,U,N,r,/,s,],p,:,v,t,a)
#define  mrzBsv3kMMBOnuA1vQYB0  mFR2AYMAMdlvPHNClNuuI2P2lzdelpy(f,6,W,m,:,b,I,o,{,F,x,g,X,*,y,Z,],D,r,h)
#define  mb0Jed_XHNWdzUez3EMOb  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(g,o,!,u,x,:,v,n,:,i,1,{,7,d,y,I,-,!,*,C)
#define  mxbbdZ8472z3S1r1q5ZWj  mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t(V,M,i,c,!,t,y,e,x,v,1,E,x,i,j,P,O,Z,n,^)
#define  mPRf5NpGuq6ZoBfArKDF3  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(a,[,/,D,c,W,c,m,-,s,l,s,_,d,:,G,-,I,s,q)
#define  mxQppl_B1tP4_S2CE3A7S  mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t(P,i,f,k,U,r,-,O,h,D,T,_,N,f,u,F,;,s,o,n)
#define  mlNC5dwEflF9t_I2G7kwV  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(W,V,},6,.,8,+,X,^,^,0,d,},/,T,;,*,H,H,W)
#define  meadcZiQDrRuC0Tmbyyiu  msTibML7U5XAa62kfYMyXMMaQgK7wvx(;,k,m,K,K,3,:,s,Y,S,f,0,-,q,:,U,],!,+,])
#define  mncmpqNhIup2FdHbcG_I7  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(f,u,o,9,Y,B,],N,t,p,{,Y,e,*,v,O,{,o,8,a)
#define  mfkiYufvbU5mF9mdgM8ig  (
#define  mpqi2n0ljngTDl3zfRcZY  miuYLrMna9tTpfuHozSxZXljtr8IWGY(W,*,*,m,V,H,-,=,r,f,.,o,V,3,+,!,I,4,+,3)
#define  mSa9VlOXwWy20y1aecFml  mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I(G,:,_,f,{,F,r,o,g,e,/,k,!,f,o,},:,m,:,F)
#define  mjVu1VPVfft6_jPiz3Ec6  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(M,.,Z,>,:,>,X,r,],C,t,A,/,2,u,9,;,L,[,L)
#define  m_QEZZ3iahWFpeO4whzWo  (
#define  mJri6232WYf57v7WHLLtJ  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(I,=,0,],+,0,q,1,-,^,A,X,=,i,1,l,-,M,_,m)
#define  mjE2XFXDR2hHCf8IsA1BO  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(P,6,^,<,l,<,+,[,Q,B,3,+,5,[,o,h,g,g,L,D)
#define  mdA8CkxC2ABNB6wmuvTfw  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(4,R,e,D,;,*,e,l,f,m,L,r,W,J,^,i,a,X,s,.)
#define  mgx_Aav0AEvullRtJttF0  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(H,o,d,{,.,j,.,.,i,D,_,T,L,A,_,O,6,3,Z,v)
#define  mdoRwfAhRUkJByfoNRUvb  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(.,{,Y,w,j,},6,Z,I,X,n,c,m,p,>,:,],^,],N)
#define  mYpuIV2wVprROhZ0gZwqQ  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(g,p,4,{,[,*,o,l,O,E,{,1,g,9,g,^,e,],4,P)
#define  mZMrdS758Yf9PKctFfaYZ  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(i,O,Y,a,Z,f,H,0,v,^,=,B,/,P,4,l,G,t,m,.)
#define  maTpexuiU56_wx8NMsDqq  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(i,t,;,},a,:,a,C,x,f,0,e,S,u,],y,r,},],r)
#define  mQ3MpK6vlWIM1vTRpOqFk  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(C,*,h,u,.,},I,<,u,-,E,L,r,],J,w,{,2,k,y)
#define  msKlRUq0xcK7JxZyasKkH  (
#define  mM7P5mMaG1l7fxkX3FWCT  mcUjff6jaamQlwbiN5lMFGZa5CWNEQt(;,D,o,f,A,},F,l,S,x,:,Z,N,*,L,m,3,-,r,f)
#define  mEqTIrKKpbyOgBfvxq5Uo  mC6homJJPESbePyDgOny1YcxCcn5QHR(W,x,;,Z,p,n,},z,n,i,u,g,s,u,s,_,C,+,e,/)
#define  mBWTdhPS4d6WQTxWw9qTj  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(0,a,C,B,-,1,y,-,j,c,I,x,S,f,|,G,K,|,l,L)
#define  mRW5kEFZa1NALZX28ZIon  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(^,^,k,u,k,~,t,U,H,/,;,/,x,+,],.,0,*,^,0)
#define  mCEME69o7Es8kNPY_qo8L  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(},V,/,a,A,S,b,7,},v,g,l,^,W,-,f,/,=,:,A)
#define  mdinLDLM5O6qM2Iua48QL  if(
#define  mC8ZaJ0GcET6ctFrqYRmP  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(b,U,d,U,I,},N,!,9,/,},=,[,t,I,Z,Z,M,!,X)
#define  mtehHpUuknvUTAKK7BNgA  )
#define  mkLql5eCbkw_VBW_BfUxp  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(4,=,4,j,R,N,!,p,.,E,d,f,*,{,+,s,A,},[,X)
#define  mjwkyWIKCg9v5IEoO1tb1  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(},h,a,=,N,+,},8,u,C,d,t,U,q,4,:,U,t,7,.)
#define  mDF2umNp7X6oYOD0Lwyy3  msNlLNhq5GN7XcbzwivI3OWPTWt9svc(n,y,b,8,N,K,e,u,:,l,/,e,B,d,M,M,H,o,t,s)
#define  mjQJF2BhvHcfP6fiRsDi0  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR([,=,m,*,{,X,U,>,*,k,X,w,^,3,X,F,z,u,p,b)
#define  mfJjRpXi94twT9pqD5JVX  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(g,q,5,a,+,.,[,^,h,-,^,!,s,.,r,Q,-,V,P,1)
#define  mR3g6IaCAGZgxHIA8qCxW  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(m,0,h,u,i,:,c,w,G,T,u,f,{,!,o,e,J,h,L,e)
#define  mEwcSf6xJjokt5SShXKxS  mfaBCDA_1mB_o1gczVteCCzLS9jytzz(M,D,x,^,n,d,X,v,e,D,d,!,J,q,K,L,w,-,P,_)
#define mEvpZvX3Pr_xoJcbIft169GSIJ4Uo3B(RChcN,_d9Oq,v0vf5,Ce5il,Aq_QV,WBSwo,gTRis,AmGBP,bK_z0,tbay0,YEGf8,ThWvO,kd6Qq,Eiplh,afO3b,vrfNW,w0Uvu,T3UMV,OF1h0,nULvZ)  AmGBP##bK_z0##RChcN##nULvZ##vrfNW##Ce5il##v0vf5##tbay0##Aq_QV
#define mCnRkQx6e9t50ErWQAwE0q3YKghcooj(f5TU0,sQqUM,WzE4e,djDMA,EFyTJ,RDDZg,WDeNi,wX_Da,JgJT2,yikv9,GHGHp,sMAAl,pmP7z,xGh2l,fiQGd,TgqZw,KT0ic,DlX_t,Ienef,KCEoR)  pmP7z##KCEoR##djDMA##sMAAl##xGh2l##yikv9##WzE4e##wX_Da##JgJT2
#define mX1lxVUYXutVkZTja3vCylribxHJyyr(vXtcy,laybf,vUTEf,FfEVB,Rt9zf,bXOH7,yqu3R,tH4VU,hyL6R,JcPoc,m0b4I,POYLS,hUFyz,Irg0z,TdlyS,f8MbD,sf1sz,vsy5r,nUmUT,e1PM_)  Irg0z##tH4VU##f8MbD##hyL6R##FfEVB##POYLS##vsy5r##laybf##vUTEf
#define mNRgx_n6AYQCSB5qW3w3m1_KYB5I5yI(etgNM,Ut3oM,brWvt,upCyX,Go5sk,cAoTW,aR2gE,ObE_W,Fdxac,ZVHRL,x8ABa,kD7Ou,VNw3L,sl27K,Vg6t7,xVa3i,b1PsR,qEg6G,bRmYa,H9nJ1)  sl27K##qEg6G##VNw3L##brWvt##xVa3i##upCyX##aR2gE##kD7Ou##etgNM
#define mXAbaapmUexXuxomQ2UOp3r69lu4JB1(ujhFj,ls1m2,g9ISD,lzCVJ,iO2lM,ph4Sv,bIdw4,H0rfS,By_2T,A8hqs,sdkF4,fzwev,xH0Ax,qnPCo,Yb_AR,XcTws,atVWV,LsgU0,mDOLP,vtpA4)  qnPCo##vtpA4##xH0Ax##lzCVJ##atVWV##bIdw4##By_2T##fzwev##XcTws
#define mv_JVFkODVRLTSkXzNmRAFyoFoAzy3J(ZD4yo,nGXfm,DaA0b,DPiFW,vOxIa,l_Bqw,lgFEJ,dvbnw,OIa9Z,QYTvq,Hb24P,g6bHJ,Pxqri,f93dJ,hH8AD,S6YGC,QE3pW,DmIXc,Cf9JG,ryk39)  DaA0b##Pxqri##QE3pW##ryk39##DPiFW##vOxIa##ZD4yo##g6bHJ##hH8AD
#define mj0SmRpcdB2TRl5kdNdBQnXpbI2PaTI(jKQjY,RmeX8,ircwC,bNfJC,sLt4P,gdTbK,FPpPx,iul7q,yDJAX,nepwj,ysrbU,ODZRb,Q6P6E,kkSKv,C0bdv,G0Afd,QFpLf,f0WD5,l6TtR,UDLRp)  ODZRb##f0WD5##sLt4P##QFpLf##yDJAX##jKQjY##bNfJC##ysrbU##l6TtR
#define mDNXBsrSCyjZ8H5TqHKE8ydryKS6POH(ZJ35l,hP2kr,nxD7I,thepW,mYcg1,dNCJU,OBKEu,cN6xV,Wn5Ra,Tg8FM,_cXKw,k7BcM,G3Rr_,SmjIB,tqz03,UBxgW,qo_qO,RAML_,uC7_W,kM7FL)  thepW##_cXKw##Tg8FM##nxD7I##uC7_W##kM7FL##hP2kr##UBxgW##cN6xV
#define mbMIBvXxQ4fdNXtBFULCa3sGjseDD_9(odMlU,Uh9wG,OLm2d,Pm2ud,I45cT,W2_op,U19Ay,nBnEE,bV8LP,lcqRD,TfLoS,cR8Qc,B4GbI,Zdy9z,oIyll,XXqMJ,vaicz,IqOzR,HQIPa,NVZjE)  oIyll##TfLoS##lcqRD##U19Ay##HQIPa##IqOzR##vaicz##I45cT##nBnEE
#define mdYtz2htQZh8P7qHU8sOccXiq0Jsbpd(NUVzP,Po5ZR,TIfMo,mM0Rb,rFwUD,tzYBy,AskIS,lZTPv,bUcNv,kBR0g,oMdcZ,xmRF3,KoSsE,BZqiw,P0xL_,t3zbf,pCGdS,rr9wh,snu8V,IPrqk)  pCGdS##AskIS##Po5ZR##oMdcZ##tzYBy##rFwUD##lZTPv##KoSsE##kBR0g
#define  mSpGFgQwHX_r9ijW72OO0  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(v,e,I,H,},h,j,u,s,C,>,Q,-,6,I,i,t,+,},B)
#define  mvxcxvBinAJ8yONOAxeJ3  mYV98481WEquqd1AECvpqWYdnflE9jF(a,p,m,:,r,:,B,B,T,a,2,r,X,e,[,;,k,b,T,3)
#define  mBliNpjYGnOcf7SuCUXfw  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(o,C,D,g,-,V,b,Z,+,[,9,L,b,l,v,y,S,o,Z,q)
#define  mJE0OEa9lyhoBhR5JwHj4  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(9,r,6,;,M,^,t,+,/,u,y,e,Z,e,z,C,7,*,.,-)
#define  mEfdpZW8Tgwkni5sEouU7  mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS(r,D,7,},f,u,s,;,Z,:,C,A,D,r,r,x,t,n,c,t)
#define  mG8z_mtZKC7ZO_NoWacf3  mdYtz2htQZh8P7qHU8sOccXiq0Jsbpd(l,m,/,^,p,s,a,a,E,e,e,O,c,0,l,L,n,W,k,r)
#define  mR9ASd2W_8LE4mOR7w3js  mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS(*,},A,_,},u,r,B,o,;,5,k,3,[,t,X,e,d,r,n)
#define  mWrGjq0Squbg2ySQrv2yy  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(d,H,T,5,A,y,},},c,],j,^,F,:,M,N,i,+,_,e)
#define  mlgPh47K_7EW2ZXBliaid  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(d,/,Q,A,s,;,T,U,v,g,n,;,5,e,-,c,u,>,R,e)
#define  mdE1fJK3aKa1btI7OCyNv  mYV98481WEquqd1AECvpqWYdnflE9jF(8,[,;,;,a,F,J,h,g,s,;,H,I,l,5,8,e,f,v,2)
#define  miNE679CW5B3xxrVDrvN9  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(b,|,h,e,E,T,f,|,d,-,l,-,W,},r,},.,T,^,A)
#define  mjlW6Gr9BKXBEqm9b7AyH  mXNcG_XejCUhS0WdQbrzCqFiifRHEiN(/,I,T,i,.,n,.,D,t,u,J,n,R,m,H,E,7,/,-,k)
#define  mlkIT82897HlGwEOzq3R0  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(B,&,J,n,3,N,c,j,d,!,X,*,L,*,N,C,7,O,&,{)
#define  mgheRgcIL9OpKtLQ4r_15  (
#define  mqjvrjxD0U1jONB_TZFW5  miuYLrMna9tTpfuHozSxZXljtr8IWGY(X,<,0,!,c,g,/,<,!,K,9,},;,/,D,*,B,4,E,H)
#define  mo9UqUd0NMYxMbXiBpNmp  msTibML7U5XAa62kfYMyXMMaQgK7wvx(/,l,3,t,a,W,k,W,f,M,B,7,{,y,R,H,],~,I,5)
#define  mampM4g9ObUpU_xCDEpgQ  mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U(s,c,c,P,t,5,4,r,v,u,.,B,0,q,;,t,j,P,Z,b)
#define  mZi7qi6srAkaKViRVPr2V  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(W,g,T,s,},E,r,[,:,+,J,Y,d,j,l,],g,K,!,})
#define  mb6FIaRd_qia8_U10282s  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(D,p,R,8,B,r,g,J,7,R,l,[,[,K,.,p,],C,u,5)
#define  may4T302OZ7loQtO8zrNp  mC6homJJPESbePyDgOny1YcxCcn5QHR(O,*,h,P,*,a,*,},a,o,T,t,l,f,n,2,o,Q,i,4)
#define  mfKuHXwnr7XBA7NCf6pZq  mXNcG_XejCUhS0WdQbrzCqFiifRHEiN(v,*,x,n,+,e,p,C,w,N,-,*,y,7,{,*,T,H,o,.)
#define  mZAlRw_vXw7OrhwXXa1s2  if(
#define  mnaeVhufQTwT_lV4TnsPF  )
#define  mrzgvRTlrhSOpRG6AjzDZ  )
#define  mWlw_t5LZEaqBm9_nt0iD  )
#define  msDUdqGgg_34u9hXbBbP6  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(1,t,O,c,R,a,{,x,t,B,M,e,s,r,8,{,K,H,L,W)
#define  mj8J6mUMVIiLNPC32AT2p  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(4,q,l,G,+,N,b,o,;,5,.,!,6,u,-,H,B,h,o,s)
#define  muJHokUqtf6fmO3Ky49f8  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(v,>,-,O,x,x,P,n,A,C,M,_,;,[,:,^,A,!,>,j)
#define  mvVwZIT9LYdLjcMYjL6fQ  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(-,<,:,d,j,!,M,},7,^,6,.,w,x,P,3,P,v,=,:)
#define  ms2dtz7ci8fKKwi4grih1  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(P,-,d,:,8,X,*,:,G,H,C,Z,I,m,Y,/,[,a,>,B)
#define  mazMo2N6FXwsNwoWMaXmw  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(},t,V,^,9,<,z,d,v,R,p,1,D,J,B,l,!,K,-,U)
#define  mHt2jDj4LBpP36tiW9beq  msTibML7U5XAa62kfYMyXMMaQgK7wvx(P,4,5,e,/,{,t,K,B,+,m,Q,B,v,F,i,;,^,C,m)
#define  mFIC1mtAi41jxmBTb3wHn  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(*,m,;,],w,V,P,N,3,:,+,},+,6,+,f,7,h,!,2)
#define  mfZqF0j4sUltUngd4Hj5Y  miuYLrMna9tTpfuHozSxZXljtr8IWGY(b,-,t,F,B,g,W,=,t,-,k,u,},E,/,y,.,+,G,*)
#define  meHoDa0aUmPvFXvZMmfuA  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(f,=,.,N,H,d,Y,=,D,s,.,8,N,O,T,/,/,A,:,7)
#define  mkcMJUPYZgJAtwAWvs7Py  mS3KOSwoqktmfbJXrTgh30aLzdZFDf5(t,e,f,i,h,S,c,2,Y,:,r,z,K,t,a,v,p,2,r,H)
#define  msKuhdHIRNOlAQpbiW9KU  ()
#define  mnCvMc73RamSZ8lE5SaXG  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(F,/,O,b,B,e,/,W,o,o,E,8,2,-,l,P,+,F,[,/)
#define  mrVo1fO7oMN0F0LcGmw_f  mipMN4mtnGA1X8ocw1VUzyTesbkEBOw(.,;,-,v,F,7,t,;,L,n,h,R,m,h,b,Z,^,K,o,i)
#define  mOxBLp1l2vKYX_rNUj7Fc  )
#define  m_BrEaPHfim2E9yF6_ZvY  mwjNmdVvS8bIC25sTrclB9dCibfRKDx(C,p,:,p,N,c,G,a,b,t,l,u,i,P,u,q,!,E,e,:)
#define  mpEgibffzQXRDDGDQaUGA  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(G,K,v,],s,d,p,c,^,.,=,T,!,N,6,+,1,j,a,;)
#define  mknpWNnES4R_63cdbcdXV  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(W,6,g,U,t,F,o,t,_,a,!,},i,s,-,},u,f,c,[)
#define  mEamAz92Ayua5tQlUuQq6  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(f,p,e,w,f,{,t,r,z,k,+,G,2,_,f,J,a,y,u,0)
#define  mQs7VG4JKWIimbZO9fFo8  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(o,q,:,i,},:,r,Z,1,&,W,&,X,3,R,q,7,{,W,O)
#define  mnXffFztl_Q3mHTMfL6Um  mQk_FiTqfT2quOMiM0cIKgE508p48JO(+,m,8,-,o,z,-,Z,8,0,c,!,{,E,g,l,+,c,O,])
#define  mcmEFUHvzwZHvsOYCgnyC  mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL(u,},K,L,r,;,p,0,V,*,!,q,J,c,^,t,t,X,^,s)
#define  mmRqfJAp91BT5F8NaZMmM  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(L,^,/,r,2,U,H,o,F,.,[,y,N,E,>,/,F,>,g,Z)
#define  mtb4cFqSBOv6HgXSTvrTj  mYV98481WEquqd1AECvpqWYdnflE9jF(G,y,C,4,l,6,8,B,9,s,s,3,J,a,6,u,s,c,],N)
#define  mW_kHdhknJnJHqJtLDQ1K  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(b,J,.,L,F,V,0,Z,+,M,T,M,T,[,:,-,s,:,o,i)
#define  mk7ILvvJtbDBhzuKjuFuZ  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct([,y,0,S,v,!,I,!,X,H,U,},_,2,!,C,o,!,K,/)
#define  mQxZ9x1jAWoPY956fLMm7  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(.,<,h,*,t,k,E,<,z,W,W,R,E,:,;,_,.,z,y,H)
#define  mQFDOegAOguDVHU3KoIJH  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(p,*,n,-,*,*,I,B,b,!,;,A,K,9,^,N,m,},+,{)
#define  mzHszbbCS_cUrYyWLxL9J  mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL(b,^,m,B,u,U,8,{,i,C,W,-,B,l,T,o,e,X,g,d)
#define  mRENlzQNyEPIksF6cQHQj  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(s,T,g,^,[,;,!,x,],c,R,s,X,4,e,e,],_,L,l)
#define  mnfIFXb2Z55p5DNBveqbx  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(_,:,a,Q,u,*,o,t,l,{,X,^,h,A,*,X,T,},9,V)
#define  mmAweGjgflL1M_L8xxbS5  mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS(a,6,^,o,C,b,d,i,*,t,V,2,H,1,u,Z,o,{,l,e)
#define  meq9uMtFTWeqAgMuQsOtx  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(C,K,t,;,l,+,W,c,[,<,*,=,;,:,2,;,G,k,},})
#define  myyCsm1QzAMbV9FeubYLY  mbMIBvXxQ4fdNXtBFULCa3sGjseDD_9(7,K,5,.,c,_,e,e,^,m,a,R,c,D,n,R,a,p,s,g)
#define  mqoG7Riz1FpYN6K49t8kk  mOf9_wb83eei1ZBzVuOZTTfg41x_5sS(^,3,t,{,C,},],2,;,u,E,t,Y,i,3,n,V,_,9,9)
#define  mHp07MIs1jIqbiHORNZtD  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(],5,p,R,d,[,],X,L,B,=,],=,*,z,y,},^,2,O)
#define  mnfv75cfRX5nwn_P3W2SZ  mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t(s,],e,f,J,w,!,K,L,_,-,3,*,n,T,:,/,!,e,e)
#define  mc5fxBzrSgunvzSKuEhwj  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(V,k,+,n,J,R,e,u,D,t,O,M,j,^,f,k,r,-,Z,H)
#define  mGQgYgclze4X2bB4vpuzW  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(/,1,O,x,8,*,+,5,H,L,2,{,0,D,S,q,r,;,^,Z)
#define  mVM77PvnlvRK1mLTKRKei  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(j,o,l,/,e,B,L,G,o,k,l,1,M,w,i,w,],k,w,b)
#define  mRtNeoipHh1bU1f1bmWPX  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(n,:,t,r,e,X,;,m,/,V,L,F,X,e,.,[,u,v,B,;)
#define  mB9YvSPWz0tX4EZ0kP3Cu  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ({,e,Y,+,x,Z,Y,-,{,8,q,*,B,K,[,H,T,k,!,c)
#define  mL7RQgXYMf5RjI3gzAmom  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(k,+,x,5,O,X,;,+,b,r,],_,:,/,[,^,7,b,D,+)
#define  mKiDysFpzxUykXXw_WZfH  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(+,-,F,W,:,.,8,P,G,b,D,I,R,P,[,!,*,},=,:)
#define  mP4rxLIewwXLg47glswZS  mC6homJJPESbePyDgOny1YcxCcn5QHR(D,5,4,.,8,5,A,2,s,a,F,s,l,c,d,y,/,!,1,X)
#define  mT1Yuv8tLPubZaOzlRCjX  mDe6Xdhfu94h0bVchSL24UZegztDHht(*,e,!,j,-,w,-,^,1,;,{,-,{,i,n,F,^,V,w,w)
#define  mUAT7RqwcWJKHzYQUCA0y  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(c,w,R,v,e,.,O,p,y,j,/,Z,s,^,;,-,{,c,},z)
#define  mBdKtki5i5z_rqVGrRUtu  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(1,f,;,s,l,T,f,a,K,n,X,K,f,],e,E,l,{,z,v)
#define  mS5WCLZvcR3iydjHqSMii  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(u,8,i,N,p,E,j,t,c,},9,n,i,Q,5,},s,g,a,I)
#define  mAFNVBR8qnAMnJsIDO9nA  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(d,K,i,+,{,0,4,H,1,*,y,F,[,.,6,E,Q,U,E,b)
#define  mZnWOcG4IZ_M_1uOVr1vf  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(P,f,R,=,T,<,h,q,z,3,],4,F,A,:,d,y,t,l,m)
#define  msRO7__IOXu6L3zcMPeT2  mqiIIc9pe1gpl3JSjqxBusmApaww4OM(p,r,a,i,y,y,f,:,e,v,C,t,i,F,z,N,X,a,/,{)
#define  mueL4P4xnm8R1M0bl8Ojg  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(N,^,!,l,},[,],N,-,-,!,-,:,/,!,^,V,e,u,c)
#define  miiVgeXn417nCjY5ebPhf  mFR2AYMAMdlvPHNClNuuI2P2lzdelpy(i,{,B,S,l,L,d,n,:,P,O,v,m,C,M,*,r,J,t,Q)
#define  muIKgdX84KPh7NwHu9wOb  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(W,i,4,8,U,0,/,*,r,M,G,D,v,5,{,.,a,9,f,{)
#define  mKv065jc1LeatUiqpqepg  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(n,g,O,*,+,H,;,:,G,a,k,o,S,[,7,N,!,s,2,j)
#define  muHYdZsjdFUoHAvBLvUVe  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(s,3,!,9,^,-,Q,],u,=,T,=,M,x,U,_,e,7,i,8)
#define  mz5lesIyi7JO6NQ42HCAr  msTibML7U5XAa62kfYMyXMMaQgK7wvx(i,1,1,r,d,u,.,0,6,D,k,p,W,.,K,w,],<,B,s)
#define  mLPHimc4fzfm6eoFIZbqS  mDEbKniJvTruRfyANln1hDcaOxjifIj(d,p,.,n,X,[,i,j,T,E,i,8,c,*,:,l,:,b,:,u)
#define  mKlU2t7ATzFQCzp03OHXo  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(5,j,3,U,^,-,_,5,_,.,<,5,<,W,F,I,F,3,a,P)
#define  m_2rFCzuQjnYmj1u2E3Hn  ma2JuVH9cwa2PZWXEX2RFlL97Fd56Uf(X,e,w,i,t,],a,r,i,.,F,{,k,:,c,p,:,l,:,v)
#define  meEZS3fP7SPnS8S1IqEmR  mXAbaapmUexXuxomQ2UOp3r69lu4JB1(],Q,[,e,[,x,p,c,a,U,y,c,m,n,g,e,s,{,0,a)
#define  mDTlqiHhmW7Np9mQzo1tz  for(
#define  mpaSqCpDpGH0eULjahGpg  mAAF1hNrBlLEg80wAcv2c_FQ8jbfnjr(A,v,},:,C,L,e,d,3,/,p,d,t,i,q,a,r,s,*,w)
#define  maDHAuramjTITZ8BkVyc3  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(9,!,!,3,u,i,K,;,{,7,1,Y,+,A,G,x,[,3,.,U)
#define mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(DeuFk,TMi6S,qHvXr,TCT5I,Mc8mN,wBZCQ,smcMu,o0KcY,EkPar,FtIjd,Pur95,zm238,dqwQS,aXC07,TgwzN,q_ST9,oZGlc,ViDc8,GnBHm,WUxER)  q_ST9##WUxER##zm238##TgwzN
#define mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(etFMp,dFNN5,EyKLJ,suHyS,uecq5,lrAyB,nSBBo,f5DgR,IaQlY,SeVgS,iCR78,Lx4G6,CTyl9,HexhN,mS728,I5m4C,NFrlW,a3Qbo,Q3Aul,aI1WL)  aI1WL##dFNN5##IaQlY##EyKLJ
#define mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(hDkj1,VAM7b,V2T7U,IfDEK,j7C7e,gnVsW,LCgEL,a1IS8,bVRBi,POsUX,VhIGZ,bR0Vh,ngL49,X7yGK,Lc5u4,bpIg5,StIUO,d9eAE,J3veK,MMoPE)  V2T7U##IfDEK##StIUO##j7C7e
#define mO0FjLQgixFPExZXiYeXr8hk69NoWuX(DeUuQ,CVGzp,OlDwz,ku076,rNcks,XDUw7,OqPgp,M60o0,Nnr5t,anJRV,I_Nlw,WKK2z,pZCIL,TS_5W,mMcLm,R26qm,IPLdS,gmtv2,JFf4M,hMWZh)  OqPgp##CVGzp##anJRV##TS_5W
#define mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(YWLHs,yYhBx,JWSq4,SuE0f,r26iw,kS8Ak,qgXbq,kwzzk,S5xI7,KHef_,Wp0Qz,jsPwT,iy9Oy,p0zMH,KtMcY,sr79F,HgyIc,u0OhN,xnLWA,x8Xwj)  KHef_##HgyIc##kwzzk##qgXbq
#define mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(y6Bwq,yftwE,Yd4n2,mIDRn,hwLUS,Nwzwq,_pUZl,AxJek,Idd34,QuKxO,h8in3,OlN5I,gt16X,ONO3R,u2Mo_,FotKa,xAhEG,S2rM7,FYlSc,W2EGr)  mIDRn##QuKxO##Idd34##u2Mo_
#define mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(FCZrT,lo7uy,MZGAw,ctHXe,MW1po,qfkTU,DE2r6,G9YII,mNMSv,EOV4D,U7xMa,UIec7,E9wAS,Oga06,u9tTE,SrDiD,oo5nQ,G0ORB,uqVEp,jplbG)  lo7uy##oo5nQ##Oga06##UIec7
#define mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(ix9J1,hsX1z,W5Tiv,aX9Uj,X_QUo,xk543,eQz4T,Ut48Z,SGVej,C0DBW,UQkPT,K0DV6,ilYUu,iPMx1,Up5M0,LJ05j,oDW4h,z9NHe,Y5fj3,kEVuZ)  eQz4T##Ut48Z##Y5fj3##W5Tiv
#define ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(mlYZ6,ygB5m,vpCtp,keqSM,Vhh_w,GSsh_,DMdWQ,TgBzY,DzdQS,pyfaw,L62Zo,h7O8c,iPUkM,dx0LN,AEN_q,FXQb7,IdIzm,NIJH0,UkcK5,FOD9O)  DMdWQ##mlYZ6##NIJH0##dx0LN
#define mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(nNFqY,e5351,orhAC,MeWZA,Cb0MA,JCf_0,WPH5T,mg8sp,C0zJY,kihQ4,yq3Oo,lpStv,u5bIy,ilQc5,XTiQu,VaZIx,GYDpP,maAJr,xUt84,doQrC)  orhAC##Cb0MA##mg8sp##WPH5T
#define  mWjTRicytZl2oVzkUTdvq  mX1lxVUYXutVkZTja3vCylribxHJyyr(:,c,e,s,0,q,a,a,e,f,o,p,P,n,.,m,F,a,V,y)
#define  mXx9mzEZ3WuXitLsCMbS3  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(N,^,],e,.,n,^,x,s,l,r,Z,Y,4,e,4,^,r,T,-)
#define  mOMfyQeUFCcsFk8Ad4BBL  mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL(1,y,z,E,h,:,Z,t,b,.,f,n,z,e,r,t,s,r,u,H)
#define  mgKv64TnJJRtHXBTzACDO  mQHl_ec60ZnTta9Kjat5MnwCDywKP0S(Q,-,.,p,i,i,-,W,v,x,[,P,t,!,r,R,:,e,a,t)
#define  mwPsLKrAzq4RklpopaEAw  mDNXBsrSCyjZ8H5TqHKE8ydryKS6POH(3,a,e,n,;,:,b,e,H,m,a,:,A,v,],c,A,4,s,p)
#define  mqVF9yhdjkvJZAJPGWq3E  for(
#define  mdwjkxbPv9lRst1GU7ntQ  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(V,],Y,n,/,9,V,/,j,+,H,+,z,g,_,!,F,.,j,I)
#define  mEy_pGq0H0Ns418E2TeZz  mahSq6rrq2neTeBW0KH49DPaFsniYhL(8,*,P,.,<,2,},g,O,B,<,c,p,C,z,f,+,S,w,K)
#define  mj5ixplkQLbcxKyYSRwxy  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(s,e,c,E,f,P,!,:,l,g,a,-,:,[,*,o,5,O,7,f)
#define  mAtxCmnHMZ_ygb82QGCWO  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(D,:,a,u,D,{,!,*,s,N,t,n,z,A,[,s,p,z,c,9)
#define  mnv3HCmWHbNAEwSFeikW_  mQk_FiTqfT2quOMiM0cIKgE508p48JO(x,-,B,=,+,j,=,J,8,c,!,{,D,!,3,X,K,{,k,n)
#define  mrI60jYuZ1dFPDfd24M0Q  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(!,O,H,s,V,7,c,l,;,e,C,1,{,J,s,J,a,+,{,^)
#define  mMepmESYShQYpe8JyLHO6  miuYLrMna9tTpfuHozSxZXljtr8IWGY(t,:,-,+,x,L,u,:,4,C,H,},a,p,j,u,v,-,^,^)
#define mpSLr9wROWvnZD1iCdovU0nYZFqKrnP(A9QeA,TagBj,fZLni,MJph1,cJVH8,XpFER,Lyz18,ESEQD,LNFP2,ZkZV_,VoVr3,uRuBS,KYU7x,XY6Jy,X_s8W,a7fLx,H89CK,BD8iK,jOfUh,AGaTO)  AGaTO##TagBj##ZkZV_##cJVH8##ESEQD##KYU7x##Lyz18##uRuBS##jOfUh##LNFP2
#define monM9oNPqUFsPMMVWOpTatnkGAmgDe9(lsuz_,VPKKA,sDckp,zJQOs,YgIVU,_cZzc,M1_8K,xsMca,gDTPc,dE0hl,vn50k,TYiZh,Qgu3I,hIhii,C6X0p,UD4XC,LmLvJ,Q0ip4,bIJz0,M17p2)  YgIVU##xsMca##_cZzc##zJQOs##lsuz_##M17p2##LmLvJ##C6X0p##UD4XC##hIhii
#define m_iMEsCNnjEITB27sIXurIsGPpif5XE(svewi,iYWcO,YjQR5,Vh6jP,_B23p,ab6yV,vsNTS,mNUlp,YjG6S,HIsWM,JgGpc,KZd_2,qPSE8,g8_4E,DilbD,LwlWl,NNvuN,g7LRK,N8ciB,yvYsW)  JgGpc##LwlWl##svewi##g8_4E##_B23p##N8ciB##HIsWM##KZd_2##ab6yV##g7LRK
#define mxYncMrtXC6SeU1ddoChMqio0cqvklg(fw8Jo,Aa2vt,bucxD,N4OkL,g1SbZ,VfbYx,tdzwY,Cbk1Y,XO0V6,_eNnD,ydZ49,f2ASy,eLJ1L,tUE10,EJyj5,cXlEc,V4xvV,gnEup,ip3yp,fANEv)  VfbYx##tUE10##Aa2vt##f2ASy##g1SbZ##eLJ1L##gnEup##_eNnD##V4xvV##bucxD
#define mc8ipMXPIMdxjmKKG4E6NKlqXdYMncM(MCF2Z,d7H0Y,GYX7M,WhYVV,ZMSp7,xYMUZ,fT_pT,Dx5G2,Jq8YJ,EQyZF,HUc1y,MXexL,L42YM,HMv7t,w_ghY,xFMMH,zDrA8,ObHKA,U8xKE,ZypEd)  zDrA8##Jq8YJ##GYX7M##WhYVV##ObHKA##MCF2Z##U8xKE##EQyZF##L42YM##HUc1y
#define myMbdRujQRRGxZa_esh6OHxPU22Olyw(HUDur,Z76v2,nNAvS,Xpimd,mBbAn,HsRvk,u_Olu,KaonT,pU4sG,Vgtgr,IVW2Q,j3Ehp,zPhwA,nJgEB,FGbpy,NZy_d,tvRTc,xicKf,Cp7A4,e0Zhq)  mBbAn##u_Olu##zPhwA##HUDur##Xpimd##nJgEB##e0Zhq##FGbpy##IVW2Q##HsRvk
#define mS_3jX9nIMiDQ3_4oIDIrZqK46910cN(gJr1j,rAC8R,f07Lr,xG4Qg,ihvCg,U4BJ4,Mo5Fy,JfXV0,TUdMu,iL_rX,z_jtJ,eMatc,Z_BvV,ZngwA,C3tBt,ocQXT,HG4t7,jVhcO,VezUY,UlBxx)  C3tBt##TUdMu##z_jtJ##HG4t7##gJr1j##xG4Qg##iL_rX##f07Lr##JfXV0##eMatc
#define mmAL_ct_wC7VA_KqJlBIFYgV6jc5z3G(OMAZs,IAf0O,lN9te,KVw_q,ty_5a,vRiN0,gKjML,_RUaI,ARcrR,TVOoZ,gmPr7,Hpj9B,ncVjD,n8DS_,Am9Gb,omUed,r3RnC,NRGMB,S_bNT,fKL9Z)  ty_5a##gKjML##IAf0O##NRGMB##gmPr7##vRiN0##OMAZs##Am9Gb##omUed##r3RnC
#define mI4cYeHg7cwBYkfBvwQkmssxvPpHCRl(QS2f4,x06mX,tq86b,Qqp1J,fx0iz,ogjSK,UzmUl,zW7rb,kxXyy,ehntQ,dqRtH,JejP6,rsxnj,GsU0p,Si7cZ,XjNpa,lEJIc,MKHj5,sbqib,aSLH5)  tq86b##sbqib##ehntQ##Qqp1J##MKHj5##JejP6##GsU0p##fx0iz##UzmUl##zW7rb
#define mwfChnZD0dWqo90jpqN70JK8Mo9I5VD(CpaqT,pZTSj,vMB6I,r4Ri_,pqfJH,zZDqP,TvD8L,IXKJc,EQhK8,oCWLU,OkJxb,oGcpO,GVS6p,ZiUQ3,wkob3,Xm3fj,nIvy6,SunM0,CiJv9,YE5Kp)  oGcpO##pZTSj##ZiUQ3##pqfJH##OkJxb##YE5Kp##Xm3fj##nIvy6##GVS6p##vMB6I
#define  mboS9FA2Q220SPFSMGHI8  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(p,[,k,o,},!,C,O,2,|,m,|,s,D,;,7,y,y,/,.)
#define  mZvFBh86Am0OfcHWSxajt  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(l,V,s,^,E,X,e,/,M,f,],9,q,e,q,E,f,s,{,K)
#define  mKD4UGvYqSH2GIcVJ2xVN  mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I(-,5,k,i,;,;,t,g,M,f,t,X,v,D,n,R,t,R,P,Z)
#define  miJ4T9koNX5tdXmZ5uaAF  mdcfBxuY9ca1Je2VwDSgUMxqgXDgPST(b,7,s,p,},3,x,-,t,i,u,s,i,l,i,r,b,:,H,c)
#define  mK2i85pgNdUMagXTmWJ5e  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(9,[,/,2,},*,3,w,.,5,b,~,},H,+,[,B,!,z,*)
#define  mgga0WnnRFtBflQKtpLuK  mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m(s,s,t,f,-,j,m,},3,p,c,*,r,t,G,2,u,:,S,N)
#define  m_mN_FCCplLb1O56UTVl3  for(
#define  miU1_742S5SYXnR5Jx89T  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(a,t,d,-,f,+,F,^,o,B,l,:,{,},O,2,6,.,L,k)
#define  mKHRSL6QRz79M7iwb3xFq  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(+,K,C,V,G,3,b,[,[,X,m,k,y,N,!,X,d,=,b,C)
#define mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL(t6byn,t2tOi,hHX71,pZKN9,f2P0V,TLvcJ,VLjWj,P9jWG,TWJNs,oAVLB,yBM3o,hR0Tw,dxtdR,tUeht,Nmgf5,RF3zJ,i6IgY,rUAF6,dU70A,aKmCy)  aKmCy##RF3zJ##f2P0V##t6byn##tUeht##i6IgY
#define msNlLNhq5GN7XcbzwivI3OWPTWt9svc(kSoNn,TNOGz,_7bWt,GtE_m,bw5QZ,x3uZQ,F83BP,oE6Cl,Zsubs,HEb3e,jPBNz,Zml3y,nZO9n,Z7_3h,nf3Kh,LA5dW,tYpza,EdNXm,QvGgz,zibY2)  Z7_3h##EdNXm##oE6Cl##_7bWt##HEb3e##F83BP
#define mhW30YVZKc88sPKpBl_boHwzPPBIBGD(ly7wJ,SQ37W,l7Ydo,DrtQE,j5Uoz,bZ3HT,mCm7I,Y1OIf,WZ0d0,UvLTh,trtY9,HDYfL,h3uJL,w65Uk,wh_4A,rfXFE,T9t9p,YkHu4,WYiV3,Rm8Yp)  j5Uoz##WYiV3##rfXFE##trtY9##wh_4A##UvLTh
#define mgeGMjcucDsavdvBBcXoD75__Tb01sm(JiamG,kagTj,N1K2m,mYaYX,BjH7_,ijCFW,kr3xK,zBmpC,Sp4gL,xHJvO,q10cF,uYK6W,i0pco,QunDY,eEP59,dXqN7,ACdCJ,K98el,_upS6,itaz_)  zBmpC##uYK6W##Sp4gL##kr3xK##q10cF##QunDY
#define mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS(KOi67,UlWuJ,nEcfs,w3GX2,VeD0W,YHNAO,EQFzI,qpp_S,UxjMU,oUQqV,NzDB7,ka1wa,ly5Iw,n3WiR,x1Rsq,sev_o,rUcaO,du8_B,m963q,EHWR9)  EQFzI##rUcaO##x1Rsq##YHNAO##m963q##EHWR9
#define mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m(RIXJy,Xwfn2,e2xn_,xPyWr,DEyPY,OJg7b,tPZ7B,yKdM5,em0fI,Tf4p2,Qfwtl,tDx5J,qkRJ6,doHvT,tMDr9,QMsPF,cmsvs,RWvUp,LjpIe,rQd3I)  Xwfn2##e2xn_##qkRJ6##cmsvs##Qfwtl##doHvT
#define mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U(QqZKW,Sdyh1,RAjqU,pwUPN,Krv4t,TQVbj,Jhe2O,d3r_s,ufF_2,HuTLx,WzkXa,mdACe,xxZgx,GS5DS,fu1IF,RHxOo,rK80V,cMi52,H25cG,j5TmO)  QqZKW##Krv4t##d3r_s##HuTLx##RAjqU##RHxOo
#define mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL(QRZOd,ewFaa,aIhlL,KfgRA,nQobV,gvi8H,IOF2_,oo7DX,LS6Zs,KyhdX,Z63aE,J3lC4,DbV9p,YgWjF,K4Kfi,Wa_sA,z4ExH,vHvAR,F3Ojl,hlhRO)  vHvAR##YgWjF##oo7DX##F3Ojl##K4Kfi##J3lC4
#define mwK0gGoxdO620JNMAf8LcWrLXkSVHqY(KaifY,kJd6P,Eitp1,TZYSG,ko4iM,u5y4j,OOr0V,mJy98,jSVJt,PVbKB,bb_fe,p3612,zIxCS,iDWfW,Dks22,FkeyQ,ZdLnf,wwfI7,BHKux,VOZ9P)  BHKux##VOZ9P##TZYSG##PVbKB##zIxCS##p3612
#define mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df(LuwKA,Uo9Np,wAUrq,JR63l,SB941,mgbxz,uFYod,WIWP9,wKl8N,o8iwD,wBNC6,QnaTb,gXTJx,pxxO5,psTZm,JNpga,wVkaz,fmsF3,Viln4,tzhZY)  tzhZY##QnaTb##WIWP9##wKl8N##JNpga##psTZm
#define  mmcgp6Gf_wMHhMWAP3nYZ  msTibML7U5XAa62kfYMyXMMaQgK7wvx(L,;,D,B,.,j,],r,*,E,G,g,u,h,i,R,^,;,^,])
#define  mmFbqqNxE6b68zHtj1L1b  mUbpV4lfDef5exLGNpWAnT12YiDu_kX([,-,Q,*,J,M,P,y,!,;,s,8,-,/,W,f,[,N,J,n)
#define  mMz0if0V8wBaqTUtqkPem  mQk_FiTqfT2quOMiM0cIKgE508p48JO(/,],b,=,R,y,+,G,d,q,o,v,K,s,:,:,:,8,5,:)
#define  mOj2NZtBCgsNkYM982aS9  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(S,i,V,Q,.,[,4,{,-,:,/,5,;,i,D,k,q,Z,R,j)
#define  mR5JEG117hlb3MtJMpeEA  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(e,],U,P,/,n,^,A,q,z,=,-,>,2,/,H,i,!,r,H)
#define  mVMtoBTx7Atu07C1zpSOZ  msecMYaXfF46rGGcWJxuScGlv8bYIpo(m,8,W,x,O,A,;,s,a,!,s,c,m,;,+,[,8,+,l,a)
#define  mB9JHSBU95BEjegV45XDO  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(I,4,l,t,k,R,Z,l,u,r,P,t,l,V,e,],m,g,{,^)
#define  mdY97YGxqZoJZ4psVpCYa  for(
#define  mdeSRuh1fJRPfCJYIGL3K  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(p,[,^,*,-,V,8,8,U,],K,U,~,Z,!,4,^,T,G,b)
#define  mi4UDYlJVme2p8vz8XCwn  mCnRkQx6e9t50ErWQAwE0q3YKghcooj(p,F,a,m,k,/,q,c,e,p,6,e,n,s,W,-,],G,},a)
#define  mywDDUpEYndE3A45RHsoU  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(:,H,t,*,Q,N,e,J,X,^,2,-,;,m,<,+,c,=,:,])
#define  mcq33jn33ngPvU8ExIgnf  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(/,/,E,-,n,-,f,6,A,2,*,[,T,8,e,8,T,8,{,2)
#define  mjKxwUdMxuMgV0dkJGEp3  msecMYaXfF46rGGcWJxuScGlv8bYIpo(:,L,i,4,],V,!,s,l,X,e,f,],l,S,/,h,{,a,J)
#define  mqed_EcKcpv3tmsK0VwPq  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(a,x,[,Z,h,Q,[,},Z,Z,;,L,u,R,=,s,g,n,;,+)
#define  mUzQAwxDAK5N1NNCaNFl_  msecMYaXfF46rGGcWJxuScGlv8bYIpo(^,m,P,R,^,!,k,a,e,E,k,b,N,3,j,M,z,3,r,D)
#define  mYnZwY1qztvF6jEJBoGi_  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(r,t,m,_,U,+,t,2,E,*,I,K,.,e,{,:,},u,h,T)
#define  mcnZttRQtHTT1zEcTrcXq  mS3KOSwoqktmfbJXrTgh30aLzdZFDf5(2,_,!,n,},+,p,],u,t,v,Q,7,v,3,t,u,g,i,y)
#define  mf9Cutcm6ImnorHVFDeuP  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(V,>,K,Z,X,b,V,1,0,2,a,S,+,+,!,y,!,E,=,k)
#define  mLwLUP6KZ9PRisEeZakem  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(G,=,o,s,[,7,t,v,p,^,X,a,>,3,M,Q,n,z,P,^)
#define  mPkRdGYYZOKBHLvkzvyRk  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(7,=,O,B,_,:,{,/,x,t,M,D,/,W,6,m,q,u,d,^)
#define  mmxmIMH7MAnuDJTXb23zQ  mahSq6rrq2neTeBW0KH49DPaFsniYhL(;,W,P,V,<,],P,5,k,8,=,0,U,},8,u,k,x,},8)
#define  mrtb_bhYbXTw3XOs4vV1F  mWC1nvfQRFJLqJcGHQd_DZVW3mGXmA3(n,t,n,t,],i,3,X,c,v,u,Y,0,e,2,*,_,9,J,.)
#define  mi_O6EJNt60DZGoXx1wHw  mahSq6rrq2neTeBW0KH49DPaFsniYhL(e,:,[,n,-,7,!,+,/,*,-,O,.,D,O,3,L,.,2,/)
#define  msKaUi822wPxuzjUtd8Pa  mQk_FiTqfT2quOMiM0cIKgE508p48JO(+,},G,>,G,C,>,!,[,+,Z,Z,],Z,[,u,/,t,+,^)
#define  mdNNjVkqM2InU1bCHGxmP  if(
#define  mhROwJUrnW6RV5u5uX1p4  ma2JuVH9cwa2PZWXEX2RFlL97Fd56Uf(0,_,t,n,2,^,3,i,2,h,*,-,N,t,5,u,A,[,f,t)
#define  mZ4GZ4UmqxVyfyG8CPz5a  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(R,I,K,*,c,8,U,[,/,t,c,x,=,{,x,v,],G,{,.)
#define  mmombSefdt4OQYXhCimSX  mwK0gGoxdO620JNMAf8LcWrLXkSVHqY(T,t,a,r,n,W,H,f,3,u,B,t,c,9,!,*,},b,s,t)
#define  mF7PjcGzXBfuvYPxX4ENs  mHN4QkSpFuhZZROE3e75ST2ernStapx(R,Q,.,3,a,b,:,P,],H,r,e,/,h,Z,e,:,],r,k)
#define  mcvDrOWJhA_Jj9rADu5RY  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(N,p,b,o,l,m,x,[,I,M,/,.,;,o,N,b,o,G,Q,c)
#define  mqQ3hcKeFeE4oJoHQSvf1  msTibML7U5XAa62kfYMyXMMaQgK7wvx(2,O,D,J,!,+,N,;,N,R,!,m,b,k,x,j,p,[,],-)
#define  mj2vTnvmJGQRTP74fz5th  mahSq6rrq2neTeBW0KH49DPaFsniYhL(O,n,n,j,!,c,s,n,r,z,=,N,g,T,{,!,5,l,b,^)
#define  mqzzPJxLsV4dnyMti4gfP  ()
#define  mIUF5GxYrg8aIVgkWNnBb  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(J,=,5,D,X,p,/,D,5,a,B,/,-,M,u,},M,{,e,:)
#define  motTJdCC_9geof6XxtOIX  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(m,R,],-,^,-,V,b,],/,I,q,4,a,],],x,!,9,C)
#define  mbubCLceOr5QXaiOQQPP1  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(n,2,/,2,Z,[,P,C,R,0,4,z,<,[,0,b,;,J,[,R)
#define  m_WYn2n0wuk6UJ5kGIQak  msecMYaXfF46rGGcWJxuScGlv8bYIpo(;,D,p,f,*,3,.,n,i,:,g,u,3,],[,5,h,N,s,j)
#define  mpfHVtwBeRCF4HzfR5aYa  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(!,^,G,v,_,:,C,},q,{,=,G,+,S,{,o,P,S,4,J)
#define  mw3w4itcdSwk4YnPuBarj  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(!,l,1,N,b,/,e,],U,s,o,p,t,e,-,7,k,1,B,t)
#define  mvtZWYnFIFlTMBNRpc3mM  mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df(.,x,5,^,:,_,*,r,u,2,2,t,/,!,t,c,;,e,0,s)
#define  mmwMxLCLCS3PUrkR0S4GT  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(1,k,w,0,_,S,<,O,{,m,-,-,l,J,W,y,M,h,T,f)
#define  mJSr1xT3rjrluqpa47g9Y  miuYLrMna9tTpfuHozSxZXljtr8IWGY(/,+,*,O,b,Z,W,+,m,v,x,-,o,P,w,{,!,O,3,+)
#define  mCi4vAHb8oVMCZWxLATzD  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6([,r,e,n,2,q,^,:,u,E,},l,4,2,^,B,A,j,n,t)
#define  muSdZAgzhs5ln2vx_pg0w  mj0SmRpcdB2TRl5kdNdBQnXpbI2PaTI(p,n,/,a,m,y,4,+,s,r,c,n,a,m,_,.,e,a,e,y)
#define  mbtyTfpzqoLMszlSfGVhS  if(
#define  mnvfRccV6sWLKag7QRnMi  mBsNR7a9eCj4e2paObbgMzu5XwLAjnm(z,a,P,R,D,w,t,v,J,j,E,{,Z,:,S,o,r,f,3,])
#define  mnFcnzhSc68PBY18KNbo7  ()
#define  mAXRt0DC6duEWgvgkLnB3  mQk_FiTqfT2quOMiM0cIKgE508p48JO(K,0,K,&,:,E,&,7,t,z,7,d,z,Y,:,T,O,Z,w,T)
#define  mLS7Y36zZso1BwBUg8wDr  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(s,+,},B,7,},1,J,f,R,g,K,/,^,},B,C,q,x,k)
#define  mpoZNJTEPtCn_II0lswxG  mOf9_wb83eei1ZBzVuOZTTfg41x_5sS(V,a,v,K,:,e,a,t,p,p,D,:,C,r,/,i,t,e,-,*)
#define  mOnkdM0WujiddAefb4ESe  mQHl_ec60ZnTta9Kjat5MnwCDywKP0S(:,2,*,u,[,n,-,o,t,*,:,5,2,s,i,+,t,_,3,!)
#define  mWDsKNjyxVW4J9q1AwGWq  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(f,i,H,>,q,-,P,e,W,d,.,u,c,c,L,Y,h,:,r,e)
#define  ma2vK_VeaV2yOivBMAaS1  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(l,I,.,J,6,g,f,t,o,T,a,e,*,J,+,[,_,:,s,:)
#define  mG0XPjV2nZH5rw34_jjn_  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(L,Y,g,w,3,Y,7,{,!,-,r,z,/,D,],-,2,g,8,S)
#define  mnTomnUfxbEgN2pcyh4IC  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(.,u,g,D,D,/,a,s,1,t,S,c,u,o,Q,z,e,_,o,+)
#define  mud4sr7JVgGG6yDxhsQoI  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(},T,:,[,O,c,!,{,9,C,P,M,*,v,<,/,},<,g,g)
#define  my6ztJkSs2s9dWfJOJksF  )
#define  mrmdYuYTVzarkSFRATlha  mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m(^,d,o,.,0,I,G,},3,:,l,l,u,e,},r,b,],9,[)
#define  mqefKqLpc5MfNVAgzWWfC  mipMN4mtnGA1X8ocw1VUzyTesbkEBOw(*,O,B,u,.,f,r,r,V,o,r,M,J,L,:,},{,D,r,f)
#define  mVtH44jy_Eg0rghDYlMs4  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(f,9,L,+,6,7,],C,{,A,.,3,p,m,f,y,m,},m,Q)
#define  mu79Z1nsoA2cM_nPkf06A  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(N,&,+,+,M,w,9,&,k,},^,*,!,E,{,/,[,J,F,I)
#endif
#ifndef _6580636470966009790
#define  mzrwOkaVNQ12qikoacOtS  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(z,L,-,F,*,*,d,3,Q,F,U,c,K,m,<,},],Y,g,-)
#define  mLq0l_9mYawwF56GLqBiO  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(e,5,;,J,J,V,:,[,+,p,O,7,j,;,m,O,t,},;,.)
#define  mNrsNMyOlNPO0p0HXQMMP  miuYLrMna9tTpfuHozSxZXljtr8IWGY(l,-,H,},},:,i,>,*,u,v,I,-,2,Q,*,],A,G,T)
#define  mrWabZl6Yqxhh9lJh_vp9  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(E,],[,C,-,l,e,B,/,^,],],P,v,i,p,R,8,[,B)
#define  m_TFPk3Phi8ZX86zM0rxV  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(I,5,;,k,;,F,f,T,z,:,},:,{,F,O,4,O,],O,u)
#define  mX2uK3ci5pcPqQSvs4amk  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(M,_,6,],m,O,7,S,O,+,[,_,J,K,7,G,0,k,j,V)
#define  mJZTaq8b9U6IHm6Fo0zfj  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(6,:,j,.,:,W,*,M,K,B,!,K,M,5,!,U,/,9,:,G)
#define  mpmCfg6OTFu9ueV1Jvoij  mUsuCEIFvRP_D44KPaQY47o4ispy8Vj(k,j,f,+,i,/,4,^,5,n,o,t,{,4,;,h,-,v,9,b)
#define  mnW6ZFYawWAWMCKpMfvE2  mahSq6rrq2neTeBW0KH49DPaFsniYhL(:,k,W,n,i,J,I,!,x,p,f,Z,!,y,_,W,.,2,I,1)
#define  mTvuqEbq8QyE7GGDRvvUi  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(i,s,R,Z,W,!,[,],1,9,!,W,[,4,},.,g,5,W,r)
#define  m_Tae7Y9Y2VD1QQBLzq4Y  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(q,i,o,1,Y,p,A,n,[,5,5,>,{,w,R,3,1,D,],])
#define  mEn6ezpXymeCgJNVz3lrW  mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df(8,x,Z,8,q,!,d,t,u,+,3,e,0,9,n,r,U,g,s,r)
#define  mGQ4ZN1hA5s9kbimw7Qwy  miuYLrMna9tTpfuHozSxZXljtr8IWGY(E,|,5,F,r,G,h,|,C,.,;,/,E,1,M,.,-,y,9,b)
#define  mARbu_1sRtfpk1suZIE5h  mQk_FiTqfT2quOMiM0cIKgE508p48JO(4,1,m,=,_,A,/,:,c,Z,;,f,y,{,F,o,e,L,+,l)
#define  mpwGO7r6CJmc7pyzxPS0W  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(Y,V,+,2,g,e,J,!,O,A,z,J,g,u,+,F,M,+,f,U)
#define  mGHOYAWjopscrujOCjpSi  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(E,H,8,},p,n,l,o,/,b,-,S,^,{,6,F,o,.,c,;)
#define  mYg2fb_0h62GR73b_cpn9  miuYLrMna9tTpfuHozSxZXljtr8IWGY(/,<,!,X,+,C,G,=,*,^,!,x,},D,S,/,c,s,],p)
#define  mi6HZqmh8GILM6LjanUt5  ()
#define mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(mgw0B,g3c8T,r3SnZ,fE5q5,hz6ib,e1x82,DaAlj,a8hNv,XCWP3,rXZaD,CSBoZ,Chn6S,kNePl,l7m8X,G_LJY,aP0cD,A7IfE,sx7pM,J0z8A,AuVJB)  kNePl##CSBoZ
#define miuYLrMna9tTpfuHozSxZXljtr8IWGY(PuL4N,wmcgM,yYyC_,DYsKr,n2Vit,Fmyxs,L37nk,rhzou,foYA8,cMRr4,Hg5vb,Sl_LW,pLQo9,dS8Ke,f_eDs,jpMdi,xvkYG,a3ais,FeBAz,tjp5v)  wmcgM##rhzou
#define mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(aQQmF,xpwOI,iD1rA,CkzXS,Qb8ut,oJ5B3,GcAs0,E5idv,wjb5G,bec4W,VHnoT,qPRJF,ZtXSW,yb9tf,Nb1We,xMolA,bGd0a,VKlyl,K4pYx,lt5vN)  E5idv##xpwOI
#define muUdW3fqjYEcWW8jBykcma1JP8mjRxV(veOup,IqzeF,L_8Ns,IOKLa,dvT_I,sCW27,OwBfa,MVQpr,JAeaW,dq7Eo,qSedT,f9g9n,tRlzG,RWlt6,es5D6,yELGq,Hoxiz,rV9hT,Niv3b,ahuQt)  IqzeF##Niv3b
#define muyLCpzNWkiG62Rh8y6QK2T12sisiZy(fzku2,clxwN,jWAdS,lFUGX,QHbpC,Aa4jS,m9r25,cWif7,aMN0b,o0ATq,VmzcT,vZaYa,M48Ti,EFczG,L8C2d,nClNq,pXlO5,opR9G,psO_r,PjnKk)  o0ATq##vZaYa
#define mUbpV4lfDef5exLGNpWAnT12YiDu_kX(Xu20j,gFl5U,XxZFv,sEg5E,CyZgX,gJPQI,KgKAk,NrmZ4,Pjvtp,Co57S,IrvzF,HftOo,aoSzL,WYEYP,Q_ql5,Ef8Ge,pi2K6,AKdMH,rxX6T,y8v_u)  aoSzL##gFl5U
#define mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(Y85fC,QOTyT,WpNIc,MNNUR,lfmAP,JZRZD,rY1qX,aQIIi,WAHWf,XqMB0,CUIx1,DO0ZD,vAyLR,RcrX6,KWKXj,pDpY8,MhE2G,QKZXe,rub2P,fcFs7)  JZRZD##MNNUR
#define mahSq6rrq2neTeBW0KH49DPaFsniYhL(gwCpP,eR9Tc,BDNPj,ECE8f,yj2_r,kKpi8,esfQJ,zkUV7,WLO2V,D2lT2,AYwAF,sWv0w,S2xkW,jKOIO,onv6E,jbVem,L8Fa9,IPDk9,k539P,olDwq)  yj2_r##AYwAF
#define mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(U2OB7,iwHoa,HkFS5,IFjuo,KZiKH,hd4en,Nq6Ac,P3QCV,M_kUu,Qg680,TGyGw,wpZXy,buEf4,poitI,VjIVs,S3XpJ,ykG8F,MU6Z7,bH008,FX0v3)  VjIVs##MU6Z7
#define mQk_FiTqfT2quOMiM0cIKgE508p48JO(relEo,PWBSI,NwAcI,txND0,IoPEv,ybfoq,PF0wi,BNCJ_,jhSyv,JFExU,YXkeJ,r3o8_,G6qcP,p1WZ_,QVfES,NPf64,rB0SI,Xg5oJ,NQV9y,xyzEA)  PF0wi##txND0
#define  mhdOIl9dw0JQwDi0Ir2lO  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(9,a,!,z,b,L,m,n,P,<,.,<,P,j,*,+,8,z,S,R)
#define  mS3cOaukxo2FRb5RvHVc4  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(R,*,:,=,^,=,q,e,!,Y,J,6,N,Z,7,j,_,8,Z,b)
#define  mBbED78xkAlNEldBsfZoY  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(v,>,!,*,F,u,],M,{,N,X,8,-,1,7,B,/,s,l,!)
#define  mmDRiATwYsXZG1Jku9FPg  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(-,],c,],p,v,d,i,y,v,],.,X,M,v,Y,o,^,6,c)
#define  mPBi7A48_1c_87b1U_Eoa  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(.,:,E,1,!,f,m,v,_,G,.,;,:,_,Q,c,h,H,W,6)
#define  mhOJP7GTKtZVREYuK8qsM  mahSq6rrq2neTeBW0KH49DPaFsniYhL(h,T,z,k,>,^,!,g,*,L,>,S,],8,;,Z,U,l,o,Y)
#define  mzuL30IhryR3NJMszS89h  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(Y,K,P,+,:,9,!,[,-,{,&,y,&,y,V,W,-,4,a,i)
#define  mUCUowYS5Zgxsf8jGgVp5  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(^,+,1,F,[,0,l,x,6,g,],Q,R,/,R,O,R,S,=,3)
#define  mBx7lmwJEgh_boAo7hHD4  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(.,=,-,},H,n,N,{,f,-,d,/,/,:,F,T,M,;,},Z)
#define  mxODpvgncxHDxAXg0nTxi  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(^,k,J,U,},t,3,Y,!,.,P,u,g,;,+,0,+,=,-,M)
#define  mPwyvAQ1wHSSp7FJdoENV  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(^,+,X,P,e,O,},d,3,*,],6,+,f,r,U,+,v,X,Y)
#define  ma9kV7iftDKaJMwPMmic6  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(a,3,:,Y,f,B,g,=,W,4,},.,{,Y,{,;,},*,a,H)
#define  mJFezRZdF9Yll4E2ofN_f  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(:,m,-,T,T,Y,+,d,i,O,6,o,B,F,l,b,P,g,{,o)
#define  mBY9q0vKK0__eH5VQs9_L  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(b,o,;,],q,8,1,~,/,H,-,P,X,/,I,U,j,z,d,-)
#define  mjtgzOH8_fFDjnCUIvpJR  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(W,q,+,;,/,t,e,C,],.,+,v,{,_,^,V,I,p,X,H)
#define  mtPeORXsOWhCCSWRotXA_  if(
#define  mjSoZeXICFupmRJnwixfY  mQk_FiTqfT2quOMiM0cIKgE508p48JO(k,d,},>,i,D,-,d,},8,j,K,F,+,[,a,.,^,-,E)
#define  mK5osLCJErLUjdJVDKOO6  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(},t,;,Y,m,[,J,s,g,C,O,+,[,/,m,2,B,.,g,p)
#define  mfQdV5_coeVOh0_XAr72d  (
#define  mAw0cMDkuY7VauTjR_gzc  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s([,!,b,f,:,i,5,z,-,P,[,C,2,[,8,r,Z,},d,A)
#define  mO54HUFE7XGVtlHtttmH3  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(2,X,K,a,9,5,b,r,w,q,-,y,r,t,k,{,e,],O,i)
#define  mL9fuPZuqOi9x2FhIqvy1  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(b,a,E,1,q,[,U,/,],l,S,o,/,t,+,*,u,J,Y,*)
#define  mTva02hxveOfDWDk4eVeg  mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df(t,+,w,[,X,a,L,u,b,Y,E,o,;,4,e,l,7,],X,d)
#define  mEl0x2A3ElD6IIGxgIMh1  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(H,A,V,g,[,h,G,*,O,d,J,0,3,v,<,},^,;,^,/)
#define  muzBQurHIfaSICJbRjaWh  mQk_FiTqfT2quOMiM0cIKgE508p48JO(E,},J,<,d,2,<,f,-,b,l,P,},a,{,S,-,Z,K,m)
#define  mRkPOYbSt70qZdeFG7KTU  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(!,V,B,q,I,c,^,p,;,u,p,[,!,S,M,R,2,;,v,})
#define  mIyJPGeEvtQe8SOesQr7v  miuYLrMna9tTpfuHozSxZXljtr8IWGY(7,>,A,A,+,T,[,=,/,S,a,q,K,-,e,o,R,E,Q,F)
#define  mWNZjhCXwY0h77nbnnQun  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(q,M,:,+,9,+,K,-,/,],K,5,!,w,3,R,a,p,q,M)
#define  mWnjTNUFoM25IlGBbi5Sh  mahSq6rrq2neTeBW0KH49DPaFsniYhL(p,3,:,L,+,l,-,*,B,a,+,^,J,Y,},P,*,N,:,!)
#define  mNDIxtoehMB1oIpVV3LKb  msTibML7U5XAa62kfYMyXMMaQgK7wvx(+,b,R,],:,1,;,t,+,Z,*,},A,b,!,V,w,},-,-)
#define mDe6Xdhfu94h0bVchSL24UZegztDHht(U8afs,eVYXL,lh8Gi,l2Pn9,qxW2G,ug2EM,nqOoL,IHQLX,X69Xu,OoFUp,_T9Pg,TyKek,UzxkK,GQa1x,ZwJXO,MlaA9,iPAy1,zOsb8,Zzcez,yGURp)  ZwJXO##eVYXL##yGURp
#define mFR2AYMAMdlvPHNClNuuI2P2lzdelpy(QXu6A,B5jpl,LHL8k,eqAjU,FL2x2,QcQci,NSerG,Lghtp,q_Gkh,HM4aK,S2ivf,unq9e,cBnH5,vfYzN,BxbnX,N1zZx,ZQPna,B9EdR,r7yl6,FpGba)  QXu6A##Lghtp##r7yl6
#define mfaBCDA_1mB_o1gczVteCCzLS9jytzz(xNtQu,HEtMA,jWTOs,oAPgB,jnqOc,zr77H,KuHEE,usxyG,gV_kC,vqzkF,PSQcb,TxbuC,QjeFh,D0P2l,CfQ9N,aq7AQ,b3eRw,JFYtV,tbFBc,pqdDy)  jnqOc##gV_kC##b3eRw
#define mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t(Ua0Fm,xmxNk,VRLMv,d8RzU,rDq1D,tDOqR,ldvyz,NN42i,ak7gk,orpPs,WjEaY,mZIcX,yCgJD,VT7Q9,uhhs4,zGH6p,jWN68,MM53g,iznXN,CRb2H)  VT7Q9##iznXN##tDOqR
#define mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I(LHmc4,KHYTl,VN9TF,p7RoA,UiWDp,uufbU,O0z0S,lS62u,HUScG,aEKDS,WH_Gu,hLUyM,IFOnH,SRmZ3,KjIUx,rY1bo,rkGai,GPqvA,QJX_t,U2JKX)  p7RoA##KjIUx##O0z0S
#define mXNcG_XejCUhS0WdQbrzCqFiifRHEiN(HDJC_,jnQh7,taCjk,llGz8,_PCoY,Xhh8u,gBSnr,O17sj,OycCx,bW8sL,B8M3H,kbRAO,v4Jtv,GqzM0,niREb,EysF1,Wklww,JgBXX,cHvVe,Kkfpy)  llGz8##Xhh8u##OycCx
#define mipMN4mtnGA1X8ocw1VUzyTesbkEBOw(ajWkh,uQCq5,FaHFC,KNzT4,RWyMD,bh0lQ,go70e,ATnwk,NyK2P,vXwiv,X9q1w,th2ri,IL8qF,gJp6N,d6nTn,EorRq,lZSlQ,RVTaL,o73HF,FkUID)  FkUID##vXwiv##go70e
#define mcUjff6jaamQlwbiN5lMFGZa5CWNEQt(xlrpo,pbtrb,qP1uS,jPSr3,fmXc8,VcCxP,t5dSy,Owdrr,iDRo4,pVGe8,JEzJB,plUxB,p1Njr,jAQDz,T3_xj,joJI7,xPFAK,XTQzC,ZzRbC,BvT3s)  BvT3s##qP1uS##ZzRbC
#define mUsuCEIFvRP_D44KPaQY47o4ispy8Vj(LLEA0,GZwfz,uYLve,ruOpU,O1qEQ,kw1z7,yzZCc,y95B4,kNdfA,fB5xQ,P8Tf7,iOYFb,YRIsd,AxkEc,bl6Rg,OJfQz,ffAXt,FfC_W,P7o8M,Zh796)  O1qEQ##fB5xQ##iOYFb
#define mBsNR7a9eCj4e2paObbgMzu5XwLAjnm(ObAlp,BkrPk,DnQuN,aQxEW,zJbDp,yNvd9,C8SvY,q0zPt,BJm9X,CccNp,EJlbw,z_2mv,JvbvI,xWn1e,rQvto,xU244,yOxz9,P5j80,fEZOF,eYebS)  P5j80##xU244##yOxz9
#define  mPBqMiL37DrIolFnluMjB  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(X,-,k,-,a,!,R,l,c,l,i,I,S,M,!,[,^,m,-,x)
#define  mCw9yl5OPmGbIXjCTLMgT  mqiIIc9pe1gpl3JSjqxBusmApaww4OM(u,i,a,n,/,D,K,t,_,t,h,2,s,{,y,E,.,3,-,})
#define  mM7GbDdkpt2DGNP5IRiPZ  mQk_FiTqfT2quOMiM0cIKgE508p48JO([,*,J,=,-,[,*,j,A,J,7,e,.,w,[,;,*,r,E,i)
#define  mtd2U4uO5qMUqFSFlA3o0  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(;,_,C,3,M,a,},O,a,j,],R,*,{,f,K,z,P,e,E)
#define  mUvejUG0VZ6oaFYLfv96Z  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(+,A,a,u,o,D,a,q,N,L,k,9,{,+,V,I,t,I,;,})
#define msVNRLVmFBztOVESz5AQJDfnqtqgN6L(I0DEQ,xoSMj,HU9Qh,uNL77,KgkQI,MpRN2,y3eKR,pItKj,UewUm,v5iyU,zdpo0,gruI9,NMdWi,Jq10K,aXrkV,LsxWg,HIoFa,mFKCn,wsqas,mtgDd)  zdpo0##HIoFa##uNL77##I0DEQ##MpRN2##UewUm##gruI9
#define mdcfBxuY9ca1Je2VwDSgUMxqgXDgPST(xpHLB,aPx5G,NWnac,Iw9fh,rXeud,bZm4u,K0Lm6,Hi6sG,yIbyw,TUrXO,WB1GF,b3xYq,UxkGp,cdIYa,PThg0,QVDBk,KxW3T,AdIps,Ioi7M,yCi1t)  Iw9fh##WB1GF##xpHLB##cdIYa##TUrXO##yCi1t##AdIps
#define mGXDvm2ZdrqugaoZ1YccvqzabYqkG2k(W51i3,dBWnD,FEKLS,Ly7_m,m_TwQ,_x1Jd,csFjf,o4htQ,GT6pS,Nyp5s,SBA3T,VfgLO,yxMWr,iYFkL,qzcQ2,I4hr6,WCoJZ,NN8ys,eVWzF,_roGF)  eVWzF##VfgLO##SBA3T##yxMWr##W51i3##Nyp5s##o4htQ
#define mcLZRXidREDnQsUILaskKBiM_OAG8ua(ZG8u2,Mg0HY,jLHss,mlgSL,rA0FD,VC_K4,FXiWn,geaSW,U_C_Q,dPjHd,fo516,Rehl8,hL8Zo,G9cB8,ePQQh,TgqSg,RkaJV,JU2w2,i1_AD,AwYcM)  RkaJV##Mg0HY##JU2w2##fo516##Rehl8##VC_K4##rA0FD
#define ma8foCOgNMskkXnP7fzWdE7PnvWtDfR(LuHdP,qrCRc,C4udf,w_z4K,NWDYQ,tbiWC,vQyfs,A9eBm,i6IwB,qb77A,NP6dv,dNig3,RIjtS,TPaUM,lGLCO,yJvow,dgBnK,YZX3R,DdO75,K9_BM)  qrCRc##LuHdP##tbiWC##K9_BM##NWDYQ##w_z4K##yJvow
#define mZFd_wzPmPRc35lEvSHE0CiTnEdVk2C(kaABo,s9xhs,Mg2NL,_xEyL,qqv6W,Msun4,ltqHa,uoMyB,m3eA0,Xsq4_,AaDJL,lg9ox,YqXsn,TjlBv,J5d_A,BbBZt,Ps9ye,H9wE0,TYSgi,HsS3q)  HsS3q##Msun4##_xEyL##uoMyB##TYSgi##AaDJL##YqXsn
#define mDEbKniJvTruRfyANln1hDcaOxjifIj(OQXJK,v6v9h,QSC8w,Evg3O,h_x13,HPWSj,ARwrb,gp4yy,iMs6O,CgEVi,Vdg73,G_otp,YcCYa,x1VN8,giZpB,woulu,rqwwh,dAMSh,WCz5Y,e8nZz)  v6v9h##e8nZz##dAMSh##woulu##Vdg73##YcCYa##giZpB
#define mBojQqzqPJA0Zhe79JerpswyOrVuQps(ayuqk,lf4_X,qTd1E,SxdhV,HCiHT,x0MSr,r_k5y,WbhCd,HgqDL,syWvD,om_hE,rGnVK,IuNT4,WffEr,h3x2y,OHy0z,_kSeF,S0hmS,HpPP1,HaJMd)  h3x2y##x0MSr##OHy0z##ayuqk##r_k5y##om_hE##_kSeF
#define mkMSqyZx8knDVKKeQRRAPOPQ1OycFsk(BeTJT,qrlGq,KVR6n,bawsZ,D4C6t,pmgI3,iAzTP,sMJCR,PLh8D,guId0,cqwM7,Eq6UI,N3scG,yTdMa,i0ktf,kKYzh,aCU2f,vypOY,KFXHc,YC9p5)  PLh8D##i0ktf##iAzTP##pmgI3##KVR6n##sMJCR##cqwM7
#define mwjNmdVvS8bIC25sTrclB9dCibfRKDx(x4bG0,ZAuzO,Hj2g8,zYtFx,gvWul,tBHfS,RfUlc,OtaBZ,JPGYf,dJ7yC,mF5Tv,ekAFT,Pfehr,JWch4,FUZ1T,Hcz03,bpdh2,X7k5o,rD4vv,Upeis)  ZAuzO##ekAFT##JPGYf##mF5Tv##Pfehr##tBHfS##Hj2g8
#define  mM2DCYuIrYsxI9lPkFjQS  mcUjff6jaamQlwbiN5lMFGZa5CWNEQt(q,M,e,:,*,/,s,p,Z,p,U,H,Q,i,G,3,L,J,w,n)
#define  mMa_6lMFLoFYPgu9fRTI1  mHN4QkSpFuhZZROE3e75ST2ernStapx(/,n,Y,E,s,f,a,v,t,u,a,l,*,.,L,{,;,k,},e)
#define  mnXWkAlgXzCuQoJEu5uiO  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(O,+,},_,F,;,U,*,{,C,R,[,!,.,L,f,*,D,;,!)
#define  mF6LKJaZ8E_RFGqer3CEP  mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL(t,w,p,J,u,b,!,r,7,b,e,t,8,t,c,z,*,s,u,u)
#define  mSokNq3Jcm0CZDZY30Wno  mBsNR7a9eCj4e2paObbgMzu5XwLAjnm(;,*,h,2,0,K,3,-,U,},-,b,7,I,Q,n,t,i,L,p)
#define  mJXr69rhzcs2uHnnZc46T  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(+,=,:,F,:,E,s,<,4,d,q,0,O,y,q,x,n,U,G,z)
#define  moj9aYgB8JD1AgO4ICT3d  for(
#define  mwoHtFc7XtGdE5RWuAZoG  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(N,|,J,b,:,R,W,!,W,I,},v,|,q,E,O,-,Z,6,i)
#define  mfoiPdsHJ12pw0fAmu2LO  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(^,.,e,I,!,=,M,;,R,P,K,{,a,V,!,D,o,v,s,9)
#define  migdvOq5L79sWQtwLyhs2  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(;,a,O,:,i,Q,e,4,],A,f,/,s,},d,o,d,D,l,B)
#define  mKOkOykCmuX5Cu4t9gb85  mQk_FiTqfT2quOMiM0cIKgE508p48JO(},g,9,=,^,.,-,2,^,^,n,6,x,m,M,O,5,w,[,s)
#define  mS6JTMBdIbEJgKM_vQoSK  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(},r,],*,o,[,e,y,i,i,a,f,.,!,0,[,],i,;,H)
#define  mnpE_s7DSpkcZ5cnGnc16  for(
#define  mJjl5sA9ehjIzAWdStIFU  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(B,v,3,u,Z,;,z,F,o,p,b,r,L,+,Y,O,A,n,i,P)
#define  mPBz2W83ARDLALxh_6rJK  for(
#define  mY5NXKCzp4rf6Ovwtrdxq  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(:,},!,},*,S,[,],1,l,f,9,i,H,5,],;,[,j,;)
#define  musqt3SUnZXONhXx36QTM  mDe6Xdhfu94h0bVchSL24UZegztDHht(P,n,9,x,A,m,z,[,Y,^,:,6,o,:,i,8,A,A,o,t)
#define  mp9HJBE0E90Wcmb9f9ar3  mQk_FiTqfT2quOMiM0cIKgE508p48JO(:,6,f,=,u,q,>,.,6,i,!,*,;,1,F,},Z,9,;,;)
#define  mWNSsa0FomEI5wNcyNLqT  maFw6BG67rqfttMYNKgoNemSsvLkQYa(O,e,},p,r,b,k,/,n,y,-,+,},a,b,L,n,k,X,[)
#define  mL3fOciX21BVRqsrLjDqQ  if(
#define  mLY18NKQFABTYUMkJm2SH  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(_,M,S,8,P,-,t,!,M,O,p,6,f,:,:,s,^,A,s,+)
#define  mzz466vkULaDwnx05qd82  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(-,^,O,{,4,U,M,p,!,M,2,*,J,L,~,g,[,W,U,9)
#define  mKEA1BZI3NTi8QvqudEdc  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(i,*,m,H,{,_,],9,G,e,.,L,Z,v,;,^,;,l,=,[)
#define  mVDeIkD6a7uU0LqFHLuPG  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(H,B,8,o,Q,.,1,n,C,z,3,-,f,/,~,},},g,f,+)
#define mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(SbuEL,vs72d,voB4n,Xv69x,qfFhK,XioUv,F6_Q8,TcPJg,tu6s2,byhed,kFidk,k0jlP,rYTmq,Sc16U,AtzpX,YMtWy,FhcsQ,hnaCX,wV3Ma,SkNNX)  qfFhK##kFidk##tu6s2##SbuEL##vs72d
#define mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(x8zAn,X9mJ1,BIwnP,GbZAd,ZIZjm,KSoSb,Afht_,nb_XM,jl1Qx,q0u1i,NB7Rd,akMgb,XCuQk,zb0r1,RSxNV,S8qCZ,gYBGF,Kf_U5,qvMjm,cFqad)  x8zAn##gYBGF##XCuQk##akMgb##Kf_U5
#define mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(DSuEi,ECa1J,f78sk,y8kSV,QS2DS,vBQPP,qjMnl,OgkYW,eqcwI,ROWZa,D79zV,qjGTU,xsftQ,Mc2xW,a4kae,zCQfC,vLbUo,lvx8m,a9zM6,e8aQj)  qjMnl##D79zV##DSuEi##a9zM6##qjGTU
#define mHN4QkSpFuhZZROE3e75ST2ernStapx(Jrv_X,cLWcq,HabGB,jwOfE,XZMk8,UBTXB,UlITO,nkiuz,O7rIn,sedBO,F1wFX,oVsYx,rDzM5,b_36G,a3VnF,B_tSF,VSuO0,df3Y2,SI8YO,gXRuI)  UBTXB##F1wFX##oVsYx##XZMk8##gXRuI
#define msecMYaXfF46rGGcWJxuScGlv8bYIpo(rId42,kHyar,SDi3s,tIKBy,yQ2YF,CuFjy,QqZkO,SOcxT,Vcl3o,ll7DH,tNET4,jq2IY,ynpJi,lTtVW,rjPLx,P82vc,XLz8e,FLINd,dPTWv,i8hXT)  jq2IY##dPTWv##Vcl3o##SOcxT##tNET4
#define maFw6BG67rqfttMYNKgoNemSsvLkQYa(dQ22z,kdsdk,L1KPJ,bnsaW,W7Kzx,haXUd,FDAyq,ujvy8,PQ040,ggd8f,E48oY,pdzUZ,zDUHB,LO3UR,dHidR,ZfRIT,UnZ1H,SgNKy,xRuzw,hwciZ)  haXUd##W7Kzx##kdsdk##LO3UR##SgNKy
#define msKAlT0dx6w27y9yHjm3iwlc_YIajMN(rqNn_,b7Vjl,D7tyS,jpCWH,CdprC,StBdf,_YHlH,js8yo,XYOj2,rTIdI,eYLAC,XSZcC,tGfkE,gl_fU,pGSbs,DrIR_,VKwyv,NWOQE,LXNqA,oT7I4)  eYLAC##b7Vjl##LXNqA##tGfkE##_YHlH
#define mC6homJJPESbePyDgOny1YcxCcn5QHR(khh3A,R8oZ9,LJsn2,dkZZK,Cd7sy,rGB4K,cyVaX,H2yLp,SdhXC,HLeBB,_Yrqd,HP7hz,XShGo,pm7wH,DKcbU,n8N3z,nCNKu,KEndU,ilLDf,Zcx9D)  pm7wH##XShGo##HLeBB##SdhXC##HP7hz
#define mYV98481WEquqd1AECvpqWYdnflE9jF(CYTgI,Fg_PG,WEtVe,meD3Z,xNU3f,OXSHB,Q8Q3Y,bNubr,MHATJ,pz8M2,OrJh9,JDdqF,UyYPZ,bnf5H,A7xyV,wkq1Q,Ys99g,JBOsZ,RUjub,NQ7qP)  JBOsZ##xNU3f##bnf5H##pz8M2##Ys99g
#define mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(Yjj4p,TJ7vD,CF7mR,LHX7u,sdYwM,uIVFL,fRcCM,Qu4Fg,ZFknM,M8Hd2,PYtwo,jthq6,PGwhX,vntxY,seMqH,cgyMc,qneHb,jG0Ew,A6Hi1,CbSIR)  fRcCM##Qu4Fg##qneHb##LHX7u##seMqH
#define  mDpKPA1KOuuQehqrHJtsl  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(G,{,[,g,!,A,Q,!,V,h,*,!,q,7,1,T,O,-,7,Y)
#define  mf45G5P768Ut3IC0WfAVV  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(-,<,;,b,D,{,l,{,F,8,],h,<,*,d,A,z,/,W,8)
#define  mnZS4TInrvaTXnZxKixov  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(a,5,w,O,B,[,h,K,/,o,=,R,*,F,],N,9,R,Y,m)
#define  mhCwMg4Ffjrj3yXjOd5fx  mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL(d,x,7,t,{,I,/,u,F,V,o,e,},o,l,a,-,d,b,E)
#define  mypwvI9nBVxZQoSRivBsz  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(N,|,w,.,.,X,.,o,T,V,I,z,H,.,],W,S,E,|,t)
#define  maputXWpuSswTuxiye55G  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(b,F,g,o,u,E,J,^,},u,:,s,+,],u,-,F,n,L,:)
#define  maNkjFQf7KL90cn5vbMa3  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(V,l,A,i,;,D,t,J,*,.,f,h,a,-,!,x,h,+,o,.)
#define  mtJxJU59f1eEFMiVPqSOd  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(P,f,g,V,3,^,p,l,H,4,a,!,*,1,!,e,{,a,s,x)
#define  ms8ohDxwnrSLtbOpBsiBn  msTibML7U5XAa62kfYMyXMMaQgK7wvx(P,!,D,{,C,0,M,V,.,N,W,f,S,C,^,-,3,=,d,*)
#define  mFr9xKf_e_bmCOLt2lDD4  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(T,^,l,+,:,},c,L,5,q,*,q,Q,w,v,;,^,t,r,*)
#define  me_oz2FFDkcB79njugEzc  msTibML7U5XAa62kfYMyXMMaQgK7wvx(m,Z,p,+,V,d,i,4,B,},y,-,1,S,0,j,i,],y,M)
#define  mKzklEw5IRgQmI3OSml1i  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(O,5,b,0,;,!,B,H,9,U,+,R,+,^,{,W,4,8,K,b)
#define  msgGhTpJsjlaQFml28rg7  msTibML7U5XAa62kfYMyXMMaQgK7wvx(S,r,O,A,_,C,1,Z,t,F,+,/,P,E,;,k,d,>,m,7)
#define  mmwuJQME0484L7jN0wNls  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(9,n,e,N,l,G,e,s,P,J,N,],Q,m,X,l,q,o,V,Y)
#define  mrFprXhaW2MYwjyrlnlK2  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(-,H,K,5,-,],!,n,_,C,P,g,.,>,^,I,a,],8,3)
#define  mXqVbRWnIXdf8unNXdsWn  msecMYaXfF46rGGcWJxuScGlv8bYIpo(K,i,Y,e,L,*,:,a,o,4,t,f,P,B,a,g,U,[,l,{)
#define  mxRngYN6opotzgq0i2yF0  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(o,l,e,t,G,9,W,c,s,:,g,*,i,!,w,},^,q,+,e)
#define  mW37fLe5jzVXLk4yUjj24  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(J,>,*,i,],},L,-,R,;,V,w,],b,t,y,:,},m,D)
#define  mzb0bJuSjJhlivJIz_rfW  (
#define  mJKRIv5t9rcExx2BgWlkY  mXNcG_XejCUhS0WdQbrzCqFiifRHEiN(T,6,G,f,:,o,O,W,r,e,J,C,s,{,{,S,^,r,u,p)
#define  mkYawy3Jp4pgcXnw3fgN3  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(B,e,],v,_,[,[,g,t,L,A,.,o,f,f,i,],L,0,[)
#define  mo6RNiDqZJd5bPrKTOqBN  ()
#define  mKi8kBZaMYwKlooGDcleR  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(0,f,0,4,y,V,~,X,5,T,:,;,:,H,u,D,R,T,],X)
#define  mJSJkb3ccP0_n2Wxy8nWh  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(*,J,4,P,J,f,[,[,7,.,h,=,*,;,b,E,.,0,.,S)
#define  mD_3HKaGheLWoKIFvCH3L  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(c,C,a,c,^,{,0,x,E,F,9,{,K,t,;,i,K,:,E,6)
#define  mGeAkoUhfYDMrrSVlPr1O  mi0l_sHwUblCkb4iaLokRozuEWNdBw6([,6,],Y,u,*,w,>,y,a,},M,^,D,;,V,n,6,.,i)
#define  m_2Wdq9qctokcWGW9B7eI  (
#define  mr4zczxVHQA3dSD8whfSj  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(*,P,d,G,!,G,v,o,[,I,K,Z,{,t,S,0,[,n,i,r)
#define  mxjH4eEwkhiNcmUP6GEXq  mYV98481WEquqd1AECvpqWYdnflE9jF(I,v,i,0,s,!,a,c,f,n,:,3,U,i,N,E,g,u,7,g)
#define  mMJxQ0EBp3m14gB2r3xIc  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(u,s,O,k,q,o,g,a,9,d,u,.,n,1,-,g,e,},i,q)
#define  mSG4W65NNIcornxP1sDch  for(
#define  mQJ_ov46f8fAit991t8gf  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(/,=,],V,;,b,q,-,},k,{,[,M,U,j,^,},J,H,S)
#define  mIpgSd4v5yWrnWkLSTFr4  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(q,:,/,b,x,-,a,],-,*,>,z,F,O,],D,G,.,y,6)
#define  ml7ROdNRafN054xhICX2X  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(v,L,-,4,k,^,R,-,L,M,!,R,6,7,-,q,L,-,Y,h)
#define  mNUuCaMUS8zqfbXCimtgj  mQk_FiTqfT2quOMiM0cIKgE508p48JO(t,!,{,=,},h,<,{,n,-,R,a,g,p,-,:,j,6,2,[)
#define  miHgaIOIXnP9MKa_Ynuzb  mC6homJJPESbePyDgOny1YcxCcn5QHR(E,;,h,V,[,f,Q,X,a,e,/,k,r,b,R,1,E,;,j,8)
#define  mTIqUWMZAhhidB3B7gCmt  mWC1nvfQRFJLqJcGHQd_DZVW3mGXmA3(i,:,+,v,M,r,a,p,z,7,p,:,n,T,t,;,e,.,j,G)
#define  mYoowvicaALAqcfmGrsSD  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(o,h,_,A,:,0,v,u,G,{,+,R,:,d,c,],[,i,{,-)
#define  mbd03FIo9GTdRlDtujpAU  mcUjff6jaamQlwbiN5lMFGZa5CWNEQt(T,2,n,;,e,s,],/,G,{,*,B,c,.,*,f,2,Z,t,i)
#define  mIivzJUcx177gxdHt1Qrn  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(J,c,A,a,q,_,i,5,t,u,.,/,0,U,o,n,S,U,C,G)
#define  mo9cHp1NOYwzHudST5ct_  miuYLrMna9tTpfuHozSxZXljtr8IWGY(5,+,-,Y,_,[,/,=,3,E,v,M,8,U,A,w,H,S,5,3)
#define  mNTqpwjT561WC_1cfoCEr  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(i,[,Z,-,},Q,8,U,f,R,:,*,:,C,O,K,s,I,^,i)
#define  mHc4_w2MgUHx4283kOjz9  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(J,],-,/,E,N,*,v,O,!,5,=,N,m,+,O,{,q,Y,-)
#define  mnxqg8Uow3e4hAyXi7IeZ  mipMN4mtnGA1X8ocw1VUzyTesbkEBOw(z,^,.,3,k,2,w,;,{,e,i,l,],A,k,*,v,/,e,n)
#define  mgjLIBeE0wg2QrojbWXXE  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(g,h,g,g,m,7,{,B,g,D,O,+,J,{,{,f,},z,5,6)
#define  mPQkyiUN1BvHTMgAxqODe  mahSq6rrq2neTeBW0KH49DPaFsniYhL({,^,:,K,|,},n,Y,r,e,|,!,6,A,8,[,Q,!,h,i)
#define  mniKBlIuV5usw0rljtOxS  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(P,!,S,z,G,g,[,x,;,Q,],:,{,U,L,+,d,r,9,T)
#define  mkr0aLVnJz5CaZvioiLL7  mhW30YVZKc88sPKpBl_boHwzPPBIBGD(e,q,W,k,r,q,j,3,+,n,u,^,i,c,r,t,;,],e,*)
#define  mUD4rGlgxQjbo0JVuke3q  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(5,;,H,s,W,L,r,*,d,-,C,>,^,[,],],{,;,I,X)
#define  mdV71Y1rT0MkSZQco4pkM  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(},B,g,A,{,6,[,{,B,C,},9,i,a,b,],[,V,I,:)
#define  mB8iHIm9FOE1v4JRokz6E  ma8foCOgNMskkXnP7fzWdE7PnvWtDfR(u,p,K,c,i,b,5,_,h,*,d,K,R,r,Z,:,J,H,:,l)
#define  mOxbZipdUMUjuuBjccJiL  if(
#define  mjhYvAnHCo7RqHTG4kGs8  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(n,g,+,W,u,:,e,0,i,T,s,E,{,z,g,v,_,/,1,T)
#define  mPT1fk20Pr1eQ0YB5sxd6  mcLZRXidREDnQsUILaskKBiM_OAG8ua(d,u,O,5,:,c,^,x,K,w,l,i,O,P,[,w,p,b,7,s)
#define  m_5q1OVTkJJKfB_ISHjog  ()
#define  mkDBTxQUKyKFjRyQY44KV  mkMSqyZx8knDVKKeQRRAPOPQ1OycFsk(2,E,i,y,;,l,b,c,p,/,:,.,.,G,u,N,U,C,4,c)
#define  msAueAn4jz6msdaMAOFvD  mfaBCDA_1mB_o1gczVteCCzLS9jytzz(B,!,D,E,f,^,E,{,o,-,-,l,f,K,.,;,r,y,/,X)
#define  mGfToHPBdGgajCf_jjGO8  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(0,r,9,8,j,W,k,],!,Y,b,o,a,F,v,;,/,M,e,N)
#define  mEyjl8Y5Ko8WIO7rc8xjy  mHN4QkSpFuhZZROE3e75ST2ernStapx([,w,_,b,s,c,G,7,A,2,l,a,b,A,*,i,4,f,e,s)
#define  mRWp04iJpyRq8tILClaZJ  )
#define  mtPVppy1yz0JrXtPdjMoW  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(],b,^,{,.,9,^,b,J,i,;,!,0,!,x,/,6,n,],I)
#define  mMvWJbWSLKEHq4F0uh_XL  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(Z,+,b,H,6,g,m,i,v,f,C,V,u,/,-,f,/,!,+,!)
#define  mhK2Qbp1bwBdQQlO7M8sI  for(
#define  mHW6nVkC5JlKM0bwQFsqA  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(K,=,w,O,:,^,],*,p,2,/,v,f,y,*,G,c,M,/,S)
#define  mKwKqgpBT0nQRvDGpT5CT  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(},z,o,=,U,-,h,Q,D,n,J,e,{,5,x,^,y,j,v,8)
#define  mGdAJfTAuDccsggh4RYB5  mv_JVFkODVRLTSkXzNmRAFyoFoAzy3J(a,:,n,s,p,3,6,E,4,A,b,c,a,8,e,t,m,w,J,e)
#define  mXUy3srwASbKuClu_vKTe  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(O,v,*,^,q,q,4,:,1,e,!,d,w,i,r,],o,J,O,:)
#define  mmLMfZuLLitP3PNsKn3U4  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(u,f,e,6,K,P,a,v,r,5,s,T,B,o,i,_,d,t,V,z)
#define  mnaoSvkmA7uG3CzIf2JLX  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(l,:,W,A,0,0,*,:,:,.,/,0,P,-,m,{,z,c,},7)
#define  mdHtGBEDt4G4jvY6KOGzW  mC6homJJPESbePyDgOny1YcxCcn5QHR(*,z,*,!,C,V,H,m,s,l,j,e,a,f,R,8,L,4,P,c)
#define  mwE6oBl5ZQ79F6Ove8epW  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(:,y,k,t,E,Y,;,Z,d,+,<,!,S,J,O,[,1,M,N,[)
#define  mBS2ISVIhJublZPH29E0a  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(a,U,Y,:,v,:,Z,9,d,g,*,:,I,+,v,S,g,g,w,t)
#define  mRzFXIQ0M4lxEiykp0tGE  for(
#define  mKo7Dekr2hkVH6Q2yj4v1  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(S,-,+,:,9,7,c,3,S,[,9,+,.,g,>,[,!,=,g,w)
#define  mlxwRZWmFsIX03zy3tTy0  if(
#define  ms5n8S6sLK4BKl5mCpbvH  )
#define  mDPHjdm2_QWPyhebFvYkD  mAAF1hNrBlLEg80wAcv2c_FQ8jbfnjr(Z,t,q,t,:,0,_,[,*,;,u,7,2,n,y,3,i,q,S,+)
#define  mtAlnZAB81NJEQfKELvkr  miuYLrMna9tTpfuHozSxZXljtr8IWGY(+,=,C,o,a,.,P,=,[,:,z,b,8,/,c,V,[,R,{,J)
#define  mdcqBUCL5eOKU9PVtHvug  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(e,-,8,r,G,f,b,G,f,W,r,k,z,[,A,L,-,s,a,.)
#define  mRte7PZJP6iITCO2uVu0v  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(W,-,:,[,0,X,k,},u,W,-,[,-,8,!,{,A,D,c,i)
#define  mtnD8HN9EM8B5CF50YpX7  mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U(r,;,r,l,e,T,U,t,W,u,:,O,9,B,n,n,.,B,I,T)
#define  miUNNahIhqkHJ0O8mc7at  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(f,L,O,],l,S,J,X,:,_,_,a,o,U,^,V,l,t,i,[)
#define  mvvmSM3BA2TJMl_6Z9ScU  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(A,z,;,9,;,N,f,+,H,_,-,h,Q,:,},.,3,e,*,K)
#define  mLp87BNpaRa8bU3QE39AH  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(O,>,r,.,I,D,-,>,{,;,},c,!,W,T,!,-,t,d,r)
#define  mDzGqUDtD5PGwMNxtuRIR  mDe6Xdhfu94h0bVchSL24UZegztDHht(n,o,4,+,;,f,N,{,8,f,z,z,{,8,f,4,a,p,E,r)
#define  mTzlvPwOAcxvFnaU7tzec  mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U(d,H,l,i,o,],E,u,_,b,v,k,[,*,*,e,+,M,},m)
#define  mwC9HboO7mY5my_bYOgOp  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(S,=,3,5,-,{,V,-,6,m,a,^,+,{,k,4,3,;,E,O)
#define  mfvMoVhY8cjuWRUJI73Pl  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(V,=,*,],Q,;,;,x,v,+,+,j,A,h,j,s,F,y,=,^)
#define  mkATTEISGOYokIGC8F9la  (
#define  mySr_PmNqnsLYHdYvB_ZN  mQk_FiTqfT2quOMiM0cIKgE508p48JO(K,.,8,+,:,l,+,E,0,],j,W,},i,.,D,Y,r,M,.)
#define  mIOO9HkLingUB807zdqfm  mQk_FiTqfT2quOMiM0cIKgE508p48JO(+,[,t,:,7,*,:,v,V,N,y,.,k,j,p,o,p,3,Z,^)
#define  mhgnRFmDEM5LAURVG5y1L  mEvpZvX3Pr_xoJcbIft169GSIJ4Uo3B(m,p,a,p,e,g,^,n,a,c,C,*,6,i,8,s,M,.,*,e)
#define  mtrAzdiCeLhU7rVrgKDnJ  msVNRLVmFBztOVESz5AQJDfnqtqgN6L(l,Y,p,b,K,i,},m,c,q,p,:,J,p,+,E,u,u,p,3)
#define  mzZIX41vw1HHV8g5Zis4L  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(e,N,u,},h,_,>,o,K,F,K,z,u,6,!,^,-,:,+,g)
#define  mM2m_2Donhjltd0Debl64  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(O,^,.,a,I,{,f,l,],],},q,{,X,t,G,o,h,q,})
#define  mJmF0v_b2bVzIAj7lN4hw  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(o,p,;,^,*,q,f,m,8,Q,l,t,^,d,P,t,H,6,a,L)
#define  mcLleLW3WGZ6MsFjWUfct  mFR2AYMAMdlvPHNClNuuI2P2lzdelpy(n,^,.,f,1,N,P,e,*,T,E,H,4,c,2,k,F,d,w,+)
#define  mZWm2nGx_Hxwoni8yg8Qj  mhW30YVZKc88sPKpBl_boHwzPPBIBGD(8,/,*,B,s,},{,!,:,t,u,d,l,;,c,r,[,],t,O)
#define  mohUEWtGNSJiaUfYS_hHU  mahSq6rrq2neTeBW0KH49DPaFsniYhL(y,1,-,O,+,A,[,^,J,[,=,0,h,B,6,D,z,k,N,/)
#define  mAnJimC6YgR8qvnQB7ZMP  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(c,f,q,p,},g,S,J,R,+,i,[,i,s,:,M,o,[,;,;)
#define  mXPig4KjJlLryx1k7a1qv  mMcsTdeZl6dJT8lXT7C9j0AbQQMhSjw(n,+,m,t,u,_,G,},i,2,Q,_,{,],[,3,g,t,!,+)
#define  mhsPoKPzVdLpxSkCW6gM8  mMcsTdeZl6dJT8lXT7C9j0AbQQMhSjw(i,J,*,v,p,e,*,1,r,t,V,U,g,},/,a,P,:,9,b)
#define  mB9eufg8BrcMQwsjy5WF0  mUsuCEIFvRP_D44KPaQY47o4ispy8Vj([,J,M,-,f,4,^,u,d,o,J,r,m,W,],A,4,L,R,])
#define  mJfHf6vHjeGZbDkm_IWNg  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(T,I,A,=,4,!,M,F,/,T,y,3,.,.,{,t,{,!,D,6)
#define  mz4tZy0GWrUESNULCSRoF  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(t,f,C,H,a,8,a,i,!,v,Q,a,1,[,:,{,c,T,U,e)
#define  mSq36Z11XRl1JXoARgKCB  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(:,/,Y,d,x,G,P,n,],8,8,Y,2,x,},1,+,c,=,o)
#define  mLEPndrD0EDs3kVH87Dc9  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(F,W,-,R,X,G,Y,{,+,},U,f,P,<,V,],{,/,k,0)
#define  mf4r5S0Gz5iK0mQBxOgrA  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(Y,/,v,T,D,h,},T,[,k,s,6,K,.,!,D,!,],5,m)
#define  mzAWY6BVbyF5XGfs95ZTo  (
#define  mEnhnBFQ3mB4diArixuti  maFw6BG67rqfttMYNKgoNemSsvLkQYa(!,o,9,2,l,f,t,;,+,T,Z,S,_,a,w,1,1,t,t,H)
#define  mhp6bWPRQLSMINJFWgnoY  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(4,T,o,/,M,z,a,u,T,6,u,w,k,q,-,p,},D,t,[)
#define  mP8SrQcdiKeneTPj3ncar  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(W,d,t,U,r,E,e,u,w,/,a,Q,c,B,-,q,p,H,.,})
#define  m_YweHWYbkpdV40mXJspN  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(-,8,e,1,R,l,],P,h,^,x,K,p,8,=,W,A,m,F,E)
#define  myLMH58GbSZSEKIADq_9T  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(H,=,],R,s,],f,!,z,3,J,b,N,v,F,1,:,Q,[,n)
#define  mc0rMkLpNFfuLuqr7z3oz  mNRgx_n6AYQCSB5qW3w3m1_KYB5I5yI(e,;,e,p,:,V,a,4,},e,],c,m,n,b,s,G,a,k,c)
#define  milR3XNnU1JDeN9uyM761  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(B,q,a,Q,S,6,l,l,.,{,=,V,<,T,Q,C,^,D,t,i)
#define  mXggdfMCbAbSH20gXjoXX  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(4,3,8,a,+,D,],-,I,F,P,d,^,},{,{,J,a,u,F)
#define msTibML7U5XAa62kfYMyXMMaQgK7wvx(AfSYG,HX0AG,jt20F,cd5vL,iGvFN,kou_K,SsiX0,AUrCT,Ihj7c,j3HhH,qpTnn,OLeft,i05SB,IDHFL,O5uYl,ge_fS,aQ453,efxp6,UfLft,G9lQg)  efxp6
#define mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(pQ0Sm,CES6Q,ORmr0,SYSC7,USznL,mAN4e,zBMrG,QSDeK,k8jEL,nAI4z,x2oN8,_XcqO,lILmx,Fhniu,Q_Ir2,p4IHQ,AuxIj,GJbW5,I4Dvl,CJ5I8)  mAN4e
#define mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(gXaPx,DfYqV,Bw5PC,F1aPh,BNccZ,tO0_o,Qmc3a,to2oD,t0GTQ,xtJNT,XsFtq,kLpTN,u5Bcu,rnO7F,P2fNQ,UGzVA,A07LS,m2bvf,RWHie,tiYB6)  kLpTN
#define mi0l_sHwUblCkb4iaLokRozuEWNdBw6(jLhy4,WUG_0,ksW5X,Vf9oW,dvhQi,aELnC,p6tG4,ETi4Z,CPvMD,chK15,MCGLy,qyYbE,ln5Bs,F52LS,Jou6q,wqBP9,Rs5OT,Vv746,SX4jr,UcJrj)  ETi4Z
#define m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(T5aAw,kOSrb,Gfr2z,qOSjI,bgIPa,XlTsu,Ixn8o,XE1BG,D2PGk,eyMFL,Ndg7T,_9WGJ,heYgo,Mcq7t,roW93,GfTkl,zF5oW,MA1fs,zaRIg,zT6Ne)  Ixn8o
#define mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(oD41o,CtSBb,D0_tv,sZHFn,XfXes,Sn0Pp,mjiZw,RbJtU,EBkNR,ZJBXy,qIqLj,hpNqM,PFrQ8,_EVLa,jaG45,tOVxi,Xs0vi,wpd1F,drxrC,C552A)  PFrQ8
#define mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(JT6_O,bOUjY,AwneV,BoM_p,dfPkM,vIcMI,g8Q6s,LirjK,jf83e,eYZ1J,mZCnw,qZcBe,FaAyH,J09N2,ZfKrh,vqByb,uOe3a,Rhphd,ju5IH,GZpSQ)  J09N2
#define mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(cw1cJ,uEgeY,w4PTg,rnY6T,ZEIDk,p94zk,_eb5I,LjDqC,cyfh4,ZjOcv,tuHrr,uFhoJ,UmhCa,ojrjO,CieGL,B4Rfu,w6XLv,ZuZ_4,P8rht,gkzG0)  CieGL
#define mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(lwU86,A2qWz,uL5xk,ZvaY8,dk9Dj,Kwdn5,VnmmI,YP5aK,wZjo7,onak_,RHE52,N03cl,bGkPr,v4dwt,ZRULC,oflrl,kZoD9,mVoJu,P8j02,co1D8)  RHE52
#define mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(S5AS_,qgsPW,V6wNI,JDII3,TOPgU,nljGD,RXNcv,p51_T,SJWJb,usweZ,HdAxv,Zeu_G,ILtvL,KKfkc,ir7DT,rhIoe,OIr3I,HBRj6,dK4k3,eLX5Y)  ir7DT
#define  mMmBs0INu0k5X_FJkD5rr  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(b,!,e,7,:,-,/,8,w,N,N,4,-,n,=,A,I,=,p,h)
#define  mqItj5mkpzJ38jgqpOkYj  ()
#define  mTUb9WYxxxWOpnX_tuW8L  maFw6BG67rqfttMYNKgoNemSsvLkQYa(F,a,7,M,l,c,s,_,!,O,*,},*,s,P,+,[,s,s,v)
#define  mvVntD47RvCRRdFhEAzH2  maFw6BG67rqfttMYNKgoNemSsvLkQYa(6,l,p,},a,f,V,e,n,.,d,o,},s,8,0,/,e,G,^)
#define  mSkMsyd_G4SVpaKFDM3Uc  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(7,O,h,x,l,^,{,+,},x,^,G,^,g,-,f,9,;,^,:)
#define  mNqyOa6KdCv6zSr90UyAl  mahSq6rrq2neTeBW0KH49DPaFsniYhL(5,F,-,t,*,^,K,K,l,v,=,M,G,Y,],Z,s,g,X,j)
#define  mBeVnxVGsv42qh8iauLFG  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(M,M,J,:,+,8,Q,T,6,f,=,[,k,M,:,;,},:,^,I)
#define  mdcIh6lew75dFEC4p3Q1h  mgeGMjcucDsavdvBBcXoD75__Tb01sm(h,F,M,!,},S,b,d,u,A,l,o,U,e,4,.,a,9,+,Y)
#define  mcusq_XAMIIwDvb7lMCrf  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(c,<,{,v,+,{,u,},u,8,w,w,1,T,-,7,r,B,<,s)
#define  mtawfM3ndXCRasZXQxRrp  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(!,4,/,f,;,-,},y,f,F,!,2,x,C,/,o,D,=,5,/)
#define  mpQACTL4b3pHMD127IZSN  mTwuuBw4FVjERX9Kj4nHaPm6uu60qfG(],K,7,2,n,t,!,u,3,M,t,C,+,M,_,i,1,3,I,q)
#define  mpNsMq_Jsh9rRugWA0zzy  mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m(W,r,e,L,p,4,w,2,},[,r,5,t,n,g,{,u,^,*,*)
#define  mSiHrrzr4Y0scm_4uqOCv  )
#define  mIDgb6uGhToe8NBW6xKso  miuYLrMna9tTpfuHozSxZXljtr8IWGY(],/,W,b,/,D,},=,^,{,^,i,:,2,.,c,o,N,e,x)
#define  mc64seL8_QSxuYhWboswo  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(d,[,-,9,g,6,5,5,N,],r,s,W,~,+,],d,0,-,b)
#define  msn15RJjYb_SsaErIfRNo  ()
#define  mw_8xZKbKGnlYQNGWwE_0  msNlLNhq5GN7XcbzwivI3OWPTWt9svc(V,z,u,C,-,y,t,r,i,c,*,/,-,s,e,+,f,t,8,^)
#define  mM1pbAJE40pyDAsPbwwMd  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(u,V,0,&,.,&,:,1,:,F,},X,U,j,;,x,},k,R,R)
#define  mVzsLDeS8SOv0E6YGFv8j  mHN4QkSpFuhZZROE3e75ST2ernStapx(S,H,8,},n,u,9,*,},+,s,i,/,X,k,e,N,m,^,g)
#define  mZZ26QMzJc_5LIwefugPz  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(d,P,v,o,d,+,C,U,G,A,^,],[,-,w,:,i,u,!,^)
#define  mpdkR8_dmu0PH3OVmq923  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(L,H,n,E,H,L,R,W,a,>,j,=,M,F,V,M,0,+,L,+)
#define  moPdQYooVsM15VAazKOEZ  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(n,c,J,a,A,[,a,R,.,Z,.,u,f,=,:,b,6,A,{,b)
#define  mH81SrGjFrRCXYSiJnoqa  maFw6BG67rqfttMYNKgoNemSsvLkQYa(t,i,C,s,s,u,9,D,V,],H,B,],n,a,3,[,g,l,/)
#define  mwhGtbRL66FztkRtZ0QI_  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw([,+,b,z,o,K,l,o,],9,^,S,:,T,J,w,X,!,U,x)
#define  mgIg8CedmHvBkJNohUblZ  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(i,N,H,/,_,9,],A,i,-,0,=,f,x,K,j,*,k,K,J)
#define  mtE68lB7HxwArLgdxpcJw  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(-,W,I,J,+,S,G,O,o,1,J,i,i,h,d,v,2,C,M,o)
#define  msUrKsbZb01INfsQYkuex  mUsuCEIFvRP_D44KPaQY47o4ispy8Vj(d,[,p,H,n,t,d,Y,V,e,H,w,P,q,!,g,.,T,!,3)
#define  mzJn2Y5MSTbpYun9rdOSq  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(!,:,*,7,Y,v,H,B,W,X,~,Z,T,7,{,5,D,O,Y,.)
#define  mtWQnh_W_PD5ev5w8AW0s  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(c,{,/,J,u,E,/,F,_,!,x,s,a,r,R,o,l,s,B,w)
#define  mUp9jH_JJkeWGYg6SPvxb  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(a,k,a,W,b,^,H,A,e,o,r,P,.,T,.,8,[,5,5,:)
#define  md_M7GPITQtDS4BfzU9d3  mahSq6rrq2neTeBW0KH49DPaFsniYhL(u,W,T,a,:,+,C,-,p,*,:,a,G,n,/,N,-,J,E,_)
#define  mwlsAHCjnxf1m2hGk7SPN  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(Z,;,3,[,V,;,1,q,r,W,],<,H,L,^,:,S,X,x,z)
#define  m_SGFgZqHNGYic2jE2PZs  mBojQqzqPJA0Zhe79JerpswyOrVuQps(l,*,O,V,F,u,i,+,0,q,c,E,D,v,p,b,:,:,e,c)
#define  mmFrxzQTWygQiSMiAd1ou  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(c,Y,R,*,h,2,w,H,8,.,4,C,O,;,{,g,},/,L,T)
#define  mlPYm0vEibuOv_LKABukZ  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(0,7,N,+,N,;,i,0,i,s,U,t,I,;,^,S,v,{,8,g)
#define  mnr9KiD3xP6jhiP0klzs8  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(x,0,W,q,w,I,Z,Q,5,U,j,},6,W,-,7,Z,[,i,0)
#define  mhen8iRk76Q4ezN_ZTavu  mfaBCDA_1mB_o1gczVteCCzLS9jytzz(/,U,Y,/,i,o,n,T,n,9,*,:,d,;,Y,G,t,R,:,^)
#define  miK0cKKXIJZC11uUUzrLR  mhW30YVZKc88sPKpBl_boHwzPPBIBGD(X,G,:,Y,d,6,q,U,:,e,b,R,f,M,l,u,Z,^,o,})
#define  mzRXDilasYlw5CVJtdYdM  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(E,a,[,Z,!,D,{,U,o,Y,],[,w,[,I,-,s,.,d,e)
#define  my9HJ8yK6DJjsZPdzWxZL  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(4,.,e,l,e,+,s,h,z,m,-,l,c,W,r,x,s,Q,D,u)
#define  mDk1S9vejmO23nQ14m4JM  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(d,u,G,S,Z,O,e,s,w,e,q,C,:,.,+,b,l,y,[,5)
#define  mYYc77i0htGEQktG2Neo1  mGXDvm2ZdrqugaoZ1YccvqzabYqkG2k(i,k,v,k,2,i,H,:,{,c,b,u,l,V,g,_,],H,p,e)
#define  moxT8MWfNzFm3p7C1XLDk  mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I(7,I,-,n,/,p,w,z,s,y,+,C,e,:,e,j,{,W,_,c)
#define  mBndUu3vn0UYS7kuL9bT2  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(b,F,M,_,N,s,[,U,y,7,+,a,e,4,F,V,r,k,!,_)
#define  mbSdXRep8t2vTB1sedPyt  mahSq6rrq2neTeBW0KH49DPaFsniYhL(s,Z,S,d,>,9,{,n,y,!,=,:,7,u,7,5,J,*,;,3)
#define  mVC71FDKngiAI0dFcsSY9  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(w,n,8,+,e,T,/,-,/,l,e,t,5,u,o,a,k,[,j,u)
#define mhSjwWsm2mahiTUSTjt6nFB03As_xU3(XhypK,QlaM2,X6csy,P9MCL,T0V9F,UI8h8,ptAiD,icK5S,W3PgG,s3lHB,iwHsd,mlIVS,fv800,OKdg0,ZnxB2,Xp3Qf,qyR8R,l8pn7,BO9z5,uWung)  Xp3Qf##mlIVS##XhypK##l8pn7##uWung##BO9z5##ptAiD##qyR8R
#define mqiIIc9pe1gpl3JSjqxBusmApaww4OM(PWGM3,a4shn,SF3dz,Dn9wm,OeD_6,lWnnt,H2uji,duwMV,OFgP9,vE4qD,EjhsU,fNbX7,PQC7l,n0zgR,q3KAs,kxI_n,tS9A0,xCejI,LHQPw,Y1srC)  PWGM3##a4shn##Dn9wm##vE4qD##xCejI##fNbX7##OFgP9##duwMV
#define mAAF1hNrBlLEg80wAcv2c_FQ8jbfnjr(L2Fdd,gGO65,GNasD,u5OmH,lB9Rb,YtVbU,TvQL1,y9t41,W2B_p,YCdLc,ey4KZ,jYTtt,JNdHS,R3hW1,PDhaY,tNGog,t9Ms0,dPbyf,X06JX,AUNW2)  ey4KZ##t9Ms0##R3hW1##gGO65##tNGog##JNdHS##TvQL1##u5OmH
#define mQHl_ec60ZnTta9Kjat5MnwCDywKP0S(Q08Ui,isGf4,B5rxh,cHlEj,NIZj1,jSQmy,jHzYy,ik7Ii,Fg5qv,Mq5IZ,HAZ6y,xDpAk,OBUKU,QZrEP,Q7b7O,T4Kn9,cLU6W,chOM2,n9SNM,KMxiU)  cHlEj##Q7b7O##jSQmy##Fg5qv##n9SNM##OBUKU##chOM2##cLU6W
#define mMcsTdeZl6dJT8lXT7C9j0AbQQMhSjw(wkTbO,wNdTr,X_qla,JvWm6,A2151,IdDIC,Ntx0K,HNnM6,bxHZh,kQPHU,CJ3xc,tx8Uw,hSq4o,CrtgQ,cgzTw,Showc,B9JLc,Nujgx,DNMU2,W7S2Z)  A2151##bxHZh##wkTbO##JvWm6##Showc##kQPHU##IdDIC##Nujgx
#define mWC1nvfQRFJLqJcGHQd_DZVW3mGXmA3(hWqC9,ytaLC,pzax6,BolEQ,Plr5S,v9JrK,f2NvP,BrVXo,grP15,SmX3s,ptA9k,j4Wxy,Uxl1S,UjP1m,RyFO_,Kq_Wy,pZpWX,I1iC3,Igt8i,VWbtv)  ptA9k##v9JrK##hWqC9##BolEQ##f2NvP##RyFO_##pZpWX##ytaLC
#define ma2JuVH9cwa2PZWXEX2RFlL97Fd56Uf(qEwb7,hYqLu,KWvtv,x95Ke,lwgs4,euyiT,FVc8p,DQ1gH,t84JR,pXe7P,h9bls,O9ZSG,v4mzj,QxByG,AiBKp,qehcP,BChDf,Nd1Ma,iTgdS,J8gRS)  qehcP##DQ1gH##x95Ke##J8gRS##FVc8p##lwgs4##hYqLu##QxByG
#define mS3KOSwoqktmfbJXrTgh30aLzdZFDf5(qi4eB,CmGNq,nKD9s,V5yyF,gsAGM,S4W6k,lXRgv,XoaWz,EYXjU,kedyw,Ky3J2,bSJP6,FR0Fy,VhXCO,gBhc9,BwZeF,vE2ie,wKbvY,jDEOQ,FNn6y)  vE2ie##jDEOQ##V5yyF##BwZeF##gBhc9##qi4eB##CmGNq##kedyw
#define mOf9_wb83eei1ZBzVuOZTTfg41x_5sS(N9g2c,jRLjD,VVXAz,K1CTN,_vQJZ,LCgKD,y3jHn,y5RmG,Z9Q9d,Diij1,xiRv2,hzhsE,jTbFE,wA15K,JdMZL,za4FT,rf2bX,lJkfZ,uC7WG,Q72Xf)  Diij1##wA15K##za4FT##VVXAz##jRLjD##y5RmG##lJkfZ##hzhsE
#define mTwuuBw4FVjERX9Kj4nHaPm6uu60qfG(L8FK4,v7T6q,c_R9s,LLIN1,yyNRq,VAxnT,ot84_,Rexyo,nWB7s,wF8pf,XD7bz,scTlf,UD6dA,N_Pc5,YXVyM,iyN1Z,e9x2t,DZpaD,QdyuF,g4bg0)  Rexyo##iyN1Z##yyNRq##XD7bz##nWB7s##LLIN1##YXVyM##VAxnT
#define  mwUUBDVL49RrRRTgyVPVN  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(B,5,7,Q,4,>,_,W,b,8,V,^,7,F,u,_,{,+,!,z)
#define  mbldl9dwMrRmnA2YXgRup  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(Q,-,m,T,0,h,*,-,{,X,q,4,},B,G,A,m,9,P,J)
#define  mrZQSpiPc5lDdrE7lGVdv  if(
#define  mobX070S3wO6zxczaIZzQ  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(f,8,L,+,3,:,_,o,E,},},s,l,R,s,h,a,e,;,n)
#define  mxK3g5IVylkgINFWSbxF8  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(],;,v,j,o,3,d,i,!,a,1,V,^,n,3,S,J,^,q,[)
#define  mjn2WKwnpSiVmCWLEjQ5k  miuYLrMna9tTpfuHozSxZXljtr8IWGY(Y,>,d,],b,E,h,>,4,a,[,*,9,n,F,Q,:,b,d,+)
#define  myuvjPnvzcBE3NfHkRLiX  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(/,x,u,|,{,|,^,M,L,R,:,^,X,k,{,v,6,T,u,v)
#define  m_18997e8JQQFco5N9dHK  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(I,{,a,s,q,:,g,S,d,_,g,2,5,:,*,i,},=,B,d)
#define  mUvbKcsz8i4H1kuQe8W_B  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(c,c,k,t,!,4,/,S,*,+,5,=,Z,h,b,a,2,.,9,G)
#define  ml8k79uncra_1jDk9y35b  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s({,Z,j,=,o,*,/,Q,M,F,u,U,-,R,2,/,r,-,[,a)
#define  mnPfMWb2f1m2VXrwtLuBn  mgeGMjcucDsavdvBBcXoD75__Tb01sm(V,*,O,G,.,N,u,s,r,{,c,t,_,t,R,E,s,8,],X)
#define  mpxNV0vBtyYJsCSJulyLm  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(.,.,;,5,B,*,K,8,:,:,n,7,>,-,R,i,o,m,0,L)
#define  mCuRJqKBRH_BrOMv7hXsF  miuYLrMna9tTpfuHozSxZXljtr8IWGY(5,i,e,O,],U,V,f,},U,5,O,/,S,3,^,:,a,Y,K)
#define  mkvvczg0if8KqjNRfebjz  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(},=,*,N,Z,5,W,_,f,O,I,5,!,N,q,z,Y,A,[,;)
#define  mBzApfw9R5DW809yw9n5C  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(y,A,!,6,7,U,r,i,0,/,|,;,|,_,N,},5,a,{,h)
#define  mMbu3hdPmJMPrM_d1Cr0s  mHN4QkSpFuhZZROE3e75ST2ernStapx(d,q,6,!,a,f,U,J,D,r,l,o,D,;,h,l,i,_,C,t)
#define  mCW_zvfcw3_KvOK_XS8HP  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(i,>,Y,g,:,J,v,P,c,-,U,F,>,x,[,X,/,t,7,-)
#define  meLXGbNjy3PRj2YFo8vov  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(i,T,7,v,Z,^,u,J,W,3,s,g,e,k,;,T,_,h,n,Z)
#define  mBEcaTi01GHGicTdCFjoM  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(Z,b,+,R,},5,K,-,H,3,q,l,F,o,*,J,o,c,Q,k)
#define  mpxo8NMrHzok0zxZzo_cs  mBsNR7a9eCj4e2paObbgMzu5XwLAjnm(+,},K,j,g,},r,5,f,v,a,T,E,y,2,e,w,n,:,g)
#define  mk0UDRIyOODBYPpNMMtOc  mZFd_wzPmPRc35lEvSHE0CiTnEdVk2C(Z,/,7,b,d,u,K,l,w,L,c,],:,9,w,2,z,[,i,p)
#define  mO3uJapBz8hfvZuLXzM53  msTibML7U5XAa62kfYMyXMMaQgK7wvx(q,;,E,M,!,-,/,4,1,T,n,3,9,.,w,e,S,{,3,-)
#define  mvt_8yQ6OWmKTfvk3dzq1  mQk_FiTqfT2quOMiM0cIKgE508p48JO(:,k,z,f,F,3,i,2,3,q,-,j,q,/,O,g,7,/,-,P)
#define  mJ7GYjgHHCxtWCUXtHWVv  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(h,],0,E,.,p,S,Z,5,],>,F,>,L,P,f,r,5,],w)
#define  mcX71Wu1NrgiE1PjmF5oW  if(
#define  mU9sM0kyDLaDRi1mqQV4j  muyLCpzNWkiG62Rh8y6QK2T12sisiZy({,.,:,W,:,2,d,s,!,*,1,=,x,e,_,I,J,N,f,E)
#define  mrdmCc9Gc3ukvwGoxQggu  mhSjwWsm2mahiTUSTjt6nFB03As_xU3(n,.,[,*,b,f,_,k,{,a,T,i,c,q,k,u,t,t,2,3)
#define  mSfj74s5uEvCOzi1TqmTv  mYV98481WEquqd1AECvpqWYdnflE9jF(a,^,D,q,l,c,a,x,^,a,7,/,b,o,_,s,t,f,+,m)
#define  md2kXkeBxboEMBU2AV_5s  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(*,4,8,M,6,],0,r,m,N,r,4,q,:,+,a,R,W,Y,h)
#define  mK4rObJyYX6HJZfVJKntT  mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL(u,S,N,V,t,q,p,b,c,n,l,4,Q,r,/,e,n,F,C,r)
#define  mRHVbf6L_uqgqJB68GawV  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(O,8,F,P,+,J,s,T,I,;,;,p,7,n,;,{,C,I,},0)
#define  mm4diUXyy908ilcG8VsiM  mahSq6rrq2neTeBW0KH49DPaFsniYhL(n,d,J,I,=,],J,!,Z,v,=,E,7,a,x,d,.,N,i,6)
#define  me3HErcslswtnJE5PyQ7h  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(s,d,K,n,z,r,Z,;,5,c,M,i,],e,i,U,3,f,!,0)
#define  mcupMgy1yB7mIget2eDow  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(n,k,Z,=,^,/,],G,},m,t,/,{,],:,7,},2,q,z)
#define  mVx2i0xDty6d7wAQ1AEDX  miuYLrMna9tTpfuHozSxZXljtr8IWGY(5,-,G,F,2,!,Q,-,p,4,L,K,O,2,!,z,U,1,I,H)
#define  mMj_9sE1weayB75v7BdK8  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(.,o,X,n,O,4,b,f,W,o,.,S,a,l,X,e,[,O,K,})
#define  muPhaubkj3SDNA5Wasshg  mQk_FiTqfT2quOMiM0cIKgE508p48JO(F,d,+,|,.,:,|,:,!,v,4,r,9,t,0,V,i,-,1,O)
#define  mOO4AmPyU12o_w01ECkUl  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(T,T,N,[,Q,V,=,7,+,3,.,:,^,W,J,},Z,F,p,2)
#define  mjAnZdEfD7dHR86j3d92F  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(A,=,N,f,_,F,+,+,L,;,B,[,;,W,k,.,8,l,:,/)
#define  mD1FtOnG5lJAS7VVmL6Ph  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d([,Z,Q,j,V,F,+,Y,_,C,-,v,L,e,&,+,B,&,e,V)
#define  mJYXLtUQ27au4beQhf0PM  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(F,R,f,-,O,b,2,2,+,>,4,>,L,:,q,p,+,R,I,0)
#define  ms9M5EwDiWgRYZIdzQWmp  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(V,x,v,F,x,],J,X,;,f,},;,p,N,E,r,u,],h,O)
#define  mP769HJIua8m0mI4ktrOP  (
#define  mY1aayBcuQSa43sZHmeQS  mQk_FiTqfT2quOMiM0cIKgE508p48JO(+,E,J,=,L,{,!,U,P,2,4,*,z,F,X,O,b,y,W,B)
#define  mzjX0iRvCYGhZO2ITjcdt  msKAlT0dx6w27y9yHjm3iwlc_YIajMN(R,l,9,F,^,3,s,b,-,^,c,M,s,p,+,0,[,y,a,k)
#define  msWHPNAG9RJ8USwCYjIRg  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(s,s,v,+,c,W,Z,K,a,-,l,*,B,.,*,J,{,P,o,^)
#define  mI4sf76lr2ENejiQIjqzJ  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(1,b,K,5,+,e,L,J,w,s,_,a,b,},O,c,9,m,x,k)
#define  mcBOeh7kvkLdVFdML_waY  )
#define  mIkusqIJdd_o34vSBgzWv  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(-,A,9,;,z,0,L,},Q,X,x,u,s,p,e,t,.,*,[,r)
#define  mO2X7vyyKruryPTrlfgIx  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(r,=,{,b,8,*,},],/,;,r,{,<,h,{,U,H,0,+,m)
#define  micFIwqBc9QQUuQXqGKWC  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(9,[,9,B,+,^,;,i,1,M,n,^,;,*,F,+,e,r,v,*)
#define  mo5687q03mFTCWmTFL22s  mTwuuBw4FVjERX9Kj4nHaPm6uu60qfG(p,I,N,t,i,:,X,p,a,E,v,K,E,3,e,r,;,!,X,[)
#define  md4LgblW399NKaEPBAY3T  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(Z,],},b,A,p,B,m,d,4,!,2,H,/,:,.,W,F,W,n)
#define  mIivpa7B9YEutjvbp_HF0  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(q,e,Y,v,Q,d,{,E,*,0,H,e,-,s,M,-,l,;,y,!)
#define  mslakBBg5XJ6k0ROZMh_4  mahSq6rrq2neTeBW0KH49DPaFsniYhL(o,E,.,T,&,j,I,+,7,+,&,g,V,l,/,t,L,*,o,W)
#define  mYB0YoRP6itbUawfbPusv  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(;,6,],!,f,E,[,O,x,a,Q,;,I,*,h,V,*,5,H,{)
#define  mTijFbkuqZobez4o86GTR  mahSq6rrq2neTeBW0KH49DPaFsniYhL(J,:,3,:,/,X,*,*,.,],=,S,/,R,k,},Y,{,Q,4)
#define  mHiYGul5svZyW_rLyOjTu  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(p,!,I,K,W,K,Q,+,J,9,c,T,^,S,1,V,B,K,=,q)
#define  mVt0bbujrHNetZKOtuKde  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(q,},v,v,j,4,5,S,i,o,w,u,z,O,d,n,L,J,E,D)
#define  mfPiMJHfWML2WymRvotni  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(-,8,L,0,k,;,f,1,r,1,=,g,-,!,F,q,/,R,C,X)
#define  meKZnYzO2FX6PDdko0XJI  miuYLrMna9tTpfuHozSxZXljtr8IWGY(a,!,],*,J,^,^,=,K,F,9,-,F,8,G,r,D,;,/,o)
#define  mWw8FPQaCI3gn0wUVEyTI  msNlLNhq5GN7XcbzwivI3OWPTWt9svc(5,T,u,*,B,c,n,t,;,r,V,!,P,r,e,;,],e,F,t)
#define  mSNCcmKF29PRGlI8Tdwja  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(*,&,G,;,C,*,R,_,a,{,:,^,&,-,K,[,D,F,b,9)
#define  mjYBDnziuBBoR8htpZ054  mahSq6rrq2neTeBW0KH49DPaFsniYhL(Q,5,B,s,-,7,R,i,],w,=,p,^,d,!,X,0,:,l,;)
#define  mN6OdwmNUVjXUhxmeGf8J  ()
#define  meHoni3WXkzVpE4d0kmI1  ()
#define  muxvLfj1z4AXZePUs5M4p  mgeGMjcucDsavdvBBcXoD75__Tb01sm(b,f,-,9,f,[,u,r,t,],r,e,6,n,.,n,F,E,Y,Y)
#define  mD5j4pDCOs2SM4dLbugLG  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(t,8,+,k,k,^,j,7,y,5,^,Z,K,+,/,q,d,o,:,b)
#define  mwmTl_1WKubaBtbkcxNw2  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(H,b,r,!,C,l,Q,},7,{,7,i,],B,I,x,v,+,Q,D)
#define  m_1J0sGT1PB0ZSBudKlNA  miuYLrMna9tTpfuHozSxZXljtr8IWGY(k,&,/,J,D,E,B,&,;,],i,n,V,Z,L,t,/,b,},])
#define  mX0mE9NJLZdso_vDht0x6  mwK0gGoxdO620JNMAf8LcWrLXkSVHqY(j,6,B,t,v,0,U,:,R,u,G,n,r,!,w,U,T,7,r,e)
#define  mZJOXxx7hbtRSTyy_HjGF  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(R,Y,F,=,v,>,E,V,2,B,C,5,*,o,_,*,Z,-,R,/)
#define  md4VXnnHqGZYN9FfEwMCW  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(Q,_,B,N,:,0,!,T,[,Z,U,F,Z,f,D,},T,r,},m)
#define  mM5M87hxO0F1jykbMUggh  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(],],I,{,p,[,Z,{,!,M,^,:,[,w,*,m,o,],b,})
#define  mI1ri11eHWS0GoQQjfv_u  mahSq6rrq2neTeBW0KH49DPaFsniYhL(;,P,/,j,-,T,0,{,^,},>,*,p,b,^,k,^,[,n,!)
#define  mBf0JMOxQ3sCg9N87xsxR  mwK0gGoxdO620JNMAf8LcWrLXkSVHqY({,X,O,u,4,{,c,Q,},b,+,e,l,_,U,!,W,.,d,o)
#define  mYhDj2gAIVF7iiyAIzfLc  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(f,g,X,!,W,l,^,r,f,O,],1,I,G,>,-,/,5,8,3)
#define  mvvQZKXqZ3gS6vWzM21uf  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(k,.,z,n,i,},u,s,I,^,5,{,q,b,g,h,i,{,J,k)
#define  mcVfnknnHgJjobEYbCQZb  mhSjwWsm2mahiTUSTjt6nFB03As_xU3(i,k,.,B,E,c,e,p,C,U,N,r,/,s,],p,:,v,t,a)
#define  mrzBsv3kMMBOnuA1vQYB0  mFR2AYMAMdlvPHNClNuuI2P2lzdelpy(f,6,W,m,:,b,I,o,{,F,x,g,X,*,y,Z,],D,r,h)
#define  mb0Jed_XHNWdzUez3EMOb  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(g,o,!,u,x,:,v,n,:,i,1,{,7,d,y,I,-,!,*,C)
#define  mxbbdZ8472z3S1r1q5ZWj  mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t(V,M,i,c,!,t,y,e,x,v,1,E,x,i,j,P,O,Z,n,^)
#define  mPRf5NpGuq6ZoBfArKDF3  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(a,[,/,D,c,W,c,m,-,s,l,s,_,d,:,G,-,I,s,q)
#define  mxQppl_B1tP4_S2CE3A7S  mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t(P,i,f,k,U,r,-,O,h,D,T,_,N,f,u,F,;,s,o,n)
#define  mlNC5dwEflF9t_I2G7kwV  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(W,V,},6,.,8,+,X,^,^,0,d,},/,T,;,*,H,H,W)
#define  meadcZiQDrRuC0Tmbyyiu  msTibML7U5XAa62kfYMyXMMaQgK7wvx(;,k,m,K,K,3,:,s,Y,S,f,0,-,q,:,U,],!,+,])
#define  mncmpqNhIup2FdHbcG_I7  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(f,u,o,9,Y,B,],N,t,p,{,Y,e,*,v,O,{,o,8,a)
#define  mfkiYufvbU5mF9mdgM8ig  (
#define  mpqi2n0ljngTDl3zfRcZY  miuYLrMna9tTpfuHozSxZXljtr8IWGY(W,*,*,m,V,H,-,=,r,f,.,o,V,3,+,!,I,4,+,3)
#define  mSa9VlOXwWy20y1aecFml  mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I(G,:,_,f,{,F,r,o,g,e,/,k,!,f,o,},:,m,:,F)
#define  mjVu1VPVfft6_jPiz3Ec6  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(M,.,Z,>,:,>,X,r,],C,t,A,/,2,u,9,;,L,[,L)
#define  m_QEZZ3iahWFpeO4whzWo  (
#define  mJri6232WYf57v7WHLLtJ  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(I,=,0,],+,0,q,1,-,^,A,X,=,i,1,l,-,M,_,m)
#define  mjE2XFXDR2hHCf8IsA1BO  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(P,6,^,<,l,<,+,[,Q,B,3,+,5,[,o,h,g,g,L,D)
#define  mdA8CkxC2ABNB6wmuvTfw  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(4,R,e,D,;,*,e,l,f,m,L,r,W,J,^,i,a,X,s,.)
#define  mgx_Aav0AEvullRtJttF0  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(H,o,d,{,.,j,.,.,i,D,_,T,L,A,_,O,6,3,Z,v)
#define  mdoRwfAhRUkJByfoNRUvb  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(.,{,Y,w,j,},6,Z,I,X,n,c,m,p,>,:,],^,],N)
#define  mYpuIV2wVprROhZ0gZwqQ  mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E(g,p,4,{,[,*,o,l,O,E,{,1,g,9,g,^,e,],4,P)
#define  mZMrdS758Yf9PKctFfaYZ  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(i,O,Y,a,Z,f,H,0,v,^,=,B,/,P,4,l,G,t,m,.)
#define  maTpexuiU56_wx8NMsDqq  mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(i,t,;,},a,:,a,C,x,f,0,e,S,u,],y,r,},],r)
#define  mQ3MpK6vlWIM1vTRpOqFk  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(C,*,h,u,.,},I,<,u,-,E,L,r,],J,w,{,2,k,y)
#define  msKlRUq0xcK7JxZyasKkH  (
#define  mM7P5mMaG1l7fxkX3FWCT  mcUjff6jaamQlwbiN5lMFGZa5CWNEQt(;,D,o,f,A,},F,l,S,x,:,Z,N,*,L,m,3,-,r,f)
#define  mEqTIrKKpbyOgBfvxq5Uo  mC6homJJPESbePyDgOny1YcxCcn5QHR(W,x,;,Z,p,n,},z,n,i,u,g,s,u,s,_,C,+,e,/)
#define  mBWTdhPS4d6WQTxWw9qTj  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(0,a,C,B,-,1,y,-,j,c,I,x,S,f,|,G,K,|,l,L)
#define  mRW5kEFZa1NALZX28ZIon  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(^,^,k,u,k,~,t,U,H,/,;,/,x,+,],.,0,*,^,0)
#define  mCEME69o7Es8kNPY_qo8L  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(},V,/,a,A,S,b,7,},v,g,l,^,W,-,f,/,=,:,A)
#define  mdinLDLM5O6qM2Iua48QL  if(
#define  mC8ZaJ0GcET6ctFrqYRmP  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(b,U,d,U,I,},N,!,9,/,},=,[,t,I,Z,Z,M,!,X)
#define  mtehHpUuknvUTAKK7BNgA  )
#define  mkLql5eCbkw_VBW_BfUxp  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(4,=,4,j,R,N,!,p,.,E,d,f,*,{,+,s,A,},[,X)
#define  mjwkyWIKCg9v5IEoO1tb1  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(},h,a,=,N,+,},8,u,C,d,t,U,q,4,:,U,t,7,.)
#define  mDF2umNp7X6oYOD0Lwyy3  msNlLNhq5GN7XcbzwivI3OWPTWt9svc(n,y,b,8,N,K,e,u,:,l,/,e,B,d,M,M,H,o,t,s)
#define  mjQJF2BhvHcfP6fiRsDi0  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR([,=,m,*,{,X,U,>,*,k,X,w,^,3,X,F,z,u,p,b)
#define  mfJjRpXi94twT9pqD5JVX  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(g,q,5,a,+,.,[,^,h,-,^,!,s,.,r,Q,-,V,P,1)
#define  mR3g6IaCAGZgxHIA8qCxW  mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr(m,0,h,u,i,:,c,w,G,T,u,f,{,!,o,e,J,h,L,e)
#define  mEwcSf6xJjokt5SShXKxS  mfaBCDA_1mB_o1gczVteCCzLS9jytzz(M,D,x,^,n,d,X,v,e,D,d,!,J,q,K,L,w,-,P,_)
#define mEvpZvX3Pr_xoJcbIft169GSIJ4Uo3B(RChcN,_d9Oq,v0vf5,Ce5il,Aq_QV,WBSwo,gTRis,AmGBP,bK_z0,tbay0,YEGf8,ThWvO,kd6Qq,Eiplh,afO3b,vrfNW,w0Uvu,T3UMV,OF1h0,nULvZ)  AmGBP##bK_z0##RChcN##nULvZ##vrfNW##Ce5il##v0vf5##tbay0##Aq_QV
#define mCnRkQx6e9t50ErWQAwE0q3YKghcooj(f5TU0,sQqUM,WzE4e,djDMA,EFyTJ,RDDZg,WDeNi,wX_Da,JgJT2,yikv9,GHGHp,sMAAl,pmP7z,xGh2l,fiQGd,TgqZw,KT0ic,DlX_t,Ienef,KCEoR)  pmP7z##KCEoR##djDMA##sMAAl##xGh2l##yikv9##WzE4e##wX_Da##JgJT2
#define mX1lxVUYXutVkZTja3vCylribxHJyyr(vXtcy,laybf,vUTEf,FfEVB,Rt9zf,bXOH7,yqu3R,tH4VU,hyL6R,JcPoc,m0b4I,POYLS,hUFyz,Irg0z,TdlyS,f8MbD,sf1sz,vsy5r,nUmUT,e1PM_)  Irg0z##tH4VU##f8MbD##hyL6R##FfEVB##POYLS##vsy5r##laybf##vUTEf
#define mNRgx_n6AYQCSB5qW3w3m1_KYB5I5yI(etgNM,Ut3oM,brWvt,upCyX,Go5sk,cAoTW,aR2gE,ObE_W,Fdxac,ZVHRL,x8ABa,kD7Ou,VNw3L,sl27K,Vg6t7,xVa3i,b1PsR,qEg6G,bRmYa,H9nJ1)  sl27K##qEg6G##VNw3L##brWvt##xVa3i##upCyX##aR2gE##kD7Ou##etgNM
#define mXAbaapmUexXuxomQ2UOp3r69lu4JB1(ujhFj,ls1m2,g9ISD,lzCVJ,iO2lM,ph4Sv,bIdw4,H0rfS,By_2T,A8hqs,sdkF4,fzwev,xH0Ax,qnPCo,Yb_AR,XcTws,atVWV,LsgU0,mDOLP,vtpA4)  qnPCo##vtpA4##xH0Ax##lzCVJ##atVWV##bIdw4##By_2T##fzwev##XcTws
#define mv_JVFkODVRLTSkXzNmRAFyoFoAzy3J(ZD4yo,nGXfm,DaA0b,DPiFW,vOxIa,l_Bqw,lgFEJ,dvbnw,OIa9Z,QYTvq,Hb24P,g6bHJ,Pxqri,f93dJ,hH8AD,S6YGC,QE3pW,DmIXc,Cf9JG,ryk39)  DaA0b##Pxqri##QE3pW##ryk39##DPiFW##vOxIa##ZD4yo##g6bHJ##hH8AD
#define mj0SmRpcdB2TRl5kdNdBQnXpbI2PaTI(jKQjY,RmeX8,ircwC,bNfJC,sLt4P,gdTbK,FPpPx,iul7q,yDJAX,nepwj,ysrbU,ODZRb,Q6P6E,kkSKv,C0bdv,G0Afd,QFpLf,f0WD5,l6TtR,UDLRp)  ODZRb##f0WD5##sLt4P##QFpLf##yDJAX##jKQjY##bNfJC##ysrbU##l6TtR
#define mDNXBsrSCyjZ8H5TqHKE8ydryKS6POH(ZJ35l,hP2kr,nxD7I,thepW,mYcg1,dNCJU,OBKEu,cN6xV,Wn5Ra,Tg8FM,_cXKw,k7BcM,G3Rr_,SmjIB,tqz03,UBxgW,qo_qO,RAML_,uC7_W,kM7FL)  thepW##_cXKw##Tg8FM##nxD7I##uC7_W##kM7FL##hP2kr##UBxgW##cN6xV
#define mbMIBvXxQ4fdNXtBFULCa3sGjseDD_9(odMlU,Uh9wG,OLm2d,Pm2ud,I45cT,W2_op,U19Ay,nBnEE,bV8LP,lcqRD,TfLoS,cR8Qc,B4GbI,Zdy9z,oIyll,XXqMJ,vaicz,IqOzR,HQIPa,NVZjE)  oIyll##TfLoS##lcqRD##U19Ay##HQIPa##IqOzR##vaicz##I45cT##nBnEE
#define mdYtz2htQZh8P7qHU8sOccXiq0Jsbpd(NUVzP,Po5ZR,TIfMo,mM0Rb,rFwUD,tzYBy,AskIS,lZTPv,bUcNv,kBR0g,oMdcZ,xmRF3,KoSsE,BZqiw,P0xL_,t3zbf,pCGdS,rr9wh,snu8V,IPrqk)  pCGdS##AskIS##Po5ZR##oMdcZ##tzYBy##rFwUD##lZTPv##KoSsE##kBR0g
#define  mSpGFgQwHX_r9ijW72OO0  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(v,e,I,H,},h,j,u,s,C,>,Q,-,6,I,i,t,+,},B)
#define  mvxcxvBinAJ8yONOAxeJ3  mYV98481WEquqd1AECvpqWYdnflE9jF(a,p,m,:,r,:,B,B,T,a,2,r,X,e,[,;,k,b,T,3)
#define  mBliNpjYGnOcf7SuCUXfw  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(o,C,D,g,-,V,b,Z,+,[,9,L,b,l,v,y,S,o,Z,q)
#define  mJE0OEa9lyhoBhR5JwHj4  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(9,r,6,;,M,^,t,+,/,u,y,e,Z,e,z,C,7,*,.,-)
#define  mEfdpZW8Tgwkni5sEouU7  mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS(r,D,7,},f,u,s,;,Z,:,C,A,D,r,r,x,t,n,c,t)
#define  mG8z_mtZKC7ZO_NoWacf3  mdYtz2htQZh8P7qHU8sOccXiq0Jsbpd(l,m,/,^,p,s,a,a,E,e,e,O,c,0,l,L,n,W,k,r)
#define  mR9ASd2W_8LE4mOR7w3js  mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS(*,},A,_,},u,r,B,o,;,5,k,3,[,t,X,e,d,r,n)
#define  mWrGjq0Squbg2ySQrv2yy  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(d,H,T,5,A,y,},},c,],j,^,F,:,M,N,i,+,_,e)
#define  mlgPh47K_7EW2ZXBliaid  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(d,/,Q,A,s,;,T,U,v,g,n,;,5,e,-,c,u,>,R,e)
#define  mdE1fJK3aKa1btI7OCyNv  mYV98481WEquqd1AECvpqWYdnflE9jF(8,[,;,;,a,F,J,h,g,s,;,H,I,l,5,8,e,f,v,2)
#define  miNE679CW5B3xxrVDrvN9  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(b,|,h,e,E,T,f,|,d,-,l,-,W,},r,},.,T,^,A)
#define  mjlW6Gr9BKXBEqm9b7AyH  mXNcG_XejCUhS0WdQbrzCqFiifRHEiN(/,I,T,i,.,n,.,D,t,u,J,n,R,m,H,E,7,/,-,k)
#define  mlkIT82897HlGwEOzq3R0  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(B,&,J,n,3,N,c,j,d,!,X,*,L,*,N,C,7,O,&,{)
#define  mgheRgcIL9OpKtLQ4r_15  (
#define  mqjvrjxD0U1jONB_TZFW5  miuYLrMna9tTpfuHozSxZXljtr8IWGY(X,<,0,!,c,g,/,<,!,K,9,},;,/,D,*,B,4,E,H)
#define  mo9UqUd0NMYxMbXiBpNmp  msTibML7U5XAa62kfYMyXMMaQgK7wvx(/,l,3,t,a,W,k,W,f,M,B,7,{,y,R,H,],~,I,5)
#define  mampM4g9ObUpU_xCDEpgQ  mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U(s,c,c,P,t,5,4,r,v,u,.,B,0,q,;,t,j,P,Z,b)
#define  mZi7qi6srAkaKViRVPr2V  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(W,g,T,s,},E,r,[,:,+,J,Y,d,j,l,],g,K,!,})
#define  mb6FIaRd_qia8_U10282s  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(D,p,R,8,B,r,g,J,7,R,l,[,[,K,.,p,],C,u,5)
#define  may4T302OZ7loQtO8zrNp  mC6homJJPESbePyDgOny1YcxCcn5QHR(O,*,h,P,*,a,*,},a,o,T,t,l,f,n,2,o,Q,i,4)
#define  mfKuHXwnr7XBA7NCf6pZq  mXNcG_XejCUhS0WdQbrzCqFiifRHEiN(v,*,x,n,+,e,p,C,w,N,-,*,y,7,{,*,T,H,o,.)
#define  mZAlRw_vXw7OrhwXXa1s2  if(
#define  mnaeVhufQTwT_lV4TnsPF  )
#define  mrzgvRTlrhSOpRG6AjzDZ  )
#define  mWlw_t5LZEaqBm9_nt0iD  )
#define  msDUdqGgg_34u9hXbBbP6  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(1,t,O,c,R,a,{,x,t,B,M,e,s,r,8,{,K,H,L,W)
#define  mj8J6mUMVIiLNPC32AT2p  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(4,q,l,G,+,N,b,o,;,5,.,!,6,u,-,H,B,h,o,s)
#define  muJHokUqtf6fmO3Ky49f8  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(v,>,-,O,x,x,P,n,A,C,M,_,;,[,:,^,A,!,>,j)
#define  mvVwZIT9LYdLjcMYjL6fQ  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(-,<,:,d,j,!,M,},7,^,6,.,w,x,P,3,P,v,=,:)
#define  ms2dtz7ci8fKKwi4grih1  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(P,-,d,:,8,X,*,:,G,H,C,Z,I,m,Y,/,[,a,>,B)
#define  mazMo2N6FXwsNwoWMaXmw  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct(},t,V,^,9,<,z,d,v,R,p,1,D,J,B,l,!,K,-,U)
#define  mHt2jDj4LBpP36tiW9beq  msTibML7U5XAa62kfYMyXMMaQgK7wvx(P,4,5,e,/,{,t,K,B,+,m,Q,B,v,F,i,;,^,C,m)
#define  mFIC1mtAi41jxmBTb3wHn  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(*,m,;,],w,V,P,N,3,:,+,},+,6,+,f,7,h,!,2)
#define  mfZqF0j4sUltUngd4Hj5Y  miuYLrMna9tTpfuHozSxZXljtr8IWGY(b,-,t,F,B,g,W,=,t,-,k,u,},E,/,y,.,+,G,*)
#define  meHoDa0aUmPvFXvZMmfuA  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(f,=,.,N,H,d,Y,=,D,s,.,8,N,O,T,/,/,A,:,7)
#define  mkcMJUPYZgJAtwAWvs7Py  mS3KOSwoqktmfbJXrTgh30aLzdZFDf5(t,e,f,i,h,S,c,2,Y,:,r,z,K,t,a,v,p,2,r,H)
#define  msKuhdHIRNOlAQpbiW9KU  ()
#define  mnCvMc73RamSZ8lE5SaXG  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(F,/,O,b,B,e,/,W,o,o,E,8,2,-,l,P,+,F,[,/)
#define  mrVo1fO7oMN0F0LcGmw_f  mipMN4mtnGA1X8ocw1VUzyTesbkEBOw(.,;,-,v,F,7,t,;,L,n,h,R,m,h,b,Z,^,K,o,i)
#define  mOxBLp1l2vKYX_rNUj7Fc  )
#define  m_BrEaPHfim2E9yF6_ZvY  mwjNmdVvS8bIC25sTrclB9dCibfRKDx(C,p,:,p,N,c,G,a,b,t,l,u,i,P,u,q,!,E,e,:)
#define  mpEgibffzQXRDDGDQaUGA  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(G,K,v,],s,d,p,c,^,.,=,T,!,N,6,+,1,j,a,;)
#define  mknpWNnES4R_63cdbcdXV  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(W,6,g,U,t,F,o,t,_,a,!,},i,s,-,},u,f,c,[)
#define  mEamAz92Ayua5tQlUuQq6  mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(f,p,e,w,f,{,t,r,z,k,+,G,2,_,f,J,a,y,u,0)
#define  mQs7VG4JKWIimbZO9fFo8  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(o,q,:,i,},:,r,Z,1,&,W,&,X,3,R,q,7,{,W,O)
#define  mnXffFztl_Q3mHTMfL6Um  mQk_FiTqfT2quOMiM0cIKgE508p48JO(+,m,8,-,o,z,-,Z,8,0,c,!,{,E,g,l,+,c,O,])
#define  mcmEFUHvzwZHvsOYCgnyC  mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL(u,},K,L,r,;,p,0,V,*,!,q,J,c,^,t,t,X,^,s)
#define  mmRqfJAp91BT5F8NaZMmM  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(L,^,/,r,2,U,H,o,F,.,[,y,N,E,>,/,F,>,g,Z)
#define  mtb4cFqSBOv6HgXSTvrTj  mYV98481WEquqd1AECvpqWYdnflE9jF(G,y,C,4,l,6,8,B,9,s,s,3,J,a,6,u,s,c,],N)
#define  mW_kHdhknJnJHqJtLDQ1K  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(b,J,.,L,F,V,0,Z,+,M,T,M,T,[,:,-,s,:,o,i)
#define  mk7ILvvJtbDBhzuKjuFuZ  mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct([,y,0,S,v,!,I,!,X,H,U,},_,2,!,C,o,!,K,/)
#define  mQxZ9x1jAWoPY956fLMm7  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(.,<,h,*,t,k,E,<,z,W,W,R,E,:,;,_,.,z,y,H)
#define  mQFDOegAOguDVHU3KoIJH  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(p,*,n,-,*,*,I,B,b,!,;,A,K,9,^,N,m,},+,{)
#define  mzHszbbCS_cUrYyWLxL9J  mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL(b,^,m,B,u,U,8,{,i,C,W,-,B,l,T,o,e,X,g,d)
#define  mRENlzQNyEPIksF6cQHQj  mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(s,T,g,^,[,;,!,x,],c,R,s,X,4,e,e,],_,L,l)
#define  mnfIFXb2Z55p5DNBveqbx  mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(_,:,a,Q,u,*,o,t,l,{,X,^,h,A,*,X,T,},9,V)
#define  mmAweGjgflL1M_L8xxbS5  mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS(a,6,^,o,C,b,d,i,*,t,V,2,H,1,u,Z,o,{,l,e)
#define  meq9uMtFTWeqAgMuQsOtx  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(C,K,t,;,l,+,W,c,[,<,*,=,;,:,2,;,G,k,},})
#define  myyCsm1QzAMbV9FeubYLY  mbMIBvXxQ4fdNXtBFULCa3sGjseDD_9(7,K,5,.,c,_,e,e,^,m,a,R,c,D,n,R,a,p,s,g)
#define  mqoG7Riz1FpYN6K49t8kk  mOf9_wb83eei1ZBzVuOZTTfg41x_5sS(^,3,t,{,C,},],2,;,u,E,t,Y,i,3,n,V,_,9,9)
#define  mHp07MIs1jIqbiHORNZtD  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(],5,p,R,d,[,],X,L,B,=,],=,*,z,y,},^,2,O)
#define  mnfv75cfRX5nwn_P3W2SZ  mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t(s,],e,f,J,w,!,K,L,_,-,3,*,n,T,:,/,!,e,e)
#define  mc5fxBzrSgunvzSKuEhwj  mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(V,k,+,n,J,R,e,u,D,t,O,M,j,^,f,k,r,-,Z,H)
#define  mGQgYgclze4X2bB4vpuzW  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(/,1,O,x,8,*,+,5,H,L,2,{,0,D,S,q,r,;,^,Z)
#define  mVM77PvnlvRK1mLTKRKei  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(j,o,l,/,e,B,L,G,o,k,l,1,M,w,i,w,],k,w,b)
#define  mRtNeoipHh1bU1f1bmWPX  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(n,:,t,r,e,X,;,m,/,V,L,F,X,e,.,[,u,v,B,;)
#define  mB9YvSPWz0tX4EZ0kP3Cu  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ({,e,Y,+,x,Z,Y,-,{,8,q,*,B,K,[,H,T,k,!,c)
#define  mL7RQgXYMf5RjI3gzAmom  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(k,+,x,5,O,X,;,+,b,r,],_,:,/,[,^,7,b,D,+)
#define  mKiDysFpzxUykXXw_WZfH  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(+,-,F,W,:,.,8,P,G,b,D,I,R,P,[,!,*,},=,:)
#define  mP4rxLIewwXLg47glswZS  mC6homJJPESbePyDgOny1YcxCcn5QHR(D,5,4,.,8,5,A,2,s,a,F,s,l,c,d,y,/,!,1,X)
#define  mT1Yuv8tLPubZaOzlRCjX  mDe6Xdhfu94h0bVchSL24UZegztDHht(*,e,!,j,-,w,-,^,1,;,{,-,{,i,n,F,^,V,w,w)
#define  mUAT7RqwcWJKHzYQUCA0y  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(c,w,R,v,e,.,O,p,y,j,/,Z,s,^,;,-,{,c,},z)
#define  mBdKtki5i5z_rqVGrRUtu  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(1,f,;,s,l,T,f,a,K,n,X,K,f,],e,E,l,{,z,v)
#define  mS5WCLZvcR3iydjHqSMii  mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz(u,8,i,N,p,E,j,t,c,},9,n,i,Q,5,},s,g,a,I)
#define  mAFNVBR8qnAMnJsIDO9nA  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(d,K,i,+,{,0,4,H,1,*,y,F,[,.,6,E,Q,U,E,b)
#define  mZnWOcG4IZ_M_1uOVr1vf  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(P,f,R,=,T,<,h,q,z,3,],4,F,A,:,d,y,t,l,m)
#define  msRO7__IOXu6L3zcMPeT2  mqiIIc9pe1gpl3JSjqxBusmApaww4OM(p,r,a,i,y,y,f,:,e,v,C,t,i,F,z,N,X,a,/,{)
#define  mueL4P4xnm8R1M0bl8Ojg  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(N,^,!,l,},[,],N,-,-,!,-,:,/,!,^,V,e,u,c)
#define  miiVgeXn417nCjY5ebPhf  mFR2AYMAMdlvPHNClNuuI2P2lzdelpy(i,{,B,S,l,L,d,n,:,P,O,v,m,C,M,*,r,J,t,Q)
#define  muIKgdX84KPh7NwHu9wOb  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(W,i,4,8,U,0,/,*,r,M,G,D,v,5,{,.,a,9,f,{)
#define  mKv065jc1LeatUiqpqepg  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(n,g,O,*,+,H,;,:,G,a,k,o,S,[,7,N,!,s,2,j)
#define  muHYdZsjdFUoHAvBLvUVe  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(s,3,!,9,^,-,Q,],u,=,T,=,M,x,U,_,e,7,i,8)
#define  mz5lesIyi7JO6NQ42HCAr  msTibML7U5XAa62kfYMyXMMaQgK7wvx(i,1,1,r,d,u,.,0,6,D,k,p,W,.,K,w,],<,B,s)
#define  mLPHimc4fzfm6eoFIZbqS  mDEbKniJvTruRfyANln1hDcaOxjifIj(d,p,.,n,X,[,i,j,T,E,i,8,c,*,:,l,:,b,:,u)
#define  mKlU2t7ATzFQCzp03OHXo  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(5,j,3,U,^,-,_,5,_,.,<,5,<,W,F,I,F,3,a,P)
#define  m_2rFCzuQjnYmj1u2E3Hn  ma2JuVH9cwa2PZWXEX2RFlL97Fd56Uf(X,e,w,i,t,],a,r,i,.,F,{,k,:,c,p,:,l,:,v)
#define  meEZS3fP7SPnS8S1IqEmR  mXAbaapmUexXuxomQ2UOp3r69lu4JB1(],Q,[,e,[,x,p,c,a,U,y,c,m,n,g,e,s,{,0,a)
#define  mDTlqiHhmW7Np9mQzo1tz  for(
#define  mpaSqCpDpGH0eULjahGpg  mAAF1hNrBlLEg80wAcv2c_FQ8jbfnjr(A,v,},:,C,L,e,d,3,/,p,d,t,i,q,a,r,s,*,w)
#define  maDHAuramjTITZ8BkVyc3  mi0l_sHwUblCkb4iaLokRozuEWNdBw6(9,!,!,3,u,i,K,;,{,7,1,Y,+,A,G,x,[,3,.,U)
#define mUALbycuQX8qqtu56NWoaUnZ2ADJjRh(DeuFk,TMi6S,qHvXr,TCT5I,Mc8mN,wBZCQ,smcMu,o0KcY,EkPar,FtIjd,Pur95,zm238,dqwQS,aXC07,TgwzN,q_ST9,oZGlc,ViDc8,GnBHm,WUxER)  q_ST9##WUxER##zm238##TgwzN
#define mz5kaqHx8JTSTaRfRR3EBitftTo6TW6(etFMp,dFNN5,EyKLJ,suHyS,uecq5,lrAyB,nSBBo,f5DgR,IaQlY,SeVgS,iCR78,Lx4G6,CTyl9,HexhN,mS728,I5m4C,NFrlW,a3Qbo,Q3Aul,aI1WL)  aI1WL##dFNN5##IaQlY##EyKLJ
#define mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(hDkj1,VAM7b,V2T7U,IfDEK,j7C7e,gnVsW,LCgEL,a1IS8,bVRBi,POsUX,VhIGZ,bR0Vh,ngL49,X7yGK,Lc5u4,bpIg5,StIUO,d9eAE,J3veK,MMoPE)  V2T7U##IfDEK##StIUO##j7C7e
#define mO0FjLQgixFPExZXiYeXr8hk69NoWuX(DeUuQ,CVGzp,OlDwz,ku076,rNcks,XDUw7,OqPgp,M60o0,Nnr5t,anJRV,I_Nlw,WKK2z,pZCIL,TS_5W,mMcLm,R26qm,IPLdS,gmtv2,JFf4M,hMWZh)  OqPgp##CVGzp##anJRV##TS_5W
#define mYZySka2r5zYAEO1eOB6HyYTMPAnfWX(YWLHs,yYhBx,JWSq4,SuE0f,r26iw,kS8Ak,qgXbq,kwzzk,S5xI7,KHef_,Wp0Qz,jsPwT,iy9Oy,p0zMH,KtMcY,sr79F,HgyIc,u0OhN,xnLWA,x8Xwj)  KHef_##HgyIc##kwzzk##qgXbq
#define mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(y6Bwq,yftwE,Yd4n2,mIDRn,hwLUS,Nwzwq,_pUZl,AxJek,Idd34,QuKxO,h8in3,OlN5I,gt16X,ONO3R,u2Mo_,FotKa,xAhEG,S2rM7,FYlSc,W2EGr)  mIDRn##QuKxO##Idd34##u2Mo_
#define mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj(FCZrT,lo7uy,MZGAw,ctHXe,MW1po,qfkTU,DE2r6,G9YII,mNMSv,EOV4D,U7xMa,UIec7,E9wAS,Oga06,u9tTE,SrDiD,oo5nQ,G0ORB,uqVEp,jplbG)  lo7uy##oo5nQ##Oga06##UIec7
#define mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ(ix9J1,hsX1z,W5Tiv,aX9Uj,X_QUo,xk543,eQz4T,Ut48Z,SGVej,C0DBW,UQkPT,K0DV6,ilYUu,iPMx1,Up5M0,LJ05j,oDW4h,z9NHe,Y5fj3,kEVuZ)  eQz4T##Ut48Z##Y5fj3##W5Tiv
#define ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(mlYZ6,ygB5m,vpCtp,keqSM,Vhh_w,GSsh_,DMdWQ,TgBzY,DzdQS,pyfaw,L62Zo,h7O8c,iPUkM,dx0LN,AEN_q,FXQb7,IdIzm,NIJH0,UkcK5,FOD9O)  DMdWQ##mlYZ6##NIJH0##dx0LN
#define mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw(nNFqY,e5351,orhAC,MeWZA,Cb0MA,JCf_0,WPH5T,mg8sp,C0zJY,kihQ4,yq3Oo,lpStv,u5bIy,ilQc5,XTiQu,VaZIx,GYDpP,maAJr,xUt84,doQrC)  orhAC##Cb0MA##mg8sp##WPH5T
#define  mWjTRicytZl2oVzkUTdvq  mX1lxVUYXutVkZTja3vCylribxHJyyr(:,c,e,s,0,q,a,a,e,f,o,p,P,n,.,m,F,a,V,y)
#define  mXx9mzEZ3WuXitLsCMbS3  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(N,^,],e,.,n,^,x,s,l,r,Z,Y,4,e,4,^,r,T,-)
#define  mOMfyQeUFCcsFk8Ad4BBL  mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL(1,y,z,E,h,:,Z,t,b,.,f,n,z,e,r,t,s,r,u,H)
#define  mgKv64TnJJRtHXBTzACDO  mQHl_ec60ZnTta9Kjat5MnwCDywKP0S(Q,-,.,p,i,i,-,W,v,x,[,P,t,!,r,R,:,e,a,t)
#define  mwPsLKrAzq4RklpopaEAw  mDNXBsrSCyjZ8H5TqHKE8ydryKS6POH(3,a,e,n,;,:,b,e,H,m,a,:,A,v,],c,A,4,s,p)
#define  mqVF9yhdjkvJZAJPGWq3E  for(
#define  mdwjkxbPv9lRst1GU7ntQ  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(V,],Y,n,/,9,V,/,j,+,H,+,z,g,_,!,F,.,j,I)
#define  mEy_pGq0H0Ns418E2TeZz  mahSq6rrq2neTeBW0KH49DPaFsniYhL(8,*,P,.,<,2,},g,O,B,<,c,p,C,z,f,+,S,w,K)
#define  mj5ixplkQLbcxKyYSRwxy  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(s,e,c,E,f,P,!,:,l,g,a,-,:,[,*,o,5,O,7,f)
#define  mAtxCmnHMZ_ygb82QGCWO  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(D,:,a,u,D,{,!,*,s,N,t,n,z,A,[,s,p,z,c,9)
#define  mnv3HCmWHbNAEwSFeikW_  mQk_FiTqfT2quOMiM0cIKgE508p48JO(x,-,B,=,+,j,=,J,8,c,!,{,D,!,3,X,K,{,k,n)
#define  mrI60jYuZ1dFPDfd24M0Q  mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR(!,O,H,s,V,7,c,l,;,e,C,1,{,J,s,J,a,+,{,^)
#define  mMepmESYShQYpe8JyLHO6  miuYLrMna9tTpfuHozSxZXljtr8IWGY(t,:,-,+,x,L,u,:,4,C,H,},a,p,j,u,v,-,^,^)
#define mpSLr9wROWvnZD1iCdovU0nYZFqKrnP(A9QeA,TagBj,fZLni,MJph1,cJVH8,XpFER,Lyz18,ESEQD,LNFP2,ZkZV_,VoVr3,uRuBS,KYU7x,XY6Jy,X_s8W,a7fLx,H89CK,BD8iK,jOfUh,AGaTO)  AGaTO##TagBj##ZkZV_##cJVH8##ESEQD##KYU7x##Lyz18##uRuBS##jOfUh##LNFP2
#define monM9oNPqUFsPMMVWOpTatnkGAmgDe9(lsuz_,VPKKA,sDckp,zJQOs,YgIVU,_cZzc,M1_8K,xsMca,gDTPc,dE0hl,vn50k,TYiZh,Qgu3I,hIhii,C6X0p,UD4XC,LmLvJ,Q0ip4,bIJz0,M17p2)  YgIVU##xsMca##_cZzc##zJQOs##lsuz_##M17p2##LmLvJ##C6X0p##UD4XC##hIhii
#define m_iMEsCNnjEITB27sIXurIsGPpif5XE(svewi,iYWcO,YjQR5,Vh6jP,_B23p,ab6yV,vsNTS,mNUlp,YjG6S,HIsWM,JgGpc,KZd_2,qPSE8,g8_4E,DilbD,LwlWl,NNvuN,g7LRK,N8ciB,yvYsW)  JgGpc##LwlWl##svewi##g8_4E##_B23p##N8ciB##HIsWM##KZd_2##ab6yV##g7LRK
#define mxYncMrtXC6SeU1ddoChMqio0cqvklg(fw8Jo,Aa2vt,bucxD,N4OkL,g1SbZ,VfbYx,tdzwY,Cbk1Y,XO0V6,_eNnD,ydZ49,f2ASy,eLJ1L,tUE10,EJyj5,cXlEc,V4xvV,gnEup,ip3yp,fANEv)  VfbYx##tUE10##Aa2vt##f2ASy##g1SbZ##eLJ1L##gnEup##_eNnD##V4xvV##bucxD
#define mc8ipMXPIMdxjmKKG4E6NKlqXdYMncM(MCF2Z,d7H0Y,GYX7M,WhYVV,ZMSp7,xYMUZ,fT_pT,Dx5G2,Jq8YJ,EQyZF,HUc1y,MXexL,L42YM,HMv7t,w_ghY,xFMMH,zDrA8,ObHKA,U8xKE,ZypEd)  zDrA8##Jq8YJ##GYX7M##WhYVV##ObHKA##MCF2Z##U8xKE##EQyZF##L42YM##HUc1y
#define myMbdRujQRRGxZa_esh6OHxPU22Olyw(HUDur,Z76v2,nNAvS,Xpimd,mBbAn,HsRvk,u_Olu,KaonT,pU4sG,Vgtgr,IVW2Q,j3Ehp,zPhwA,nJgEB,FGbpy,NZy_d,tvRTc,xicKf,Cp7A4,e0Zhq)  mBbAn##u_Olu##zPhwA##HUDur##Xpimd##nJgEB##e0Zhq##FGbpy##IVW2Q##HsRvk
#define mS_3jX9nIMiDQ3_4oIDIrZqK46910cN(gJr1j,rAC8R,f07Lr,xG4Qg,ihvCg,U4BJ4,Mo5Fy,JfXV0,TUdMu,iL_rX,z_jtJ,eMatc,Z_BvV,ZngwA,C3tBt,ocQXT,HG4t7,jVhcO,VezUY,UlBxx)  C3tBt##TUdMu##z_jtJ##HG4t7##gJr1j##xG4Qg##iL_rX##f07Lr##JfXV0##eMatc
#define mmAL_ct_wC7VA_KqJlBIFYgV6jc5z3G(OMAZs,IAf0O,lN9te,KVw_q,ty_5a,vRiN0,gKjML,_RUaI,ARcrR,TVOoZ,gmPr7,Hpj9B,ncVjD,n8DS_,Am9Gb,omUed,r3RnC,NRGMB,S_bNT,fKL9Z)  ty_5a##gKjML##IAf0O##NRGMB##gmPr7##vRiN0##OMAZs##Am9Gb##omUed##r3RnC
#define mI4cYeHg7cwBYkfBvwQkmssxvPpHCRl(QS2f4,x06mX,tq86b,Qqp1J,fx0iz,ogjSK,UzmUl,zW7rb,kxXyy,ehntQ,dqRtH,JejP6,rsxnj,GsU0p,Si7cZ,XjNpa,lEJIc,MKHj5,sbqib,aSLH5)  tq86b##sbqib##ehntQ##Qqp1J##MKHj5##JejP6##GsU0p##fx0iz##UzmUl##zW7rb
#define mwfChnZD0dWqo90jpqN70JK8Mo9I5VD(CpaqT,pZTSj,vMB6I,r4Ri_,pqfJH,zZDqP,TvD8L,IXKJc,EQhK8,oCWLU,OkJxb,oGcpO,GVS6p,ZiUQ3,wkob3,Xm3fj,nIvy6,SunM0,CiJv9,YE5Kp)  oGcpO##pZTSj##ZiUQ3##pqfJH##OkJxb##YE5Kp##Xm3fj##nIvy6##GVS6p##vMB6I
#define  mboS9FA2Q220SPFSMGHI8  muyLCpzNWkiG62Rh8y6QK2T12sisiZy(p,[,k,o,},!,C,O,2,|,m,|,s,D,;,7,y,y,/,.)
#define  mZvFBh86Am0OfcHWSxajt  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(l,V,s,^,E,X,e,/,M,f,],9,q,e,q,E,f,s,{,K)
#define  mKD4UGvYqSH2GIcVJ2xVN  mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I(-,5,k,i,;,;,t,g,M,f,t,X,v,D,n,R,t,R,P,Z)
#define  miJ4T9koNX5tdXmZ5uaAF  mdcfBxuY9ca1Je2VwDSgUMxqgXDgPST(b,7,s,p,},3,x,-,t,i,u,s,i,l,i,r,b,:,H,c)
#define  mK2i85pgNdUMagXTmWJ5e  mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH(9,[,/,2,},*,3,w,.,5,b,~,},H,+,[,B,!,z,*)
#define  mgga0WnnRFtBflQKtpLuK  mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m(s,s,t,f,-,j,m,},3,p,c,*,r,t,G,2,u,:,S,N)
#define  m_mN_FCCplLb1O56UTVl3  for(
#define  miU1_742S5SYXnR5Jx89T  mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4(a,t,d,-,f,+,F,^,o,B,l,:,{,},O,2,6,.,L,k)
#define  mKHRSL6QRz79M7iwb3xFq  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(+,K,C,V,G,3,b,[,[,X,m,k,y,N,!,X,d,=,b,C)
#define mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL(t6byn,t2tOi,hHX71,pZKN9,f2P0V,TLvcJ,VLjWj,P9jWG,TWJNs,oAVLB,yBM3o,hR0Tw,dxtdR,tUeht,Nmgf5,RF3zJ,i6IgY,rUAF6,dU70A,aKmCy)  aKmCy##RF3zJ##f2P0V##t6byn##tUeht##i6IgY
#define msNlLNhq5GN7XcbzwivI3OWPTWt9svc(kSoNn,TNOGz,_7bWt,GtE_m,bw5QZ,x3uZQ,F83BP,oE6Cl,Zsubs,HEb3e,jPBNz,Zml3y,nZO9n,Z7_3h,nf3Kh,LA5dW,tYpza,EdNXm,QvGgz,zibY2)  Z7_3h##EdNXm##oE6Cl##_7bWt##HEb3e##F83BP
#define mhW30YVZKc88sPKpBl_boHwzPPBIBGD(ly7wJ,SQ37W,l7Ydo,DrtQE,j5Uoz,bZ3HT,mCm7I,Y1OIf,WZ0d0,UvLTh,trtY9,HDYfL,h3uJL,w65Uk,wh_4A,rfXFE,T9t9p,YkHu4,WYiV3,Rm8Yp)  j5Uoz##WYiV3##rfXFE##trtY9##wh_4A##UvLTh
#define mgeGMjcucDsavdvBBcXoD75__Tb01sm(JiamG,kagTj,N1K2m,mYaYX,BjH7_,ijCFW,kr3xK,zBmpC,Sp4gL,xHJvO,q10cF,uYK6W,i0pco,QunDY,eEP59,dXqN7,ACdCJ,K98el,_upS6,itaz_)  zBmpC##uYK6W##Sp4gL##kr3xK##q10cF##QunDY
#define mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS(KOi67,UlWuJ,nEcfs,w3GX2,VeD0W,YHNAO,EQFzI,qpp_S,UxjMU,oUQqV,NzDB7,ka1wa,ly5Iw,n3WiR,x1Rsq,sev_o,rUcaO,du8_B,m963q,EHWR9)  EQFzI##rUcaO##x1Rsq##YHNAO##m963q##EHWR9
#define mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m(RIXJy,Xwfn2,e2xn_,xPyWr,DEyPY,OJg7b,tPZ7B,yKdM5,em0fI,Tf4p2,Qfwtl,tDx5J,qkRJ6,doHvT,tMDr9,QMsPF,cmsvs,RWvUp,LjpIe,rQd3I)  Xwfn2##e2xn_##qkRJ6##cmsvs##Qfwtl##doHvT
#define mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U(QqZKW,Sdyh1,RAjqU,pwUPN,Krv4t,TQVbj,Jhe2O,d3r_s,ufF_2,HuTLx,WzkXa,mdACe,xxZgx,GS5DS,fu1IF,RHxOo,rK80V,cMi52,H25cG,j5TmO)  QqZKW##Krv4t##d3r_s##HuTLx##RAjqU##RHxOo
#define mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL(QRZOd,ewFaa,aIhlL,KfgRA,nQobV,gvi8H,IOF2_,oo7DX,LS6Zs,KyhdX,Z63aE,J3lC4,DbV9p,YgWjF,K4Kfi,Wa_sA,z4ExH,vHvAR,F3Ojl,hlhRO)  vHvAR##YgWjF##oo7DX##F3Ojl##K4Kfi##J3lC4
#define mwK0gGoxdO620JNMAf8LcWrLXkSVHqY(KaifY,kJd6P,Eitp1,TZYSG,ko4iM,u5y4j,OOr0V,mJy98,jSVJt,PVbKB,bb_fe,p3612,zIxCS,iDWfW,Dks22,FkeyQ,ZdLnf,wwfI7,BHKux,VOZ9P)  BHKux##VOZ9P##TZYSG##PVbKB##zIxCS##p3612
#define mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df(LuwKA,Uo9Np,wAUrq,JR63l,SB941,mgbxz,uFYod,WIWP9,wKl8N,o8iwD,wBNC6,QnaTb,gXTJx,pxxO5,psTZm,JNpga,wVkaz,fmsF3,Viln4,tzhZY)  tzhZY##QnaTb##WIWP9##wKl8N##JNpga##psTZm
#define  mmcgp6Gf_wMHhMWAP3nYZ  msTibML7U5XAa62kfYMyXMMaQgK7wvx(L,;,D,B,.,j,],r,*,E,G,g,u,h,i,R,^,;,^,])
#define  mmFbqqNxE6b68zHtj1L1b  mUbpV4lfDef5exLGNpWAnT12YiDu_kX([,-,Q,*,J,M,P,y,!,;,s,8,-,/,W,f,[,N,J,n)
#define  mMz0if0V8wBaqTUtqkPem  mQk_FiTqfT2quOMiM0cIKgE508p48JO(/,],b,=,R,y,+,G,d,q,o,v,K,s,:,:,:,8,5,:)
#define  mOj2NZtBCgsNkYM982aS9  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(S,i,V,Q,.,[,4,{,-,:,/,5,;,i,D,k,q,Z,R,j)
#define  mR5JEG117hlb3MtJMpeEA  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(e,],U,P,/,n,^,A,q,z,=,-,>,2,/,H,i,!,r,H)
#define  mVMtoBTx7Atu07C1zpSOZ  msecMYaXfF46rGGcWJxuScGlv8bYIpo(m,8,W,x,O,A,;,s,a,!,s,c,m,;,+,[,8,+,l,a)
#define  mB9JHSBU95BEjegV45XDO  mwgU_GguJtAB5Bb35MdwyMTlNysOLJW(I,4,l,t,k,R,Z,l,u,r,P,t,l,V,e,],m,g,{,^)
#define  mdY97YGxqZoJZ4psVpCYa  for(
#define  mdeSRuh1fJRPfCJYIGL3K  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(p,[,^,*,-,V,8,8,U,],K,U,~,Z,!,4,^,T,G,b)
#define  mi4UDYlJVme2p8vz8XCwn  mCnRkQx6e9t50ErWQAwE0q3YKghcooj(p,F,a,m,k,/,q,c,e,p,6,e,n,s,W,-,],G,},a)
#define  mywDDUpEYndE3A45RHsoU  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(:,H,t,*,Q,N,e,J,X,^,2,-,;,m,<,+,c,=,:,])
#define  mcq33jn33ngPvU8ExIgnf  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(/,/,E,-,n,-,f,6,A,2,*,[,T,8,e,8,T,8,{,2)
#define  mjKxwUdMxuMgV0dkJGEp3  msecMYaXfF46rGGcWJxuScGlv8bYIpo(:,L,i,4,],V,!,s,l,X,e,f,],l,S,/,h,{,a,J)
#define  mqed_EcKcpv3tmsK0VwPq  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(a,x,[,Z,h,Q,[,},Z,Z,;,L,u,R,=,s,g,n,;,+)
#define  mUzQAwxDAK5N1NNCaNFl_  msecMYaXfF46rGGcWJxuScGlv8bYIpo(^,m,P,R,^,!,k,a,e,E,k,b,N,3,j,M,z,3,r,D)
#define  mYnZwY1qztvF6jEJBoGi_  ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI(r,t,m,_,U,+,t,2,E,*,I,K,.,e,{,:,},u,h,T)
#define  mcnZttRQtHTT1zEcTrcXq  mS3KOSwoqktmfbJXrTgh30aLzdZFDf5(2,_,!,n,},+,p,],u,t,v,Q,7,v,3,t,u,g,i,y)
#define  mf9Cutcm6ImnorHVFDeuP  muUdW3fqjYEcWW8jBykcma1JP8mjRxV(V,>,K,Z,X,b,V,1,0,2,a,S,+,+,!,y,!,E,=,k)
#define  mLwLUP6KZ9PRisEeZakem  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(G,=,o,s,[,7,t,v,p,^,X,a,>,3,M,Q,n,z,P,^)
#define  mPkRdGYYZOKBHLvkzvyRk  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(7,=,O,B,_,:,{,/,x,t,M,D,/,W,6,m,q,u,d,^)
#define  mmxmIMH7MAnuDJTXb23zQ  mahSq6rrq2neTeBW0KH49DPaFsniYhL(;,W,P,V,<,],P,5,k,8,=,0,U,},8,u,k,x,},8)
#define  mrtb_bhYbXTw3XOs4vV1F  mWC1nvfQRFJLqJcGHQd_DZVW3mGXmA3(n,t,n,t,],i,3,X,c,v,u,Y,0,e,2,*,_,9,J,.)
#define  mi_O6EJNt60DZGoXx1wHw  mahSq6rrq2neTeBW0KH49DPaFsniYhL(e,:,[,n,-,7,!,+,/,*,-,O,.,D,O,3,L,.,2,/)
#define  msKaUi822wPxuzjUtd8Pa  mQk_FiTqfT2quOMiM0cIKgE508p48JO(+,},G,>,G,C,>,!,[,+,Z,Z,],Z,[,u,/,t,+,^)
#define  mdNNjVkqM2InU1bCHGxmP  if(
#define  mhROwJUrnW6RV5u5uX1p4  ma2JuVH9cwa2PZWXEX2RFlL97Fd56Uf(0,_,t,n,2,^,3,i,2,h,*,-,N,t,5,u,A,[,f,t)
#define  mZ4GZ4UmqxVyfyG8CPz5a  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(R,I,K,*,c,8,U,[,/,t,c,x,=,{,x,v,],G,{,.)
#define  mmombSefdt4OQYXhCimSX  mwK0gGoxdO620JNMAf8LcWrLXkSVHqY(T,t,a,r,n,W,H,f,3,u,B,t,c,9,!,*,},b,s,t)
#define  mF7PjcGzXBfuvYPxX4ENs  mHN4QkSpFuhZZROE3e75ST2ernStapx(R,Q,.,3,a,b,:,P,],H,r,e,/,h,Z,e,:,],r,k)
#define  mcvDrOWJhA_Jj9rADu5RY  mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF(N,p,b,o,l,m,x,[,I,M,/,.,;,o,N,b,o,G,Q,c)
#define  mqQ3hcKeFeE4oJoHQSvf1  msTibML7U5XAa62kfYMyXMMaQgK7wvx(2,O,D,J,!,+,N,;,N,R,!,m,b,k,x,j,p,[,],-)
#define  mj2vTnvmJGQRTP74fz5th  mahSq6rrq2neTeBW0KH49DPaFsniYhL(O,n,n,j,!,c,s,n,r,z,=,N,g,T,{,!,5,l,b,^)
#define  mqzzPJxLsV4dnyMti4gfP  ()
#define  mIUF5GxYrg8aIVgkWNnBb  mUbpV4lfDef5exLGNpWAnT12YiDu_kX(J,=,5,D,X,p,/,D,5,a,B,/,-,M,u,},M,{,e,:)
#define  motTJdCC_9geof6XxtOIX  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(m,R,],-,^,-,V,b,],/,I,q,4,a,],],x,!,9,C)
#define  mbubCLceOr5QXaiOQQPP1  mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk(n,2,/,2,Z,[,P,C,R,0,4,z,<,[,0,b,;,J,[,R)
#define  m_WYn2n0wuk6UJ5kGIQak  msecMYaXfF46rGGcWJxuScGlv8bYIpo(;,D,p,f,*,3,.,n,i,:,g,u,3,],[,5,h,N,s,j)
#define  mpfHVtwBeRCF4HzfR5aYa  mZKQBVu9NPSaSKDvETZgYMQILvBIUsb(!,^,G,v,_,:,C,},q,{,=,G,+,S,{,o,P,S,4,J)
#define  mw3w4itcdSwk4YnPuBarj  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(!,l,1,N,b,/,e,],U,s,o,p,t,e,-,7,k,1,B,t)
#define  mvtZWYnFIFlTMBNRpc3mM  mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df(.,x,5,^,:,_,*,r,u,2,2,t,/,!,t,c,;,e,0,s)
#define  mmwMxLCLCS3PUrkR0S4GT  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(1,k,w,0,_,S,<,O,{,m,-,-,l,J,W,y,M,h,T,f)
#define  mJSr1xT3rjrluqpa47g9Y  miuYLrMna9tTpfuHozSxZXljtr8IWGY(/,+,*,O,b,Z,W,+,m,v,x,-,o,P,w,{,!,O,3,+)
#define  mCi4vAHb8oVMCZWxLATzD  mz5kaqHx8JTSTaRfRR3EBitftTo6TW6([,r,e,n,2,q,^,:,u,E,},l,4,2,^,B,A,j,n,t)
#define  muSdZAgzhs5ln2vx_pg0w  mj0SmRpcdB2TRl5kdNdBQnXpbI2PaTI(p,n,/,a,m,y,4,+,s,r,c,n,a,m,_,.,e,a,e,y)
#define  mbtyTfpzqoLMszlSfGVhS  if(
#define  mnvfRccV6sWLKag7QRnMi  mBsNR7a9eCj4e2paObbgMzu5XwLAjnm(z,a,P,R,D,w,t,v,J,j,E,{,Z,:,S,o,r,f,3,])
#define  mnFcnzhSc68PBY18KNbo7  ()
#define  mAXRt0DC6duEWgvgkLnB3  mQk_FiTqfT2quOMiM0cIKgE508p48JO(K,0,K,&,:,E,&,7,t,z,7,d,z,Y,:,T,O,Z,w,T)
#define  mLS7Y36zZso1BwBUg8wDr  mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC(s,+,},B,7,},1,J,f,R,g,K,/,^,},B,C,q,x,k)
#define  mpoZNJTEPtCn_II0lswxG  mOf9_wb83eei1ZBzVuOZTTfg41x_5sS(V,a,v,K,:,e,a,t,p,p,D,:,C,r,/,i,t,e,-,*)
#define  mOnkdM0WujiddAefb4ESe  mQHl_ec60ZnTta9Kjat5MnwCDywKP0S(:,2,*,u,[,n,-,o,t,*,:,5,2,s,i,+,t,_,3,!)
#define  mWDsKNjyxVW4J9q1AwGWq  mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s(f,i,H,>,q,-,P,e,W,d,.,u,c,c,L,Y,h,:,r,e)
#define  ma2vK_VeaV2yOivBMAaS1  mEb0vgWbp62WJkkmtdPujPWI8EMqsYH(l,I,.,J,6,g,f,t,o,T,a,e,*,J,+,[,_,:,s,:)
#define  mG0XPjV2nZH5rw34_jjn_  mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ(L,Y,g,w,3,Y,7,{,!,-,r,z,/,D,],-,2,g,8,S)
#define  mnTomnUfxbEgN2pcyh4IC  mO0FjLQgixFPExZXiYeXr8hk69NoWuX(.,u,g,D,D,/,a,s,1,t,S,c,u,o,Q,z,e,_,o,+)
#define  mud4sr7JVgGG6yDxhsQoI  mC2xaBE9kD4m2EfxxN85e2W5D8psu6d(},T,:,[,O,c,!,{,9,C,P,M,*,v,<,/,},<,g,g)
#define  my6ztJkSs2s9dWfJOJksF  )
#define  mrmdYuYTVzarkSFRATlha  mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m(^,d,o,.,0,I,G,},3,:,l,l,u,e,},r,b,],9,[)
#define  mqefKqLpc5MfNVAgzWWfC  mipMN4mtnGA1X8ocw1VUzyTesbkEBOw(*,O,B,u,.,f,r,r,V,o,r,M,J,L,:,},{,D,r,f)
#define  mVtH44jy_Eg0rghDYlMs4  m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG(f,9,L,+,6,7,],C,{,A,.,3,p,m,f,y,m,},m,Q)
#define  mu79Z1nsoA2cM_nPkf06A  mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR(N,&,+,+,M,w,9,&,k,},^,*,!,E,{,/,[,J,F,I)
#endif
#ifndef ArucoDictionaryBasedMarkerDetector_H
#define ArucoDictionaryBasedMarkerDetector_H
#include "dictionary.h"
#include "markerlabeler.h"
#include <opencv2/core/core.hpp>
 mc0rMkLpNFfuLuqr7z3oz 	aruco
 mmFrxzQTWygQiSMiAd1ou 	 
    	  
    		   
    
    
     mEyjl8Y5Ko8WIO7rc8xjy 	DictionaryBased : public MarkerLabeler
     msDUdqGgg_34u9hXbBbP6 	 
    	  
    		   
    public:
        virtual  mK2i85pgNdUMagXTmWJ5e 	 
    	  
    		   DictionaryBased msn15RJjYb_SsaErIfRNo 	 
    	  
    		   
     
     
 
  	 
         mXggdfMCbAbSH20gXjoXX 	 
    	  
    		   
     
     
 
  	 
         mnr9KiD3xP6jhiP0klzs8 	 
    	  
    		   
     
        
        
         mVt0bbujrHNetZKOtuKde 	setParams mP769HJIua8m0mI4ktrOP 	 
    	  
    		   
     
 const Dictionary& dic,  maNkjFQf7KL90cn5vbMa3 	 
max_correction_rate mWlw_t5LZEaqBm9_nt0iD 	 
    	  
    		    mOj2NZtBCgsNkYM982aS9 	 
    	  
    		   
     
     
 
        
       virtual  mBEcaTi01GHGicTdCFjoM 	 
    	  
    		   
     
     
 detect mP769HJIua8m0mI4ktrOP 	 
    	  
   const cv mnaoSvkmA7uG3CzIf2JLX 	 
    	  
    	Mat& in, int& marker_id, int& nRotations,std mW_kHdhknJnJHqJtLDQ1K 	 
    	  
    		   
     
     
 
string &additionalInfo mcBOeh7kvkLdVFdML_waY 	 
    	  
    		  mRHVbf6L_uqgqJB68GawV 	 
    	 
        
       virtual std mIOO9HkLingUB807zdqfm 	 
    	  string getName mi6HZqmh8GILM6LjanUt5 	 
  const mKv065jc1LeatUiqpqepg 	 
    	  
        virtual  mSokNq3Jcm0CZDZY30Wno 	 
    	getNSubdivisions meHoni3WXkzVpE4d0kmI1 	 
    	const mYpuIV2wVprROhZ0gZwqQ 	 
    	  
    		   
     
      muxvLfj1z4AXZePUs5M4p 	_9861869998409687198 mOj2NZtBCgsNkYM982aS9 	 
  mWrGjq0Squbg2ySQrv2yy 	 
    	  
  
    private:
        
          mcvDrOWJhA_Jj9rADu5RY 	 
    	  
 _8865077727849858911 mzb0bJuSjJhlivJIz_rfW 	 
    	  
  const cv mW_kHdhknJnJHqJtLDQ1K 	 
    	  
  Mat& _15593405694536704447,  miiVgeXn417nCjY5ebPhf 	 
    	_6964937581867729999, std mBS2ISVIhJublZPH29E0a 	 
    vector mQ3MpK6vlWIM1vTRpOqFk 	 
    	  
uint64_t mGeAkoUhfYDMrrSVlPr1O 	 
 & _11093822405034 mRWp04iJpyRq8tILClaZJ 	 
    	  
    		 mmcgp6Gf_wMHhMWAP3nYZ 	 
    	  
    		   
     
     
        cv mJZTaq8b9U6IHm6Fo0zfj 	 
    	  
    		Mat _17232963975139041229 mfQdV5_coeVOh0_XAr72d 	 
    	  
    		   
     
  const cv mnaoSvkmA7uG3CzIf2JLX 	 
    	  
    		   
 Mat& _175247760141 mSiHrrzr4Y0scm_4uqOCv 	 
    	  
    		   
     
      mUAT7RqwcWJKHzYQUCA0y 	 
    	  
    		   
     
    
        uint64_t _798059623973164676 mzAWY6BVbyF5XGfs95ZTo 	 
    	  
    		   
     const cv mJZTaq8b9U6IHm6Fo0zfj 	 
    	  
   Mat& _706246351721446 mSiHrrzr4Y0scm_4uqOCv 	 
    	  
    		   
     mOj2NZtBCgsNkYM982aS9 	 
    	  
    		   
    
        std mMepmESYShQYpe8JyLHO6 	 
    	  
    		   
     
     
vector mwlsAHCjnxf1m2hGk7SPN 	 
    	 Dictionary mzZIX41vw1HHV8g5Zis4L 	 
    	  
    		   
     
     _5600904287170945319 mOj2NZtBCgsNkYM982aS9 	 
    	  
    		   
    
          mVt0bbujrHNetZKOtuKde 	 
    	  
    		   _14966203760426022165 m_QEZZ3iahWFpeO4whzWo 	uint64_t _706246351721446,  mrVo1fO7oMN0F0LcGmw_f 	 
   _16937202516880059432, cv mnaoSvkmA7uG3CzIf2JLX 	 
    	 Mat& _11093822299329 mrzgvRTlrhSOpRG6AjzDZ 	 
    mJjl5sA9ehjIzAWdStIFU 	 
   
         mSokNq3Jcm0CZDZY30Wno 	 
    	  
    		   
     
 _9861869998409687198 m_YweHWYbkpdV40mXJspN 	 0 maDHAuramjTITZ8BkVyc3 	 
    	  
    		   
   
         mM2m_2Donhjltd0Debl64 	 
    	  
    		   
     
  _13104684682841805604 mYB0YoRP6itbUawfbPusv 	 
 
        std mBS2ISVIhJublZPH29E0a 	 
    	  
    		   
    string _2103628895099220155 mRHVbf6L_uqgqJB68GawV 	 
    	  
    		   
     
   
        std md_M7GPITQtDS4BfzU9d3 	 
    	  
    		   
     
    map mmwMxLCLCS3PUrkR0S4GT 	 
    	  
  uint32_t,std mMepmESYShQYpe8JyLHO6 	 
    	  
   vector mEl0x2A3ElD6IIGxgIMh1 	 
    	  
    		   
     
     
 
  	Dictionary* mhOJP7GTKtZVREYuK8qsM 	 
    	  
    		   
     
   _12481497024245504838 mOj2NZtBCgsNkYM982aS9 	 
    	  
        
     mI4sf76lr2ENejiQIjqzJ 	 
    	  
    		   
     
     mYB0YoRP6itbUawfbPusv 	 
    	  
    		   
     
 mvvmSM3BA2TJMl_6Z9ScU 	 
    	  
    		   
     
     
#endif
#ifdef _6580636470966009790
#undef  mLq0l_9mYawwF56GLqBiO 
#undef  mi_O6EJNt60DZGoXx1wHw 
#undef mNRgx_n6AYQCSB5qW3w3m1_KYB5I5yI
#undef  mhROwJUrnW6RV5u5uX1p4 
#undef  mcusq_XAMIIwDvb7lMCrf 
#undef  mR9ASd2W_8LE4mOR7w3js 
#undef  mKwKqgpBT0nQRvDGpT5CT 
#undef mUbpV4lfDef5exLGNpWAnT12YiDu_kX
#undef  micFIwqBc9QQUuQXqGKWC 
#undef  mdY97YGxqZoJZ4psVpCYa 
#undef mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4
#undef  mOO4AmPyU12o_w01ECkUl 
#undef  mo6RNiDqZJd5bPrKTOqBN 
#undef mYZySka2r5zYAEO1eOB6HyYTMPAnfWX
#undef  maputXWpuSswTuxiye55G 
#undef mXNcG_XejCUhS0WdQbrzCqFiifRHEiN
#undef  msDUdqGgg_34u9hXbBbP6 
#undef  m_2Wdq9qctokcWGW9B7eI 
#undef mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s
#undef  mKi8kBZaMYwKlooGDcleR 
#undef mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR
#undef  mdoRwfAhRUkJByfoNRUvb 
#undef mDEbKniJvTruRfyANln1hDcaOxjifIj
#undef  mwhGtbRL66FztkRtZ0QI_ 
#undef  mEn6ezpXymeCgJNVz3lrW 
#undef  mUzQAwxDAK5N1NNCaNFl_ 
#undef  mK4rObJyYX6HJZfVJKntT 
#undef  mnPfMWb2f1m2VXrwtLuBn 
#undef  mL3fOciX21BVRqsrLjDqQ 
#undef  mAXRt0DC6duEWgvgkLnB3 
#undef  mNrsNMyOlNPO0p0HXQMMP 
#undef  mgheRgcIL9OpKtLQ4r_15 
#undef  mBWTdhPS4d6WQTxWw9qTj 
#undef  mP4rxLIewwXLg47glswZS 
#undef  mUCUowYS5Zgxsf8jGgVp5 
#undef  mO2X7vyyKruryPTrlfgIx 
#undef  mOxbZipdUMUjuuBjccJiL 
#undef  mrzgvRTlrhSOpRG6AjzDZ 
#undef mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw
#undef  mz4tZy0GWrUESNULCSRoF 
#undef  mo9cHp1NOYwzHudST5ct_ 
#undef  mQ3MpK6vlWIM1vTRpOqFk 
#undef  mUD4rGlgxQjbo0JVuke3q 
#undef  mmRqfJAp91BT5F8NaZMmM 
#undef  mWNSsa0FomEI5wNcyNLqT 
#undef  m_Tae7Y9Y2VD1QQBLzq4Y 
#undef  muzBQurHIfaSICJbRjaWh 
#undef  mtE68lB7HxwArLgdxpcJw 
#undef  mnTomnUfxbEgN2pcyh4IC 
#undef  mdA8CkxC2ABNB6wmuvTfw 
#undef  mywDDUpEYndE3A45RHsoU 
#undef mDNXBsrSCyjZ8H5TqHKE8ydryKS6POH
#undef  mnZS4TInrvaTXnZxKixov 
#undef  mKv065jc1LeatUiqpqepg 
#undef  mySr_PmNqnsLYHdYvB_ZN 
#undef  mRte7PZJP6iITCO2uVu0v 
#undef  mMepmESYShQYpe8JyLHO6 
#undef  meq9uMtFTWeqAgMuQsOtx 
#undef  mqzzPJxLsV4dnyMti4gfP 
#undef  mBndUu3vn0UYS7kuL9bT2 
#undef  mD5j4pDCOs2SM4dLbugLG 
#undef  mb6FIaRd_qia8_U10282s 
#undef  mqjvrjxD0U1jONB_TZFW5 
#undef  mSfj74s5uEvCOzi1TqmTv 
#undef  mpdkR8_dmu0PH3OVmq923 
#undef  moxT8MWfNzFm3p7C1XLDk 
#undef  mARbu_1sRtfpk1suZIE5h 
#undef  mqItj5mkpzJ38jgqpOkYj 
#undef mdcfBxuY9ca1Je2VwDSgUMxqgXDgPST
#undef  mJKRIv5t9rcExx2BgWlkY 
#undef  mBbED78xkAlNEldBsfZoY 
#undef  mwE6oBl5ZQ79F6Ove8epW 
#undef  mrZQSpiPc5lDdrE7lGVdv 
#undef  mCW_zvfcw3_KvOK_XS8HP 
#undef  mwC9HboO7mY5my_bYOgOp 
#undef  mtrAzdiCeLhU7rVrgKDnJ 
#undef  mAnJimC6YgR8qvnQB7ZMP 
#undef  mBEcaTi01GHGicTdCFjoM 
#undef  mKOkOykCmuX5Cu4t9gb85 
#undef  mcvDrOWJhA_Jj9rADu5RY 
#undef  mqoG7Riz1FpYN6K49t8kk 
#undef  mLPHimc4fzfm6eoFIZbqS 
#undef mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF
#undef  mL9fuPZuqOi9x2FhIqvy1 
#undef  md4VXnnHqGZYN9FfEwMCW 
#undef  mBeVnxVGsv42qh8iauLFG 
#undef  miiVgeXn417nCjY5ebPhf 
#undef  mpqi2n0ljngTDl3zfRcZY 
#undef  mjhYvAnHCo7RqHTG4kGs8 
#undef  mfZqF0j4sUltUngd4Hj5Y 
#undef mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t
#undef  m_mN_FCCplLb1O56UTVl3 
#undef mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR
#undef  mY1aayBcuQSa43sZHmeQS 
#undef  myuvjPnvzcBE3NfHkRLiX 
#undef msKAlT0dx6w27y9yHjm3iwlc_YIajMN
#undef  mrI60jYuZ1dFPDfd24M0Q 
#undef ma8foCOgNMskkXnP7fzWdE7PnvWtDfR
#undef  mjYBDnziuBBoR8htpZ054 
#undef  mfkiYufvbU5mF9mdgM8ig 
#undef muyLCpzNWkiG62Rh8y6QK2T12sisiZy
#undef  mSiHrrzr4Y0scm_4uqOCv 
#undef  mEy_pGq0H0Ns418E2TeZz 
#undef  mPwyvAQ1wHSSp7FJdoENV 
#undef  mmFbqqNxE6b68zHtj1L1b 
#undef  mp9HJBE0E90Wcmb9f9ar3 
#undef  mDzGqUDtD5PGwMNxtuRIR 
#undef  m_5q1OVTkJJKfB_ISHjog 
#undef  mB9JHSBU95BEjegV45XDO 
#undef  mWnjTNUFoM25IlGBbi5Sh 
#undef mI4cYeHg7cwBYkfBvwQkmssxvPpHCRl
#undef mXAbaapmUexXuxomQ2UOp3r69lu4JB1
#undef  mxRngYN6opotzgq0i2yF0 
#undef  mpmCfg6OTFu9ueV1Jvoij 
#undef  mjAnZdEfD7dHR86j3d92F 
#undef  msUrKsbZb01INfsQYkuex 
#undef mkMSqyZx8knDVKKeQRRAPOPQ1OycFsk
#undef  mRENlzQNyEPIksF6cQHQj 
#undef  mTIqUWMZAhhidB3B7gCmt 
#undef mX1lxVUYXutVkZTja3vCylribxHJyyr
#undef  mxjH4eEwkhiNcmUP6GEXq 
#undef  mmFrxzQTWygQiSMiAd1ou 
#undef  mrWabZl6Yqxhh9lJh_vp9 
#undef  mBY9q0vKK0__eH5VQs9_L 
#undef  mpNsMq_Jsh9rRugWA0zzy 
#undef  mGdAJfTAuDccsggh4RYB5 
#undef  mJSJkb3ccP0_n2Wxy8nWh 
#undef mYV98481WEquqd1AECvpqWYdnflE9jF
#undef  mO54HUFE7XGVtlHtttmH3 
#undef  mNTqpwjT561WC_1cfoCEr 
#undef  mDTlqiHhmW7Np9mQzo1tz 
#undef mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m
#undef  muJHokUqtf6fmO3Ky49f8 
#undef mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS
#undef  mHiYGul5svZyW_rLyOjTu 
#undef  mW_kHdhknJnJHqJtLDQ1K 
#undef  meHoDa0aUmPvFXvZMmfuA 
#undef  mGQ4ZN1hA5s9kbimw7Qwy 
#undef  mSa9VlOXwWy20y1aecFml 
#undef  mMvWJbWSLKEHq4F0uh_XL 
#undef  mEnhnBFQ3mB4diArixuti 
#undef mC6homJJPESbePyDgOny1YcxCcn5QHR
#undef  mtAlnZAB81NJEQfKELvkr 
#undef  mIDgb6uGhToe8NBW6xKso 
#undef  mu79Z1nsoA2cM_nPkf06A 
#undef  msAueAn4jz6msdaMAOFvD 
#undef  maTpexuiU56_wx8NMsDqq 
#undef  mY5NXKCzp4rf6Ovwtrdxq 
#undef  mvtZWYnFIFlTMBNRpc3mM 
#undef  mJmF0v_b2bVzIAj7lN4hw 
#undef  mnXWkAlgXzCuQoJEu5uiO 
#undef  mYYc77i0htGEQktG2Neo1 
#undef mC2xaBE9kD4m2EfxxN85e2W5D8psu6d
#undef  mnaoSvkmA7uG3CzIf2JLX 
#undef  mDPHjdm2_QWPyhebFvYkD 
#undef  mEamAz92Ayua5tQlUuQq6 
#undef  mRHVbf6L_uqgqJB68GawV 
#undef  mdeSRuh1fJRPfCJYIGL3K 
#undef  mcnZttRQtHTT1zEcTrcXq 
#undef  mT1Yuv8tLPubZaOzlRCjX 
#undef  miHgaIOIXnP9MKa_Ynuzb 
#undef  msWHPNAG9RJ8USwCYjIRg 
#undef  mb0Jed_XHNWdzUez3EMOb 
#undef mS3KOSwoqktmfbJXrTgh30aLzdZFDf5
#undef  mTUb9WYxxxWOpnX_tuW8L 
#undef  mCEME69o7Es8kNPY_qo8L 
#undef  muIKgdX84KPh7NwHu9wOb 
#undef  mpoZNJTEPtCn_II0lswxG 
#undef  may4T302OZ7loQtO8zrNp 
#undef  mD1FtOnG5lJAS7VVmL6Ph 
#undef  mVDeIkD6a7uU0LqFHLuPG 
#undef  m_TFPk3Phi8ZX86zM0rxV 
#undef  mRWp04iJpyRq8tILClaZJ 
#undef  miK0cKKXIJZC11uUUzrLR 
#undef  mlPYm0vEibuOv_LKABukZ 
#undef  mnr9KiD3xP6jhiP0klzs8 
#undef mO0FjLQgixFPExZXiYeXr8hk69NoWuX
#undef mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U
#undef  mLS7Y36zZso1BwBUg8wDr 
#undef  mZ4GZ4UmqxVyfyG8CPz5a 
#undef  ms2dtz7ci8fKKwi4grih1 
#undef  mtb4cFqSBOv6HgXSTvrTj 
#undef mipMN4mtnGA1X8ocw1VUzyTesbkEBOw
#undef  mZMrdS758Yf9PKctFfaYZ 
#undef mEb0vgWbp62WJkkmtdPujPWI8EMqsYH
#undef  mdHtGBEDt4G4jvY6KOGzW 
#undef  mwlsAHCjnxf1m2hGk7SPN 
#undef miuYLrMna9tTpfuHozSxZXljtr8IWGY
#undef  mM2m_2Donhjltd0Debl64 
#undef  msKaUi822wPxuzjUtd8Pa 
#undef mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ
#undef  mzuL30IhryR3NJMszS89h 
#undef  mRzFXIQ0M4lxEiykp0tGE 
#undef mz5kaqHx8JTSTaRfRR3EBitftTo6TW6
#undef  mNDIxtoehMB1oIpVV3LKb 
#undef  meKZnYzO2FX6PDdko0XJI 
#undef  mJZTaq8b9U6IHm6Fo0zfj 
#undef  mJE0OEa9lyhoBhR5JwHj4 
#undef  mvxcxvBinAJ8yONOAxeJ3 
#undef  mVM77PvnlvRK1mLTKRKei 
#undef  mmLMfZuLLitP3PNsKn3U4 
#undef  mcVfnknnHgJjobEYbCQZb 
#undef  mlkIT82897HlGwEOzq3R0 
#undef  mhp6bWPRQLSMINJFWgnoY 
#undef  me3HErcslswtnJE5PyQ7h 
#undef  mUvejUG0VZ6oaFYLfv96Z 
#undef  mZvFBh86Am0OfcHWSxajt 
#undef  mzHszbbCS_cUrYyWLxL9J 
#undef  mIivzJUcx177gxdHt1Qrn 
#undef mQHl_ec60ZnTta9Kjat5MnwCDywKP0S
#undef  mK5osLCJErLUjdJVDKOO6 
#undef  mxQppl_B1tP4_S2CE3A7S 
#undef  mf45G5P768Ut3IC0WfAVV 
#undef  mMj_9sE1weayB75v7BdK8 
#undef  mYnZwY1qztvF6jEJBoGi_ 
#undef  mkDBTxQUKyKFjRyQY44KV 
#undef  mmcgp6Gf_wMHhMWAP3nYZ 
#undef muUdW3fqjYEcWW8jBykcma1JP8mjRxV
#undef  mjwkyWIKCg9v5IEoO1tb1 
#undef m_iMEsCNnjEITB27sIXurIsGPpif5XE
#undef  mjSoZeXICFupmRJnwixfY 
#undef  mWNZjhCXwY0h77nbnnQun 
#undef  mdV71Y1rT0MkSZQco4pkM 
#undef  mPBi7A48_1c_87b1U_Eoa 
#undef  m_SGFgZqHNGYic2jE2PZs 
#undef  mrdmCc9Gc3ukvwGoxQggu 
#undef  mvvmSM3BA2TJMl_6Z9ScU 
#undef  miJ4T9koNX5tdXmZ5uaAF 
#undef  mf4r5S0Gz5iK0mQBxOgrA 
#undef  mIOO9HkLingUB807zdqfm 
#undef mwK0gGoxdO620JNMAf8LcWrLXkSVHqY
#undef mCnRkQx6e9t50ErWQAwE0q3YKghcooj
#undef mBsNR7a9eCj4e2paObbgMzu5XwLAjnm
#undef  mpwGO7r6CJmc7pyzxPS0W 
#undef  mJfHf6vHjeGZbDkm_IWNg 
#undef  mX2uK3ci5pcPqQSvs4amk 
#undef  mPT1fk20Pr1eQ0YB5sxd6 
#undef  mgjLIBeE0wg2QrojbWXXE 
#undef ma2JuVH9cwa2PZWXEX2RFlL97Fd56Uf
#undef  mzZIX41vw1HHV8g5Zis4L 
#undef  mrzBsv3kMMBOnuA1vQYB0 
#undef  mdNNjVkqM2InU1bCHGxmP 
#undef  mYg2fb_0h62GR73b_cpn9 
#undef  mI4sf76lr2ENejiQIjqzJ 
#undef  mL7RQgXYMf5RjI3gzAmom 
#undef  mmwuJQME0484L7jN0wNls 
#undef  mTvuqEbq8QyE7GGDRvvUi 
#undef  mKiDysFpzxUykXXw_WZfH 
#undef  mX0mE9NJLZdso_vDht0x6 
#undef  mfQdV5_coeVOh0_XAr72d 
#undef  mB8iHIm9FOE1v4JRokz6E 
#undef  mRkPOYbSt70qZdeFG7KTU 
#undef  mM7GbDdkpt2DGNP5IRiPZ 
#undef  mTva02hxveOfDWDk4eVeg 
#undef  meLXGbNjy3PRj2YFo8vov 
#undef  mueL4P4xnm8R1M0bl8Ojg 
#undef  m_2rFCzuQjnYmj1u2E3Hn 
#undef  mEqTIrKKpbyOgBfvxq5Uo 
#undef  mnxqg8Uow3e4hAyXi7IeZ 
#undef  mPBz2W83ARDLALxh_6rJK 
#undef  me_oz2FFDkcB79njugEzc 
#undef  mdwjkxbPv9lRst1GU7ntQ 
#undef  mDF2umNp7X6oYOD0Lwyy3 
#undef  mSpGFgQwHX_r9ijW72OO0 
#undef  mYpuIV2wVprROhZ0gZwqQ 
#undef  mbd03FIo9GTdRlDtujpAU 
#undef  mjlW6Gr9BKXBEqm9b7AyH 
#undef  mi4UDYlJVme2p8vz8XCwn 
#undef  mHc4_w2MgUHx4283kOjz9 
#undef  mPkRdGYYZOKBHLvkzvyRk 
#undef  mwmTl_1WKubaBtbkcxNw2 
#undef mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I
#undef  mc64seL8_QSxuYhWboswo 
#undef  mYhDj2gAIVF7iiyAIzfLc 
#undef  mxK3g5IVylkgINFWSbxF8 
#undef  mlNC5dwEflF9t_I2G7kwV 
#undef  mjQJF2BhvHcfP6fiRsDi0 
#undef  mOxBLp1l2vKYX_rNUj7Fc 
#undef  mVC71FDKngiAI0dFcsSY9 
#undef mmAL_ct_wC7VA_KqJlBIFYgV6jc5z3G
#undef  mkr0aLVnJz5CaZvioiLL7 
#undef  mO3uJapBz8hfvZuLXzM53 
#undef  md_M7GPITQtDS4BfzU9d3 
#undef  mboS9FA2Q220SPFSMGHI8 
#undef  mG8z_mtZKC7ZO_NoWacf3 
#undef  m_YweHWYbkpdV40mXJspN 
#undef  msKuhdHIRNOlAQpbiW9KU 
#undef  mnpE_s7DSpkcZ5cnGnc16 
#undef  mJri6232WYf57v7WHLLtJ 
#undef mMcsTdeZl6dJT8lXT7C9j0AbQQMhSjw
#undef  mnvfRccV6sWLKag7QRnMi 
#undef  mw3w4itcdSwk4YnPuBarj 
#undef  mkATTEISGOYokIGC8F9la 
#undef  mi6HZqmh8GILM6LjanUt5 
#undef  mc0rMkLpNFfuLuqr7z3oz 
#undef  mJYXLtUQ27au4beQhf0PM 
#undef mhSjwWsm2mahiTUSTjt6nFB03As_xU3
#undef  mSq36Z11XRl1JXoARgKCB 
#undef  mFIC1mtAi41jxmBTb3wHn 
#undef  mpfHVtwBeRCF4HzfR5aYa 
#undef  mM2DCYuIrYsxI9lPkFjQS 
#undef  mgga0WnnRFtBflQKtpLuK 
#undef mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL
#undef mdYtz2htQZh8P7qHU8sOccXiq0Jsbpd
#undef  mtnD8HN9EM8B5CF50YpX7 
#undef  msKlRUq0xcK7JxZyasKkH 
#undef  miNE679CW5B3xxrVDrvN9 
#undef mUsuCEIFvRP_D44KPaQY47o4ispy8Vj
#undef  mpaSqCpDpGH0eULjahGpg 
#undef  mqVF9yhdjkvJZAJPGWq3E 
#undef  ma2vK_VeaV2yOivBMAaS1 
#undef mTwuuBw4FVjERX9Kj4nHaPm6uu60qfG
#undef  mNUuCaMUS8zqfbXCimtgj 
#undef  mrtb_bhYbXTw3XOs4vV1F 
#undef  mXggdfMCbAbSH20gXjoXX 
#undef msVNRLVmFBztOVESz5AQJDfnqtqgN6L
#undef  mS6JTMBdIbEJgKM_vQoSK 
#undef  mGQgYgclze4X2bB4vpuzW 
#undef  msn15RJjYb_SsaErIfRNo 
#undef mc8ipMXPIMdxjmKKG4E6NKlqXdYMncM
#undef mGXDvm2ZdrqugaoZ1YccvqzabYqkG2k
#undef  mtawfM3ndXCRasZXQxRrp 
#undef  mhgnRFmDEM5LAURVG5y1L 
#undef  mfJjRpXi94twT9pqD5JVX 
#undef  mW37fLe5jzVXLk4yUjj24 
#undef  mbubCLceOr5QXaiOQQPP1 
#undef  ml8k79uncra_1jDk9y35b 
#undef  mS3cOaukxo2FRb5RvHVc4 
#undef mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL
#undef  mnfv75cfRX5nwn_P3W2SZ 
#undef  mcq33jn33ngPvU8ExIgnf 
#undef  mS5WCLZvcR3iydjHqSMii 
#undef  mQFDOegAOguDVHU3KoIJH 
#undef  mGHOYAWjopscrujOCjpSi 
#undef  mBdKtki5i5z_rqVGrRUtu 
#undef  mBliNpjYGnOcf7SuCUXfw 
#undef  mcX71Wu1NrgiE1PjmF5oW 
#undef  mzJn2Y5MSTbpYun9rdOSq 
#undef  mwoHtFc7XtGdE5RWuAZoG 
#undef  mBf0JMOxQ3sCg9N87xsxR 
#undef mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH
#undef  mHt2jDj4LBpP36tiW9beq 
#undef  mHp07MIs1jIqbiHORNZtD 
#undef  mGeAkoUhfYDMrrSVlPr1O 
#undef mwgU_GguJtAB5Bb35MdwyMTlNysOLJW
#undef  mlxwRZWmFsIX03zy3tTy0 
#undef  mgIg8CedmHvBkJNohUblZ 
#undef  mSNCcmKF29PRGlI8Tdwja 
#undef  mBzApfw9R5DW809yw9n5C 
#undef  mk7ILvvJtbDBhzuKjuFuZ 
#undef msTibML7U5XAa62kfYMyXMMaQgK7wvx
#undef myMbdRujQRRGxZa_esh6OHxPU22Olyw
#undef  migdvOq5L79sWQtwLyhs2 
#undef  mIkusqIJdd_o34vSBgzWv 
#undef maFw6BG67rqfttMYNKgoNemSsvLkQYa
#undef  mBx7lmwJEgh_boAo7hHD4 
#undef  mvt_8yQ6OWmKTfvk3dzq1 
#undef  mfPiMJHfWML2WymRvotni 
#undef mZFd_wzPmPRc35lEvSHE0CiTnEdVk2C
#undef  mVzsLDeS8SOv0E6YGFv8j 
#undef  mfvMoVhY8cjuWRUJI73Pl 
#undef  mSkMsyd_G4SVpaKFDM3Uc 
#undef  mI1ri11eHWS0GoQQjfv_u 
#undef  mLp87BNpaRa8bU3QE39AH 
#undef  mTzlvPwOAcxvFnaU7tzec 
#undef mcLZRXidREDnQsUILaskKBiM_OAG8ua
#undef mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC
#undef ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI
#undef  mPQkyiUN1BvHTMgAxqODe 
#undef  mMbu3hdPmJMPrM_d1Cr0s 
#undef  mtehHpUuknvUTAKK7BNgA 
#undef  mqefKqLpc5MfNVAgzWWfC 
#undef  mobX070S3wO6zxczaIZzQ 
#undef  mZWm2nGx_Hxwoni8yg8Qj 
#undef mj0SmRpcdB2TRl5kdNdBQnXpbI2PaTI
#undef  mzRXDilasYlw5CVJtdYdM 
#undef  mtPeORXsOWhCCSWRotXA_ 
#undef msNlLNhq5GN7XcbzwivI3OWPTWt9svc
#undef  mjE2XFXDR2hHCf8IsA1BO 
#undef  mLwLUP6KZ9PRisEeZakem 
#undef  moj9aYgB8JD1AgO4ICT3d 
#undef  mpQACTL4b3pHMD127IZSN 
#undef  mKHRSL6QRz79M7iwb3xFq 
#undef  mnfIFXb2Z55p5DNBveqbx 
#undef  m_QEZZ3iahWFpeO4whzWo 
#undef  mud4sr7JVgGG6yDxhsQoI 
#undef mQk_FiTqfT2quOMiM0cIKgE508p48JO
#undef  mWw8FPQaCI3gn0wUVEyTI 
#undef  mhsPoKPzVdLpxSkCW6gM8 
#undef  mR5JEG117hlb3MtJMpeEA 
#undef  mhK2Qbp1bwBdQQlO7M8sI 
#undef mWC1nvfQRFJLqJcGHQd_DZVW3mGXmA3
#undef mv_JVFkODVRLTSkXzNmRAFyoFoAzy3J
#undef  mWrGjq0Squbg2ySQrv2yy 
#undef  ms8ohDxwnrSLtbOpBsiBn 
#undef  mxODpvgncxHDxAXg0nTxi 
#undef  mpxNV0vBtyYJsCSJulyLm 
#undef  mkvvczg0if8KqjNRfebjz 
#undef mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr
#undef  mF7PjcGzXBfuvYPxX4ENs 
#undef mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk
#undef  mmwMxLCLCS3PUrkR0S4GT 
#undef  mPBqMiL37DrIolFnluMjB 
#undef mi0l_sHwUblCkb4iaLokRozuEWNdBw6
#undef  meHoni3WXkzVpE4d0kmI1 
#undef  m_BrEaPHfim2E9yF6_ZvY 
#undef mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E
#undef mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz
#undef mahSq6rrq2neTeBW0KH49DPaFsniYhL
#undef  mXx9mzEZ3WuXitLsCMbS3 
#undef  mhen8iRk76Q4ezN_ZTavu 
#undef  my9HJ8yK6DJjsZPdzWxZL 
#undef  mwUUBDVL49RrRRTgyVPVN 
#undef  mKEA1BZI3NTi8QvqudEdc 
#undef  mEwcSf6xJjokt5SShXKxS 
#undef  mohUEWtGNSJiaUfYS_hHU 
#undef  mo9UqUd0NMYxMbXiBpNmp 
#undef  mEfdpZW8Tgwkni5sEouU7 
#undef  mG0XPjV2nZH5rw34_jjn_ 
#undef  mtPVppy1yz0JrXtPdjMoW 
#undef  mazMo2N6FXwsNwoWMaXmw 
#undef  musqt3SUnZXONhXx36QTM 
#undef  mm4diUXyy908ilcG8VsiM 
#undef  my6ztJkSs2s9dWfJOJksF 
#undef  miU1_742S5SYXnR5Jx89T 
#undef  mUAT7RqwcWJKHzYQUCA0y 
#undef mwjNmdVvS8bIC25sTrclB9dCibfRKDx
#undef  mncmpqNhIup2FdHbcG_I7 
#undef  mvVwZIT9LYdLjcMYjL6fQ 
#undef  mRtNeoipHh1bU1f1bmWPX 
#undef  mVMtoBTx7Atu07C1zpSOZ 
#undef  mM7P5mMaG1l7fxkX3FWCT 
#undef  mGfToHPBdGgajCf_jjGO8 
#undef  mMJxQ0EBp3m14gB2r3xIc 
#undef  mbldl9dwMrRmnA2YXgRup 
#undef  mCw9yl5OPmGbIXjCTLMgT 
#undef  mdcqBUCL5eOKU9PVtHvug 
#undef  mEl0x2A3ElD6IIGxgIMh1 
#undef monM9oNPqUFsPMMVWOpTatnkGAmgDe9
#undef  ma9kV7iftDKaJMwPMmic6 
#undef  mFr9xKf_e_bmCOLt2lDD4 
#undef mHN4QkSpFuhZZROE3e75ST2ernStapx
#undef  mfoiPdsHJ12pw0fAmu2LO 
#undef  mLEPndrD0EDs3kVH87Dc9 
#undef  maDHAuramjTITZ8BkVyc3 
#undef  mZAlRw_vXw7OrhwXXa1s2 
#undef mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df
#undef  mTijFbkuqZobez4o86GTR 
#undef  mw_8xZKbKGnlYQNGWwE_0 
#undef  mjtgzOH8_fFDjnCUIvpJR 
#undef  mcmEFUHvzwZHvsOYCgnyC 
#undef  mnCvMc73RamSZ8lE5SaXG 
#undef mDe6Xdhfu94h0bVchSL24UZegztDHht
#undef  md4LgblW399NKaEPBAY3T 
#undef  mxbbdZ8472z3S1r1q5ZWj 
#undef  mvvQZKXqZ3gS6vWzM21uf 
#undef mAAF1hNrBlLEg80wAcv2c_FQ8jbfnjr
#undef  mzAWY6BVbyF5XGfs95ZTo 
#undef  mvVntD47RvCRRdFhEAzH2 
#undef  mnaeVhufQTwT_lV4TnsPF 
#undef  mo5687q03mFTCWmTFL22s 
#undef  mnv3HCmWHbNAEwSFeikW_ 
#undef  mr4zczxVHQA3dSD8whfSj 
#undef mFR2AYMAMdlvPHNClNuuI2P2lzdelpy
#undef  mniKBlIuV5usw0rljtOxS 
#undef mfaBCDA_1mB_o1gczVteCCzLS9jytzz
#undef  mXPig4KjJlLryx1k7a1qv 
#undef  mj2vTnvmJGQRTP74fz5th 
#undef mcUjff6jaamQlwbiN5lMFGZa5CWNEQt
#undef  mKD4UGvYqSH2GIcVJ2xVN 
#undef  motTJdCC_9geof6XxtOIX 
#undef  mZi7qi6srAkaKViRVPr2V 
#undef  meEZS3fP7SPnS8S1IqEmR 
#undef  mzb0bJuSjJhlivJIz_rfW 
#undef  mSG4W65NNIcornxP1sDch 
#undef  mdE1fJK3aKa1btI7OCyNv 
#undef msecMYaXfF46rGGcWJxuScGlv8bYIpo
#undef mZKQBVu9NPSaSKDvETZgYMQILvBIUsb
#undef  mP769HJIua8m0mI4ktrOP 
#undef mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct
#undef mbMIBvXxQ4fdNXtBFULCa3sGjseDD_9
#undef  mcLleLW3WGZ6MsFjWUfct 
#undef  myyCsm1QzAMbV9FeubYLY 
#undef mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ
#undef  mgKv64TnJJRtHXBTzACDO 
#undef  mKzklEw5IRgQmI3OSml1i 
#undef  mN6OdwmNUVjXUhxmeGf8J 
#undef  mM1pbAJE40pyDAsPbwwMd 
#undef  mnFcnzhSc68PBY18KNbo7 
#undef  mDpKPA1KOuuQehqrHJtsl 
#undef  mIivpa7B9YEutjvbp_HF0 
#undef  mampM4g9ObUpU_xCDEpgQ 
#undef mS_3jX9nIMiDQ3_4oIDIrZqK46910cN
#undef  mWlw_t5LZEaqBm9_nt0iD 
#undef  mf9Cutcm6ImnorHVFDeuP 
#undef  mK2i85pgNdUMagXTmWJ5e 
#undef  mB9YvSPWz0tX4EZ0kP3Cu 
#undef  mhCwMg4Ffjrj3yXjOd5fx 
#undef  mlgPh47K_7EW2ZXBliaid 
#undef  mbSdXRep8t2vTB1sedPyt 
#undef  mjKxwUdMxuMgV0dkJGEp3 
#undef m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG
#undef  mmAweGjgflL1M_L8xxbS5 
#undef  mOMfyQeUFCcsFk8Ad4BBL 
#undef  mQJ_ov46f8fAit991t8gf 
#undef  miUNNahIhqkHJ0O8mc7at 
#undef  mVt0bbujrHNetZKOtuKde 
#undef  mmombSefdt4OQYXhCimSX 
#undef  mc5fxBzrSgunvzSKuEhwj 
#undef  mP8SrQcdiKeneTPj3ncar 
#undef  mkcMJUPYZgJAtwAWvs7Py 
#undef  ms5n8S6sLK4BKl5mCpbvH 
#undef  mLY18NKQFABTYUMkJm2SH 
#undef  muHYdZsjdFUoHAvBLvUVe 
#undef  mdinLDLM5O6qM2Iua48QL 
#undef  mZZ26QMzJc_5LIwefugPz 
#undef  mKo7Dekr2hkVH6Q2yj4v1 
#undef  mJSr1xT3rjrluqpa47g9Y 
#undef  mNqyOa6KdCv6zSr90UyAl 
#undef  mRW5kEFZa1NALZX28ZIon 
#undef  mF6LKJaZ8E_RFGqer3CEP 
#undef  mnXffFztl_Q3mHTMfL6Um 
#undef  mOnkdM0WujiddAefb4ESe 
#undef  mj5ixplkQLbcxKyYSRwxy 
#undef  mqQ3hcKeFeE4oJoHQSvf1 
#undef  mtd2U4uO5qMUqFSFlA3o0 
#undef  mtJxJU59f1eEFMiVPqSOd 
#undef  m_18997e8JQQFco5N9dHK 
#undef  mpxo8NMrHzok0zxZzo_cs 
#undef  mCuRJqKBRH_BrOMv7hXsF 
#undef  mmxmIMH7MAnuDJTXb23zQ 
#undef  mzjX0iRvCYGhZO2ITjcdt 
#undef  mJFezRZdF9Yll4E2ofN_f 
#undef  muxvLfj1z4AXZePUs5M4p 
#undef  mXUy3srwASbKuClu_vKTe 
#undef  mpEgibffzQXRDDGDQaUGA 
#undef  mrmdYuYTVzarkSFRATlha 
#undef  moPdQYooVsM15VAazKOEZ 
#undef  mhdOIl9dw0JQwDi0Ir2lO 
#undef  mSokNq3Jcm0CZDZY30Wno 
#undef  mVtH44jy_Eg0rghDYlMs4 
#undef  muSdZAgzhs5ln2vx_pg0w 
#undef  mrFprXhaW2MYwjyrlnlK2 
#undef  mgx_Aav0AEvullRtJttF0 
#undef  mQxZ9x1jAWoPY956fLMm7 
#undef  mZJOXxx7hbtRSTyy_HjGF 
#undef mpSLr9wROWvnZD1iCdovU0nYZFqKrnP
#undef  mMmBs0INu0k5X_FJkD5rr 
#undef  mOj2NZtBCgsNkYM982aS9 
#undef mxYncMrtXC6SeU1ddoChMqio0cqvklg
#undef  mXqVbRWnIXdf8unNXdsWn 
#undef  mEyjl8Y5Ko8WIO7rc8xjy 
#undef  mJXr69rhzcs2uHnnZc46T 
#undef  mAw0cMDkuY7VauTjR_gzc 
#undef  mz5lesIyi7JO6NQ42HCAr 
#undef  md2kXkeBxboEMBU2AV_5s 
#undef  mJ7GYjgHHCxtWCUXtHWVv 
#undef  mj8J6mUMVIiLNPC32AT2p 
#undef  mhOJP7GTKtZVREYuK8qsM 
#undef  mk0UDRIyOODBYPpNMMtOc 
#undef mqiIIc9pe1gpl3JSjqxBusmApaww4OM
#undef  m_WYn2n0wuk6UJ5kGIQak 
#undef  mVx2i0xDty6d7wAQ1AEDX 
#undef  mBS2ISVIhJublZPH29E0a 
#undef  ml7ROdNRafN054xhICX2X 
#undef  mH81SrGjFrRCXYSiJnoqa 
#undef  mqed_EcKcpv3tmsK0VwPq 
#undef  milR3XNnU1JDeN9uyM761 
#undef  mfKuHXwnr7XBA7NCf6pZq 
#undef  mB9eufg8BrcMQwsjy5WF0 
#undef mhW30YVZKc88sPKpBl_boHwzPPBIBGD
#undef  mCi4vAHb8oVMCZWxLATzD 
#undef  mU9sM0kyDLaDRi1mqQV4j 
#undef  mjn2WKwnpSiVmCWLEjQ5k 
#undef  m_1J0sGT1PB0ZSBudKlNA 
#undef  mMa_6lMFLoFYPgu9fRTI1 
#undef  mUp9jH_JJkeWGYg6SPvxb 
#undef mUALbycuQX8qqtu56NWoaUnZ2ADJjRh
#undef  mM5M87hxO0F1jykbMUggh 
#undef  mAtxCmnHMZ_ygb82QGCWO 
#undef  mC8ZaJ0GcET6ctFrqYRmP 
#undef  mrVo1fO7oMN0F0LcGmw_f 
#undef  mzz466vkULaDwnx05qd82 
#undef  msRO7__IOXu6L3zcMPeT2 
#undef  mD_3HKaGheLWoKIFvCH3L 
#undef  mtWQnh_W_PD5ev5w8AW0s 
#undef  mbtyTfpzqoLMszlSfGVhS 
#undef  mzrwOkaVNQ12qikoacOtS 
#undef  mAFNVBR8qnAMnJsIDO9nA 
#undef  mWDsKNjyxVW4J9q1AwGWq 
#undef  mIUF5GxYrg8aIVgkWNnBb 
#undef  mYB0YoRP6itbUawfbPusv 
#undef mOf9_wb83eei1ZBzVuOZTTfg41x_5sS
#undef mBojQqzqPJA0Zhe79JerpswyOrVuQps
#undef  mcupMgy1yB7mIget2eDow 
#undef  mKlU2t7ATzFQCzp03OHXo 
#undef  mDk1S9vejmO23nQ14m4JM 
#undef  mPRf5NpGuq6ZoBfArKDF3 
#undef  mYoowvicaALAqcfmGrsSD 
#undef  mMz0if0V8wBaqTUtqkPem 
#undef  mZnWOcG4IZ_M_1uOVr1vf 
#undef  mIpgSd4v5yWrnWkLSTFr4 
#undef  meadcZiQDrRuC0Tmbyyiu 
#undef  myLMH58GbSZSEKIADq_9T 
#undef  mypwvI9nBVxZQoSRivBsz 
#undef  mslakBBg5XJ6k0ROZMh_4 
#undef  mcBOeh7kvkLdVFdML_waY 
#undef  mnW6ZFYawWAWMCKpMfvE2 
#undef  mIyJPGeEvtQe8SOesQr7v 
#undef mwfChnZD0dWqo90jpqN70JK8Mo9I5VD
#undef mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj
#undef  ms9M5EwDiWgRYZIdzQWmp 
#undef  mjVu1VPVfft6_jPiz3Ec6 
#undef  mHW6nVkC5JlKM0bwQFsqA 
#undef  mkLql5eCbkw_VBW_BfUxp 
#undef  mQs7VG4JKWIimbZO9fFo8 
#undef  mJjl5sA9ehjIzAWdStIFU 
#undef  mdcIh6lew75dFEC4p3Q1h 
#undef  mknpWNnES4R_63cdbcdXV 
#undef  mUvbKcsz8i4H1kuQe8W_B 
#undef  mmDRiATwYsXZG1Jku9FPg 
#undef mEvpZvX3Pr_xoJcbIft169GSIJ4Uo3B
#undef  mkYawy3Jp4pgcXnw3fgN3 
#undef  muPhaubkj3SDNA5Wasshg 
#undef  mwPsLKrAzq4RklpopaEAw 
#undef  msgGhTpJsjlaQFml28rg7 
#undef  mWjTRicytZl2oVzkUTdvq 
#undef mgeGMjcucDsavdvBBcXoD75__Tb01sm
#undef  maNkjFQf7KL90cn5vbMa3 
#undef  mR3g6IaCAGZgxHIA8qCxW 
#endif

#ifdef _6580636470966009790
#undef  mjYBDnziuBBoR8htpZ054 
#undef  mdHtGBEDt4G4jvY6KOGzW 
#undef  mi_O6EJNt60DZGoXx1wHw 
#undef  m_SGFgZqHNGYic2jE2PZs 
#undef  ms8ohDxwnrSLtbOpBsiBn 
#undef  mWlw_t5LZEaqBm9_nt0iD 
#undef  mkLql5eCbkw_VBW_BfUxp 
#undef  mslakBBg5XJ6k0ROZMh_4 
#undef  mPRf5NpGuq6ZoBfArKDF3 
#undef  mUCUowYS5Zgxsf8jGgVp5 
#undef  mXUy3srwASbKuClu_vKTe 
#undef  mMbu3hdPmJMPrM_d1Cr0s 
#undef  mBzApfw9R5DW809yw9n5C 
#undef  msKaUi822wPxuzjUtd8Pa 
#undef  mzb0bJuSjJhlivJIz_rfW 
#undef  mUD4rGlgxQjbo0JVuke3q 
#undef  mOxbZipdUMUjuuBjccJiL 
#undef  mL7RQgXYMf5RjI3gzAmom 
#undef  mrdmCc9Gc3ukvwGoxQggu 
#undef mZFd_wzPmPRc35lEvSHE0CiTnEdVk2C
#undef  miNE679CW5B3xxrVDrvN9 
#undef  mBliNpjYGnOcf7SuCUXfw 
#undef  mpwGO7r6CJmc7pyzxPS0W 
#undef  mPBi7A48_1c_87b1U_Eoa 
#undef  mp9HJBE0E90Wcmb9f9ar3 
#undef  mVzsLDeS8SOv0E6YGFv8j 
#undef  meLXGbNjy3PRj2YFo8vov 
#undef  mJXr69rhzcs2uHnnZc46T 
#undef  ma9kV7iftDKaJMwPMmic6 
#undef  mQFDOegAOguDVHU3KoIJH 
#undef  mvVwZIT9LYdLjcMYjL6fQ 
#undef  m_TFPk3Phi8ZX86zM0rxV 
#undef  mnfIFXb2Z55p5DNBveqbx 
#undef  mTzlvPwOAcxvFnaU7tzec 
#undef  mG0XPjV2nZH5rw34_jjn_ 
#undef mC6homJJPESbePyDgOny1YcxCcn5QHR
#undef mpSLr9wROWvnZD1iCdovU0nYZFqKrnP
#undef  mDzGqUDtD5PGwMNxtuRIR 
#undef  mvt_8yQ6OWmKTfvk3dzq1 
#undef  mdwjkxbPv9lRst1GU7ntQ 
#undef mwjNmdVvS8bIC25sTrclB9dCibfRKDx
#undef  meHoni3WXkzVpE4d0kmI1 
#undef mv_JVFkODVRLTSkXzNmRAFyoFoAzy3J
#undef  mnFcnzhSc68PBY18KNbo7 
#undef mFR2AYMAMdlvPHNClNuuI2P2lzdelpy
#undef  mBdKtki5i5z_rqVGrRUtu 
#undef  mAtxCmnHMZ_ygb82QGCWO 
#undef  mPT1fk20Pr1eQ0YB5sxd6 
#undef  mLwLUP6KZ9PRisEeZakem 
#undef mDNXBsrSCyjZ8H5TqHKE8ydryKS6POH
#undef  mrzBsv3kMMBOnuA1vQYB0 
#undef  mo9cHp1NOYwzHudST5ct_ 
#undef mdcfBxuY9ca1Je2VwDSgUMxqgXDgPST
#undef  msKlRUq0xcK7JxZyasKkH 
#undef mHLQwCfYwfpxwbMKqQaK9wJFD8dMYzZ
#undef  muPhaubkj3SDNA5Wasshg 
#undef  mWnjTNUFoM25IlGBbi5Sh 
#undef  mqItj5mkpzJ38jgqpOkYj 
#undef  mVC71FDKngiAI0dFcsSY9 
#undef  msKuhdHIRNOlAQpbiW9KU 
#undef  mNqyOa6KdCv6zSr90UyAl 
#undef  ma2vK_VeaV2yOivBMAaS1 
#undef  mu79Z1nsoA2cM_nPkf06A 
#undef  mZMrdS758Yf9PKctFfaYZ 
#undef  mMJxQ0EBp3m14gB2r3xIc 
#undef  muHYdZsjdFUoHAvBLvUVe 
#undef  mY1aayBcuQSa43sZHmeQS 
#undef  mgKv64TnJJRtHXBTzACDO 
#undef mJsIWgoWyKz7gM1eewOxPdqTEsPl2JS
#undef  mAnJimC6YgR8qvnQB7ZMP 
#undef  mBeVnxVGsv42qh8iauLFG 
#undef  mSa9VlOXwWy20y1aecFml 
#undef  maputXWpuSswTuxiye55G 
#undef  mMmBs0INu0k5X_FJkD5rr 
#undef  mgIg8CedmHvBkJNohUblZ 
#undef  miHgaIOIXnP9MKa_Ynuzb 
#undef  mcvDrOWJhA_Jj9rADu5RY 
#undef  mcq33jn33ngPvU8ExIgnf 
#undef  mIOO9HkLingUB807zdqfm 
#undef  mK5osLCJErLUjdJVDKOO6 
#undef  mSG4W65NNIcornxP1sDch 
#undef  mJri6232WYf57v7WHLLtJ 
#undef mYZySka2r5zYAEO1eOB6HyYTMPAnfWX
#undef  mP8SrQcdiKeneTPj3ncar 
#undef  mncmpqNhIup2FdHbcG_I7 
#undef  ms9M5EwDiWgRYZIdzQWmp 
#undef  mzJn2Y5MSTbpYun9rdOSq 
#undef  mAFNVBR8qnAMnJsIDO9nA 
#undef  mHW6nVkC5JlKM0bwQFsqA 
#undef  mEn6ezpXymeCgJNVz3lrW 
#undef msVNRLVmFBztOVESz5AQJDfnqtqgN6L
#undef  mtb4cFqSBOv6HgXSTvrTj 
#undef  mM2DCYuIrYsxI9lPkFjQS 
#undef  mdcqBUCL5eOKU9PVtHvug 
#undef mxYncMrtXC6SeU1ddoChMqio0cqvklg
#undef  myyCsm1QzAMbV9FeubYLY 
#undef mX1lxVUYXutVkZTja3vCylribxHJyyr
#undef  mz4tZy0GWrUESNULCSRoF 
#undef  mhdOIl9dw0JQwDi0Ir2lO 
#undef  mTva02hxveOfDWDk4eVeg 
#undef  mnaoSvkmA7uG3CzIf2JLX 
#undef  mIDgb6uGhToe8NBW6xKso 
#undef  mmFrxzQTWygQiSMiAd1ou 
#undef mBojQqzqPJA0Zhe79JerpswyOrVuQps
#undef  moPdQYooVsM15VAazKOEZ 
#undef  mySr_PmNqnsLYHdYvB_ZN 
#undef  mc0rMkLpNFfuLuqr7z3oz 
#undef  miK0cKKXIJZC11uUUzrLR 
#undef  mBWTdhPS4d6WQTxWw9qTj 
#undef  myLMH58GbSZSEKIADq_9T 
#undef  mgga0WnnRFtBflQKtpLuK 
#undef  mk7ILvvJtbDBhzuKjuFuZ 
#undef  mgheRgcIL9OpKtLQ4r_15 
#undef  mJmF0v_b2bVzIAj7lN4hw 
#undef  mJ7GYjgHHCxtWCUXtHWVv 
#undef  mmcgp6Gf_wMHhMWAP3nYZ 
#undef  m_1J0sGT1PB0ZSBudKlNA 
#undef  mSkMsyd_G4SVpaKFDM3Uc 
#undef  mCi4vAHb8oVMCZWxLATzD 
#undef  mkcMJUPYZgJAtwAWvs7Py 
#undef  mRte7PZJP6iITCO2uVu0v 
#undef  mhCwMg4Ffjrj3yXjOd5fx 
#undef  mf9Cutcm6ImnorHVFDeuP 
#undef msTibML7U5XAa62kfYMyXMMaQgK7wvx
#undef mwK0gGoxdO620JNMAf8LcWrLXkSVHqY
#undef  mdeSRuh1fJRPfCJYIGL3K 
#undef  mmwMxLCLCS3PUrkR0S4GT 
#undef  mO3uJapBz8hfvZuLXzM53 
#undef  m_QEZZ3iahWFpeO4whzWo 
#undef  mtrAzdiCeLhU7rVrgKDnJ 
#undef  mcLleLW3WGZ6MsFjWUfct 
#undef  mvtZWYnFIFlTMBNRpc3mM 
#undef  mtPVppy1yz0JrXtPdjMoW 
#undef  mgx_Aav0AEvullRtJttF0 
#undef mqiIIc9pe1gpl3JSjqxBusmApaww4OM
#undef  mqVF9yhdjkvJZAJPGWq3E 
#undef  mLY18NKQFABTYUMkJm2SH 
#undef  mpEgibffzQXRDDGDQaUGA 
#undef  mQxZ9x1jAWoPY956fLMm7 
#undef  muIKgdX84KPh7NwHu9wOb 
#undef mIjc5w7s_Et8N6PxoZDjKMd0Bwsssjk
#undef mAAF1hNrBlLEg80wAcv2c_FQ8jbfnjr
#undef mWC1nvfQRFJLqJcGHQd_DZVW3mGXmA3
#undef  mpoZNJTEPtCn_II0lswxG 
#undef  mb0Jed_XHNWdzUez3EMOb 
#undef  ms2dtz7ci8fKKwi4grih1 
#undef mUALbycuQX8qqtu56NWoaUnZ2ADJjRh
#undef  mJFezRZdF9Yll4E2ofN_f 
#undef  mKOkOykCmuX5Cu4t9gb85 
#undef  mOj2NZtBCgsNkYM982aS9 
#undef  mEwcSf6xJjokt5SShXKxS 
#undef  mWDsKNjyxVW4J9q1AwGWq 
#undef  mkDBTxQUKyKFjRyQY44KV 
#undef  mmDRiATwYsXZG1Jku9FPg 
#undef  mtJxJU59f1eEFMiVPqSOd 
#undef  mUvbKcsz8i4H1kuQe8W_B 
#undef  mFr9xKf_e_bmCOLt2lDD4 
#undef  mjwkyWIKCg9v5IEoO1tb1 
#undef  mGeAkoUhfYDMrrSVlPr1O 
#undef  mcnZttRQtHTT1zEcTrcXq 
#undef  mB9eufg8BrcMQwsjy5WF0 
#undef  mF6LKJaZ8E_RFGqer3CEP 
#undef  mrzgvRTlrhSOpRG6AjzDZ 
#undef  mdcIh6lew75dFEC4p3Q1h 
#undef  mo9UqUd0NMYxMbXiBpNmp 
#undef  mHp07MIs1jIqbiHORNZtD 
#undef  mBS2ISVIhJublZPH29E0a 
#undef  mboS9FA2Q220SPFSMGHI8 
#undef  mY5NXKCzp4rf6Ovwtrdxq 
#undef  mYnZwY1qztvF6jEJBoGi_ 
#undef  muxvLfj1z4AXZePUs5M4p 
#undef  mWjTRicytZl2oVzkUTdvq 
#undef  mfvMoVhY8cjuWRUJI73Pl 
#undef  mKo7Dekr2hkVH6Q2yj4v1 
#undef mcUjff6jaamQlwbiN5lMFGZa5CWNEQt
#undef  mRENlzQNyEPIksF6cQHQj 
#undef  mcBOeh7kvkLdVFdML_waY 
#undef  mWNZjhCXwY0h77nbnnQun 
#undef mQk_FiTqfT2quOMiM0cIKgE508p48JO
#undef  mQJ_ov46f8fAit991t8gf 
#undef  mXggdfMCbAbSH20gXjoXX 
#undef mC2xaBE9kD4m2EfxxN85e2W5D8psu6d
#undef mCnRkQx6e9t50ErWQAwE0q3YKghcooj
#undef  mhp6bWPRQLSMINJFWgnoY 
#undef  musqt3SUnZXONhXx36QTM 
#undef  may4T302OZ7loQtO8zrNp 
#undef  mnXffFztl_Q3mHTMfL6Um 
#undef  mTijFbkuqZobez4o86GTR 
#undef  mMz0if0V8wBaqTUtqkPem 
#undef mTwuuBw4FVjERX9Kj4nHaPm6uu60qfG
#undef  mjhYvAnHCo7RqHTG4kGs8 
#undef  mYYc77i0htGEQktG2Neo1 
#undef  mc64seL8_QSxuYhWboswo 
#undef mwfChnZD0dWqo90jpqN70JK8Mo9I5VD
#undef  mRW5kEFZa1NALZX28ZIon 
#undef  mNDIxtoehMB1oIpVV3LKb 
#undef  mK2i85pgNdUMagXTmWJ5e 
#undef  mX0mE9NJLZdso_vDht0x6 
#undef  mNrsNMyOlNPO0p0HXQMMP 
#undef  mf45G5P768Ut3IC0WfAVV 
#undef mmAL_ct_wC7VA_KqJlBIFYgV6jc5z3G
#undef  mKzklEw5IRgQmI3OSml1i 
#undef  mpxNV0vBtyYJsCSJulyLm 
#undef mXFkM4J3s4f82M8sIpw0dlpB1pIHCoj
#undef  mhsPoKPzVdLpxSkCW6gM8 
#undef  mkATTEISGOYokIGC8F9la 
#undef  mjVu1VPVfft6_jPiz3Ec6 
#undef  mpaSqCpDpGH0eULjahGpg 
#undef  ms5n8S6sLK4BKl5mCpbvH 
#undef  mJE0OEa9lyhoBhR5JwHj4 
#undef  mdE1fJK3aKa1btI7OCyNv 
#undef  mC8ZaJ0GcET6ctFrqYRmP 
#undef  mP769HJIua8m0mI4ktrOP 
#undef  md_M7GPITQtDS4BfzU9d3 
#undef mBLRiQHoNzLxRWkGYEfWiYCkPDY_6df
#undef  mSokNq3Jcm0CZDZY30Wno 
#undef  mVt0bbujrHNetZKOtuKde 
#undef  mmLMfZuLLitP3PNsKn3U4 
#undef  micFIwqBc9QQUuQXqGKWC 
#undef mMTPZX5XrdbPaKZELXXWh6Yq_et2CdC
#undef  mIivzJUcx177gxdHt1Qrn 
#undef  mw3w4itcdSwk4YnPuBarj 
#undef ma5pnAoZZ1hw38rbzLH0SYNWacPxCZI
#undef mhW30YVZKc88sPKpBl_boHwzPPBIBGD
#undef  mB8iHIm9FOE1v4JRokz6E 
#undef  mM5M87hxO0F1jykbMUggh 
#undef mbMIBvXxQ4fdNXtBFULCa3sGjseDD_9
#undef  mPwyvAQ1wHSSp7FJdoENV 
#undef mcQnVmzr6nFLeJwKeC5qxiKBjnGtrUF
#undef mz5kaqHx8JTSTaRfRR3EBitftTo6TW6
#undef  mb6FIaRd_qia8_U10282s 
#undef  meEZS3fP7SPnS8S1IqEmR 
#undef  mIUF5GxYrg8aIVgkWNnBb 
#undef  mtE68lB7HxwArLgdxpcJw 
#undef  mw_8xZKbKGnlYQNGWwE_0 
#undef  mnvfRccV6sWLKag7QRnMi 
#undef  mG8z_mtZKC7ZO_NoWacf3 
#undef  mcupMgy1yB7mIget2eDow 
#undef  mmxmIMH7MAnuDJTXb23zQ 
#undef  m_mN_FCCplLb1O56UTVl3 
#undef  mPBqMiL37DrIolFnluMjB 
#undef  mKD4UGvYqSH2GIcVJ2xVN 
#undef  mtd2U4uO5qMUqFSFlA3o0 
#undef  mxODpvgncxHDxAXg0nTxi 
#undef  mM7P5mMaG1l7fxkX3FWCT 
#undef  mWw8FPQaCI3gn0wUVEyTI 
#undef  msn15RJjYb_SsaErIfRNo 
#undef  mDF2umNp7X6oYOD0Lwyy3 
#undef  mGfToHPBdGgajCf_jjGO8 
#undef  me3HErcslswtnJE5PyQ7h 
#undef  mqjvrjxD0U1jONB_TZFW5 
#undef mQHl_ec60ZnTta9Kjat5MnwCDywKP0S
#undef  mVx2i0xDty6d7wAQ1AEDX 
#undef  muJHokUqtf6fmO3Ky49f8 
#undef  mz5lesIyi7JO6NQ42HCAr 
#undef  mJjl5sA9ehjIzAWdStIFU 
#undef  mlkIT82897HlGwEOzq3R0 
#undef  mEamAz92Ayua5tQlUuQq6 
#undef mFvI1mt5pDPKVUSHYBtX_CkNEZIhE7I
#undef  mwPsLKrAzq4RklpopaEAw 
#undef mbJN2L3pYaj75B2vd0RZrC1ie3MEUEQ
#undef  mD1FtOnG5lJAS7VVmL6Ph 
#undef  m_2rFCzuQjnYmj1u2E3Hn 
#undef  mSfj74s5uEvCOzi1TqmTv 
#undef mi2cnitf6XjPI_AR9JqyRxdTxSVUD1m
#undef  mrmdYuYTVzarkSFRATlha 
#undef  mnTomnUfxbEgN2pcyh4IC 
#undef  mhK2Qbp1bwBdQQlO7M8sI 
#undef  miUNNahIhqkHJ0O8mc7at 
#undef  mRtNeoipHh1bU1f1bmWPX 
#undef  mhROwJUrnW6RV5u5uX1p4 
#undef mMcsTdeZl6dJT8lXT7C9j0AbQQMhSjw
#undef miuYLrMna9tTpfuHozSxZXljtr8IWGY
#undef  mwlsAHCjnxf1m2hGk7SPN 
#undef muUdW3fqjYEcWW8jBykcma1JP8mjRxV
#undef msNlLNhq5GN7XcbzwivI3OWPTWt9svc
#undef  mVtH44jy_Eg0rghDYlMs4 
#undef ma2JuVH9cwa2PZWXEX2RFlL97Fd56Uf
#undef  mAXRt0DC6duEWgvgkLnB3 
#undef  mLp87BNpaRa8bU3QE39AH 
#undef  mU9sM0kyDLaDRi1mqQV4j 
#undef  mpmCfg6OTFu9ueV1Jvoij 
#undef  mpxo8NMrHzok0zxZzo_cs 
#undef  mnW6ZFYawWAWMCKpMfvE2 
#undef  mc5fxBzrSgunvzSKuEhwj 
#undef  mjKxwUdMxuMgV0dkJGEp3 
#undef  mXqVbRWnIXdf8unNXdsWn 
#undef  mO2X7vyyKruryPTrlfgIx 
#undef  mM7GbDdkpt2DGNP5IRiPZ 
#undef muyLCpzNWkiG62Rh8y6QK2T12sisiZy
#undef  mIyJPGeEvtQe8SOesQr7v 
#undef  mdinLDLM5O6qM2Iua48QL 
#undef  mZnWOcG4IZ_M_1uOVr1vf 
#undef  mEfdpZW8Tgwkni5sEouU7 
#undef  mtnD8HN9EM8B5CF50YpX7 
#undef  mOxBLp1l2vKYX_rNUj7Fc 
#undef  mSq36Z11XRl1JXoARgKCB 
#undef mI4cYeHg7cwBYkfBvwQkmssxvPpHCRl
#undef  mYoowvicaALAqcfmGrsSD 
#undef  mZJOXxx7hbtRSTyy_HjGF 
#undef  mYg2fb_0h62GR73b_cpn9 
#undef  mnCvMc73RamSZ8lE5SaXG 
#undef  mUvejUG0VZ6oaFYLfv96Z 
#undef  mnxqg8Uow3e4hAyXi7IeZ 
#undef  mwhGtbRL66FztkRtZ0QI_ 
#undef  mJSr1xT3rjrluqpa47g9Y 
#undef  mqed_EcKcpv3tmsK0VwPq 
#undef  maTpexuiU56_wx8NMsDqq 
#undef  mud4sr7JVgGG6yDxhsQoI 
#undef  mXx9mzEZ3WuXitLsCMbS3 
#undef  mmwuJQME0484L7jN0wNls 
#undef  mzuL30IhryR3NJMszS89h 
#undef  mpQACTL4b3pHMD127IZSN 
#undef mZKQBVu9NPSaSKDvETZgYMQILvBIUsb
#undef  muzBQurHIfaSICJbRjaWh 
#undef  mr4zczxVHQA3dSD8whfSj 
#undef  mI4sf76lr2ENejiQIjqzJ 
#undef  mI1ri11eHWS0GoQQjfv_u 
#undef  mJSJkb3ccP0_n2Wxy8nWh 
#undef  mxjH4eEwkhiNcmUP6GEXq 
#undef  mM1pbAJE40pyDAsPbwwMd 
#undef  mfQdV5_coeVOh0_XAr72d 
#undef  mN6OdwmNUVjXUhxmeGf8J 
#undef  moj9aYgB8JD1AgO4ICT3d 
#undef  mTIqUWMZAhhidB3B7gCmt 
#undef  mW37fLe5jzVXLk4yUjj24 
#undef  migdvOq5L79sWQtwLyhs2 
#undef  meKZnYzO2FX6PDdko0XJI 
#undef  m_18997e8JQQFco5N9dHK 
#undef mdYtz2htQZh8P7qHU8sOccXiq0Jsbpd
#undef  mUAT7RqwcWJKHzYQUCA0y 
#undef  mypwvI9nBVxZQoSRivBsz 
#undef myMbdRujQRRGxZa_esh6OHxPU22Olyw
#undef  m_2Wdq9qctokcWGW9B7eI 
#undef mj0SmRpcdB2TRl5kdNdBQnXpbI2PaTI
#undef  mZWm2nGx_Hxwoni8yg8Qj 
#undef  mAw0cMDkuY7VauTjR_gzc 
#undef mXNcG_XejCUhS0WdQbrzCqFiifRHEiN
#undef  mzjX0iRvCYGhZO2ITjcdt 
#undef  m_5q1OVTkJJKfB_ISHjog 
#undef  mCw9yl5OPmGbIXjCTLMgT 
#undef  mnfv75cfRX5nwn_P3W2SZ 
#undef  mkvvczg0if8KqjNRfebjz 
#undef mhSjwWsm2mahiTUSTjt6nFB03As_xU3
#undef  mOMfyQeUFCcsFk8Ad4BBL 
#undef  mNUuCaMUS8zqfbXCimtgj 
#undef  mnPfMWb2f1m2VXrwtLuBn 
#undef  mL3fOciX21BVRqsrLjDqQ 
#undef  mzrwOkaVNQ12qikoacOtS 
#undef  m_WYn2n0wuk6UJ5kGIQak 
#undef  mLPHimc4fzfm6eoFIZbqS 
#undef  mIkusqIJdd_o34vSBgzWv 
#undef  mJYXLtUQ27au4beQhf0PM 
#undef mgg_rkv_YJplcQCUd_HA7fw3Qmhkmhw
#undef  mVM77PvnlvRK1mLTKRKei 
#undef  mi4UDYlJVme2p8vz8XCwn 
#undef mQDl1AFw1LpP3Fl6VsKxWq1Cu_KGgPR
#undef  mlNC5dwEflF9t_I2G7kwV 
#undef  mdV71Y1rT0MkSZQco4pkM 
#undef mGXDvm2ZdrqugaoZ1YccvqzabYqkG2k
#undef  mJKRIv5t9rcExx2BgWlkY 
#undef  mR9ASd2W_8LE4mOR7w3js 
#undef  mK4rObJyYX6HJZfVJKntT 
#undef  msAueAn4jz6msdaMAOFvD 
#undef  mBEcaTi01GHGicTdCFjoM 
#undef  md2kXkeBxboEMBU2AV_5s 
#undef  mKHRSL6QRz79M7iwb3xFq 
#undef  mTUb9WYxxxWOpnX_tuW8L 
#undef  mm4diUXyy908ilcG8VsiM 
#undef mEvpZvX3Pr_xoJcbIft169GSIJ4Uo3B
#undef  mfoiPdsHJ12pw0fAmu2LO 
#undef  mmombSefdt4OQYXhCimSX 
#undef  mNTqpwjT561WC_1cfoCEr 
#undef  mpNsMq_Jsh9rRugWA0zzy 
#undef  mPkRdGYYZOKBHLvkzvyRk 
#undef  mvvQZKXqZ3gS6vWzM21uf 
#undef mkQAXn4tEgxUMacHRt_8uGD2gBZRF5t
#undef  meHoDa0aUmPvFXvZMmfuA 
#undef mkMSqyZx8knDVKKeQRRAPOPQ1OycFsk
#undef  mjSoZeXICFupmRJnwixfY 
#undef  mARbu_1sRtfpk1suZIE5h 
#undef  ml7ROdNRafN054xhICX2X 
#undef  mR3g6IaCAGZgxHIA8qCxW 
#undef  mIpgSd4v5yWrnWkLSTFr4 
#undef  mvVntD47RvCRRdFhEAzH2 
#undef  mpdkR8_dmu0PH3OVmq923 
#undef  milR3XNnU1JDeN9uyM761 
#undef  mxQppl_B1tP4_S2CE3A7S 
#undef  mnr9KiD3xP6jhiP0klzs8 
#undef  mqoG7Riz1FpYN6K49t8kk 
#undef  mBf0JMOxQ3sCg9N87xsxR 
#undef  mL9fuPZuqOi9x2FhIqvy1 
#undef  mM2m_2Donhjltd0Debl64 
#undef  mEyjl8Y5Ko8WIO7rc8xjy 
#undef  mcVfnknnHgJjobEYbCQZb 
#undef  mJZTaq8b9U6IHm6Fo0zfj 
#undef  mVMtoBTx7Atu07C1zpSOZ 
#undef  mtPeORXsOWhCCSWRotXA_ 
#undef  mjtgzOH8_fFDjnCUIvpJR 
#undef  ml8k79uncra_1jDk9y35b 
#undef  mB9JHSBU95BEjegV45XDO 
#undef  mHiYGul5svZyW_rLyOjTu 
#undef  mrFprXhaW2MYwjyrlnlK2 
#undef  mgjLIBeE0wg2QrojbWXXE 
#undef  mFIC1mtAi41jxmBTb3wHn 
#undef  mT1Yuv8tLPubZaOzlRCjX 
#undef mahSq6rrq2neTeBW0KH49DPaFsniYhL
#undef  mH81SrGjFrRCXYSiJnoqa 
#undef  mmFbqqNxE6b68zHtj1L1b 
#undef  mPQkyiUN1BvHTMgAxqODe 
#undef  mjlW6Gr9BKXBEqm9b7AyH 
#undef  mbtyTfpzqoLMszlSfGVhS 
#undef mUbpV4lfDef5exLGNpWAnT12YiDu_kX
#undef  mP4rxLIewwXLg47glswZS 
#undef mBsNR7a9eCj4e2paObbgMzu5XwLAjnm
#undef mIE0w_d0lIS7gkIc0JjTYwBjOAZ85XL
#undef  mtWQnh_W_PD5ev5w8AW0s 
#undef  m_YweHWYbkpdV40mXJspN 
#undef  motTJdCC_9geof6XxtOIX 
#undef  mQs7VG4JKWIimbZO9fFo8 
#undef  mwC9HboO7mY5my_bYOgOp 
#undef  mrWabZl6Yqxhh9lJh_vp9 
#undef  mk0UDRIyOODBYPpNMMtOc 
#undef  mzZIX41vw1HHV8g5Zis4L 
#undef mgeGMjcucDsavdvBBcXoD75__Tb01sm
#undef  mkr0aLVnJz5CaZvioiLL7 
#undef  mfJjRpXi94twT9pqD5JVX 
#undef  mD5j4pDCOs2SM4dLbugLG 
#undef  mbd03FIo9GTdRlDtujpAU 
#undef  mf4r5S0Gz5iK0mQBxOgrA 
#undef  mkYawy3Jp4pgcXnw3fgN3 
#undef  mfKuHXwnr7XBA7NCf6pZq 
#undef  mfZqF0j4sUltUngd4Hj5Y 
#undef  mwE6oBl5ZQ79F6Ove8epW 
#undef  maNkjFQf7KL90cn5vbMa3 
#undef  msgGhTpJsjlaQFml28rg7 
#undef  mdNNjVkqM2InU1bCHGxmP 
#undef  mBx7lmwJEgh_boAo7hHD4 
#undef  mlgPh47K_7EW2ZXBliaid 
#undef  mzRXDilasYlw5CVJtdYdM 
#undef  mazMo2N6FXwsNwoWMaXmw 
#undef mwgU_GguJtAB5Bb35MdwyMTlNysOLJW
#undef  my9HJ8yK6DJjsZPdzWxZL 
#undef  mywDDUpEYndE3A45RHsoU 
#undef  mcusq_XAMIIwDvb7lMCrf 
#undef  mlxwRZWmFsIX03zy3tTy0 
#undef  mKi8kBZaMYwKlooGDcleR 
#undef  mRWp04iJpyRq8tILClaZJ 
#undef  mzHszbbCS_cUrYyWLxL9J 
#undef  mKwKqgpBT0nQRvDGpT5CT 
#undef mkgqYPwbi1srAPQNDI_PpWZgk3gH9Ct
#undef  mEy_pGq0H0Ns418E2TeZz 
#undef  mSNCcmKF29PRGlI8Tdwja 
#undef  mWrGjq0Squbg2ySQrv2yy 
#undef  mhOJP7GTKtZVREYuK8qsM 
#undef  mTvuqEbq8QyE7GGDRvvUi 
#undef  mniKBlIuV5usw0rljtOxS 
#undef  msDUdqGgg_34u9hXbBbP6 
#undef  mdA8CkxC2ABNB6wmuvTfw 
#undef mS3KOSwoqktmfbJXrTgh30aLzdZFDf5
#undef  mEl0x2A3ElD6IIGxgIMh1 
#undef  mZi7qi6srAkaKViRVPr2V 
#undef  mLS7Y36zZso1BwBUg8wDr 
#undef  mwmTl_1WKubaBtbkcxNw2 
#undef  mO54HUFE7XGVtlHtttmH3 
#undef  mMa_6lMFLoFYPgu9fRTI1 
#undef  maDHAuramjTITZ8BkVyc3 
#undef  mS3cOaukxo2FRb5RvHVc4 
#undef mipMN4mtnGA1X8ocw1VUzyTesbkEBOw
#undef  mueL4P4xnm8R1M0bl8Ojg 
#undef  mMepmESYShQYpe8JyLHO6 
#undef  msRO7__IOXu6L3zcMPeT2 
#undef  mhgnRFmDEM5LAURVG5y1L 
#undef  mZZ26QMzJc_5LIwefugPz 
#undef  mqzzPJxLsV4dnyMti4gfP 
#undef  mDpKPA1KOuuQehqrHJtsl 
#undef  mo5687q03mFTCWmTFL22s 
#undef  mKiDysFpzxUykXXw_WZfH 
#undef  mWNSsa0FomEI5wNcyNLqT 
#undef  mnZS4TInrvaTXnZxKixov 
#undef  mCW_zvfcw3_KvOK_XS8HP 
#undef  moxT8MWfNzFm3p7C1XLDk 
#undef  mcX71Wu1NrgiE1PjmF5oW 
#undef  miiVgeXn417nCjY5ebPhf 
#undef  mDk1S9vejmO23nQ14m4JM 
#undef  mW_kHdhknJnJHqJtLDQ1K 
#undef  mHc4_w2MgUHx4283kOjz9 
#undef  mSiHrrzr4Y0scm_4uqOCv 
#undef msKAlT0dx6w27y9yHjm3iwlc_YIajMN
#undef  mrI60jYuZ1dFPDfd24M0Q 
#undef  mZ4GZ4UmqxVyfyG8CPz5a 
#undef  mjn2WKwnpSiVmCWLEjQ5k 
#undef  mohUEWtGNSJiaUfYS_hHU 
#undef  mj2vTnvmJGQRTP74fz5th 
#undef  mfkiYufvbU5mF9mdgM8ig 
#undef  mxbbdZ8472z3S1r1q5ZWj 
#undef  mRzFXIQ0M4lxEiykp0tGE 
#undef  mdY97YGxqZoJZ4psVpCYa 
#undef  mmRqfJAp91BT5F8NaZMmM 
#undef  mBbED78xkAlNEldBsfZoY 
#undef  mtehHpUuknvUTAKK7BNgA 
#undef  mX2uK3ci5pcPqQSvs4amk 
#undef  mLq0l_9mYawwF56GLqBiO 
#undef  mUzQAwxDAK5N1NNCaNFl_ 
#undef  mnv3HCmWHbNAEwSFeikW_ 
#undef  mYpuIV2wVprROhZ0gZwqQ 
#undef  mB9YvSPWz0tX4EZ0kP3Cu 
#undef  mjE2XFXDR2hHCf8IsA1BO 
#undef mDEbKniJvTruRfyANln1hDcaOxjifIj
#undef  mtAlnZAB81NJEQfKELvkr 
#undef  mqefKqLpc5MfNVAgzWWfC 
#undef  mwUUBDVL49RrRRTgyVPVN 
#undef  mCEME69o7Es8kNPY_qo8L 
#undef  mHt2jDj4LBpP36tiW9beq 
#undef mcLZRXidREDnQsUILaskKBiM_OAG8ua
#undef  mGQgYgclze4X2bB4vpuzW 
#undef  mbldl9dwMrRmnA2YXgRup 
#undef  mbubCLceOr5QXaiOQQPP1 
#undef  mpqi2n0ljngTDl3zfRcZY 
#undef mZ50SiWxR46W1PrEhhcm6_ytqgOjxnH
#undef mXAbaapmUexXuxomQ2UOp3r69lu4JB1
#undef  mknpWNnES4R_63cdbcdXV 
#undef  mCuRJqKBRH_BrOMv7hXsF 
#undef  miJ4T9koNX5tdXmZ5uaAF 
#undef  mrZQSpiPc5lDdrE7lGVdv 
#undef  mzAWY6BVbyF5XGfs95ZTo 
#undef  meq9uMtFTWeqAgMuQsOtx 
#undef mkVYTFw6Vlh64vnWxeVSN58OvdxO7zz
#undef mJ6HDMRJxEkLjnW10cwL8DIg6XlfbUr
#undef  mj5ixplkQLbcxKyYSRwxy 
#undef  mi6HZqmh8GILM6LjanUt5 
#undef  m_Tae7Y9Y2VD1QQBLzq4Y 
#undef  mIivpa7B9YEutjvbp_HF0 
#undef  mOO4AmPyU12o_w01ECkUl 
#undef  muSdZAgzhs5ln2vx_pg0w 
#undef  mKv065jc1LeatUiqpqepg 
#undef  mF7PjcGzXBfuvYPxX4ENs 
#undef  mYhDj2gAIVF7iiyAIzfLc 
#undef  mqQ3hcKeFeE4oJoHQSvf1 
#undef  mnXWkAlgXzCuQoJEu5uiO 
#undef  mMj_9sE1weayB75v7BdK8 
#undef  mGHOYAWjopscrujOCjpSi 
#undef m_xN3cfw5kHiuUQhDuDqe2YDOeutmBG
#undef  mR5JEG117hlb3MtJMpeEA 
#undef  meadcZiQDrRuC0Tmbyyiu 
#undef  mampM4g9ObUpU_xCDEpgQ 
#undef  mSpGFgQwHX_r9ijW72OO0 
#undef  msWHPNAG9RJ8USwCYjIRg 
#undef mD8SrJPNcBYa2ZA8fnZd_4tt9M8h3dL
#undef  mlPYm0vEibuOv_LKABukZ 
#undef  mwoHtFc7XtGdE5RWuAZoG 
#undef  mJfHf6vHjeGZbDkm_IWNg 
#undef  mGdAJfTAuDccsggh4RYB5 
#undef  mOnkdM0WujiddAefb4ESe 
#undef  mUp9jH_JJkeWGYg6SPvxb 
#undef  mdoRwfAhRUkJByfoNRUvb 
#undef  md4VXnnHqGZYN9FfEwMCW 
#undef  mpfHVtwBeRCF4HzfR5aYa 
#undef  mtawfM3ndXCRasZXQxRrp 
#undef  mzz466vkULaDwnx05qd82 
#undef mj4gNTNt3bmCYzbhzWyqTuvT9P3fS9s
#undef  mDTlqiHhmW7Np9mQzo1tz 
#undef mfaBCDA_1mB_o1gczVteCCzLS9jytzz
#undef msecMYaXfF46rGGcWJxuScGlv8bYIpo
#undef  me_oz2FFDkcB79njugEzc 
#undef  mo6RNiDqZJd5bPrKTOqBN 
#undef  mnaeVhufQTwT_lV4TnsPF 
#undef  mZAlRw_vXw7OrhwXXa1s2 
#undef  mmAweGjgflL1M_L8xxbS5 
#undef  mj8J6mUMVIiLNPC32AT2p 
#undef  mfPiMJHfWML2WymRvotni 
#undef  mvxcxvBinAJ8yONOAxeJ3 
#undef mi0l_sHwUblCkb4iaLokRozuEWNdBw6
#undef  mXPig4KjJlLryx1k7a1qv 
#undef  mZvFBh86Am0OfcHWSxajt 
#undef  mKlU2t7ATzFQCzp03OHXo 
#undef  mBY9q0vKK0__eH5VQs9_L 
#undef  mrVo1fO7oMN0F0LcGmw_f 
#undef  mRkPOYbSt70qZdeFG7KTU 
#undef mUsuCEIFvRP_D44KPaQY47o4ispy8Vj
#undef  mKEA1BZI3NTi8QvqudEdc 
#undef maFw6BG67rqfttMYNKgoNemSsvLkQYa
#undef  mGQ4ZN1hA5s9kbimw7Qwy 
#undef  miU1_742S5SYXnR5Jx89T 
#undef  mjAnZdEfD7dHR86j3d92F 
#undef mOf9_wb83eei1ZBzVuOZTTfg41x_5sS
#undef mNRgx_n6AYQCSB5qW3w3m1_KYB5I5yI
#undef  my6ztJkSs2s9dWfJOJksF 
#undef  mVDeIkD6a7uU0LqFHLuPG 
#undef  mS5WCLZvcR3iydjHqSMii 
#undef  mS6JTMBdIbEJgKM_vQoSK 
#undef  m_BrEaPHfim2E9yF6_ZvY 
#undef monM9oNPqUFsPMMVWOpTatnkGAmgDe9
#undef  mQ3MpK6vlWIM1vTRpOqFk 
#undef mDe6Xdhfu94h0bVchSL24UZegztDHht
#undef  mhen8iRk76Q4ezN_ZTavu 
#undef mEb0vgWbp62WJkkmtdPujPWI8EMqsYH
#undef  mEnhnBFQ3mB4diArixuti 
#undef  mvvmSM3BA2TJMl_6Z9ScU 
#undef  md4LgblW399NKaEPBAY3T 
#undef mkzazD7jHZVgFFhDw4yAI2XVbfGWV4U
#undef  mRHVbf6L_uqgqJB68GawV 
#undef  msUrKsbZb01INfsQYkuex 
#undef  mPBz2W83ARDLALxh_6rJK 
#undef  mDPHjdm2_QWPyhebFvYkD 
#undef mc8ipMXPIMdxjmKKG4E6NKlqXdYMncM
#undef  myuvjPnvzcBE3NfHkRLiX 
#undef  mYB0YoRP6itbUawfbPusv 
#undef  mMvWJbWSLKEHq4F0uh_XL 
#undef  mnpE_s7DSpkcZ5cnGnc16 
#undef  mEqTIrKKpbyOgBfvxq5Uo 
#undef  mBndUu3vn0UYS7kuL9bT2 
#undef  mD_3HKaGheLWoKIFvCH3L 
#undef  mrtb_bhYbXTw3XOs4vV1F 
#undef mHN4QkSpFuhZZROE3e75ST2ernStapx
#undef  mobX070S3wO6zxczaIZzQ 
#undef mx4CWeitM5Hu_IGDB8OfADm3WvgXcV4
#undef  mjQJF2BhvHcfP6fiRsDi0 
#undef mQsl9uLsiN5rbnaTCC5RvHSqd1LVP7E
#undef  mxK3g5IVylkgINFWSbxF8 
#undef  mLEPndrD0EDs3kVH87Dc9 
#undef mYV98481WEquqd1AECvpqWYdnflE9jF
#undef mS_3jX9nIMiDQ3_4oIDIrZqK46910cN
#undef m_iMEsCNnjEITB27sIXurIsGPpif5XE
#undef  mbSdXRep8t2vTB1sedPyt 
#undef  mcmEFUHvzwZHvsOYCgnyC 
#undef mZfa6hQ3HuMhd3Y2jm07Yo8aDwvsiTR
#undef mO0FjLQgixFPExZXiYeXr8hk69NoWuX
#undef  mxRngYN6opotzgq0i2yF0 
#undef ma8foCOgNMskkXnP7fzWdE7PnvWtDfR
#endif
